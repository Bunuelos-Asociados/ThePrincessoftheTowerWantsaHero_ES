
init 1000 python:
    renpy.game.preferences.language = "Spanish"
    
