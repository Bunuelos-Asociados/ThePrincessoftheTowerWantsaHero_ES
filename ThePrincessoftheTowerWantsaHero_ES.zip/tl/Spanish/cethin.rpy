# TODO: Translation updated at 2024-02-08 08:02

# game/cethin.rpy:7
translate Spanish cethinroute_b1d94948:

    # cethin "Thank you for taking care of that, Lumi..."
    cethin "Gracias por ocuparte de eso, Lumi…"

# game/cethin.rpy:9
translate Spanish cethinroute_792b1869:

    # lumihappy "Oh, it's nothing. You shall be the one doing most of the work anyway."
    lumihappy "Oh, no es nada. De todas formas, tú serás quien haga la mayor parte del trabajo."

# game/cethin.rpy:11
translate Spanish cethinroute_345cee89:

    # lumi "(And he did the decorating as well.)"
    lumi "(Y él también hizo la decoración.)"

# game/cethin.rpy:13
translate Spanish cethinroute_3b8d7366:

    # lumisad "(All I've done was sample the sweets Reo would serve for the festival...)"
    lumisad "(Todo lo que hice fue probar los dulces que Reo serviría en el festival...)"

# game/cethin.rpy:15
translate Spanish cethinroute_3048ee12:

    # lumisad "(Really, I'm the one who isn't doing much here.)"
    lumisad "(En serio, soy yo quien no está haciendo mucho aquí.)"

# game/cethin.rpy:17
translate Spanish cethinroute_e581b05d:

    # "She shook her head and forced herself to perk up."
    "Ella sacudió la cabeza y se obligó a animarse."

# game/cethin.rpy:19
translate Spanish cethinroute_9fa2668e:

    # lumihappy "So, just make sure to make a wonderful feast!"
    lumihappy "¡Así que asegúrate de preparar un banquete maravilloso!"

# game/cethin.rpy:23
translate Spanish cethinroute_deea9641:

    # cethin "I'll try."
    cethin "Lo intentaré."

# game/cethin.rpy:25
translate Spanish cethinroute_c9fdf43e:

    # lumisad "(I do wonder... is there anything I could do to express my gratitude to Cethin?)"
    lumisad "(Me pregunto... ¿habrá algo que pueda hacer para expresar mi gratitud a Cethin?)"

# game/cethin.rpy:27
translate Spanish cethinroute_4b8ae62d:

    # lumihappy "(Ever since he had arrived, I've started enjoying my stay here.)"
    lumihappy "(Desde que llegó, he comenzado a disfrutar mi estadía aquí.)"

# game/cethin.rpy:29
translate Spanish cethinroute_0f49bf6a:

    # lumisad "(I owe him much, yet he seems to think nothing of his efforts...)"
    lumisad "(Le debo mucho, y aun así parece no darle importancia a sus esfuerzos...)"

# game/cethin.rpy:31
translate Spanish cethinroute_e52e8d93:

    # lumided "(It's rather clear words alone wouldn't get through his head.)"
    lumided "(Está bastante claro que las palabras por sí solas no lograrían hacerlo entender.)"

# game/cethin.rpy:33
translate Spanish cethinroute_5e593d87:

    # lumisad "(Hm... what to do? Something that I could do within this room...)"
    lumisad "(Mmm... ¿qué haré? Algo que pueda hacer aquí en esta habitación...)"

# game/cethin.rpy:35
translate Spanish cethinroute_3878924d:

    # lumitalk "(Ah. I know!)"
    lumitalk "(Ah. ¡Ya sé!)"

# game/cethin.rpy:37
translate Spanish cethinroute_7fddaad3:

    # lumihappy "(I hope he'll like it.)"
    lumihappy "(Espero que le guste.)"

# game/cethin.rpy:43
translate Spanish cethinroute_4f24f22d:

    # "The butler and the bard busied themselves with the festival preparations."
    "El mayordomo y el bardo se ocuparon con los preparativos del festival."

# game/cethin.rpy:45
translate Spanish cethinroute_5eee38a1:

    # "Thanks to Reo, Cethin had been able to slip in and out much easier."
    "Gracias a Reo, Cethin había podido entrar y salir con mucha más facilidad."

# game/cethin.rpy:47
translate Spanish cethinroute_67ff1dab:

    # "The princess, who wasn't allowed to leave her room couldn't really do much..."
    "La princesa, a quien no se le permitía salir de su habitación, realmente no podía hacer mucho..."

# game/cethin.rpy:49
translate Spanish cethinroute_1228513e:

    # "But with the absence of the two, she managed to pre-occupy herself with a certain personal project."
    "Pero con la ausencia de los dos, logró ocupar su tiempo con cierto proyecto personal."

# game/cethin.rpy:51
translate Spanish cethinroute_e52a8f1e:

    # "And thus, a few days passed."
    "Y así, pasaron unos cuantos días."

# game/cethin.rpy:56
translate Spanish cethinroute_56ab895a:

    # "... The night of the festival finally arrived."
    "... Finalmente llegó la noche del festival."

# game/cethin.rpy:62
translate Spanish cethinroute_a422c584:

    # cethin "Such a shame Reo couldn't join us..."
    cethin "Qué pena que Reo no pudiera acompañarnos..."

# game/cethin.rpy:64
translate Spanish cethinroute_097e45ce:

    # "A spread of festive cooking was laid on their small tea table."
    "Una variedad de platillos festivos estaba dispuesta en su pequeña mesa de té."

# game/cethin.rpy:66
translate Spanish cethinroute_832ee823:

    # "There was a large roasted bird at the center, surrounded by appetizers and decorative tableware."
    "Había un gran ave asada en el centro, rodeada de aperitivos y vajilla decorativa."

# game/cethin.rpy:68
translate Spanish cethinroute_8c43d15a:

    # "A candlelight stood at the side, close to the colorful desserts which were available in different shapes and sizes."
    "Una vela se erguía al costado, cerca de los coloridos postres disponibles en diferentes formas y tamaños."

# game/cethin.rpy:70
translate Spanish cethinroute_675683c0:

    # "Honestly, it was too much for just the two of them..."
    "Sinceramente, era demasiado para solo los dos..."

# game/cethin.rpy:75
translate Spanish cethinroute_56fff035:

    # lumihappy "Well, he does deserve a break. Just look at this! You two truly outdid yourselves."
    lumihappy "Bueno, él sí que merece un descanso. ¡Mira esto! De verdad se superaron."

# game/cethin.rpy:77
translate Spanish cethinroute_71b08cdc:

    # lumitalk "I'm quite sure he should be enjoying the festival with his family right about now."
    lumitalk "Estoy bastante segura de que ahora mismo debe de estar disfrutando del festival con su familia."

# game/cethin.rpy:79
translate Spanish cethinroute_b03c6b8d:

    # lumi "(Come to think of it... did he even have a family?)"
    lumi "(Ahora que lo pienso... ¿acaso tenía familia?)"

# game/cethin.rpy:81
translate Spanish cethinroute_92550fc3:

    # "Without pausing, the princess elegantly sliced a piece of her roasted meal."
    "Sin detenerse, la princesa cortó elegantemente un trozo de su comida asada."

# game/cethin.rpy:83
translate Spanish cethinroute_c016c75f:

    # lumiwish "Mmm...!"
    lumiwish "¡Mmm...!"

# game/cethin.rpy:85
translate Spanish cethinroute_65a3b4ce:

    # lumiehe "Your cooking is wonderful as usual."
    lumiehe "Tu comida está deliciosa, como siempre."

# game/cethin.rpy:87
translate Spanish cethinroute_860300c6:

    # lumiwish "This roasted fowl is simply divine!"
    lumiwish "¡Esta ave asada es simplemente divina!"

# game/cethin.rpy:89
translate Spanish cethinroute_b0a62bc1:

    # lumiwish "The skin is moist, flavorful and crispy. The meat is juicy and tender... and this sauce! Words cannot describe how well they go together."
    lumiwish "La piel está húmeda, sabrosa y crujiente. La carne es jugosa y tierna... ¡y esta salsa! Las palabras no pueden describir lo bien que combinan."

# game/cethin.rpy:93
translate Spanish cethinroute_c15ac43f:

    # cethin "The sauce was made by Reo, so I wouldn't take full credit for that."
    cethin "La salsa la hizo Reo, así que no me atribuiré todo el mérito por eso."

# game/cethin.rpy:97
translate Spanish cethinroute_d886d7b1:

    # cethin "As for the meat, I'd say it's all thanks to its freshness."
    cethin "En cuanto a la carne, diría que es gracias a su frescura."

# game/cethin.rpy:101
translate Spanish cethinroute_f8030124:

    # cethin "Normally, we can only use frozen ingredients due to logistical reasons... but luckily, I managed to hunt that bird the other day."
    cethin "Normalmente solo podemos usar ingredientes congelados por cuestiones logísticas... pero por suerte, logré cazar esa ave el otro día."

# game/cethin.rpy:104
translate Spanish cethinroute_890d9137:

    # lumitalk "I see! ... Are you certain that you are a bard? Perhaps you're better off as an archer?"
    lumitalk "¡Ya veo! ... ¿Estás seguro de que eres un bardo? ¿Quizás estarías mejor como arquero?"

# game/cethin.rpy:108
translate Spanish cethinroute_776688b9:

    # cethin "Please stop changing my occupation..."
    cethin "Por favor, deja de cambiar mi ocupación..."

# game/cethin.rpy:112
translate Spanish cethinroute_e51b725a:

    # cethin "I did not shoot it down with a bow and arrow. I used magic."
    cethin "No la derribé con arco y flecha. Usé magia."

# game/cethin.rpy:114
translate Spanish cethinroute_17a5f8db:

    # lumishock "Now that sounds even more impressive."
    lumishock "Eso suena aún más impresionante."

# game/cethin.rpy:116
translate Spanish cethinroute_43bdf716:

    # lumided "(Still not bard-like though?)"
    lumided "(¿Aunque sigue sin sonar muy de bardo?)"

# game/cethin.rpy:121
translate Spanish cethinroute_af2a938b:

    # cethin "It's... really not much. Everyone in our clan can do such a basic spell."
    cethin "No es gran cosa. Todos en nuestro clan pueden hacer ese hechizo básico."

# game/cethin.rpy:123
translate Spanish cethinroute_4a6aa39a:

    # lumisad "You're always selling yourself short, you know that?"
    lumisad "Siempre te menosprecias, ¿lo sabías?"

# game/cethin.rpy:127
translate Spanish cethinroute_93f16c7b:

    # cethin "Ah... ha..."
    cethin "Ah... ja..."

# game/cethin.rpy:129
translate Spanish cethinroute_7ecab629:

    # lumisad "(I think I've made things rather awkward...)"
    lumisad "(Creo que acabo de hacer que las cosas se pusieran un poco incómodas...)"

# game/cethin.rpy:131
translate Spanish cethinroute_5dce99ea:

    # lumihappy "Oh, I know!"
    lumihappy "¡Oh, ya sé!"

# game/cethin.rpy:136
translate Spanish cethinroute_ec44b0c2:

    # lumi "Cethin, you know that one song right? I believe you played it the other day."
    lumi "Cethin, ¿conoces esa canción, verdad? Creo que la tocaste el otro día."

# game/cethin.rpy:140
translate Spanish cethinroute_076076b6:

    # cethin "...? Which one?"
    cethin "¿...? ¿Cuál?"

# game/cethin.rpy:146
translate Spanish cethinroute_8bcfafbb:

    # lumisad "The title slips my mind, but I believe it to be a classic."
    lumisad "No recuerdo el título, pero creo que es un clásico."

# game/cethin.rpy:148
translate Spanish cethinroute_997ca3d0:

    # lumi "Bards at the palace would often sing it during such festivities!"
    lumi "¡Los bardos del palacio solían cantarla durante estas festividades!"

# game/cethin.rpy:156
translate Spanish cethinroute_0df3c41a:

    # cethin "Classic... ah. I believe you mean this one?"
    cethin "Clásico... ah. ¿Creo que te refieres a esta?"

# game/cethin.rpy:161
translate Spanish cethinroute_6393a0b0:

    # voice "voice1/line84.mp3"
    # cethin "~This song shall be my testament- a song of mementos~"
    voice "voice1/line84.mp3"
    cethin "~Esta canción será mi testamento, una canción de recuerdos~"

# game/cethin.rpy:165
translate Spanish cethinroute_7955a051:

    # voice "voice1/line85.mp3"
    # cethin "~A sovereign of ruin, born of sorrow...~"
    voice "voice1/line85.mp3"
    cethin "~Un soberano de ruina, nacido del dolor...~"

# game/cethin.rpy:169
translate Spanish cethinroute_7f77177f:

    # voice "voice1/line86.mp3"
    # cethin "~A birth that shall engulf the world in loss forevermore...~"
    voice "voice1/line86.mp3"
    cethin "~Un nacimiento que envolverá al mundo en pérdida por siempre jamás...~"

# game/cethin.rpy:173
translate Spanish cethinroute_315f8e79:

    # voice "voice1/line87.mp3"
    # cethin "~Only blood of maiden of lore~"
    voice "voice1/line87.mp3"
    cethin "~Solo sangre de doncella de leyenda~"

# game/cethin.rpy:183
translate Spanish cethinroute_88ae4599:

    # lumihappy "Yes! That one."
    lumihappy "¡Sí! Esa."

# game/cethin.rpy:185
translate Spanish cethinroute_6634d394:

    # lumitalk "I believe I've actually heard that quite so often during special events?"
    lumitalk "Creo que la he escuchado bastante seguido durante eventos especiales."

# game/cethin.rpy:189
translate Spanish cethinroute_88970cdb:

    # cethin "This is one of the oldest songs of us bards."
    cethin "Es una de las canciones más antiguas entre nosotros los bardos."

# game/cethin.rpy:193
translate Spanish cethinroute_07e6fe21:

    # cethin "There was a saying among us- if you wanted to be a bard, you must learn this song first and foremost."
    cethin "Había un dicho entre nosotros: si querías ser un bardo, debías aprender esta canción antes que cualquier otra."

# game/cethin.rpy:197
translate Spanish cethinroute_34ac337b:

    # cethin "It's called: 'Maiden of Sacrifice'."
    cethin "Se llama: “Doncella del Sacrificio”."

# game/cethin.rpy:199
translate Spanish cethinroute_bdeb2996:

    # lumided "That... sounds oddly sinister."
    lumided "Eso... suena extrañamente siniestro."

# game/cethin.rpy:203
translate Spanish cethinroute_d337d1d8:

    # cethin "True."
    cethin "Cierto."

# game/cethin.rpy:207
translate Spanish cethinroute_00e02443:

    # cethin "Would you like me to continue then?"
    cethin "¿Quieres que continúe entonces?"

# game/cethin.rpy:209
translate Spanish cethinroute_f8c8a248:

    # lumitalk "Hmm... maybe not."
    lumitalk "Hmm... tal vez no."

# game/cethin.rpy:211
translate Spanish cethinroute_97add5ec:

    # lumided "I do not really recall how it goes next, but I do not think I'd like it."
    lumided "No recuerdo bien cómo sigue, pero no creo que me gustaría."

# game/cethin.rpy:217
translate Spanish cethinroute_a21189a1:

    # cethin "... Well, that's fine."
    cethin "... Bueno, está bien."

# game/cethin.rpy:221
translate Spanish cethinroute_0f57e5d9:

    # lumi "Anyway, we're about almost done here."
    lumi "De todas formas, ya casi terminamos aquí."

# game/cethin.rpy:223
translate Spanish cethinroute_41b25500:

    # lumihappy "I've stuffed myself tonight. I don't think I can have another bite..."
    lumihappy "He comido demasiado esta noche. No creo que pueda dar otro bocado..."

# game/cethin.rpy:227
translate Spanish cethinroute_b304f075:

    # cethin "Same. I'll clean up here."
    cethin "Igual. Yo limpiaré aquí."

# game/cethin.rpy:231
translate Spanish cethinroute_a3a385a7:

    # cethin "Why don't you catch some fresh air?"
    cethin "¿Por qué no tomas un poco de aire fresco?"

# game/cethin.rpy:233
translate Spanish cethinroute_fe5c726d:

    # "Of course, she couldn't go outside... which meant the balcony."
    "Por supuesto, ella no podía salir afuera... lo que significaba el balcón."

# game/cethin.rpy:235
translate Spanish cethinroute_f216cfba:

    # lumi "Very well. I would not mind helping you out, though?"
    lumi "Muy bien. Aunque no me importaría ayudarte."

# game/cethin.rpy:241
translate Spanish cethinroute_4c76eb4f:

    # cethin "No, no.. it's fine."
    cethin "No, no... está bien."

# game/cethin.rpy:243
translate Spanish cethinroute_e475ef87:

    # cethin "This should be quick."
    cethin "Esto será rápido."

# game/cethin.rpy:245
translate Spanish cethinroute_8e17d9c2:

    # lumi "If you say so."
    lumi "Si tú lo dices."

# game/cethin.rpy:251
translate Spanish cethinroute_fee3f0c8:

    # "Just as Cethin had suggested, the princess walked over to the balcony to catch some fresh air."
    "Tal como Cethin había sugerido, la princesa caminó hacia el balcón para tomar un poco de aire fresco."

# game/cethin.rpy:253
translate Spanish cethinroute_1ddb8883:

    # "Honestly? There wasn't anything special about the view."
    "¿Honestamente? No había nada especial en la vista."

# game/cethin.rpy:255
translate Spanish cethinroute_e245582b:

    # "It's the same old barren land of snow."
    "Era la misma vieja tierra nevada y desolada."

# game/cethin.rpy:257
translate Spanish cethinroute_f59b36e5:

    # lumiserious "..."
    lumiserious "..."

# game/cethin.rpy:264
translate Spanish cethinroute_6583377c:

    # "The girl turned her head for a moment, watching the dark elf pack up their leftovers."
    "La chica giró la cabeza por un momento, observando al elfo oscuro guardar las sobras."

# game/cethin.rpy:268
translate Spanish cethinroute_bd909479:

    # "With a soft huff, she then turned up to the star filled sky."
    "Con un suave suspiro, alzó la vista hacia el cielo lleno de estrellas."

# game/cethin.rpy:270
translate Spanish cethinroute_9dad88b5:

    # lumiblush "I wonder why I never bothered to look up?"
    lumiblush "Me pregunto por qué nunca me molesté en mirar hacia arriba."

# game/cethin.rpy:272
translate Spanish cethinroute_4acb17fa:

    # lumihappy "(It's pretty.)"
    lumihappy "(Es bonito.)"

# game/cethin.rpy:274
translate Spanish cethinroute_3f2602c6:

    # "She smiled to herself."
    "Sonrió para sí misma."

# game/cethin.rpy:276
translate Spanish cethinroute_69cc019e:

    # lumihappy "(I wish Cethin would get here soon, then we can watch together.)"
    lumihappy "(Ojalá Cethin llegara pronto, así podríamos mirar juntos.)"

# game/cethin.rpy:283
translate Spanish cethinroute_222af07f:

    # voice "voice1/line111.mp3"
    # cethin "The sky is brighter tonight, isn't it?"
    voice "voice1/line111.mp3"
    cethin "El cielo está más brillante esta noche, ¿no?"

# game/cethin.rpy:287
translate Spanish cethinroute_7bb2e313:

    # "Lumi flinched from Cethin's sudden appearance." with vpunch
    "Lumi se sobresaltó por la repentina aparición de Cethin." with vpunch

# game/cethin.rpy:291
translate Spanish cethinroute_5a98f055:

    # voice "voice1/line112.mp3"
    # cethin "Aha... did I surprise you?"
    voice "voice1/line112.mp3"
    cethin "Ajá... ¿te asusté?"

# game/cethin.rpy:295
translate Spanish cethinroute_30e2f60d:

    # lumishy "(... Too soon.)"
    lumishy "(... Demasiado pronto.)"

# game/cethin.rpy:297
translate Spanish cethinroute_b551e5ff:

    # lumihappy "(Oh well, this works.)"
    lumihappy "(Bueno, igual sirve.)"

# game/cethin.rpy:302
translate Spanish cethinroute_ab5e5ef7:

    # voice "voice1/line113.mp3"
    # cethin "Sorry about that."
    voice "voice1/line113.mp3"
    cethin "Perdón por eso."

# game/cethin.rpy:308
translate Spanish cethinroute_ad9db35f:

    # lumishy "(He's smiling...)"
    lumishy "(Está sonriendo...)"

# game/cethin.rpy:310
translate Spanish cethinroute_ec0b685c:

    # lumiplead "Well... you walk too quietly."
    lumiplead "Bueno... caminas demasiado silenciosamente."

# game/cethin.rpy:312
translate Spanish cethinroute_a0e58c29:

    # voice "voice1/line114.mp3"
    # cethin "Do I now?"
    voice "voice1/line114.mp3"
    cethin "¿Ah, sí?"

# game/cethin.rpy:318
translate Spanish cethinroute_3048338e:

    # voice "voice1/line115.mp3"
    # cethin "You know what? I think you're not the first to say that, actually..."
    voice "voice1/line115.mp3"
    cethin "¿Sabes? Creo que no eres la primera en decirlo, de hecho..."

# game/cethin.rpy:322
translate Spanish cethinroute_2292fc0f:

    # lumihappy "Then perhaps you really would have been better off as an assassin."
    lumihappy "Entonces quizás realmente habrías estado mejor como asesino."

# game/cethin.rpy:327
translate Spanish cethinroute_4847f30c:

    # voice "voice1/line116.mp3"
    # cethin "Come on. There is no way I could pull that off."
    voice "voice1/line116.mp3"
    cethin "Vamos ya. No hay manera de que pudiera hacer eso."

# game/cethin.rpy:331
translate Spanish cethinroute_631eb9fe:

    # lumided "(No. Really. We're all saying you're too good at it.)"
    lumided "(No. En serio. Todos decimos que eres demasiado bueno en eso.)"

# game/cethin.rpy:336
translate Spanish cethinroute_bbda852b:

    # lumitalk "Mhm... actually, why did you become a bard?"
    lumitalk "Mhm... en realidad, ¿por qué te hiciste bardo?"

# game/cethin.rpy:338
translate Spanish cethinroute_3b6b0df9:

    # "The question had been bugging her for quite a while now."
    "La pregunta la había estado inquietando por un buen tiempo."

# game/cethin.rpy:342
translate Spanish cethinroute_bae90a25:

    # "Sure, he had mentioned before that his mother liked music..."
    "Claro, él había mencionado antes que a su madre le gustaba la música..."

# game/cethin.rpy:344
translate Spanish cethinroute_c4d57292:

    # "But their conversation was cut short back then."
    "Pero su conversación se había interrumpido en ese momento."

# game/cethin.rpy:346
translate Spanish cethinroute_2b7987fe:

    # "Lumi wondered if he had some other reason."
    "Lumi se preguntaba si él tendría alguna otra razón."

# game/cethin.rpy:351
translate Spanish cethinroute_7ced22d2:

    # voice "voice1/line117.mp3"
    # cethin "..."
    voice "voice1/line117.mp3"
    cethin "..."

# game/cethin.rpy:355
translate Spanish cethinroute_9bcc5450:

    # lumi "You don't have to answer if you don't want to."
    lumi "No tienes que responder si no quieres."

# game/cethin.rpy:360
translate Spanish cethinroute_8d75abb1:

    # voice "voice1/line118.mp3"
    # cethin "It's... not that."
    voice "voice1/line118.mp3"
    cethin "No es eso..."

# game/cethin.rpy:367
translate Spanish cethinroute_839487f4:

    # voice "voice1/line119.mp3"
    # cethin "If... if I tell you, would you answer something of mine too?"
    voice "voice1/line119.mp3"
    cethin "Si... si te lo cuento, ¿responderías algo mío también?"

# game/cethin.rpy:374
translate Spanish cethinroute_b96d9db5:

    # lumitalk "Oh? Well, as long as it is something I could answer."
    lumitalk "¿Oh? Bueno, mientras sea algo que pueda responder."

# game/cethin.rpy:378
translate Spanish cethinroute_80cd33f8:

    # "Cethin perked up. His timid demeanor was swept away... or at least, he tried to sweep it away."
    "Cethin se animó. Su actitud tímida se desvaneció... o al menos, intentó disimularla."

# game/cethin.rpy:380
translate Spanish cethinroute_903b0fef:

    # "It was still obvious that he was anxious, but motivated."
    "Aun así, era evidente que estaba nervioso, pero motivado."

# game/cethin.rpy:382
translate Spanish cethinroute_f1b0f4e9:

    # lumithink "(Goodness. I thought we're already at a stage where we don't get nervous around each other anymore.)"
    lumithink "(Dios santo. Pensé que ya estábamos en una etapa en la que no nos poníamos nerviosos el uno con el otro.)"

# game/cethin.rpy:389
translate Spanish cethinroute_82a8e960:

    # voice "voice1/line120.mp3"
    # cethin "Do you recall when I mentioned that our clan specialized in the dark arts?"
    voice "voice1/line120.mp3"
    cethin "¿Recuerdas cuando mencioné que nuestro clan se especializaba en las artes oscuras?"

# game/cethin.rpy:393
translate Spanish cethinroute_4ae30f7d:

    # "Lumi nodded."
    "Lumi asintió."

# game/cethin.rpy:397
translate Spanish cethinroute_a913cc5f:

    # voice "voice1/line121.mp3"
    # cethin "See... I was terrible at it."
    voice "voice1/line121.mp3"
    cethin "Verás... yo era terrible en eso."

# game/cethin.rpy:403
translate Spanish cethinroute_879238d6:

    # voice "voice1/line122.mp3"
    # cethin "All I could do were basic spells, when everyone else was already practicing advanced spells."
    voice "voice1/line122.mp3"
    cethin "Solo podía hacer hechizos básicos, cuando los demás ya practicaban conjuros avanzados."

# game/cethin.rpy:407
translate Spanish cethinroute_eee7dab6:

    # voice "voice1/line123.mp3"
    # cethin "I was falling back."
    voice "voice1/line123.mp3"
    cethin "Me estaba quedando atrás."

# game/cethin.rpy:414
translate Spanish cethinroute_35d513e6:

    # voice "voice1/line124.mp3"
    # cethin "I tried many other things. Archery, swordsmanship, potions..."
    voice "voice1/line124.mp3"
    cethin "Intenté muchas otras cosas. Arquería, esgrima, pociones..."

# game/cethin.rpy:420
translate Spanish cethinroute_6e9fdd42:

    # voice "voice1/line125.mp3"
    # cethin "But I always found myself fumbling."
    voice "voice1/line125.mp3"
    cethin "Pero siempre terminaba tropezando."

# game/cethin.rpy:426
translate Spanish cethinroute_7527c262:

    # voice "voice1/line126.mp3"
    # cethin "Everyone started considering me as useless since I couldn't do anything right."
    voice "voice1/line126.mp3"
    cethin "Todos comenzaron a considerarme inútil porque no podía hacer nada bien."

# game/cethin.rpy:433
translate Spanish cethinroute_b3fef037:

    # voice "voice1/line127.mp3"
    # cethin "Once, I played around with my mother's instrument... and when she heard me, she insisted that I pursue it."
    voice "voice1/line127.mp3"
    cethin "Una vez jugué con el instrumento de mi madre... y cuando me escuchó, insistió en que lo siguiera."

# game/cethin.rpy:439
translate Spanish cethinroute_3bf0c0a3:

    # voice "voice1/line128.mp3"
    # cethin "Becoming a bard isn't common among us dark elves, so I was reluctant."
    voice "voice1/line128.mp3"
    cethin "Convertirse en bardo no es común entre nosotros los elfos oscuros, así que dudaba en hacerlo."

# game/cethin.rpy:445
translate Spanish cethinroute_24412ad2:

    # voice "voice1/line129.mp3"
    # cethin "But my mother was quite... how do you say it? An oddball? Yes, I suppose that's it."
    voice "voice1/line129.mp3"
    cethin "Pero mi madre era bastante... ¿cómo se dice? ¿Excéntrica? Sí, supongo que eso es."

# game/cethin.rpy:452
translate Spanish cethinroute_0fedb012:

    # voice "voice1/line130.mp3"
    # cethin "She was an oddball."
    voice "voice1/line130.mp3"
    cethin "Era una excéntrica."

# game/cethin.rpy:458
translate Spanish cethinroute_f6a3b791:

    # voice "voice1/line131.mp3"
    # cethin "Her circumstances prevented her from pursuing it herself."
    voice "voice1/line131.mp3"
    cethin "Sus circunstancias le impidieron dedicarse a ello por sí misma."

# game/cethin.rpy:462
translate Spanish cethinroute_10dd083d:

    # voice "voice1/line132.mp3"
    # cethin "So with that, you can guess the rest of the story."
    voice "voice1/line132.mp3"
    cethin "Así que con eso, puedes imaginarte el resto de la historia."

# game/cethin.rpy:466
translate Spanish cethinroute_be49f443:

    # "The way he said it, it almost seemed like he wasn't particularly fond of the memories."
    "Por la forma en que lo dijo, casi parecía que no tenía mucho aprecio por esos recuerdos."

# game/cethin.rpy:468
translate Spanish cethinroute_ac742743:

    # "Part of Lumi felt bad for asking him, but another was just glad to know more about this bard."
    "Parte de Lumi se sintió mal por haberle preguntado, pero otra parte se alegró de saber más sobre ese bardo."

# game/cethin.rpy:472
translate Spanish cethinroute_e1b5bfa7:

    # voice "voice1/line133.mp3"
    # cethin "Although honestly, I don't really enjoy playing."
    voice "voice1/line133.mp3"
    cethin "Aunque siendo honesto, no disfruto realmente tocar."

# game/cethin.rpy:478
translate Spanish cethinroute_b1924225:

    # lumishock "You don't? But you always seem enthusiastic to play!"
    lumishock "¿No lo haces? ¡Pero siempre pareces entusiasmado al tocar!"

# game/cethin.rpy:480
translate Spanish cethinroute_474bf028:

    # lumisad "I wouldn't have thought..."
    lumisad "No lo habría pensado..."

# game/cethin.rpy:482
translate Spanish cethinroute_5e1aa5b3:

    # "Lumi felt bad."
    "Lumi se sintió mal."

# game/cethin.rpy:484
translate Spanish cethinroute_a697035a:

    # "Does that mean that she had been forcing him to play all along?"
    "¿Significaba eso que lo había estado obligando a tocar todo este tiempo?"

# game/cethin.rpy:488
translate Spanish cethinroute_a5b0a779:

    # voice "voice1/line134.mp3"
    # cethin "Haha... don't worry."
    voice "voice1/line134.mp3"
    cethin "Jaja... no te preocupes."

# game/cethin.rpy:494
translate Spanish cethinroute_c0436c04:

    # voice "voice1/line135.mp3"
    # cethin "I'm not particularly fond of playing, but I do like seeing others enjoy my performance."
    voice "voice1/line135.mp3"
    cethin "No me apasiona tocar, pero sí me gusta ver a los demás disfrutar de mi interpretación."

# game/cethin.rpy:498
translate Spanish cethinroute_4c5632b2:

    # voice "voice1/line136.mp3"
    # cethin "Even if it was in the form of making fun of it."
    voice "voice1/line136.mp3"
    cethin "Incluso si fuera en forma de burlas."

# game/cethin.rpy:504
translate Spanish cethinroute_640e5215:

    # voice "voice1/line137.mp3"
    # cethin "Erm... well, granted, you seem to be the only one who ever wholeheartedly enjoys it."
    voice "voice1/line137.mp3"
    cethin "Ehm... bueno, a decir verdad, pareces ser la única que realmente lo disfruta de corazón."

# game/cethin.rpy:508
translate Spanish cethinroute_016426db:

    # lumishy "..."
    lumishy "..."

# game/cethin.rpy:510
translate Spanish cethinroute_090f401b:

    # "For a moment, the princess felt her chest tighten."
    "Por un momento, la princesa sintió que el pecho se le apretaba."

# game/cethin.rpy:512
translate Spanish cethinroute_6bff0a9f:

    # "She wondered... Was it sadness? Or was it happiness?"
    "Se preguntó... ¿era tristeza? ¿O era felicidad?"

# game/cethin.rpy:514
translate Spanish cethinroute_8ec94f8d:

    # "She couldn't tell... so for now, she could only purse her lips and keep it in."
    "No podía saberlo... así que, por ahora, solo apretó los labios y lo contuvo."

# game/cethin.rpy:518
translate Spanish cethinroute_b5d12e9f:

    # voice "voice1/line138.mp3"
    # cethin "It's not a particularly interesting story, is it?"
    voice "voice1/line138.mp3"
    cethin "No es una historia particularmente interesante, ¿verdad?"

# game/cethin.rpy:522
translate Spanish cethinroute_5688171a:

    # "The girl shook her head."
    "La chica negó con la cabeza."

# game/cethin.rpy:524
translate Spanish cethinroute_e5f7945f:

    # lumihappy "No. I learned a lot more about you."
    lumihappy "No. Aprendí mucho más sobre ti."

# game/cethin.rpy:526
translate Spanish cethinroute_93d25b40:

    # lumiawk "I'm honestly just glad you opened up to me like this."
    lumiawk "En serio, me alegra que te hayas abierto conmigo de esta manera."

# game/cethin.rpy:531
translate Spanish cethinroute_5cf21121:

    # voice "voice1/line139.mp3"
    # cethin "I... I see."
    voice "voice1/line139.mp3"
    cethin "Ya... ya veo."

# game/cethin.rpy:538
translate Spanish cethinroute_3936e2e3:

    # lumihappy "Now then, I suppose I owe you an answer this time?"
    lumihappy "Entonces, supongo que ahora te debo una respuesta, ¿no?"

# game/cethin.rpy:540
translate Spanish cethinroute_01749195:

    # lumi "Go on now."
    lumi "Vamos, continúa."

# game/cethin.rpy:544
translate Spanish cethinroute_3f3517c2:

    # "The dark elf seemed like he was hesitating to ask his question."
    "El elfo oscuro parecía dudar al formular su pregunta."

# game/cethin.rpy:548
translate Spanish cethinroute_e1c5718b:

    # voice "voice1/line140.mp3"
    # cethin "Are you really fine with marrying anyone?"
    voice "voice1/line140.mp3"
    cethin "¿De verdad estás conforme con casarte con cualquiera?"

# game/cethin.rpy:555
translate Spanish cethinroute_3cff4d30:

    # "The princess blinked."
    "La princesa parpadeó."

# game/cethin.rpy:557
translate Spanish cethinroute_8db565e6:

    # "She was unsure where this question suddenly came from."
    "No estaba segura de dónde había salido esa pregunta tan repentina."

# game/cethin.rpy:559
translate Spanish cethinroute_810cd47b:

    # "... But it would be a lie to say that she didn't know what he meant."
    "... Pero sería mentira decir que no sabía a qué se refería."

# game/cethin.rpy:561
translate Spanish cethinroute_5cb1091a:

    # "Whoever rescues her does have a right for her hand in marriage."
    "Quienquiera que la rescatara tenía derecho a su mano en matrimonio."

# game/cethin.rpy:563
translate Spanish cethinroute_d1240cdb:

    # "As to whether or not she could refuse..."
    "En cuanto a si podía rechazarlo o no..."

# game/cethin.rpy:565
translate Spanish cethinroute_fde34762:

    # "That would be difficult to answer."
    "Eso sería difícil de responder."

# game/cethin.rpy:573
translate Spanish cethinroute_98c661ef:

    # lumiserious "Of course."
    lumiserious "Por supuesto."

# game/cethin.rpy:575
translate Spanish cethinroute_de591b20:

    # "She answered without hesitation."
    "Respondió sin dudar."

# game/cethin.rpy:582
translate Spanish cethinroute_576b44a1:

    # lumiserious "If I were to be honest? No."
    lumiserious "Si he de ser honesta... no."

# game/cethin.rpy:584
translate Spanish cethinroute_0aa352da:

    # lumisad "Of course not."
    lumisad "Por supuesto que no."

# game/cethin.rpy:586
translate Spanish cethinroute_e880703e:

    # lumisad "Either way, it is my responsibility as a princess."
    lumisad "De cualquier modo, es mi responsabilidad como princesa."

# game/cethin.rpy:591
translate Spanish cethinroute_bfe5064d:

    # lumihappy "Whether I like it or not is irrelevant. I've never had the choice in this matter."
    lumihappy "Me guste o no es irrelevante. Nunca he tenido elección en este asunto."

# game/cethin.rpy:593
translate Spanish cethinroute_1b1b4eb3:

    # lumi "Had I not been imprisoned here, I would have been married off for political purposes."
    lumi "De no haber sido encarcelada aquí, ya habría sido entregada en matrimonio por motivos políticos."

# game/cethin.rpy:595
translate Spanish cethinroute_b1fbc312:

    # lumihappy "This is simply what I must pay for the privileges I've received as a princess."
    lumihappy "Esto es simplemente el precio que debo pagar por los privilegios que he recibido como princesa."

# game/cethin.rpy:597
translate Spanish cethinroute_76bddb15:

    # "Her childhood had been a rather happy one."
    "Su infancia había sido bastante feliz."

# game/cethin.rpy:599
translate Spanish cethinroute_86c6da0c:

    # "She could ask for all the toys, dresses, and jewelries she wanted. She didn't have to worry about hunger or sickness."
    "Podía pedir todos los juguetes, vestidos y joyas que quisiera. No tenía que preocuparse por el hambre ni la enfermedad."

# game/cethin.rpy:601
translate Spanish cethinroute_085f9a1b:

    # "Lumi would even proudly admit that she had been spoiled."
    "Lumi incluso admitiría con orgullo que había sido consentida."

# game/cethin.rpy:606
translate Spanish cethinroute_3a6343cf:

    # lumishy "I'd honestly prefer this... to be tied to someone who risked their life just to reach my side-"
    lumishy "Honestamente, prefiero esto... estar ligada a alguien que arriesgó su vida solo para llegar a mi lado..."

# game/cethin.rpy:608
translate Spanish cethinroute_139cec8f:

    # lumihappy "You'd think such a person would at least have an inkling of feeling for me, yes?"
    lumihappy "Uno pensaría que alguien así tendría al menos un poco de cariño por mí, ¿no?"

# game/cethin.rpy:613
translate Spanish cethinroute_385018f9:

    # voice "voice1/line141.mp3"
    # cethin "... But what if the hero turns out to be unpleasant?"
    voice "voice1/line141.mp3"
    cethin "... Pero ¿y si el héroe resulta ser desagradable?"

# game/cethin.rpy:619
translate Spanish cethinroute_59e0f6a2:

    # lumihappy "Well, nothing I can do then."
    lumihappy "Bueno, no habría nada que pudiera hacer entonces."

# game/cethin.rpy:621
translate Spanish cethinroute_a228d1ef:

    # "Her reply was nonchalant. As if it was the most natural thing."
    "Su respuesta fue despreocupada. Como si fuera lo más natural del mundo."

# game/cethin.rpy:623
translate Spanish cethinroute_ec8f171a:

    # "The princess looked up the sky once again."
    "La princesa volvió a mirar hacia el cielo."

# game/cethin.rpy:625
translate Spanish cethinroute_89bc8fd9:

    # "Without looking back at Cethin, she continued."
    "Sin volver la vista hacia Cethin, continuó."

# game/cethin.rpy:627
translate Spanish cethinroute_7e368712:

    # lumishy "My hero could be an aging old man or even a mad sorcerer, and I must still marry them if they so desire."
    lumishy "Mi héroe podría ser un viejo decrépito o incluso un mago loco, y aun así tendría que casarme con él si así lo desea."

# game/cethin.rpy:629
translate Spanish cethinroute_8b69e0bb:

    # lumitalk "There had even been a record of a princess whose hero was an ogre..."
    lumitalk "Incluso hubo un registro de una princesa cuyo héroe fue un ogro..."

# game/cethin.rpy:631
translate Spanish cethinroute_66dde5c8:

    # lumisad "Ogres are known to be hideous, short-tempered and uncouth."
    lumisad "Los ogros son conocidos por ser horribles, temperamentales y groseros."

# game/cethin.rpy:633
translate Spanish cethinroute_2ea22052:

    # "This time, she turned to him with a smile."
    "Esta vez, ella se volvió hacia él con una sonrisa."

# game/cethin.rpy:635
translate Spanish cethinroute_792dcb36:

    # lumihappy "Yet stories say that they lived happily ever after."
    lumihappy "Y aun así, las historias dicen que vivieron felices para siempre."

# game/cethin.rpy:640
translate Spanish cethinroute_7ff78922:

    # lumihappy "If such a relationship could work out... mine should as well, yes?"
    lumihappy "Si una relación así pudo funcionar... la mía también debería, ¿no?"

# game/cethin.rpy:642
translate Spanish cethinroute_7d77221a:

    # "Lumi tried shifting the mood, but her companion still seemed down about it."
    "Lumi intentó cambiar el ánimo, pero su compañero seguía abatido por el tema."

# game/cethin.rpy:644
translate Spanish cethinroute_b7c58917:

    # "She furrowed her brows and gave him an empathic look."
    "Frunció el ceño y le dedicó una mirada empática."

# game/cethin.rpy:646
translate Spanish cethinroute_57c94233:

    # lumisad "(I didn't realize he was worrying about such things...)"
    lumisad "(No me había dado cuenta de que se preocupaba por algo así...)"

# game/cethin.rpy:648
translate Spanish cethinroute_b0a4792b:

    # lumihappy "(But... it feels good to know that Cethin cares about me to this extent.)"
    lumihappy "(Pero... se siente bien saber que a Cethin le importo hasta ese punto.)"

# game/cethin.rpy:662
translate Spanish cethinroute_be0d557e:

    # "She held out her hands to cup his cheeks."
    "Le tomó el rostro entre las manos."

# game/cethin.rpy:666
translate Spanish cethinroute_253b009b:

    # "Cethin staggered because of her sudden gesture and tried to step back, but she pulled him back in."
    "Cethin se tambaleó por el gesto repentino e intentó apartarse, pero ella lo atrajo de nuevo."

# game/cethin.rpy:668
translate Spanish cethinroute_c3588598:

    # lumihappy "Come now! Why the long face?"
    lumihappy "¡Vamos ya! ¿Por qué esa cara tan larga?"

# game/cethin.rpy:670
translate Spanish cethinroute_b51261bb:

    # lumided "You look silly like this."
    lumided "Te ves gracioso así."

# game/cethin.rpy:674
translate Spanish cethinroute_064ffe43:

    # "She chuckled as she stared at his squeezed cheeks."
    "Ella se rió mientras observaba sus mejillas apretadas."

# game/cethin.rpy:676
translate Spanish cethinroute_ab666ca3:

    # "Cethin grabbed her wrists to take them off his face."
    "Cethin le tomó las muñecas para apartarlas de su rostro."

# game/cethin.rpy:678
translate Spanish cethinroute_3159f306:

    # "He seemed very flustered."
    "Parecía muy desconcertado."

# game/cethin.rpy:680
translate Spanish cethinroute_db7641f3:

    # "The princess sighed."
    "La princesa suspiró."

# game/cethin.rpy:682
translate Spanish cethinroute_b5234710:

    # lumiblush "Oh, you..."
    lumiblush "Ay, tú..."

# game/cethin.rpy:686
translate Spanish cethinroute_baa502ac:

    # lumihappy "It's the yule festival! We should be celebrating merrily."
    lumihappy "¡Es el festival de Yule! Deberíamos estar celebrando con alegría."

# game/cethin.rpy:688
translate Spanish cethinroute_d9928c43:

    # lumi "If it'd make you feel any better, my father, the king himself, had assured me that he'd handpick my heroes."
    lumi "Si eso te hace sentir mejor, mi padre, el mismísimo rey, me aseguró que él mismo escogería a mis héroes."

# game/cethin.rpy:690
translate Spanish cethinroute_39d271ee:

    # lumihappy "I doubt he'd send in just about anyone."
    lumihappy "Dudo que enviara a cualquiera."

# game/cethin.rpy:692
translate Spanish cethinroute_392ffff3:

    # lumi "And then there's your party. They should still be close by, yes?"
    lumi "Y luego está tu grupo. Deberían seguir cerca, ¿no?"

# game/cethin.rpy:694
translate Spanish cethinroute_89dddd86:

    # "Speaking of them... it had probably already been a month or so, and they have yet to pick up their friend..."
    "Hablando de ellos... probablemente ya ha pasado un mes o algo así, y todavía no han venido por su amigo..."

# game/cethin.rpy:696
translate Spanish cethinroute_c60e760f:

    # "Lumi worried if they're doing well."
    "Lumi se preguntaba si estarían bien."

# game/cethin.rpy:698
translate Spanish cethinroute_733bf661:

    # "What if one of them was heavily injured?"
    "¿Qué tal si alguno de ellos resultó gravemente herido?"

# game/cethin.rpy:700
translate Spanish cethinroute_42ff4a67:

    # "She could only hope that Cethin would be able to re-unite with his companions."
    "Solo podía esperar que Cethin pudiera reunirse con sus compañeros."

# game/cethin.rpy:702
translate Spanish cethinroute_f5a80806:

    # voice "voice1/line142.mp3"
    # cethin "..."
    voice "voice1/line142.mp3"
    cethin "..."

# game/cethin.rpy:706
translate Spanish cethinroute_922eab06:

    # "Her words didn't seem to have gotten through to him."
    "Sus palabras no parecían haber llegado a él."

# game/cethin.rpy:708
translate Spanish cethinroute_26eda2ba:

    # "The princess sighed once again."
    "La princesa suspiró una vez más."

# game/cethin.rpy:710
translate Spanish cethinroute_779268cb:

    # lumiawk "What am I to do with you?"
    lumiawk "¿Qué voy a hacer contigo?"

# game/cethin.rpy:712
translate Spanish cethinroute_f5f6f18a:

    # "She took her attention away from him for a moment and fished something from inside her sleeves."
    "Apartó su atención de él por un momento y sacó algo de dentro de sus mangas."

# game/cethin.rpy:715
translate Spanish cethinroute_7e586155:

    # "Without warning, she took the dark elf's hands and dropped something on his palm."
    "Sin previo aviso, tomó las manos del elfo oscuro y dejó caer algo en su palma."

# game/cethin.rpy:718
translate Spanish cethinroute_9ad54ced:

    # "He blinked."
    "Él parpadeó."

# game/cethin.rpy:720
translate Spanish cethinroute_7bf702f3:

    # voice "voice1/line143.mp3"
    # cethin "What's..."
    voice "voice1/line143.mp3"
    cethin "¿Qué es...?"

# game/cethin.rpy:724
translate Spanish cethinroute_8d58a75d:

    # lumihappy "I am not particularly good at crafts... but I hope you like it."
    lumihappy "No soy particularmente buena con las manualidades... pero espero que te guste."

# game/cethin.rpy:726
translate Spanish cethinroute_0aec138e:

    # "It was a bracelet.{w} The trinket was evidently handmade."
    "Era una pulsera.{w} El pequeño adorno estaba claramente hecho a mano."

# game/cethin.rpy:728
translate Spanish cethinroute_9313d358:

    # lumi "You said that it is your tradition to gift handmade trinkets during your festival, yes?"
    lumi "Dijiste que es tradición tuya regalar adornos hechos a mano durante tu festival, ¿cierto?"

# game/cethin.rpy:730
translate Spanish cethinroute_16c081a0:

    # lumihappy "So, I wanted to express my gratitude for you."
    lumihappy "Así que quería expresarte mi gratitud."

# game/cethin.rpy:732
translate Spanish cethinroute_ce002f9e:

    # lumiblush "I'm glad that you came here."
    lumiblush "Me alegra que hayas venido aquí."

# game/cethin.rpy:734
translate Spanish cethinroute_3d6a1f90:

    # lumihappy "It is thanks to you that everyday has become something I look forward to."
    lumihappy "Es gracias a ti que cada día se ha convertido en algo que espero con ansias."

# game/cethin.rpy:736
translate Spanish cethinroute_a21e1f61:

    # lumiplead "That was difficult to craft. I even had Reo sneak me in some materials."
    lumiplead "Fue difícil de hacer. Incluso tuve que pedirle a Reo que me consiguiera algunos materiales a escondidas."

# game/cethin.rpy:738
translate Spanish cethinroute_1699747d:

    # lumiblush "So... I hope you like it even if it may seem shabby."
    lumiblush "Así que... espero que te guste, aunque pueda parecer algo pobre."

# game/cethin.rpy:744
translate Spanish cethinroute_28518b27:

    # "Cethin could only stare at the princess' gift, before suddenly turning his back on her."
    "Cethin solo pudo quedarse mirando el regalo de la princesa, antes de darse la vuelta de repente."

# game/cethin.rpy:746
translate Spanish cethinroute_1bbdb03e:

    # lumishy "Ce-cethin...? Is everything all right?"
    lumishy "¿Ce-cethin...? ¿Todo está bien?"

# game/cethin.rpy:748
translate Spanish cethinroute_fa477301:

    # voice "voice1/line144.mp3"
    # cethin "P-please... don't look at me right now..."
    voice "voice1/line144.mp3"
    cethin "P-por favor... no me mires ahora mismo..."

# game/cethin.rpy:752
translate Spanish cethinroute_02f92aa2:

    # lumishock "Oh."
    lumishock "Oh."

# game/cethin.rpy:754
translate Spanish cethinroute_9c9f2197:

    # "It was easy to tell. He was crying."
    "Era fácil saberlo. Estaba llorando."

# game/cethin.rpy:756
translate Spanish cethinroute_0e65823b:

    # "The princess huffed and simply rubbed his back."
    "La princesa soltó un suspiro y simplemente le frotó la espalda."

# game/cethin.rpy:758
translate Spanish cethinroute_7c4e33a6:

    # lumihappy "I hope it made you happy?"
    lumihappy "¿Espero que te haya hecho feliz?"

# game/cethin.rpy:760
translate Spanish cethinroute_785fc343:

    # voice "voice1/line145.mp3"
    # cethin "Mhm..."
    voice "voice1/line145.mp3"
    cethin "Mhm..."

# game/cethin.rpy:771
translate Spanish cethinroute_6af6e00f:

    # "Lumi allowed Cethin some time to calm himself."
    "Lumi le dio tiempo a Cethin para calmarse."

# game/cethin.rpy:773
translate Spanish cethinroute_d92d1ba8:

    # "She continued to comfort him althroughout."
    "Lo consoló todo el tiempo."

# game/cethin.rpy:775
translate Spanish cethinroute_517158c0:

    # "The princess had never really done anything like consoling someone... but with Cethin, it felt so natural to her."
    "La princesa nunca había hecho algo como consolar a alguien... pero con Cethin, le resultaba tan natural."

# game/cethin.rpy:777
translate Spanish cethinroute_b9e4a256:

    # lumitalk "Are you feeling better now?"
    lumitalk "¿Te sientes mejor ahora?"

# game/cethin.rpy:782
translate Spanish cethinroute_732e6883:

    # cethin "Yeah, sorry about that sad display..."
    cethin "Sí, perdón por ese espectáculo tan triste..."

# game/cethin.rpy:784
translate Spanish cethinroute_6607b345:

    # lumihappy "Didn't I tell you to reduce your apologies?"
    lumihappy "¿No te dije que dejaras de disculparte tanto?"

# game/cethin.rpy:789
translate Spanish cethinroute_7a894505:

    # cethin "Ahaha... right.{w} Then, thank you for putting up with me."
    cethin "Jajaja... cierto.{w} Entonces, gracias por soportarme."

# game/cethin.rpy:791
translate Spanish cethinroute_db881881:

    # lumihappy "You are very welcome."
    lumihappy "De nada."

# game/cethin.rpy:793
translate Spanish cethinroute_797db401:

    # "She curtsied jokingly."
    "Hizo una reverencia en tono de broma."

# game/cethin.rpy:797
translate Spanish cethinroute_1450e2fb:

    # "Both of them chuckled."
    "Ambos se rieron."

# game/cethin.rpy:802
translate Spanish cethinroute_28911fac:

    # cethin "Unfortunately, I don't really have anything to repay you with..."
    cethin "Desafortunadamente, no tengo nada con qué devolverte el favor..."

# game/cethin.rpy:804
translate Spanish cethinroute_eff2e038:

    # lumi "You do not have to! I already told you that it's my show of gratitude to you."
    lumi "¡No tienes que hacerlo! Ya te dije que era mi forma de agradecerte."

# game/cethin.rpy:806
translate Spanish cethinroute_bdd92d63:

    # lumiblush "You've made this feast possible, you make everyday so much fun, and you..."
    lumiblush "Hiciste posible este banquete, haces que cada día sea tan divertido, y tú..."

# game/cethin.rpy:808
translate Spanish cethinroute_53d4fe91:

    # "She looked away, and swallowed her words."
    "Apartó la mirada y se tragó las palabras."

# game/cethin.rpy:810
translate Spanish cethinroute_b46e6184:

    # lumishy "Hm. Yes. Let's end it there."
    lumishy "Hm. Sí. Dejémoslo ahí."

# game/cethin.rpy:812
translate Spanish cethinroute_7e1afcb4:

    # cethin "But I'd really like it if I can..."
    cethin "Pero me gustaría poder..."

# game/cethin.rpy:817
translate Spanish cethinroute_8aca633b:

    # cethin "Oh!"
    cethin "¡Oh!"

# game/cethin.rpy:821
translate Spanish cethinroute_1348b8d5:

    # "The look on his face just screamed: {i}'I've thought of something!'{/i}"
    "La expresión en su rostro gritaba: {i}“¡Se me acaba de ocurrir algo!”{/i}"

# game/cethin.rpy:823
translate Spanish cethinroute_dad29832:

    # "Lumi peered at him curiously."
    "Lumi lo miró con curiosidad."

# game/cethin.rpy:837
translate Spanish cethinroute_fcda0f85:

    # "Cethin closed his eyes and held out his hand, muttering words unknown to the girl."
    "Cethin cerró los ojos y extendió su mano, murmurando palabras desconocidas para la chica."

# game/cethin.rpy:849
translate Spanish cethinroute_08578327:

    # "Just then, light orbs began forming around them."
    "En ese instante, esferas de luz comenzaron a formarse a su alrededor."

# game/cethin.rpy:851
translate Spanish cethinroute_7e1564cc:

    # "The princess could only stare in awe."
    "La princesa solo pudo observar con asombro."

# game/cethin.rpy:853
translate Spanish cethinroute_838d99a9:

    # lumisickshock "It's... beautiful!"
    lumisickshock "¡Es... hermoso!"

# game/cethin.rpy:855
translate Spanish cethinroute_a3a0fbc3:

    # lumishock "Is this magic...?"
    lumishock "¿Es magia...?"

# game/cethin.rpy:857
translate Spanish cethinroute_29c98a88:

    # voice "voice1/line146.mp3"
    # cethin "Yes. We use this spell to light up dark areas."
    voice "voice1/line146.mp3"
    cethin "Sí. Usamos este hechizo para iluminar lugares oscuros."

# game/cethin.rpy:861
translate Spanish cethinroute_0795082a:

    # "The lights flickered about, dancing around them."
    "Las luces parpadeaban, danzando a su alrededor."

# game/cethin.rpy:863
translate Spanish cethinroute_b5bdd4b8:

    # "Lumi chased one of them, and the small orb settled on her hands."
    "Lumi persiguió una de ellas, y la pequeña esfera se posó en sus manos."

# game/cethin.rpy:865
translate Spanish cethinroute_aac10454:

    # "Surprisingly enough, it actually felt cool to the touch."
    "Para su sorpresa, se sentía fresca al tacto."

# game/cethin.rpy:867
translate Spanish cethinroute_0b59dda2:

    # "She cupped it inside her palms, and then released it back into the sky."
    "La sostuvo entre las palmas y luego la liberó hacia el cielo."

# game/cethin.rpy:869
translate Spanish cethinroute_c6ebba3f:

    # "The lights then began to go upward."
    "Las luces comenzaron a elevarse."

# game/cethin.rpy:871
translate Spanish cethinroute_08d5e91a:

    # "Cethin chuckled in the background, while she watched them twirl around in the air."
    "Cethin se reía suavemente al fondo, mientras ella las observaba girar en el aire."

# game/cethin.rpy:873
translate Spanish cethinroute_50e694b7:

    # lumiblush "(He's controlling them isn't he?)"
    lumiblush "(Él las está controlando, ¿verdad?)"

# game/cethin.rpy:875
translate Spanish cethinroute_84e6600d:

    # "The girl huffed."
    "La chica bufó."

# game/cethin.rpy:877
translate Spanish cethinroute_c9984b44:

    # "It was clear that he had been directing the lights in a way that would please her."
    "Era evidente que estaba dirigiendo las luces de una manera que la complaciera."

# game/cethin.rpy:879
translate Spanish cethinroute_32daf4bb:

    # lumishy "(Oh, Cethin...)"
    lumishy "(Oh, Cethin...)"

# game/cethin.rpy:881
translate Spanish cethinroute_ed1d5440:

    # "It was a performance unlike any other."
    "Fue una presentación como ninguna otra."

# game/cethin.rpy:883
translate Spanish cethinroute_de24d53e:

    # voice "voice1/line147.mp3"
    # cethin "Do you like it?"
    voice "voice1/line147.mp3"
    cethin "¿Te gusta?"

# game/cethin.rpy:887
translate Spanish cethinroute_861bdf0f:

    # lumihappy "Verily!"
    lumihappy "¡Por supuesto!"

# game/cethin.rpy:891
translate Spanish cethinroute_d6636a0d:

    # voice "voice1/line148.mp3"
    # cethin "Haha. I'm glad."
    voice "voice1/line148.mp3"
    cethin "Jaja. Me alegra."

# game/cethin.rpy:895
translate Spanish cethinroute_c108890b:

    # "When the dark elf smiled the way he did, the princess felt something leap inside her chest."
    "Cuando el elfo oscuro sonrió de esa manera, la princesa sintió algo saltar dentro de su pecho."

# game/cethin.rpy:897
translate Spanish cethinroute_b9923316:

    # lumishy "(Whatwasthat...?)"
    lumishy "(¿Q-qué fue eso...?)"

# game/cethin.rpy:904
translate Spanish cethinroute_92ba6a33:

    # voice "voice1/line149.mp3"
    # cethin "..."
    voice "voice1/line149.mp3"
    cethin "..."

# game/cethin.rpy:913
translate Spanish cethinroute_5a9f66bf:

    # "Finally, he had sent the lights away with a soft flick of his hand."
    "Finalmente, él hizo desaparecer las luces con un suave movimiento de su mano."

# game/cethin.rpy:915
translate Spanish cethinroute_9b2f07b1:

    # "The lights slowly faded in the darkness."
    "Las luces se desvanecieron lentamente en la oscuridad."

# game/cethin.rpy:917
translate Spanish cethinroute_6d6920ab:

    # voice "voice1/line150.mp3"
    # cethin "Lumi."
    voice "voice1/line150.mp3"
    cethin "Lumi."

# game/cethin.rpy:921
translate Spanish cethinroute_1cd9f5ec:

    # "Cethin made her flinch when he called her name."
    "Cethin la sobresaltó al llamarla por su nombre."

# game/cethin.rpy:923
translate Spanish cethinroute_5a876c75:

    # lumisickshock "(Lumi. Calm down.)"
    lumisickshock "(Lumi. Cálmate.)"

# game/cethin.rpy:925
translate Spanish cethinroute_cbb1fcdc:

    # voice "voice1/line151.mp3"
    # cethin "I've decided. I'll do my best to become worthy of standing by your side."
    voice "voice1/line151.mp3"
    cethin "He decidido. Haré mi mejor esfuerzo para ser digno de estar a tu lado."

# game/cethin.rpy:929
translate Spanish cethinroute_3f0ebce0:

    # voice "voice1/line152.mp3"
    # cethin "So... please wait for me."
    voice "voice1/line152.mp3"
    cethin "Así que... por favor, espérame."

# game/cethin.rpy:933
translate Spanish cethinroute_239e4c63:

    # lumiserious "...?"
    lumiserious "¿...?"

# game/cethin.rpy:939
translate Spanish cethinroute_3b3f38f4:

    # voice "voice1/line153.mp3"
    # cethin "Don't mind what I just said."
    voice "voice1/line153.mp3"
    cethin "No prestes atención a lo que acabo de decir."

# game/cethin.rpy:948
translate Spanish cethinroute_87acb149:

    # voice "voice1/line154.mp3"
    # cethin "If you are cold, we can go back inside."
    voice "voice1/line154.mp3"
    cethin "Si tienes frío, podemos volver adentro."

# game/cethin.rpy:952
translate Spanish cethinroute_98403a4a:

    # "She was confused by his last words, but she really still couldn't process anything."
    "Estaba confundida por sus últimas palabras, pero aún no podía procesar nada."

# game/cethin.rpy:954
translate Spanish cethinroute_3abbdfda:

    # "Something inside her was still beating loudly."
    "Algo dentro de ella seguía latiendo con fuerza."

# game/cethin.rpy:956
translate Spanish cethinroute_9d4b49ac:

    # "Her heart."
    "Su corazón."

# game/cethin.rpy:958
translate Spanish cethinroute_34b456ba:

    # "The only thing that occupied her mind, was the hope that her companion couldn't hear it."
    "Lo único que ocupaba su mente era la esperanza de que su compañero no pudiera oírlo."

# game/cethin.rpy:960
translate Spanish cethinroute_76150e5e:

    # lumishy "(I hope those long ears are just for show...!)" with vpunch
    lumishy "(¡Espero que esas orejas largas sean solo decorativas...!)" with vpunch

# game/cethin.rpy:965
translate Spanish cethinroute_b9aee213:

    # lumishy "Y-yes... I'm quite fatigued."
    lumishy "S-sí... Estoy bastante cansada."

# game/cethin.rpy:967
translate Spanish cethinroute_4a5c8761:

    # lumishy "I think I'll turn in for the night."
    lumishy "Creo que me retiraré por la noche."

# game/cethin.rpy:969
translate Spanish cethinroute_809932e3:

    # lumihappy "Goodnight, Cethin."
    lumihappy "Buenas noches, Cethin."

# game/cethin.rpy:971
translate Spanish cethinroute_396d40f9:

    # voice "voice1/line155.mp3"
    # cethin "Goodnight, Lumi."
    voice "voice1/line155.mp3"
    cethin "Buenas noches, Lumi."

# game/cethin.rpy:977
translate Spanish cethinroute_44524289:

    # lumishy "(What is wrong with me? His smile is driving me mad...)"
    lumishy "(¿Qué me pasa? Su sonrisa me está volviendo loca...)"

# game/cethin.rpy:979
translate Spanish cethinroute_016426db_1:

    # lumishy "..."
    lumishy "..."

# game/cethin.rpy:981
translate Spanish cethinroute_015cf57d:

    # lumishy "(Could it be...?)"
    lumishy "(¿Podría ser...?)"

# game/cethin.rpy:983
translate Spanish cethinroute_4e73b48f:

    # "She froze for a moment."
    "Se quedó inmóvil por un momento."

# game/cethin.rpy:985
translate Spanish cethinroute_92077658:

    # lumisad "{size=-5}No... I shouldn't.{/size}"
    lumisad "{size=-5}No... no debería.{/size}"

# game/cethin.rpy:987
translate Spanish cethinroute_654e1cf9:

    # "The princess pursed her lips and decided to tuck those feelings away."
    "La princesa apretó los labios y decidió guardar esos sentimientos."

# game/cethin.rpy:989
translate Spanish cethinroute_44b90ff7:

    # "She had calmed down."
    "Se había calmado."

# game/cethin.rpy:993
translate Spanish cethinroute_72a80871:

    # "... But all that was left was a feeling of emptiness."
    "... Pero lo único que quedó fue una sensación de vacío."

# game/cethin.rpy:1009
translate Spanish cethinside_47f548bd:

    # voice "voice2/line73.mp3"
    # reo "Oh? Is the lady asleep?"
    voice "voice2/line73.mp3"
    reo "¿Oh? ¿Está dormida la señorita?"

# game/cethin.rpy:1014
translate Spanish cethinside_8a3e29de:

    # voice "voice2/line74.mp3"
    # reo "How was your date? Were you able to give her your little present?"
    voice "voice2/line74.mp3"
    reo "¿Cómo fue tu cita? ¿Pudiste darle tu pequeño regalo?"

# game/cethin.rpy:1020
translate Spanish cethinside_372510fc:

    # voice "voice1/line156.mp3"
    # cethin "I couldn't."
    voice "voice1/line156.mp3"
    cethin "No pude."

# game/cethin.rpy:1025
translate Spanish cethinside_26adbd09:

    # voice "voice2/line75.mp3"
    # reo "Tsk. So you chickened out."
    voice "voice2/line75.mp3"
    reo "Tsk. Así que te acobardaste."

# game/cethin.rpy:1029
translate Spanish cethinside_52fe0e8e:

    # voice "voice2/line76.mp3"
    # reo "You're really a piece of work."
    voice "voice2/line76.mp3"
    reo "Eres todo un caso."

# game/cethin.rpy:1035
translate Spanish cethinside_348b9a66:

    # voice "voice2/line77.mp3"
    # reo "I have never seen a drow as timid as you are."
    voice "voice2/line77.mp3"
    reo "Nunca había visto a un drow tan tímido como tú."

# game/cethin.rpy:1041
translate Spanish cethinside_de151814:

    # voice "voice1/line157.mp3"
    # cethin "..."
    voice "voice1/line157.mp3"
    cethin "..."

# game/cethin.rpy:1048
translate Spanish cethinside_af7f1fc2:

    # voice "voice2/line78.mp3"
    # reo "To think you've been working on that trinket of yours for weeks."
    voice "voice2/line78.mp3"
    reo "Pensar que has estado trabajando en ese amuleto tuyo durante semanas."

# game/cethin.rpy:1053
translate Spanish cethinside_60c8d42a:

    # voice "voice2/line79.mp3"
    # reo "You even hunted down such a rare bird to obtain your materials."
    voice "voice2/line79.mp3"
    reo "Incluso cazaste un ave tan rara para obtener tus materiales."

# game/cethin.rpy:1058
translate Spanish cethinside_62bae33c:

    # voice "voice2/line80.mp3"
    # reo "...And I even had the courtesy to leave the two of you be!"
    voice "voice2/line80.mp3"
    reo "...¡Y aun así tuve la cortesía de dejarlos solos a los dos!"

# game/cethin.rpy:1062
translate Spanish cethinside_b4681882:

    # voice "voice2/line81.mp3"
    # reo "How could you miss such chance?"
    voice "voice2/line81.mp3"
    reo "¿Cómo pudiste perder tal oportunidad?"

# game/cethin.rpy:1066
translate Spanish cethinside_c0aeb191:

    # "The butler nagged as he repeatedly jabbed a finger on the elf's chest."
    "El mayordomo regañó mientras repetidamente le clavaba un dedo en el pecho al elfo."

# game/cethin.rpy:1072
translate Spanish cethinside_6a73e1b4:

    # voice "voice1/line158.mp3"
    # cethin "You knew that Lumi was making me one as well, didn't you?"
    voice "voice1/line158.mp3"
    cethin "Sabías que Lumi también me estaba haciendo uno, ¿verdad?"

# game/cethin.rpy:1079
translate Spanish cethinside_93bc13a6:

    # voice "voice2/line82.mp3"
    # reo "..."
    voice "voice2/line82.mp3"
    reo "..."

# game/cethin.rpy:1083
translate Spanish cethinside_64e9a1dd:

    # voice "voice2/line83.mp3"
    # reo "Whatever are you talking about?"
    voice "voice2/line83.mp3"
    reo "¿De qué hablas?"

# game/cethin.rpy:1089
translate Spanish cethinside_a6ad928a:

    # voice "voice1/line159.mp3"
    # cethin "She couldn't have gotten those materials otherwise."
    voice "voice1/line159.mp3"
    cethin "De otro modo, no podría haber conseguido esos materiales."

# game/cethin.rpy:1096
translate Spanish cethinside_55b8a0a2:

    # voice "voice2/line84.mp3"
    # reo "I... have the right to remain silent."
    voice "voice2/line84.mp3"
    reo "Yo... tengo derecho a guardar silencio."

# game/cethin.rpy:1100
translate Spanish cethinside_065bd7f1:

    # "He replied smugly."
    "Respondió con aire engreído."

# game/cethin.rpy:1106
translate Spanish cethinside_734e51e3:

    # voice "voice1/line160.mp3"
    # cethin "You also knew what it meant for us to do the exchange, didn't you?"
    voice "voice1/line160.mp3"
    cethin "También sabías lo que significaba para nosotros hacer el intercambio, ¿no?"

# game/cethin.rpy:1112
translate Spanish cethinside_0e3fa8f8:

    # voice "voice1/line161.mp3"
    # cethin "Normally, it's a one way exchange for family and friends. It's different when both sides give a trinket..."
    voice "voice1/line161.mp3"
    cethin "Normalmente, es un intercambio unilateral para familia y amigos. Es diferente cuando ambos lados entregan un amuleto..."

# game/cethin.rpy:1117
translate Spanish cethinside_157694a4:

    # voice "voice1/line162.mp3"
    # cethin "It means..."
    voice "voice1/line162.mp3"
    cethin "Significa..."

# game/cethin.rpy:1122
translate Spanish cethinside_bf3128de:

    # voice "voice2/line85.mp3"
    # reo "Reciprocal love."
    voice "voice2/line85.mp3"
    reo "Amor recíproco."

# game/cethin.rpy:1129
translate Spanish cethinside_c4c198d8:

    # voice "voice1/line163.mp3"
    # cethin "..."
    voice "voice1/line163.mp3"
    cethin "..."

# game/cethin.rpy:1134
translate Spanish cethinside_d30ea89b:

    # voice "voice2/line86.mp3"
    # reo "Ahahaha...! I see now why you weren't able to do it!"
    voice "voice2/line86.mp3"
    reo "¡Jajaja...! ¡Ya veo por qué no pudiste hacerlo!"

# game/cethin.rpy:1138
translate Spanish cethinside_053fa4da:

    # voice "voice2/line87.mp3"
    # reo "Goodness... you are far too innocent still."
    voice "voice2/line87.mp3"
    reo "Dioses... sigues siendo demasiado inocente."

# game/cethin.rpy:1142
translate Spanish cethinside_3e24426b:

    # "He knew. He obviously knew from the start."
    "Él lo sabía. Evidentemente lo sabía desde el principio."

# game/cethin.rpy:1144
translate Spanish cethinside_6706ffae:

    # "The butler was definitely just playing with the night elf."
    "El mayordomo definitivamente solo estaba jugando con el elfo nocturno."

# game/cethin.rpy:1148
translate Spanish cethinside_2c9827f1:

    # voice "voice2/line88.mp3"
    # reo "I wish you had given yours first, then when the lady reveals that she has one for you as well..."
    voice "voice2/line88.mp3"
    reo "Ojalá hubieras dado el tuyo primero, y luego, cuando la dama revelara que también tenía uno para ti..."

# game/cethin.rpy:1152
translate Spanish cethinside_c7c51822:

    # voice "voice2/line89.mp3"
    # reo "WELL. That would have been fun."
    voice "voice2/line89.mp3"
    reo "BUENO. Eso habría sido divertido."

# game/cethin.rpy:1158
translate Spanish cethinside_0353ec08:

    # voice "voice1/line164.mp3"
    # cethin "It's... not that."
    voice "voice1/line164.mp3"
    cethin "No es eso..."

# game/cethin.rpy:1164
translate Spanish cethinside_8ed1b888:

    # voice "voice1/line165.mp3"
    # cethin "At least... not only that."
    voice "voice1/line165.mp3"
    cethin "Al menos... no solo eso."

# game/cethin.rpy:1170
translate Spanish cethinside_0e57c050:

    # voice "voice2/line61.mp3"
    # reo "...?"
    voice "voice2/line61.mp3"
    reo "¿...?"

# game/cethin.rpy:1176
translate Spanish cethinside_b86cd885:

    # voice "voice1/line166.mp3"
    # cethin "..."
    voice "voice1/line166.mp3"
    cethin "..."

# game/cethin.rpy:1184
translate Spanish cethinside_25ead9ec:

    # voice "voice1/line167.mp3"
    # cethin "I have a favor."
    voice "voice1/line167.mp3"
    cethin "Tengo un favor."

# game/cethin.rpy:1190
translate Spanish cethinside_9de72d56:

    # voice "voice2/line90.mp3"
    # reo "Mhm. I suppose I'll hear you out first."
    voice "voice2/line90.mp3"
    reo "Mhm. Supongo que primero te escucharé."

# game/cethin.rpy:1197
translate Spanish cethinside_ea596820:

    # voice "voice1/line168.mp3"
    # cethin "Please train me."
    voice "voice1/line168.mp3"
    cethin "Por favor, entrena conmigo."

# game/cethin.rpy:1203
translate Spanish cethinside_9c0d09c4:

    # "The demon butler raised his brows."
    "El mayordomo demonio alzó las cejas."

# game/cethin.rpy:1208
translate Spanish cethinside_573001c2:

    # "And then, he smiled."
    "Y luego, sonrió."

# game/cethin.rpy:1210
translate Spanish cethinside_c6616d00:

    # "With that, a long night passed..."
    "Con eso, pasó una larga noche..."

# game/cethin.rpy:1218
translate Spanish spat_0a118970:

    # "Days have passed since the yule festival, and things have returned to normal."
    "Han pasado días desde el festival de Yule, y las cosas han vuelto a la normalidad."

# game/cethin.rpy:1220
translate Spanish spat_9ce875e9:

    # "Or not."
    "O no."

# game/cethin.rpy:1222
translate Spanish spat_3d0e94ed:

    # "It would be a lie to say that nothing have changed after the yule festival."
    "Sería mentira decir que nada cambió después del festival de Yule."

# game/cethin.rpy:1224
translate Spanish spat_fb37b5ab:

    # "Cethin and Reo have become a rare sight for her, just as how it was back when they've been preparing for the feast."
    "Cethin y Reo casi no se dejaban ver, como cuando preparaban el banquete."

# game/cethin.rpy:1226
translate Spanish spat_860720b4:

    # "... Which unfortunately meant that the princess was back to her dull days."
    "... Lo que, desafortunadamente, significaba que la princesa había vuelto a sus días aburridos."

# game/cethin.rpy:1230
translate Spanish spat_c8d0c62d:

    # lumisad "(But it would be a lie to say that I'm upset to be alone...)"
    lumisad "(Pero sería mentira decir que me molesta estar sola...)"

# game/cethin.rpy:1232
translate Spanish spat_2381d816:

    # "Truthfully, she was rather relieved to not see their faces, especially Cethin's."
    "En verdad, se sentía más bien aliviada de no ver sus rostros, especialmente el de Cethin."

# game/cethin.rpy:1234
translate Spanish spat_1577d0ca:

    # lumishy "(Somehow, I feel breathless whenever he's around.)"
    lumishy "(De algún modo, me falta el aire cada vez que está cerca.)"

# game/cethin.rpy:1236
translate Spanish spat_0ffe795a:

    # lumishy "(I just cannot keep calm.)"
    lumishy "(No puedo mantener la calma.)"

# game/cethin.rpy:1238
translate Spanish spat_60a55d2e:

    # "She closed her eyes as she laid flat on her bed, with both arms outstretched."
    "Cerró los ojos mientras yacía boca arriba en su cama, con ambos brazos extendidos."

# game/cethin.rpy:1240
translate Spanish spat_b578f506:

    # lumishy "I was hoping that feeling was only due to the atmosphere that night, or something of the like..."
    lumishy "Esperaba que ese sentimiento solo se debiera al ambiente de aquella noche, o algo por el estilo..."

# game/cethin.rpy:1242
translate Spanish spat_0404e00b:

    # lumishy "If only it went away a day after... or the next. Or the next one after that..."
    lumishy "Si tan solo hubiera desaparecido un día después... o el siguiente. O el de después..."

# game/cethin.rpy:1244
translate Spanish spat_fee068d3:

    # lumisad "Whenever he isn't around, I keep thinking about him."
    lumisad "Siempre que él no está cerca, sigo pensando en él."

# game/cethin.rpy:1246
translate Spanish spat_41aa2df2:

    # "The girl muttered to herself."
    "La chica murmuró para sí misma."

# game/cethin.rpy:1248
translate Spanish spat_c1b5af06:

    # lumishy "... But if it is like this-"
    lumishy "... Pero si es así-"

# game/cethin.rpy:1250
translate Spanish spat_4ed72ea3:

    # "She grabbed a pillow and buried her face with it."
    "Tomó una almohada y enterró su rostro en ella."

# game/cethin.rpy:1252
translate Spanish spat_e5173726:

    # lumisad "(Then...)"
    lumisad "(Entonces...)"

# game/cethin.rpy:1259
translate Spanish spat_9fba5c8c:

    # lumisad "(I've read enough novels to know these symptoms...)"
    lumisad "(He leído suficientes novelas para saber estos síntomas...)"

# game/cethin.rpy:1261
translate Spanish spat_bf9600cf:

    # lumishy "(I'm... in love with Cethin, aren't I?)"
    lumishy "(Estoy... enamorada de Cethin, ¿verdad?)"

# game/cethin.rpy:1267
translate Spanish spat_016426db:

    # lumishy "..."
    lumishy "..."

# game/cethin.rpy:1269
translate Spanish spat_7a2b46a8:

    # lumided "I've got nothing..."
    lumided "No tengo nada..."

# game/cethin.rpy:1271
translate Spanish spat_f41901fa:

    # "She sighed."
    "Suspiró."

# game/cethin.rpy:1275
translate Spanish spat_1d87fc2b:

    # reo "Oh princess, may I come in?"
    reo "Oh princesa, ¿puedo entrar?"

# game/cethin.rpy:1277
translate Spanish spat_469bf34c:

    # "Reo's voice came from the other side of the door."
    "La voz de Reo vino del otro lado de la puerta."

# game/cethin.rpy:1279
translate Spanish spat_5ab131ee:

    # "Lumi sat up and set her pillow aside to welcome him in."
    "Lumi se incorporó y dejó la almohada a un lado para recibirlo."

# game/cethin.rpy:1281
translate Spanish spat_c113ddf4:

    # lumitalk "Very well. Come in."
    lumitalk "Muy bien. Entra."

# game/cethin.rpy:1288
translate Spanish spat_2c0742bd:

    # reo "Excuse me then."
    reo "Entonces, con permiso."

# game/cethin.rpy:1292
translate Spanish spat_47757a1b:

    # reo "Let's see... did you move the laundry by any chance?"
    reo "Veamos... ¿moviste la colada por casualidad?"

# game/cethin.rpy:1296
translate Spanish spat_0ac4d45a:

    # lumi "It should be beside the tub."
    lumi "Debería estar junto a la tina."

# game/cethin.rpy:1300
translate Spanish spat_4ddc510c:

    # reo "I see. Thank you."
    reo "Ya veo. Gracias."

# game/cethin.rpy:1308
translate Spanish spat_01dd5c3e:

    # "Lumi lazily watched the butler tend to his work."
    "Lumi observó perezosamente al mayordomo atender sus tareas."

# game/cethin.rpy:1310
translate Spanish spat_1b0fc568:

    # lumitalk "Reo?"
    lumitalk "¿Reo?"

# game/cethin.rpy:1312
translate Spanish spat_fe23b57e:

    # reo "Go on milady. If you have anything to ask, just say it."
    reo "Adelante, mi señora. Si tienes algo que preguntar, solo dilo."

# game/cethin.rpy:1314
translate Spanish spat_42b64cfa:

    # reo "I have all day, but I'd rather not give them all to you."
    reo "Tengo todo el día, pero preferiría no dártelo por completo."

# game/cethin.rpy:1316
translate Spanish spat_a1a7e4aa:

    # reo "Nor do I have the energy to get in between your lover's spat."
    reo "Ni tengo la energía para entrometerme en la pelea de pareja de ustedes."

# game/cethin.rpy:1318
translate Spanish spat_9826d1d2:

    # lumiuwu "We are not in a spat...!"
    lumiuwu "¡No estamos peleando...!"

# game/cethin.rpy:1320
translate Spanish spat_3ddd991b:

    # "A pause."
    "Una pausa."

# game/cethin.rpy:1322
translate Spanish spat_a36edb70:

    # lumiuwu "N-nor are we even lovers!"
    lumiuwu "¡N-ni siquiera somos pareja!"

# game/cethin.rpy:1328
translate Spanish spat_f18fc33f:

    # reo "Haha. I know."
    reo "Jaja. Lo sé."

# game/cethin.rpy:1330
translate Spanish spat_59565992:

    # reo "You should have seen your face. Why, it is as ripe as a tomato."
    reo "Deberías haberte visto la cara. Vaya, está tan roja como un tomate."

# game/cethin.rpy:1332
translate Spanish spat_30107198:

    # lumiserious "You're insufferable."
    lumiserious "Eres insufrible."

# game/cethin.rpy:1336
translate Spanish spat_c0825efd:

    # reo "I'm sorry. I simply couldn't help it."
    reo "Lo siento. Simplemente no pude evitarlo."

# game/cethin.rpy:1338
translate Spanish spat_d28235f7:

    # reo "You are far too adorable."
    reo "Eres demasiado adorable."

# game/cethin.rpy:1340
translate Spanish spat_fda8bc47:

    # lumided "Such empty flattery would not work on me."
    lumided "Esa adulación vacía no funcionará conmigo."

# game/cethin.rpy:1342
translate Spanish spat_f1da4ac1:

    # "She huffed, crossing her arms over her chest."
    "Resopló, cruzando los brazos sobre el pecho."

# game/cethin.rpy:1346
translate Spanish spat_d8016488:

    # reo "I tried."
    reo "Lo intenté."

# game/cethin.rpy:1352
translate Spanish spat_6599e31a:

    # reo "Well then, if you do not need anything else..."
    reo "Bueno entonces, si no necesitas nada más..."

# game/cethin.rpy:1354
translate Spanish spat_6d574c01:

    # "He was ready to leave with the basket of laundry on his hands-"
    "Estaba listo para irse con la cesta de ropa en sus manos-"

# game/cethin.rpy:1356
translate Spanish spat_680710dd:

    # lumitalk "I do. That was why I called your attention in the first place."
    lumitalk "Sí necesito. Por eso llamé tu atención desde el principio."

# game/cethin.rpy:1358
translate Spanish spat_d44bedc3:

    # lumiserious "Do not think your distraction would work on me."
    lumiserious "No creas que tu distracción funcionará conmigo."

# game/cethin.rpy:1364
translate Spanish spat_c96e4672:

    # reo "Oop. You got me."
    reo "Ups. Me atrapaste."

# game/cethin.rpy:1368
translate Spanish spat_92b2c185:

    # reo "Fine. Shoot your question, milady."
    reo "Bien. Dispara tu pregunta, mi señora."

# game/cethin.rpy:1370
translate Spanish spat_bde84069:

    # lumisad "What has Cethin been up to, anyway?"
    lumisad "¿Qué ha estado haciendo Cethin, de todos modos?"

# game/cethin.rpy:1372
translate Spanish spat_1e6bdb73:

    # lumitalk "He only comes in to bring my meals, but he goes off immediately right after."
    lumitalk "Solo entra para traerme las comidas, pero se va inmediatamente después."

# game/cethin.rpy:1374
translate Spanish spat_ce559afc:

    # lumisad "I rarely see him these days."
    lumisad "Rara vez lo veo estos días."

# game/cethin.rpy:1376
translate Spanish spat_d069e6bc:

    # lumisad "The only reason I'm letting him be was because he said he was working on something with you..."
    lumisad "La única razón por la que lo dejo tranquilo es porque dijo que estaba trabajando en algo contigo..."

# game/cethin.rpy:1378
translate Spanish spat_ac6fcbeb:

    # lumisad "... But here you are!"
    lumisad "... ¡Pero aquí estás tú!"

# game/cethin.rpy:1380
translate Spanish spat_6498f511:

    # "The girl pouted. It was obvious what she was implying."
    "La chica hizo un puchero. Era obvio lo que estaba insinuando."

# game/cethin.rpy:1384
translate Spanish spat_ec699fbb:

    # reo "Hm~ should I tell you or should I not?"
    reo "Hm~ ¿debería decirte o no?"

# game/cethin.rpy:1386
translate Spanish spat_d29e749a:

    # reo "It's not like I promised him that I wouldn't..."
    reo "No es como si le hubiera prometido que no lo haría..."

# game/cethin.rpy:1388
translate Spanish spat_63252cfd:

    # "He said in a teasing tone."
    "Dijo con un tono burlón."

# game/cethin.rpy:1390
translate Spanish spat_6de3e47e:

    # lumided "Then just tell me."
    lumided "Entonces solo dímelo."

# game/cethin.rpy:1394
translate Spanish spat_cde44289:

    # reo "In any case- I assure you that he did not lie this time."
    reo "En cualquier caso, te aseguro que esta vez no mintió."

# game/cethin.rpy:1398
translate Spanish spat_bad040f1:

    # reo "I left him with a task, so I bequeathed him to work on that."
    reo "Le dejé una tarea, así que le encargué que trabajara en eso."

# game/cethin.rpy:1400
translate Spanish spat_4e3ac053:

    # lumishock "Do not tell me you took him in as a staff...?"
    lumishock "¿No me digas que lo tomaste como parte del personal...?"

# game/cethin.rpy:1404
translate Spanish spat_d0e877df:

    # reo "Why, I would have done that earlier if I could!"
    reo "¡Vaya, lo habría hecho antes si pudiera!"

# game/cethin.rpy:1406
translate Spanish spat_ca937548:

    # reo "The drow's a hard worker, I'll give him that."
    reo "El drow es un trabajador incansable, eso sí te lo concedo."

# game/cethin.rpy:1410
translate Spanish spat_6f4f3747:

    # reo "But no. I did not."
    reo "Pero no. No lo hice."

# game/cethin.rpy:1414
translate Spanish spat_2d7ea4e9:

    # reo "All I can tell you is that: he is doing this all... for your sake."
    reo "Todo lo que puedo decirte es que: él está haciendo todo esto... por tu bien."

# game/cethin.rpy:1416
translate Spanish spat_4fc006ea:

    # "He said with a wink."
    "Dijo con un guiño."

# game/cethin.rpy:1418
translate Spanish spat_83b9d7c2:

    # lumi "...?"
    lumi "¿...?"

# game/cethin.rpy:1422
translate Spanish spat_3792df7d:

    # reo "That said, it'd be best if you hear it from him yourself."
    reo "Dicho esto, sería mejor que lo oyeras de él mismo."

# game/cethin.rpy:1426
translate Spanish spat_8d7d2a25:

    # reo "Things rarely ever go well when you involve a third party, at least, I think so."
    reo "Las cosas rara vez salen bien cuando involucras a un tercero, al menos, eso creo."

# game/cethin.rpy:1428
translate Spanish spat_31cef7bd:

    # reo "If nothing more, then I shall get going."
    reo "Si no hay nada más, entonces me retiraré."

# game/cethin.rpy:1436
translate Spanish spat_d9dc827a:

    # "The princess once again grabbed a pillow and hugged it close to her."
    "La princesa volvió a tomar una almohada y la abrazó con fuerza."

# game/cethin.rpy:1438
translate Spanish spat_ba61abf9:

    # lumishy "For me...?"
    lumishy "¿Por mí...?"

# game/cethin.rpy:1440
translate Spanish spat_8fdfdc91:

    # lumisad "(Training, huh? I think I know what is on his mind.)"
    lumisad "(¿Entrenamiento, eh? Creo que sé lo que tiene en mente.)"

# game/cethin.rpy:1442
translate Spanish spat_27fec60a:

    # lumisad "(But why...?)"
    lumisad "(¿Pero por qué...?)"

# game/cethin.rpy:1444
translate Spanish spat_0d0bd527:

    # lumishy "(Don't tell me... he's trying to...?)"
    lumishy "(No me digas... que está intentando...?)"

# game/cethin.rpy:1446
translate Spanish spat_016426db_1:

    # lumishy "..."
    lumishy "..."

# game/cethin.rpy:1450
translate Spanish spat_76c65d02:

    # lumishy "... How foolish."
    lumishy "... Qué tonto."

# game/cethin.rpy:1457
translate Spanish returnparty_0d88853e:

    # "Peaceful days passed, yet the season never changed."
    "Los días pacíficos pasaron, y sin embargo la estación nunca cambió."

# game/cethin.rpy:1459
translate Spanish returnparty_68c9e11c:

    # "Despite the hint Reo had left her, Lumi couldn't bring herself to ask Cethin about what had been going on with him."
    "A pesar de la pista que Reo le había dejado, Lumi no pudo reunir el valor para preguntarle a Cethin qué había estado haciendo."

# game/cethin.rpy:1461
translate Spanish returnparty_95275a43:

    # "Their everyday was tranquil and unchanging, yet every moment they spent together, no matter how short, was precious."
    "Sus días eran tranquilos e invariables, pero cada momento que pasaban juntos, por corto que fuera, era precioso."

# game/cethin.rpy:1463
translate Spanish returnparty_87a11099:

    # "... But perhaps, this was simply the calm before the storm?"
    "... Pero quizás, ¿esto era simplemente la calma antes de la tormenta?"

# game/cethin.rpy:1476
translate Spanish returnparty_faa11539:

    # lumishock "What the-" with vpunch
    lumishock "Qué de-" with vpunch

# game/cethin.rpy:1480
translate Spanish returnparty_7d48d068:

    # "The princess almost leapt from the sudden noise."
    "La princesa casi saltó del susto por el ruido repentino."

# game/cethin.rpy:1482
translate Spanish returnparty_6747f992:

    # "It was a seemingly ordinary day."
    "Era un día aparentemente normal."

# game/cethin.rpy:1484
translate Spanish returnparty_bfdd78ee:

    # "Just as usual, Cethin made breakfast, had a chat with Lumi and went off somewhere."
    "Como de costumbre, Cethin preparó el desayuno, charló con Lumi y se fue a algún lugar."

# game/cethin.rpy:1486
translate Spanish returnparty_3bb9e6e4:

    # "Reo was out taking care of his duties, and the princess was left lounging in her room."
    "Reo estaba fuera cumpliendo con sus deberes, y la princesa se encontraba descansando en su habitación."

# game/cethin.rpy:1488
translate Spanish returnparty_365cc1f1:

    # "-That was when an explosion shook her up."
    "-Fue entonces cuando una explosión la sobresaltó."

# game/cethin.rpy:1492
translate Spanish returnparty_6019af56:

    # "She got on her feet and grabbed Reo's bell-{w} it was for calling him in case of emergency... though she had never really tried it out." with vpunch
    "Se puso de pie y tomó la campanilla de Reo-{w} era para llamarlo en caso de emergencia... aunque nunca la había usado en realidad." with vpunch

# game/cethin.rpy:1494
translate Spanish returnparty_e536ad10:

    # lumishock "(What's going on?)"
    lumishock "(¿Qué está pasando?)"

# game/cethin.rpy:1496
translate Spanish returnparty_8de47857:

    # "With most of her days being the same routine day in and day out, a sudden event like this easily blew bubbles of anxiety inside her."
    "Con la mayoría de sus días siendo la misma rutina, un evento repentino como este fácilmente hizo estallar burbujas de ansiedad dentro de ella."

# game/cethin.rpy:1498
translate Spanish returnparty_31ade39d:

    # "The girl held the bell close to her chest, ready to use it anytime, when-"
    "La chica sostuvo la campanilla cerca de su pecho, lista para usarla en cualquier momento, cuando-"

# game/cethin.rpy:1502
translate Spanish returnparty_48056cb6:

    # lumisad "(Thank goodness, Reo...!{w} But why didn't he kno-)"
    lumisad "(¡Gracias a los cielos, Reo...!{w} Pero por qué no sabí-)"

# game/cethin.rpy:1508
translate Spanish returnparty_4cfacd05:

    # voice "voice3/f1.mp3"
    # who "Oh Princess Lumi! We've finally found you!"
    voice "voice3/f1.mp3"
    who "¡Oh, princesa Lumi! ¡Por fin la encontramos!"

# game/cethin.rpy:1514
translate Spanish returnparty_e2929e57:

    # "The princess froze in place, as three strangers stepped inside her room without warning."
    "La princesa se quedó helada en el lugar, mientras tres desconocidos entraban en su habitación sin previo aviso."

# game/cethin.rpy:1516
translate Spanish returnparty_a64209cb:

    # "... But it would be a lie to say that she had no idea who they could be."
    "... Pero sería mentira decir que no tenía idea de quiénes podían ser."

# game/cethin.rpy:1518
translate Spanish returnparty_bf710441:

    # lumishock "Hero...?"
    lumishock "¿Héroe...?"

# game/cethin.rpy:1520
translate Spanish returnparty_30c50457:

    # "The man's eyes sparkled."
    "Los ojos del hombre brillaron."

# game/cethin.rpy:1524
translate Spanish returnparty_595a8ec2:

    # voice "voice3/f2.mp3"
    # hero "Indeed, it is I! One of the heroes chosen by your dear father, his highness."
    voice "voice3/f2.mp3"
    hero "¡En efecto, soy yo! Uno de los héroes elegidos por su amado padre, su alteza."

# game/cethin.rpy:1528
translate Spanish returnparty_5c22b7e5:

    # "Behind him were two women."
    "Detrás de él había dos mujeres."

# game/cethin.rpy:1530
translate Spanish returnparty_d6aa112d:

    # "One clad in black robes and the other in white."
    "Una vestida con túnicas negras y la otra con blancas."

# game/cethin.rpy:1532
translate Spanish returnparty_b4d50019:

    # "It wasn't difficult to tell that one was a white mage and the other was a black mage."
    "No era difícil deducir que una era maga de luz y la otra una maga oscura."

# game/cethin.rpy:1536
translate Spanish returnparty_e505dac2:

    # voice "voice3/f3.mp3"
    # hero "I apologize for the long wait... alas, it was a treacherous path we had to tread!"
    voice "voice3/f3.mp3"
    hero "Disculpe la larga espera... ¡ay, fue un camino traicionero el que tuvimos que recorrer!"

# game/cethin.rpy:1542
translate Spanish returnparty_6218558a:

    # voice "voice3/f4.mp3"
    # hero "Now, you are safe within our arms."
    voice "voice3/f4.mp3"
    hero "Ahora, está a salvo en nuestros brazos."

# game/cethin.rpy:1546
translate Spanish returnparty_43eb5e0c:

    # voice "voice3/f5.mp3"
    # hero "You have nothing more to fear!"
    voice "voice3/f5.mp3"
    hero "¡No tiene nada más que temer!"

# game/cethin.rpy:1550
translate Spanish returnparty_286f07a3:

    # "The man was just as how she had always imagined her hero to be like- a strong looking build, golden hair and crystal blue eyes."
    "El hombre era exactamente como siempre había imaginado que sería su héroe: de complexión fuerte, cabello dorado y ojos azul cristal."

# game/cethin.rpy:1552
translate Spanish returnparty_1d48469b:

    # "Yes, that was her type."
    "Sí, ese era su tipo."

# game/cethin.rpy:1557
translate Spanish returnparty_36922c3c:

    # "He kneeled in front of her, just as Cethin did when they first met."
    "Se arrodilló ante ella, tal como Cethin lo hizo la primera vez que se conocieron."

# game/cethin.rpy:1559
translate Spanish returnparty_65105050:

    # "However, instead of happiness... all she felt was discomfort."
    "Sin embargo, en lugar de felicidad... lo que sintió fue incomodidad."

# game/cethin.rpy:1561
translate Spanish returnparty_c1309b88:

    # "Why? Why was this happening now...?"
    "¿Por qué? ¿Por qué estaba ocurriendo esto ahora...?"

# game/cethin.rpy:1563
translate Spanish returnparty_db91d1e5:

    # lumisad "Oh... yes. Welcome, brave hero."
    lumisad "Oh... sí. Bienvenido, valiente héroe."

# game/cethin.rpy:1565
translate Spanish returnparty_cb0a5812:

    # "She replied without a hint of enthusiasm."
    "Respondió sin un atisbo de entusiasmo."

# game/cethin.rpy:1567
translate Spanish returnparty_9a00113a:

    # "This was nothing close to any of her earnest hero-welcoming practice attempts."
    "Esto no se parecía en nada a ninguno de sus ensayos para recibir a un héroe con fervor."

# game/cethin.rpy:1569
translate Spanish returnparty_beb5177c:

    # lumiuwu "(Cethin? Reo? Where are you two?!)" with vpunch
    lumiuwu "(¿Cethin? ¿Reo? ¿Dónde están los dos?!)" with vpunch

# game/cethin.rpy:1571
translate Spanish returnparty_64ab8c1f:

    # "The man didn't budge from his position, and kept his head down, as if he was waiting for something."
    "El hombre no se movió de su posición y mantuvo la cabeza baja, como si esperara algo."

# game/cethin.rpy:1573
translate Spanish returnparty_a0b62e7c:

    # "Behind him, his two companions also watched, with brows starting to furrow as if noticing that something was amiss."
    "Detrás de él, sus dos compañeras observaban también, con los ceños fruncidos, notando que algo no andaba bien."

# game/cethin.rpy:1575
translate Spanish returnparty_75a46040:

    # lumiawk "(Right... as per custom...)"
    lumiawk "(Cierto... según la costumbre...)"

# game/cethin.rpy:1583
translate Spanish returnparty_7a68b79e:

    # "The girl swallowed and held out her hand, and just as Cethin did, the man brought it to his lips."
    "La chica tragó saliva y extendió su mano, y justo como lo hizo Cethin, el hombre la llevó a sus labios."

# game/cethin.rpy:1591
translate Spanish returnparty_11f2e3e8:

    # "-And then she immediately pulled back."
    "-Y entonces se apartó de inmediato."

# game/cethin.rpy:1593
translate Spanish returnparty_5d6458ac:

    # "He noticed her aversion, but he seemed to at least have some tact and pretended as if it didn't happen."
    "Él notó su rechazo, pero pareció tener algo de tacto y fingió que no había pasado nada."

# game/cethin.rpy:1596
translate Spanish returnparty_39d76b21:

    # voice "voice3/f6.mp3"
    # hero "I know not what the princess has gone through, but you are safe now."
    voice "voice3/f6.mp3"
    hero "No sé por lo que habrá pasado la princesa, pero ahora está a salvo."

# game/cethin.rpy:1601
translate Spanish returnparty_4e38ee3c:

    # voice "voice3/f7.mp3"
    # hero "Let us go! We shall lead you out and then vanquish the demon lord."
    voice "voice3/f7.mp3"
    hero "¡Vayamos! La guiaremos afuera y luego venceremos al señor demonio."

# game/cethin.rpy:1605
translate Spanish returnparty_b8462a97:

    # "The girl blinked."
    "La chica parpadeó."

# game/cethin.rpy:1607
translate Spanish returnparty_4e3d672e:

    # lumitalk "You still have not done so?"
    lumitalk "¿Aún no lo han hecho?"

# game/cethin.rpy:1609
translate Spanish returnparty_43371d64:

    # voice "voice3/f8.mp3"
    voice "voice3/f8.mp3"

# game/cethin.rpy:1612
translate Spanish returnparty_7da8ec26:

    # hero "Unfortunately, but with your blessing, I am sure that we can-"
    hero "Lamentablemente, pero con su bendición, estoy seguro de que podemos-"

# game/cethin.rpy:1621
translate Spanish returnparty_d94c232e:

    # voice "voice1/line168-5.mp3"
    # cethin "Lumi...! I hurried as soon as Reo-"
    voice "voice1/line168-5.mp3"
    cethin "¡Lumi...! Me apresuré en cuanto Reo-"

# game/cethin.rpy:1625
translate Spanish returnparty_23f7cdb9:

    # "Lumi turned around, to see Cethin leaping in from the balcony- his personal entrance and exit door."
    "Lumi se dio la vuelta para ver a Cethin saltar desde el balcón, su puerta personal de entrada y salida."

# game/cethin.rpy:1629
translate Spanish returnparty_c51ad32f:

    # "However, he stopped on his tracks the moment his eyes met the others' inside the room."
    "Sin embargo, se detuvo en seco en cuanto sus ojos se encontraron con los de los demás dentro de la habitación."

# game/cethin.rpy:1631
translate Spanish returnparty_684abb0e:

    # voice "voice1/line169.mp3"
    # cethin "Farol...?"
    voice "voice1/line169.mp3"
    cethin "¿Farol...?"

# game/cethin.rpy:1637
translate Spanish returnparty_69255273:

    # voice "voice3/f9.mp3"
    # hero "The luggage mule? You're alive!?"
    voice "voice3/f9.mp3"
    hero "¿La mula de carga? ¿¡Estás vivo!?"

# game/cethin.rpy:1643
translate Spanish returnparty_e599682b:

    # "Lumi blinked, and her eyes went back and forth between the two."
    "Lumi parpadeó, y sus ojos fueron de uno a otro."

# game/cethin.rpy:1645
translate Spanish returnparty_7c725ecd:

    # lumiserious "What 'luggage mule'?"
    lumiserious "¿Qué “mula de carga”?"

# game/cethin.rpy:1648
translate Spanish returnparty_e465a2d4:

    # voice "voice3/f10.mp3"
    # hero "Oh princess, I hope you do not mind that foul cur!"
    voice "voice3/f10.mp3"
    hero "Oh princesa, espero que no le moleste ese sucio perro."

# game/cethin.rpy:1654
translate Spanish returnparty_6b8959d6:

    # "The princess was all sorts of confused, but she definitely wasn't happy with that offhanded insult on Cethin."
    "La princesa estaba totalmente confundida, pero definitivamente no le agradó ese insulto tan descarado hacia Cethin."

# game/cethin.rpy:1656
translate Spanish returnparty_82f88741:

    # "Part of her wanted to believe that she just heard wrong."
    "Parte de ella quería creer que había escuchado mal."

# game/cethin.rpy:1660
translate Spanish returnparty_cf9366b6:

    # voice "voice3/f11.mp3"
    # hero "We were kind enough to take this drow in our party, despite his lack of well... everything."
    voice "voice3/f11.mp3"
    hero "Fuimos lo bastante amables como para aceptar a este drow en nuestro grupo, a pesar de su falta de... bueno, de todo."

# game/cethin.rpy:1668
translate Spanish returnparty_5958ef4b:

    # voice "voice3/w1.mp3"
    # mage "We even had him do the easiest work! He just had to carry our things~"
    voice "voice3/w1.mp3"
    mage "¡Incluso le dimos el trabajo más fácil! Solo tenía que cargar nuestras cosas~"

# game/cethin.rpy:1672
translate Spanish returnparty_05bcd463:

    # "The lady at the back chimed in."
    "Intervino la dama del fondo."

# game/cethin.rpy:1674
translate Spanish returnparty_de446a54:

    # voice "voice3/b1.mp3"
    # darkmage "Uh-huh. We picked him up because no one else wanted to take him in."
    voice "voice3/b1.mp3"
    darkmage "Ajá. Lo recogimos porque nadie más quiso llevarlo."

# game/cethin.rpy:1678
translate Spanish returnparty_8b9a9ed9:

    # "The other one added in deadpan."
    "Agregó la otra, con tono plano."

# game/cethin.rpy:1680
translate Spanish returnparty_11493011:

    # voice "voice3/b2.mp3"
    # darkmage "He couldn't fight, he couldn't sing, he couldn't charm... what a useless bard, right?"
    voice "voice3/b2.mp3"
    darkmage "No podía pelear, no podía cantar, no podía encantar... qué bardo tan inútil, ¿verdad?"

# game/cethin.rpy:1684
translate Spanish returnparty_4f16668d:

    # voice "voice3/b3.mp3"
    # darkmage "Even the inn kicked him out because he was both an earsore and an eyesore."
    voice "voice3/b3.mp3"
    darkmage "Incluso en la posada lo echaron porque era tanto una molestia para los oídos como para la vista."

# game/cethin.rpy:1688
translate Spanish returnparty_f00c82aa:

    # voice "voice3/b4.mp3"
    # darkmage "Funny, right?"
    voice "voice3/b4.mp3"
    darkmage "Gracioso, ¿no?"

# game/cethin.rpy:1694
translate Spanish returnparty_87224684:

    # voice "voice3/f12.mp3"
    # hero "... But he left us when we were overwhelmed the first time we arrived here."
    voice "voice3/f12.mp3"
    hero "... Pero nos dejó cuando fuimos superados la primera vez que llegamos aquí."

# game/cethin.rpy:1698
translate Spanish returnparty_4f8709cd:

    # voice "voice3/w2.mp3"
    # mage "We thought that he died already. I guess drows are kind of like weed. Unwanted but resilient."
    voice "voice3/w2.mp3"
    mage "Pensamos que ya había muerto. Supongo que los drows son como la mala hierba. No deseados pero resistentes."

# game/cethin.rpy:1702
translate Spanish returnparty_de5a9c2b:

    # "The mage at the back added again."
    "Añadió de nuevo la maga del fondo."

# game/cethin.rpy:1709
translate Spanish returnparty_ed94d824:

    # voice "voice1/line170.mp3"
    # cethin "No- Lumi, I can expl-"
    voice "voice1/line170.mp3"
    cethin "No- Lumi, puedo expl-"

# game/cethin.rpy:1726
translate Spanish returnparty_588ef4ae:

    # voice "voice3/f13.mp3"
    # hero "Hold it right there drow!" with vpunch
    voice "voice3/f13.mp3"
    hero "¡Detente ahí mismo, drow!" with vpunch

# game/cethin.rpy:1730
translate Spanish returnparty_429b8191:

    # voice "voice3/f14.mp3"
    # hero "How dare you try to get close to the princess?!"
    voice "voice3/f14.mp3"
    hero "¡¿Cómo te atreves a intentar acercarte a la princesa?!"

# game/cethin.rpy:1734
translate Spanish returnparty_93f3d60e:

    # "His outburst made Cethin freeze right then and there."
    "Su arrebato hizo que Cethin se quedara paralizado en el acto."

# game/cethin.rpy:1739
translate Spanish returnparty_3ef19428:

    # voice "voice3/f15-5.mp3"
    # hero "And to even utter her name?! How shameless!" with vpunch
    voice "voice3/f15-5.mp3"
    hero "¡¿Y encima te atreves a pronunciar su nombre?! ¡Qué descaro!" with vpunch

# game/cethin.rpy:1743
translate Spanish returnparty_811da481:

    # voice "voice3/f15.mp3"
    # hero "You must be taught a lesson."
    voice "voice3/f15.mp3"
    hero "Debes recibir una lección."

# game/cethin.rpy:1756
translate Spanish returnparty_8ad96f41:

    # "The man placed a hand on his sword's hilt, readying to draw it out-"
    "El hombre colocó una mano sobre el pomo de su espada, preparándose para desenvainarla-"

# game/cethin.rpy:1758
translate Spanish returnparty_6c284b92:

    # lumiserious "{b}ENOUGH.{/b}"
    lumiserious "{b}BASTA.{/b}"

# game/cethin.rpy:1760
translate Spanish returnparty_67d56820:

    # lumiserious "You dare attempt to shed blood in my room?"
    lumiserious "¿Te atreves a intentar derramar sangre en mi habitación?"

# game/cethin.rpy:1762
translate Spanish returnparty_b523b8bf:

    # "-But he paused as the princess' cold voice pierced him."
    "-Pero se detuvo cuando la fría voz de la princesa lo atravesó."

# game/cethin.rpy:1767
translate Spanish returnparty_5999427d:

    # voice "voice3/f16.mp3"
    # hero "Apologies. I hope you were not too offended by this tactless whelp."
    voice "voice3/f16.mp3"
    hero "Mis disculpas. Espero que no se haya sentido demasiado ofendida por este necio sin modales."

# game/cethin.rpy:1771
translate Spanish returnparty_c2510400:

    # "The man continued as he relaxed his stance."
    "Continuó el hombre mientras relajaba su postura."

# game/cethin.rpy:1775
translate Spanish returnparty_e2fc2ec8:

    # voice "voice3/f17.mp3"
    # hero "Don't worry, I'll make sure that he'd learn his lesson later."
    voice "voice3/f17.mp3"
    hero "No se preocupe, me aseguraré de que aprenda su lección más tarde."

# game/cethin.rpy:1781
translate Spanish returnparty_a1917fcb:

    # lumiserious "So, you really did abandon him?"
    lumiserious "Entonces, ¿de verdad lo abandonaron?"

# game/cethin.rpy:1783
translate Spanish returnparty_fbf646a0:

    # lumiserious "You wilfully left him to fend for himself?"
    lumiserious "¿Lo dejaron deliberadamente a su suerte?"

# game/cethin.rpy:1785
translate Spanish returnparty_e15e1aa7:

    # lumisad "Here-{w} in the most dangerous demonic beast stronghold of the kingdom?"
    lumisad "¿Aquí-{w} en el más peligroso bastión de bestias demoníacas del reino?"

# game/cethin.rpy:1787
translate Spanish returnparty_293c5b8e:

    # "Ignoring his previous statements, the princess continued her line of inquiry."
    "Ignorando sus declaraciones anteriores, la princesa continuó con su interrogatorio."

# game/cethin.rpy:1789
translate Spanish returnparty_e6805955:

    # "Her voice was unlike usual. It was frigid and sharp."
    "Su voz no era la de siempre. Era gélida y cortante."

# game/cethin.rpy:1792
translate Spanish returnparty_a9b5beb2:

    # voice "voice3/f18.mp3"
    # hero "Your kindness is truly immeasurable, princess."
    voice "voice3/f18.mp3"
    hero "Tu amabilidad es realmente inconmensurable, princesa."

# game/cethin.rpy:1798
translate Spanish returnparty_8a09d339:

    # voice "voice3/f19.mp3"
    # hero "However, it's not like we could turn back just to save a mere drow... I hope you understand."
    voice "voice3/f19.mp3"
    hero "Sin embargo, no es como si pudiéramos regresar solo para salvar a un simple drow... Espero que lo entiendas."

# game/cethin.rpy:1804
translate Spanish returnparty_b7930f3e:

    # lumihappy "I see. At least you're {b}honest{/b}."
    lumihappy "Ya veo. Al menos eres {b}honesto{/b}."

# game/cethin.rpy:1821
translate Spanish returnparty_55fe34b3:

    # "She peered into Cethin for a moment, which made him flinch."
    "Ella lo miró fijamente por un momento, lo que hizo que Cethin se estremeciera."

# game/cethin.rpy:1823
translate Spanish returnparty_bd15ec82:

    # "Of course he could understand that look."
    "Por supuesto que podía entender esa mirada."

# game/cethin.rpy:1825
translate Spanish returnparty_87c9adf2:

    # "He lied to her."
    "Le mintió."

# game/cethin.rpy:1827
translate Spanish returnparty_56bbe960:

    # "He had told her that he offered himself as a bait..."
    "Le había dicho que se ofreció como cebo..."

# game/cethin.rpy:1829
translate Spanish returnparty_13ee2098:

    # "... But that was far from the truth."
    "... Pero eso estaba muy lejos de la verdad."

# game/cethin.rpy:1831
translate Spanish returnparty_469d2f61:

    # "They left him for dead."
    "Lo dieron por muerto."

# game/cethin.rpy:1833
translate Spanish returnparty_1d5094d0:

    # lumihappy "Dear hero, thank you very much for coming to my rescue, but..."
    lumihappy "Querido héroe, muchas gracias por venir a rescatarme, pero..."

# game/cethin.rpy:1853
translate Spanish returnparty_c69c008d:

    # voice "voice3/f20.mp3"
    # hero "Ghh...!" with vpunch
    voice "voice3/f20.mp3"
    hero "Ghh...!" with vpunch

# game/cethin.rpy:1857
translate Spanish returnparty_88fa84ac:

    # "She punched him straight to the face, making him topple backwards."
    "Ella le dio un puñetazo directo en la cara, haciéndolo caer hacia atrás."

# game/cethin.rpy:1861
translate Spanish returnparty_191ac28b:

    # voice "voice3/w3.mp3"
    # mage "Farol...!"
    voice "voice3/w3.mp3"
    mage "Farol...!"

# game/cethin.rpy:1866
translate Spanish returnparty_56dc0f7e:

    # voice "voice3/b5.mp3"
    # darkmage "Farriiie...!"
    voice "voice3/b5.mp3"
    darkmage "Farriiie...!"

# game/cethin.rpy:1870
translate Spanish returnparty_c21ccc78:

    # "The two scurried beside the hero in panic."
    "Las dos corrieron junto al héroe en pánico."

# game/cethin.rpy:1872
translate Spanish returnparty_90a2201b:

    # lumiserious "How dare you treat my friend as though he's a disposable object?"
    lumiserious "¿Cómo te atreves a tratar a mi amigo como si fuera un objeto desechable?"

# game/cethin.rpy:1877
translate Spanish returnparty_4428ddd8:

    # lumiserious "I do not need a hero like you. "
    lumiserious "No necesito un héroe como tú."

# game/cethin.rpy:1879
translate Spanish returnparty_4ae60ef2:

    # lumiserious "{b}Please leave at once.{/b}"
    lumiserious "{b}Por favor, vete de inmediato.{/b}"

# game/cethin.rpy:1881
translate Spanish returnparty_f40a58af:

    # "The man didn't seem to have heard her words as he had already lost consciousness from her single blow..."
    "El hombre no pareció escuchar sus palabras, ya que había perdido el conocimiento con un solo golpe suyo..."

# game/cethin.rpy:1883
translate Spanish returnparty_5fdb7d5b:

    # voice "voice3/b6.mp3"
    # darkmage "You...! You gorilla princess...! How dare you hurt Farrie's face?!" with vpunch
    voice "voice3/b6.mp3"
    darkmage "¡Tú...! ¡Princesa gorila...! ¡¿Cómo te atreves a lastimar la cara de Farrie?!" with vpunch

# game/cethin.rpy:1887
translate Spanish returnparty_3410bcbd:

    # voice "voice3/w4.mp3"
    # mage "You'll pay for this!"
    voice "voice3/w4.mp3"
    mage "¡Pagarás por esto!"

# game/cethin.rpy:1894
translate Spanish returnparty_1dd51398:

    # lumithink "Oh? You wish to be next?"
    lumithink "¿Oh? ¿Quieres ser la siguiente?"

# game/cethin.rpy:1896
translate Spanish returnparty_075609e6:

    # "She replied coldly."
    "Respondió ella fríamente."

# game/cethin.rpy:1898
translate Spanish returnparty_d9714079:

    # "The two trembled and turned their attention back to the hero..."
    "Las dos temblaron y volvieron su atención al héroe..."

# game/cethin.rpy:1902
translate Spanish returnparty_2321301b:

    # "The two then worked together to drag him away from the princess, and off to a safer place..."
    "Luego, ambas trabajaron juntas para arrastrarlo lejos de la princesa y llevarlo a un lugar más seguro..."

# game/cethin.rpy:1904
translate Spanish returnparty_fc5fe0b0:

    # "Now, it was just the princess and the bard in the room."
    "Ahora, solo quedaban la princesa y el bardo en la habitación."

# game/cethin.rpy:1906
translate Spanish returnparty_70ac59f6:

    # voice "voice1/line171.mp3"
    # cethin "Lumi, listen, I-"
    voice "voice1/line171.mp3"
    cethin "Lumi, escucha, yo-"

# game/cethin.rpy:1910
translate Spanish returnparty_6316393e:

    # voice "voice1/line172.mp3"
    # cethin "I'm sorry..."
    voice "voice1/line172.mp3"
    cethin "Lo siento..."

# game/cethin.rpy:1920
translate Spanish returnparty_f8911bcf:

    # lumisad "Wait-"
    lumisad "Espera-"

# game/cethin.rpy:1927
translate Spanish returnparty_1dc37ee3:

    # "She tried to run after him, but before she could reach him, the bard had already leapt out of the balcony."
    "Ella intentó correr tras él, pero antes de poder alcanzarlo, el bardo ya había saltado desde el balcón."

# game/cethin.rpy:1929
translate Spanish returnparty_b47de12f:

    # "The girl pursed her lips, feeling helpless that she couldn't do more."
    "La chica frunció los labios, sintiéndose impotente al no poder hacer más."

# game/cethin.rpy:1931
translate Spanish returnparty_f54d4bc6:

    # lumisad "(I suppose he'd like to be alone for now...)"
    lumisad "(Supongo que por ahora le apetece estar solo...)"

# game/cethin.rpy:1933
translate Spanish returnparty_910a78eb:

    # lumisad "(He'll return. He promised...)"
    lumisad "(Volverá. Lo prometió...)"

# game/cethin.rpy:1935
translate Spanish returnparty_d3b31a69:

    # lumisad "(He promised he wouldn't leave without a word...)"
    lumisad "(Prometió que no se iría sin decir una palabra...)"

# game/cethin.rpy:2088
translate Spanish returnparty_9ea5011d:

    # hero "What?! That wench...!" with vpunch
    hero "¡¿Qué?! ¡Esa arpía...!" with vpunch

# game/cethin.rpy:2093
translate Spanish returnparty_97113a5c:

    # mage "Yeah! She said she doesn't need you."
    mage "¡Sí! Dijo que no te necesita."

# game/cethin.rpy:2095
translate Spanish returnparty_0cf6f2bf:

    # "Meanwhile, the duo had managed to safely drag Farol out of the castle once again."
    "Mientras tanto, el dúo había logrado arrastrar a Farol fuera del castillo una vez más."

# game/cethin.rpy:2097
translate Spanish returnparty_7c3f9412:

    # "It didn't really take long before he regained consciousness."
    "No tardó mucho en recuperar la conciencia."

# game/cethin.rpy:2099
translate Spanish returnparty_33d5a6a7:

    # darkmage "That abandoned princess is a waste of time!"
    darkmage "¡Esa princesa abandonada es una pérdida de tiempo!"

# game/cethin.rpy:2101
translate Spanish returnparty_49dbb3bf:

    # darkmage "Let's just go... it's cold here. I hate it."
    darkmage "Vámonos... hace frío aquí. Lo odio."

# game/cethin.rpy:2103
translate Spanish returnparty_65ddf1fa:

    # "He clicked his tongue."
    "Chasqueó la lengua."

# game/cethin.rpy:2107
translate Spanish returnparty_a9c4bb9a:

    # hero "I had thought that the foolish girl was naive, as I had heard that she was but an ornamental princess..."
    hero "Pensé que esa chica tonta era ingenua, ya que había escuchado que no era más que una princesa ornamental..."

# game/cethin.rpy:2111
translate Spanish returnparty_1a417bd1:

    # mage "But she lashed out on you!"
    mage "¡Pero se desquitó contigo!"

# game/cethin.rpy:2113
translate Spanish returnparty_5b0bf2bc:

    # mage "Forget her. You have me."
    mage "Olvídala. Me tienes a mí."

# game/cethin.rpy:2115
translate Spanish returnparty_9d517f31:

    # darkmage "{b}US.{/b}"
    darkmage "{b}A NOSOTROS.{/b}"

# game/cethin.rpy:2117
translate Spanish returnparty_c025cc0d:

    # "The black mage was quick to correct."
    "La maga oscura se apresuró a corregir."

# game/cethin.rpy:2119
translate Spanish returnparty_a623cc68:

    # mage "Yes, us."
    mage "Sí, a nosotros."

# game/cethin.rpy:2121
translate Spanish returnparty_e8083236:

    # "She added in deadpan."
    "Agregó ella sin expresión."

# game/cethin.rpy:2125
translate Spanish returnparty_821feec6:

    # hero "Listen here the two of you... Completing this quest should allow us to live like royalty for the rest of our lives."
    hero "Escuchen ustedes dos... Completar esta misión debería permitirnos vivir como la realeza por el resto de nuestras vidas."

# game/cethin.rpy:2127
translate Spanish returnparty_441e437d:

    # hero "And we've been at this for years."
    hero "Y llevamos años en esto."

# game/cethin.rpy:2131
translate Spanish returnparty_d96d75f4:

    # hero "We cannot give this up now!"
    hero "¡No podemos rendirnos ahora!"

# game/cethin.rpy:2135
translate Spanish returnparty_6dcc4a53:

    # darkmage "That aside, I was thinking... maybe that drow cast a spell on her?"
    darkmage "Aparte de eso, estaba pensando... ¿quizás ese drow le lanzó un hechizo?"

# game/cethin.rpy:2137
translate Spanish returnparty_1d89ce37:

    # "The hero narrowed his eyes."
    "El héroe entrecerró los ojos."

# game/cethin.rpy:2139
translate Spanish returnparty_022d07d5:

    # hero "Oh? Care to explain?"
    hero "¿Oh? ¿Podrías explicarte?"

# game/cethin.rpy:2141
translate Spanish returnparty_b565221a:

    # darkmage "As you all may know, drows are masters of the dark arts. What if he was manipulating her?"
    darkmage "Como todos saben, los drows son maestros en las artes oscuras. ¿Y si la estaba manipulando?"

# game/cethin.rpy:2146
translate Spanish returnparty_1907cbff:

    # hero "Ha! That weakling...?"
    hero "¡Ja! ¿Ese debilucho...?"

# game/cethin.rpy:2150
translate Spanish returnparty_3ddd991b:

    # "A pause."
    "Una pausa."

# game/cethin.rpy:2152
translate Spanish returnparty_c21fe7d9:

    # hero "No... hold on... you might have a point there."
    hero "No... espera... puede que tengas razón."

# game/cethin.rpy:2156
translate Spanish returnparty_b6766a27:

    # hero "Perhaps he's even one of the demon lord's pawns!"
    hero "¡Quizás incluso sea uno de los peones del señor demonio!"

# game/cethin.rpy:2160
translate Spanish returnparty_1d6473d6:

    # hero "Yes, that makes sense... that makes so much sense!"
    hero "Sí, eso tiene sentido... ¡mucho sentido!"

# game/cethin.rpy:2162
translate Spanish returnparty_ffa89b5d:

    # hero "That's how he still lives!"
    hero "¡Así es como sigue vivo!"

# game/cethin.rpy:2167
translate Spanish returnparty_a4ae9b6e:

    # hero "Oh, that pitiful princess...! I should have realized earlier..."
    hero "¡Oh, esa pobre princesa...! Debería haberlo notado antes..."

# game/cethin.rpy:2169
translate Spanish returnparty_ddddf929:

    # hero "That damned drow pulled a fast one on us..."
    hero "Ese maldito drow nos engañó..."

# game/cethin.rpy:2173
translate Spanish returnparty_21b1a1d5:

    # hero "He must have been a spy for the demon lord all along!"
    hero "¡Debe haber sido un espía del señor demonio desde el principio!"

# game/cethin.rpy:2175
translate Spanish returnparty_b4977bce:

    # mage "Oooh Farol, you're sooo smart!"
    mage "¡Oooh Farol, eres taaaan inteligente!"

# game/cethin.rpy:2179
translate Spanish returnparty_fd0bfa86:

    # hero "I am, aren't I?"
    hero "Lo soy, ¿verdad?"

# game/cethin.rpy:2183
translate Spanish returnparty_fc8fb4e9:

    # hero "Of course I am."
    hero "Por supuesto que lo soy."

# game/cethin.rpy:2187
translate Spanish returnparty_c54f50ee:

    # hero "So, our mission is to take away the brainwashed princess, even against her brainwashed will..."
    hero "Entonces, nuestra misión es rescatar a la princesa lavada del cerebro, incluso contra su voluntad manipulada..."

# game/cethin.rpy:2189
translate Spanish returnparty_c993f83d:

    # hero "And then cut down the demon lord, and that evil drow."
    hero "Y luego derrotar al señor demonio, y a ese malvado drow."

# game/cethin.rpy:2191
translate Spanish returnparty_d4aea59f:

    # hero "Let us prepare and wait for the right moment. It's best to strike when least expected."
    hero "Preparémonos y esperemos el momento adecuado. Es mejor atacar cuando menos se lo esperan."

# game/cethin.rpy:2195
translate Spanish returnparty_278c7e29:

    # "........."
    "........."

# game/cethin.rpy:2204
translate Spanish returnparty_24f8d9dd:

    # "The night elf slipped through the balcony and cautiously walked inside the room."
    "El elfo oscuro se deslizó por el balcón y caminó con cautela dentro de la habitación."

# game/cethin.rpy:2206
translate Spanish returnparty_a0415841:

    # "His steps were quiet, consciously so. He didn't want to wake up the princess after all."
    "Sus pasos eran silenciosos, deliberadamente. Después de todo, no quería despertar a la princesa."

# game/cethin.rpy:2210
translate Spanish returnparty_5365bc89:

    # "He was about to enter his closet when-"
    "Estaba a punto de entrar en su armario cuando-"

# game/cethin.rpy:2214
translate Spanish returnparty_85e3062b:

    # lumitalk "I do not understand why you still need to stay there when Reo is already an accomplice."
    lumitalk "No entiendo por qué aún necesitas quedarte ahí cuando Reo ya es un cómplice."

# game/cethin.rpy:2216
translate Spanish returnparty_ed275b45:

    # "The princess sat up from her bed."
    "La princesa se incorporó en su cama."

# game/cethin.rpy:2221
translate Spanish returnparty_dcb37024:

    # "The dark elf froze."
    "El elfo oscuro se congeló."

# game/cethin.rpy:2225
translate Spanish returnparty_d9cc717e:

    # voice "voice1/line173.mp3"
    # cethin "Oh... Lumi."
    voice "voice1/line173.mp3"
    cethin "Oh... Lumi."

# game/cethin.rpy:2231
translate Spanish returnparty_197ec4ab:

    # lumihappy "Have you sorted out your thoughts?"
    lumihappy "¿Has aclarado tus pensamientos?"

# game/cethin.rpy:2233
translate Spanish returnparty_6a779593:

    # "Her tone was gentle. It was evident that she had been concerned over him."
    "Su tono era amable. Era evidente que había estado preocupada por él."

# game/cethin.rpy:2235
translate Spanish returnparty_37778ac4:

    # "He averted his gaze from the girl, unsure how to proceed."
    "Apartó la mirada de la chica, inseguro de cómo proceder."

# game/cethin.rpy:2237
translate Spanish returnparty_92be2fba:

    # "Lumi crossed her arms over her chest."
    "Lumi cruzó los brazos sobre su pecho."

# game/cethin.rpy:2239
translate Spanish returnparty_f63df693:

    # lumi "Do not worry. I shall keep waiting for you."
    lumi "No te preocupes. Seguiré esperando por ti."

# game/cethin.rpy:2243
translate Spanish returnparty_254d80b0:

    # lumihappy "No matter how long."
    lumihappy "Por mucho tiempo que sea."

# game/cethin.rpy:2245
translate Spanish returnparty_12b0db2f:

    # lumi "I may be quite upset, but I am not angry."
    lumi "Puedo estar bastante molesta, pero no estoy enojada."

# game/cethin.rpy:2247
translate Spanish returnparty_a14b8659:

    # "The dark elf hung his head low, as though a child being scolded by his mother."
    "El elfo oscuro bajó la cabeza, como un niño siendo reprendido por su madre."

# game/cethin.rpy:2255
translate Spanish returnparty_364284a2:

    # voice "voice1/line174.mp3"
    # cethin "I lied to you..."
    voice "voice1/line174.mp3"
    cethin "Te mentí..."

# game/cethin.rpy:2259
translate Spanish returnparty_1c9ee158:

    # lumi "Yes, I could tell."
    lumi "Sí, podía notarlo."

# game/cethin.rpy:2263
translate Spanish returnparty_f1e5b0c1:

    # lumisad "I have a good idea as to why you did it, but..."
    lumisad "Tengo una buena idea de por qué lo hiciste, pero..."

# game/cethin.rpy:2265
translate Spanish returnparty_7331480d:

    # lumitalk "I'd still like to hear it directly from you."
    lumitalk "Aun así, me gustaría oírlo directamente de ti."

# game/cethin.rpy:2267
translate Spanish returnparty_10947cb9:

    # "Cethin remained silent for a long while, but Lumi didn't mind. Just as she had told him- she will be waiting for him, no matter how long."
    "Cethin permaneció en silencio durante un largo rato, pero a Lumi no le importó. Tal como le había dicho, lo esperaría, por mucho tiempo que tomara."

# game/cethin.rpy:2269
translate Spanish returnparty_1fdb7dbe:

    # "It was quiet, even more so that the area was practically a barren wasteland of snow."
    "Era un silencio profundo, más aún porque el área era prácticamente un páramo nevado."

# game/cethin.rpy:2271
translate Spanish returnparty_73ed3f45:

    # "Sometimes, a soft breeze would blow to break the stillness. At times, they would hear an owl hooting, or a wolf howling from afar."
    "A veces, una suave brisa rompía la quietud. En ocasiones, se escuchaba el ulular de un búho o el aullido de un lobo a lo lejos."

# game/cethin.rpy:2273
translate Spanish returnparty_f74ea5e8:

    # "The princess paid no heed to her surroundings, and only placed her focus on Cethin who was standing in front of her."
    "La princesa no prestaba atención a su entorno y solo centraba su mirada en Cethin, que estaba frente a ella."

# game/cethin.rpy:2278
translate Spanish returnparty_8870ad04:

    # voice "voice1/line175.mp3"
    # cethin "I started off my travels with fellow dark elves from my clan..."
    voice "voice1/line175.mp3"
    cethin "Comencé mis viajes con otros elfos oscuros de mi clan..."

# game/cethin.rpy:2282
translate Spanish returnparty_97f2f1d5:

    # "He finally began talking."
    "Finalmente empezó a hablar."

# game/cethin.rpy:2286
translate Spanish returnparty_678e2ae5:

    # voice "voice1/line176.mp3"
    # cethin "... But soon, I proved to be a detriment to them, so they abandoned me."
    voice "voice1/line176.mp3"
    cethin "... Pero pronto, me convertí en una carga para ellos, así que me abandonaron."

# game/cethin.rpy:2290
translate Spanish returnparty_ab231b56:

    # voice "voice1/line177.mp3"
    # cethin "No other party was willing to take me in as I was a dark elf, so I later found myself traveling on my own."
    voice "voice1/line177.mp3"
    cethin "Ningún otro grupo quiso aceptarme porque era un elfo oscuro, así que terminé viajando solo."

# game/cethin.rpy:2294
translate Spanish returnparty_cbffd408:

    # voice "voice1/line178.mp3"
    # cethin "I've never ventured through dungeons or vanquished dragons... all I ever did was run away at any sign of danger."
    voice "voice1/line178.mp3"
    cethin "Nunca he explorado mazmorras ni vencido dragones... todo lo que hice fue huir ante cualquier señal de peligro."

# game/cethin.rpy:2300
translate Spanish returnparty_aa14edfb:

    # voice "voice1/line179.mp3"
    # cethin "Rather 'adventure', all I've done was 'roam'."
    voice "voice1/line179.mp3"
    cethin "Más que 'aventurarme', lo único que he hecho es 'vagar'."

# game/cethin.rpy:2307
translate Spanish returnparty_87b24b2a:

    # voice "voice1/line180.mp3"
    # cethin "And then, Farol invited me to their party. I was happy to be asked for once..."
    voice "voice1/line180.mp3"
    cethin "Y entonces, Farol me invitó a su grupo. Me sentí feliz de que alguien me pidiera unirme por una vez..."

# game/cethin.rpy:2314
translate Spanish returnparty_be5e70dd:

    # voice "voice1/line181.mp3"
    # cethin "... But I found myself not as a 'member' of his party, but more of an attendant."
    voice "voice1/line181.mp3"
    cethin "... Pero me encontré siendo no un “miembro” de su grupo, sino más bien un sirviente."

# game/cethin.rpy:2318
translate Spanish returnparty_801ed7b8:

    # voice "voice1/line182.mp3"
    # cethin "All I ever did was carry their things, and sometimes serve them food. Attend to their needs."
    voice "voice1/line182.mp3"
    cethin "Todo lo que hacía era cargar sus cosas, y a veces servirles comida. Atender sus necesidades."

# game/cethin.rpy:2324
translate Spanish returnparty_2f327773:

    # voice "voice1/line183.mp3"
    # cethin "... Yet, I was happy. They at least accepted me."
    voice "voice1/line183.mp3"
    cethin "... Aun así, era feliz. Al menos me aceptaron."

# game/cethin.rpy:2330
translate Spanish returnparty_ff1a7713:

    # voice "voice1/line184.mp3"
    # cethin "I'm no {i}valiant{/i} warrior. I'm nothing but a fraud."
    voice "voice1/line184.mp3"
    cethin "No soy un guerrero {i}valiente{/i}. No soy más que un fraude."

# game/cethin.rpy:2336
translate Spanish returnparty_a173db8e:

    # "He lifted his head, and for once througout this conversation, he faced the princess."
    "Levantó la cabeza y, por primera vez en toda la conversación, miró a la princesa."

# game/cethin.rpy:2340
translate Spanish returnparty_2cd5439a:

    # voice "voice1/line185.mp3"
    # cethin "I was never here to rescue you."
    voice "voice1/line185.mp3"
    cethin "Nunca estuve aquí para rescatarte."

# game/cethin.rpy:2344
translate Spanish returnparty_315d806b:

    # voice "voice1/line186.mp3"
    # cethin "I've never been deserving of your kindness."
    voice "voice1/line186.mp3"
    cethin "Nunca he sido digno de tu amabilidad."

# game/cethin.rpy:2350
translate Spanish returnparty_75902bb4:

    # voice "voice1/line186-5.mp3"
    # cethin "I'm... I'm..."
    voice "voice1/line186-5.mp3"
    cethin "Yo... yo..."

# game/cethin.rpy:2354
translate Spanish returnparty_9b8f7bbf:

    # "Once again, the dark elf lowered his gaze, unable to meet eyes with Lumi."
    "Una vez más, el elfo oscuro bajó la mirada, incapaz de encontrarse con los ojos de Lumi."

# game/cethin.rpy:2358
translate Spanish returnparty_209ae24f:

    # lumiserious "You do not have to force yourself. I understand."
    lumiserious "No tienes que forzarte. Lo entiendo."

# game/cethin.rpy:2369
translate Spanish returnparty_517d41e5:

    # "The princess stood up and took his hands."
    "La princesa se levantó y tomó sus manos."

# game/cethin.rpy:2371
translate Spanish returnparty_0b6b976b:

    # "He found himself looking back at her."
    "Él se encontró mirándola de nuevo."

# game/cethin.rpy:2373
translate Spanish returnparty_08c3ca08:

    # lumisad "You've been through a lot. I could tell."
    lumisad "Has pasado por mucho. Puedo notarlo."

# game/cethin.rpy:2377
translate Spanish returnparty_956d59a9:

    # lumisad "It must have been lonely, being alone... unaccepted by everyone around you."
    lumisad "Debe haber sido solitario, estar solo... sin ser aceptado por nadie a tu alrededor."

# game/cethin.rpy:2379
translate Spanish returnparty_97154020:

    # lumisad "(I know of loneliness borne from isolation, but his was borne from nonacceptance.)"
    lumisad "(Sé lo que es la soledad causada por el aislamiento, pero la suya viene del rechazo.)"

# game/cethin.rpy:2381
translate Spanish returnparty_0838b6ca:

    # lumisad "(At least I know that I have my family to return to... but Cethin does not.)"
    lumisad "(Al menos yo sé que tengo una familia a la que puedo volver... pero Cethin no.)"

# game/cethin.rpy:2383
translate Spanish returnparty_d3c550ec:

    # "She could feel her chest tighten for him. It must have been painful."
    "Podía sentir su pecho apretarse por él. Debió haber sido doloroso."

# game/cethin.rpy:2387
translate Spanish returnparty_fc309a5f:

    # lumisad "Honestly, I could not dare say that I know how you feel."
    lumisad "Sinceramente, no podría atreverme a decir que sé cómo te sientes."

# game/cethin.rpy:2389
translate Spanish returnparty_7d660123:

    # lumiserious "However, there is one thing I've no doubt about-"
    lumiserious "Sin embargo, hay algo de lo que no tengo duda-"

# game/cethin.rpy:2391
translate Spanish returnparty_8d055528:

    # "She squeezed his hands tight. Cethin couldn't help but meet her eyes once more."
    "Apretó sus manos con fuerza. Cethin no pudo evitar mirarla a los ojos una vez más."

# game/cethin.rpy:2395
translate Spanish returnparty_f7f2b88e:

    # lumihappy "I shall always welcome you by my side, no matter what."
    lumihappy "Siempre te daré la bienvenida a mi lado, sin importar qué."

# game/cethin.rpy:2397
translate Spanish returnparty_db63f583:

    # lumisad "You are worth more than what they make you out to be."
    lumisad "Vales más de lo que ellos creen que vales."

# game/cethin.rpy:2399
translate Spanish returnparty_c187e283:

    # lumitalk "They do not define you. I do not define you. You define yourself."
    lumitalk "Ellos no te definen. Yo no te defino. Tú te defines a ti mismo."

# game/cethin.rpy:2401
translate Spanish returnparty_d4d19c9c:

    # lumisad "If they do not see your worth, then they do not deserve you."
    lumisad "Si ellos no ven tu valor, entonces no te merecen."

# game/cethin.rpy:2405
translate Spanish returnparty_ed2322ff:

    # voice "voice1/line186-6.mp3"
    # cethin "... Lumi."
    voice "voice1/line186-6.mp3"
    cethin "... Lumi."

# game/cethin.rpy:2413
translate Spanish returnparty_8316bd92:

    # "He could only utter her name in response."
    "Solo pudo pronunciar su nombre en respuesta."

# game/cethin.rpy:2415
translate Spanish returnparty_14788874:

    # "The girl wrapped her arms around him, and allowed the elf to bury his head on her shoulders."
    "La chica lo abrazó, permitiéndole al elfo enterrar su cabeza en su hombro."

# game/cethin.rpy:2417
translate Spanish returnparty_83754d11:

    # lumiblush "Go on..."
    lumiblush "Adelante..."

# game/cethin.rpy:2419
translate Spanish returnparty_16706df0:

    # voice "voice1/line187.mp3"
    # cethin "Thank you... thank you.{w} Thank you."
    voice "voice1/line187.mp3"
    cethin "Gracias... gracias.{w} Gracias."

# game/cethin.rpy:2423
translate Spanish returnparty_fcbf8dca:

    # "She couldn't see, but she knew that tears had fallen from his eyes."
    "Ella no podía verlo, pero sabía que lágrimas habían caído de sus ojos."

# game/cethin.rpy:2425
translate Spanish returnparty_cc473980:

    # "Once again, he had cried."
    "Una vez más, había llorado."

# game/cethin.rpy:2427
translate Spanish returnparty_cdff8d6f:

    # "Lumi knew that Cethin didn't want her to see him like that, just like as he did during their yule feast."
    "Lumi sabía que Cethin no quería que lo viera así, igual que durante su banquete de Yule."

# game/cethin.rpy:2429
translate Spanish returnparty_97f2e42a:

    # lumiblush "It's fine. It's fine."
    lumiblush "Está bien. Está bien."

# game/cethin.rpy:2431
translate Spanish returnparty_cf803356:

    # "She comforted him the same way she did last time."
    "Lo consoló de la misma forma que la vez anterior."

# game/cethin.rpy:2435
translate Spanish returnparty_dfed0c8a:

    # "They stayed like that for a while until her friend had calmed down."
    "Permanecieron así un rato hasta que su amigo se calmó."

# game/cethin.rpy:2437
translate Spanish returnparty_2d99e164:

    # "........................"
    "........................"

# game/cethin.rpy:2444
translate Spanish returnparty_b8b29c1b:

    # "After a while, the princess had put herself back in bed."
    "Después de un tiempo, la princesa volvió a meterse en la cama."

# game/cethin.rpy:2446
translate Spanish returnparty_4c873513:

    # "Cethin, on the other hand, was on the floor, with his back resting against the edge of her bed."
    "Cethin, por otro lado, estaba en el suelo, con la espalda apoyada en el borde de su cama."

# game/cethin.rpy:2450
translate Spanish returnparty_2f004068:

    # cethin "I'm sorry for keeping you up..."
    cethin "Perdón por haberte mantenido despierta..."

# game/cethin.rpy:2454
translate Spanish returnparty_37793c60:

    # lumi "This is nothing. I just hope that you are feeling better now?"
    lumi "No es nada. ¿Solo espero que te sientas mejor ahora?"

# game/cethin.rpy:2459
translate Spanish returnparty_dffdf5d2:

    # cethin "Mhm..."
    cethin "Mhm..."

# game/cethin.rpy:2461
translate Spanish returnparty_eca71b7d:

    # "He nodded, though, she could only see the back of his head."
    "Asintió, aunque ella solo podía ver la parte trasera de su cabeza."

# game/cethin.rpy:2465
translate Spanish returnparty_92e71aad:

    # cethin "About what you said..."
    cethin "Sobre lo que dijiste..."

# game/cethin.rpy:2469
translate Spanish returnparty_40a24ff8:

    # cethin "The reason I've been training with Reo was actually to strengthen myself as a bard."
    cethin "La razón por la que he estado entrenando con Reo en realidad era para fortalecerme como bardo."

# game/cethin.rpy:2473
translate Spanish returnparty_6730176e:

    # cethin "... Because I wanted to become the adventurer that you think I am."
    cethin "... Porque quería convertirme en el aventurero que tú crees que soy."

# game/cethin.rpy:2475
translate Spanish returnparty_0552b34c:

    # lumisad "(I figured it was something like that...)"
    lumisad "(Me imaginé que era algo así...)"

# game/cethin.rpy:2477
translate Spanish returnparty_83bfed84:

    # lumided "I was not aware that Reo was... well, could {i}do-bard{/i}."
    lumided "No sabía que Reo era... bueno, que podía {i}hacer-de-bardo{/i}."

# game/cethin.rpy:2481
translate Spanish returnparty_1f386ebb:

    # cethin "He actually complained about it."
    cethin "En realidad se quejó de eso."

# game/cethin.rpy:2485
translate Spanish returnparty_5394607f:

    # cethin "{i}I am not a bard! Why are you asking me?!{/i}"
    cethin "{i}¡No soy un bardo! ¿Por qué me lo pides a mí?!{/i}"

# game/cethin.rpy:2487
translate Spanish returnparty_6f9356ec:

    # "He said, mimicking the redhead."
    "Dijo, imitando al pelirrojo."

# game/cethin.rpy:2491
translate Spanish returnparty_47ab8eb6:

    # "It was evident how much more cheerful he sounded now."
    "Era evidente lo mucho más animado que sonaba ahora."

# game/cethin.rpy:2493
translate Spanish returnparty_3205c1b4:

    # lumitalk "Then...? How did you coerce him?"
    lumitalk "¿Entonces...? ¿Cómo lo convenciste?"

# game/cethin.rpy:2495
translate Spanish returnparty_17ebb038:

    # "She asked excitedly."
    "Preguntó ella emocionada."

# game/cethin.rpy:2499
translate Spanish returnparty_3681f144:

    # cethin "I... pleaded."
    cethin "Yo... supliqué."

# game/cethin.rpy:2503
translate Spanish returnparty_cba68cf4:

    # cethin "He may not be a bard, but I had a feeling that Reo knew more than he lets on."
    cethin "Puede que no sea un bardo, pero tenía la sensación de que Reo sabía más de lo que deja ver."

# game/cethin.rpy:2507
translate Spanish returnparty_b6552e7e:

    # cethin "I asked him for advice on how I could get better, and I was not wrong to come to him."
    cethin "Le pedí consejos sobre cómo podía mejorar, y no me equivoqué al acudir a él."

# game/cethin.rpy:2509
translate Spanish returnparty_8000d4ce:

    # lumihappy "Oooh. I see."
    lumihappy "Oooh. Ya veo."

# game/cethin.rpy:2511
translate Spanish returnparty_14e91363:

    # "The princess nodded in understanding."
    "La princesa asintió comprendiendo."

# game/cethin.rpy:2515
translate Spanish returnparty_dde260ce:

    # "Honestly, she still didn't understand it fully. How could a butler provide bard training...?"
    "Aunque, sinceramente, aún no lo entendía del todo. ¿Cómo podía un mayordomo enseñar a ser bardo...?"

# game/cethin.rpy:2517
translate Spanish returnparty_6c0fdb19:

    # "Truly... that butler was mysterious."
    "Realmente... ese mayordomo era un misterio."

# game/cethin.rpy:2519
translate Spanish returnparty_83724bc0:

    # lumitalk "Then, why the need to be so secretive about this?"
    lumitalk "Entonces, ¿por qué la necesidad de ser tan reservado con esto?"

# game/cethin.rpy:2524
translate Spanish returnparty_24246459:

    # cethin "Huh?"
    cethin "¿Eh?"

# game/cethin.rpy:2529
translate Spanish returnparty_bfdb08d2:

    # cethin "W-was I...?"
    cethin "¿Y-yo fui...?"

# game/cethin.rpy:2531
translate Spanish returnparty_f2719ce2:

    # "He averted his gaze, while scratching his cheek."
    "Apartó la mirada mientras se rascaba la mejilla."

# game/cethin.rpy:2533
translate Spanish returnparty_e7e6b755:

    # "Lumi stared at him with narrowed eyes."
    "Lumi lo observó con los ojos entrecerrados."

# game/cethin.rpy:2537
translate Spanish returnparty_015de182:

    # cethin "I... well... that night..."
    cethin "Yo... bueno... esa noche..."

# game/cethin.rpy:2539
translate Spanish returnparty_ef7cfe96:

    # cethin "{size=-5}I felt nervous around you{/size} {size=-9}after that night, {/size}{size=-15}so I wanted to get away for a while...{/size}"
    cethin "{size=-5}Me sentí nervioso contigo{/size} {size=-9}después de esa noche, {/size}{size=-15}así que quise alejarme un tiempo...{/size}"

# game/cethin.rpy:2541
translate Spanish returnparty_41996a4d:

    # "His voice went smaller and smaller as he spoke."
    "Su voz se hacía más y más pequeña a medida que hablaba."

# game/cethin.rpy:2543
translate Spanish returnparty_ecaea8c1:

    # "Lumi could only knit her brows together in confusion."
    "Lumi solo frunció el ceño en confusión."

# game/cethin.rpy:2545
translate Spanish returnparty_80f518c6:

    # lumitalk "Could you repeat that?"
    lumitalk "¿Podrías repetir eso?"

# game/cethin.rpy:2547
translate Spanish returnparty_01526406:

    # cethin "Ngh..."
    cethin "Ngh..."

# game/cethin.rpy:2549
translate Spanish returnparty_77d2520d:

    # "He was obviously in distress."
    "Estaba claramente angustiado."

# game/cethin.rpy:2551
translate Spanish returnparty_db7641f3:

    # "The princess sighed."
    "La princesa suspiró."

# game/cethin.rpy:2556
translate Spanish returnparty_f379b229:

    # lumishy "If you keep this up, you'll drive me insane."
    lumishy "Si sigues así, me volverás loca."

# game/cethin.rpy:2558
translate Spanish returnparty_7cfc129b:

    # "She closed her eyes and took a deep breath, placing a hand over her bosom."
    "Cerró los ojos y respiró profundo, colocando una mano sobre su pecho."

# game/cethin.rpy:2560
translate Spanish returnparty_f2eb4948:

    # lumishy "You have no idea how tumultuous it is within my chest right now..."
    lumishy "No tienes idea de lo agitado que está mi corazón en este momento..."

# game/cethin.rpy:2569
translate Spanish returnparty_4a76ba3e:

    # lumishy "I think I might be in love with you."
    lumishy "Creo que estoy enamorada de ti."

# game/cethin.rpy:2575
translate Spanish returnparty_2965fef5:

    # cethin "..." with vpunch
    cethin "..." with vpunch

# game/cethin.rpy:2577
translate Spanish returnparty_9fef8df4:

    # "The dark elf was left frozen and speechless by her sudden confession."
    "El elfo oscuro quedó congelado y sin palabras ante su repentina confesión."

# game/cethin.rpy:2579
translate Spanish returnparty_7085f1f8:

    # "After a moment of nonreaction, she couldn't help but just hide her face behind her hands."
    "Después de un momento sin reacción, no pudo evitar ocultar su rostro tras sus manos."

# game/cethin.rpy:2581
translate Spanish returnparty_51b43c02:

    # "She was aware how red her face had become, and while it may already be dark... night elves had good eyes."
    "Era consciente de lo roja que se había puesto su cara, y aunque ya era de noche... los elfos oscuros tenían buena vista."

# game/cethin.rpy:2583
translate Spanish returnparty_438e3c18:

    # "Thankfully, he wasn't looking, as only the back of his head was facing to her."
    "Afortunadamente, él no estaba mirando, ya que solo la parte trasera de su cabeza estaba vuelta hacia ella."

# game/cethin.rpy:2585
translate Spanish returnparty_5c14b871:

    # "Even so, she just-"
    "Aun así, ella simplemente..."

# game/cethin.rpy:2592
translate Spanish returnparty_16b76f39:

    # "Cethin's mouth hung open after hearing her words."
    "La boca de Cethin quedó abierta tras escuchar sus palabras."

# game/cethin.rpy:2594
translate Spanish returnparty_7b2afc43:

    # "Not that she could tell, as only the back of his head was visible to her."
    "No que ella pudiera notarlo, ya que solo veía la parte trasera de su cabeza."

# game/cethin.rpy:2596
translate Spanish returnparty_d7831333:

    # "For a moment, there was only silence in the room."
    "Por un momento, solo hubo silencio en la habitación."

# game/cethin.rpy:2598
translate Spanish returnparty_d1685337:

    # "Finally, the bard swallowed."
    "Finalmente, el bardo tragó saliva."

# game/cethin.rpy:2608
translate Spanish returnparty_ee6b7a80:

    # cethin "I... do."
    cethin "Yo... también."

# game/cethin.rpy:2612
translate Spanish returnparty_f173442e:

    # "He averted his gaze."
    "Apartó la mirada."

# game/cethin.rpy:2614
translate Spanish returnparty_0310146a:

    # cethin "I... I could hear it right now..."
    cethin "Yo... puedo oírlo ahora mismo..."

# game/cethin.rpy:2616
translate Spanish returnparty_54323161:

    # "The elf added as he placed two hands over his ears."
    "Agregó el elfo mientras se cubría las orejas con ambas manos."

# game/cethin.rpy:2618
translate Spanish returnparty_6ae77aaa:

    # "Both of their faces went red."
    "Ambos rostros se pusieron rojos."

# game/cethin.rpy:2620
translate Spanish returnparty_afe707af:

    # lumiuwu "(Gods... so they DO have especially strong hearing...!)" with vpunch
    lumiuwu "(Dioses... ¡así que SÍ tienen un oído especialmente agudo...!)" with vpunch

# game/cethin.rpy:2622
translate Spanish returnparty_02b6805f:

    # lumishy "S-so... even that night...?"
    lumishy "E-entonces... ¿incluso esa noche...?"

# game/cethin.rpy:2624
translate Spanish returnparty_37e8f817:

    # cethin "Hah... you have no idea how much I had to endure when I heard them."
    cethin "Hah... no tienes idea de cuánto tuve que soportar cuando los escuché."

# game/cethin.rpy:2626
translate Spanish returnparty_6912bcf3:

    # lumiuwu "{size=+5}Aaaa{/size}{size=+3}aaa{/size}{size=-2}ahh....{/size}"
    lumiuwu "{size=+5}Aaaa{/size}{size=+3}aaa{/size}{size=-2}ahh....{/size}"

# game/cethin.rpy:2631
translate Spanish returnparty_49219cc4:

    # voice "voice1/line188.mp3"
    # cethin "L-lumi...?"
    voice "voice1/line188.mp3"
    cethin "¿L-Lumi...?"

# game/cethin.rpy:2635
translate Spanish returnparty_02ae1781:

    # "Cethin turned around and peered at the girl."
    "Cethin se dio la vuelta y miró a la chica."

# game/cethin.rpy:2639
translate Spanish returnparty_f7601c88:

    # lumiuwu "F-forget what I said...!"
    lumiuwu "¡O-olvida lo que dije...!"

# game/cethin.rpy:2641
translate Spanish returnparty_fe27ca13:

    # lumiuwu "Please, spare me the shame."
    lumiuwu "Por favor, perdóname la vergüenza."

# game/cethin.rpy:2648
translate Spanish returnparty_6767efa4:

    # "She said as she buried herself under her bed sheet."
    "Dijo mientras se enterraba bajo su sábana."

# game/cethin.rpy:2650
translate Spanish returnparty_b9f70425:

    # "The princess curled up inside. She knew how inelegant she was being- very unlike a princess..."
    "La princesa se acurrucó dentro. Sabía lo poco elegante que estaba siendo, muy poco propio de una princesa..."

# game/cethin.rpy:2652
translate Spanish returnparty_d99141c9:

    # "But what else could she do? Her emotions were all over the place."
    "Pero ¿qué más podía hacer? Sus emociones estaban por todos lados."

# game/cethin.rpy:2654
translate Spanish returnparty_26cdbb36:

    # "This was nothing like the romance she had always imagined. In her mind, it had always been a solemn thing."
    "Esto no se parecía en nada al romance que siempre había imaginado. En su mente, siempre había sido algo solemne."

# game/cethin.rpy:2656
translate Spanish returnparty_05205da5:

    # "A pledge of love, a kiss on the hand, and an elegant wedding."
    "Una promesa de amor, un beso en la mano y una boda elegante."

# game/cethin.rpy:2658
translate Spanish returnparty_740edc66:

    # "Just like fairy tales."
    "Como en los cuentos de hadas."

# game/cethin.rpy:2660
translate Spanish returnparty_e71f3e48:

    # "Nothing like this."
    "Nada como esto."

# game/cethin.rpy:2662
translate Spanish returnparty_0191615f:

    # voice "voice1/line189.mp3"
    # cethin "Lumi."
    voice "voice1/line189.mp3"
    cethin "Lumi."

# game/cethin.rpy:2666
translate Spanish returnparty_b7a17317:

    # "The princess could hear footsteps walking up closer, until a shadow loomed over her."
    "La princesa escuchó pasos acercándose, hasta que una sombra se cernió sobre ella."

# game/cethin.rpy:2668
translate Spanish returnparty_ce6abc0e:

    # voice "voice1/line190.mp3"
    # cethin "I'll lift up the blanket."
    voice "voice1/line190.mp3"
    cethin "Levantaré la manta."

# game/cethin.rpy:2672
translate Spanish returnparty_8a97e945:

    # lumishy "No."
    lumishy "No."

# game/cethin.rpy:2674
translate Spanish returnparty_a20cefa7:

    # "..."
    "..."

# game/cethin.rpy:2676
translate Spanish returnparty_755f2797:

    # "And then there was silence."
    "Y entonces hubo silencio."

# game/cethin.rpy:2678
translate Spanish returnparty_a7965c50:

    # "She could tell what he wanted to convey even without the use of words:{w} 'I'll wait for you.'"
    "Pudo entender lo que él quería transmitir sin necesidad de palabras:{w} “Te esperaré.”"

# game/cethin.rpy:2680
translate Spanish returnparty_fd3b0838:

    # lumishy "... Fine."
    lumishy "... Está bien."

# game/cethin.rpy:2682
translate Spanish returnparty_4ea7bf4b:

    # "She heard a soft sigh of relief from outside her covers."
    "Escuchó un suave suspiro de alivio desde fuera de sus cobijas."

# game/cethin.rpy:2686
translate Spanish returnparty_a6e4540b:

    # "Gently, her sheets were lifted up, revealing the girl trembling underneath."
    "Con cuidado, sus sábanas fueron levantadas, revelando a la chica temblando debajo."

# game/cethin.rpy:2693
translate Spanish returnparty_69001b54:

    # voice "voice1/line191.mp3"
    # cethin "You know I won't make fun of you."
    voice "voice1/line191.mp3"
    cethin "Sabes que no me burlaré de ti."

# game/cethin.rpy:2697
translate Spanish returnparty_e15be150:

    # lumishy "I know."
    lumishy "Lo sé."

# game/cethin.rpy:2701
translate Spanish returnparty_3f0cbf99:

    # voice "voice1/line192.mp3"
    # cethin "I like you too."
    voice "voice1/line192.mp3"
    cethin "Yo también te quiero."

# game/cethin.rpy:2707
translate Spanish returnparty_77140eee:

    # lumisickshock "...!" with vpunch
    lumisickshock "...!" with vpunch

# game/cethin.rpy:2709
translate Spanish returnparty_cdfdb136:

    # lumishy "S-so..."
    lumishy "A-así que..."

# game/cethin.rpy:2714
translate Spanish returnparty_155be103:

    # voice "voice1/line193.mp3"
    # cethin "But... not yet."
    voice "voice1/line193.mp3"
    cethin "Pero... aún no."

# game/cethin.rpy:2718
translate Spanish returnparty_c5f0dd59:

    # "The girl, who had been avoiding to meet his gaze, finally met his."
    "La chica, que había estado evitando mirarlo, finalmente cruzó su mirada con la de él."

# game/cethin.rpy:2722
translate Spanish returnparty_843a2888:

    # voice "voice1/line194.mp3"
    # cethin "I'm sorry, but please, wait a little longer."
    voice "voice1/line194.mp3"
    cethin "Lo siento, pero por favor, espera un poco más."

# game/cethin.rpy:2728
translate Spanish returnparty_de4ec841:

    # lumishy "How much longer?"
    lumishy "¿Cuánto más?"

# game/cethin.rpy:2730
translate Spanish returnparty_5e452969:

    # "She's been waiting and waiting and waiting..."
    "Ella había estado esperando y esperando y esperando..."

# game/cethin.rpy:2732
translate Spanish returnparty_a6f4f540:

    # "When the news of the hero's party arriving came, it was almost in her grasp, only to be taken right away."
    "Cuando llegó la noticia de que el grupo del héroe había arribado, casi la tenía al alcance, pero se la arrebataron enseguida."

# game/cethin.rpy:2734
translate Spanish returnparty_dc98bf71:

    # "And now, her heart has been stolen and the thief was right in front."
    "Y ahora, su corazón había sido robado y el ladrón estaba justo enfrente."

# game/cethin.rpy:2736
translate Spanish returnparty_d2895b6a:

    # "It's almost there. Yet it's not."
    "Casi lo tenía. Pero no del todo."

# game/cethin.rpy:2738
translate Spanish returnparty_9a216c94:

    # "She wanted to see the world he had shown her through his songs, through her own eyes."
    "Quería ver el mundo que él le había mostrado a través de sus canciones, con sus propios ojos."

# game/cethin.rpy:2740
translate Spanish returnparty_070f7364:

    # "Why was it so hard to grasp?"
    "¿Por qué era tan difícil alcanzarlo?"

# game/cethin.rpy:2744
translate Spanish returnparty_ae94be4c:

    # voice "voice1/line195.mp3"
    # cethin "Not much longer."
    voice "voice1/line195.mp3"
    cethin "No mucho más."

# game/cethin.rpy:2748
translate Spanish returnparty_0d6b58d6:

    # "He finally replied."
    "Finalmente respondió."

# game/cethin.rpy:2752
translate Spanish returnparty_e8c537ea:

    # "The girl swallowed, downhearted."
    "La chica tragó saliva, desanimada."

# game/cethin.rpy:2762
translate Spanish returnparty_0359fcde:

    # "But then- she felt her hand being grabbed."
    "Pero entonces... sintió que le tomaban la mano."

# game/cethin.rpy:2764
translate Spanish returnparty_d42cb8d0:

    # "Lumi looked up, and once again met Cethin's gaze."
    "Lumi levantó la vista, y una vez más se encontró con la mirada de Cethin."

# game/cethin.rpy:2768
translate Spanish returnparty_860e4d2f:

    # voice "voice1/line196.mp3"
    # cethin "You're a princess, and I'm..."
    voice "voice1/line196.mp3"
    cethin "Eres una princesa, y yo soy..."

# game/cethin.rpy:2775
translate Spanish returnparty_6787c27e:

    # voice "voice1/line197.mp3"
    # cethin "I'm nothing of note. A mere commoner."
    voice "voice1/line197.mp3"
    cethin "No soy nada especial. Un simple plebeyo."

# game/cethin.rpy:2779
translate Spanish returnparty_725016bf:

    # "She blinked."
    "Ella parpadeó."

# game/cethin.rpy:2781
translate Spanish returnparty_ed9f2e14:

    # lumishock "(Ah.)"
    lumishock "(Ah.)"

# game/cethin.rpy:2783
translate Spanish returnparty_8d994c32:

    # "Of course. This was something she had failed to take into consideration, as she had always assumed that Cethin was part of the hero's party..."
    "Por supuesto. Esto era algo que no había considerado, ya que siempre había asumido que Cethin era parte del grupo del héroe..."

# game/cethin.rpy:2785
translate Spanish returnparty_d675afb5:

    # "He may not have been the hero himself, but being a member was just as honorable- a heroic feat worthy of the princess' hand."
    "Puede que no fuera el héroe en sí, pero ser miembro ya era algo honorable, una hazaña digna de la mano de una princesa."

# game/cethin.rpy:2787
translate Spanish returnparty_adb4b871:

    # "But now with the truth that had come out... he didn't have the qualifications."
    "Pero ahora, con la verdad revelada... no tenía las cualificaciones."

# game/cethin.rpy:2789
translate Spanish returnparty_7fb69a64:

    # lumisad "(Has he thought about it this far...?)"
    lumisad "(¿Ha pensado en esto hasta ese punto...?)"

# game/cethin.rpy:2794
translate Spanish returnparty_06d1167a:

    # voice "voice1/line198.mp3"
    # cethin "That's why, I want to be someone who can protect you. Someone who you can be proud of. Someone who can stand by your side."
    voice "voice1/line198.mp3"
    cethin "Por eso, quiero ser alguien que pueda protegerte. Alguien de quien puedas sentirte orgullosa. Alguien que pueda estar a tu lado."

# game/cethin.rpy:2800
translate Spanish returnparty_938cb462:

    # voice "voice1/line199.mp3"
    # cethin "I want to be your hero."
    voice "voice1/line199.mp3"
    cethin "Quiero ser tu héroe."

# game/cethin.rpy:2804
translate Spanish returnparty_17596b0e:

    # "He placed one hand on her cheek, and then held her hand up with his other."
    "Colocó una mano en su mejilla, y luego sostuvo su mano con la otra."

# game/cethin.rpy:2809
translate Spanish returnparty_31b90591:

    # "The bard then brought her hand into his lips."
    "El bardo entonces llevó su mano a sus labios."

# game/cethin.rpy:2811
translate Spanish returnparty_1e3eba0b:

    # voice "voice1/line200.mp3"
    # cethin "This, I pledge."
    voice "voice1/line200.mp3"
    cethin "Esto, lo prometo."

# game/cethin.rpy:2815
translate Spanish returnparty_b22ab332:

    # "The girl could only watch."
    "La chica solo pudo observar."

# game/cethin.rpy:2817
translate Spanish returnparty_6f806014:

    # "She had to wait longer, but it was fine."
    "Tendría que esperar más tiempo, pero estaba bien."

# game/cethin.rpy:2819
translate Spanish returnparty_a0354789:

    # "Because this time, she didn't have to wait alone."
    "Porque esta vez, no tendría que esperar sola."

# game/cethin.rpy:2823
translate Spanish returnparty_7b68118d:

    # lumiblush "Hehe... very well. I accept."
    lumiblush "Hehe... muy bien. Lo acepto."

# game/cethin.rpy:2825
translate Spanish returnparty_36562336:

    # "Thus, the princess had officially granted Cethin the title of 'hero candidate'-"
    "Así, la princesa le otorgó oficialmente a Cethin el título de “candidato a héroe”-"

# game/cethin.rpy:2827
translate Spanish returnparty_0e494bcb:

    # "A privilege only those of royal blood could sanctify upon the worthy."
    "Un privilegio que solo quienes tenían sangre real podían otorgar a quien lo mereciera."

# game/cethin.rpy:2831
translate Spanish returnparty_3350b41e:

    # lumiblush "Then, I shall be waiting for you, my hero."
    lumiblush "Entonces, te estaré esperando, mi héroe."

# game/cethin.rpy:2833
translate Spanish returnparty_792cfe31:

    # "The rest of the night was spent like any another."
    "El resto de la noche transcurrió como cualquier otra."

# game/cethin.rpy:2837
translate Spanish returnparty_31946a9c:

    # "Chatting with each other, stories and songs."
    "Charlando entre ellos, historias y canciones."

# game/cethin.rpy:2841
translate Spanish returnparty_d7144884:

    # "It had been the same room, the same person, the same place..."
    "Era la misma habitación, la misma persona, el mismo lugar..."

# game/cethin.rpy:2843
translate Spanish returnparty_f19b8af7:

    # "Yet, everthing felt different."
    "Y aun así, todo se sentía diferente."

# game/cethin.rpy:2845
translate Spanish returnparty_0e079ac5:

    # "Her cold, lonely room... had become warm and comforting."
    "Su fría y solitaria habitación... se había vuelto cálida y reconfortante."

# game/cethin.rpy:2849
translate Spanish returnparty_10fd81d9:

    # "................................"
    "................................"

# game/cethin.rpy:2867
translate Spanish elvenears_6bc88919:

    # "Cethin started staying around Lumi's room for much longer periods before his training time."
    "Cethin empezó a quedarse en la habitación de Lumi por periodos mucho más largos antes de su hora de entrenamiento."

# game/cethin.rpy:2869
translate Spanish elvenears_95ed8a6b:

    # "He was no longer avoiding her."
    "Ya no la evitaba."

# game/cethin.rpy:2871
translate Spanish elvenears_62bdeffb:

    # "Most of the time, they'd just chat, drink tea, and enjoy some music..."
    "La mayoría del tiempo, solo charlaban, bebían té y disfrutaban algo de música..."

# game/cethin.rpy:2873
translate Spanish elvenears_49deec1f:

    # "It was almost just like how it was before, except...{w} they knew that they were more than friends."
    "Era casi igual que antes, excepto que...{w} sabían que eran más que amigos."

# game/cethin.rpy:2875
translate Spanish elvenears_c78b83b1:

    # "Not that either one would voice it out loud."
    "No es que ninguno de los dos lo dijera en voz alta."

# game/cethin.rpy:2877
translate Spanish elvenears_0b3fee05:

    # "They knew, and that was enough for now."
    "Lo sabían, y eso bastaba por ahora."

# game/cethin.rpy:2879
translate Spanish elvenears_2dd61a1a:

    # "Despite how they feel... both of them have drawn a line, to honor the promise."
    "A pesar de lo que sentían... ambos habían trazado una línea, para honrar la promesa."

# game/cethin.rpy:2886
translate Spanish elvenears_7337b9c4:

    # cethin "Uhm... Lumi, you've been staring for quite a while now."
    cethin "Uhm... Lumi, has estado mirando por un buen rato ya."

# game/cethin.rpy:2888
translate Spanish elvenears_387d2df3:

    # lumiserious "*STARES*"
    lumiserious "*MIRA FIJAMENTE*"

# game/cethin.rpy:2890
translate Spanish elvenears_58cdce7d:

    # lumiserious "... As I've thought."
    lumiserious "... Como pensé."

# game/cethin.rpy:2892
translate Spanish elvenears_5977856d:

    # lumiblush "I really want to do it."
    lumiblush "Realmente quiero hacerlo."

# game/cethin.rpy:2896
translate Spanish elvenears_343acc90:

    # cethin "D-do what...?"
    cethin "¿H-hacer qué...?"

# game/cethin.rpy:2898
translate Spanish elvenears_02c99a65:

    # lumiuwu "Do it with you!"
    lumiuwu "¡Hacerlo contigo!"

# game/cethin.rpy:2900
translate Spanish elvenears_663a46ed:

    # lumiehe "I'd like to touch your ears!"
    lumiehe "¡Quisiera tocar tus orejas!"

# game/cethin.rpy:2902
translate Spanish elvenears_79486c60:

    # lumiblush "(I've been wondering how they felt like...)"
    lumiblush "(Me he estado preguntando cómo se sentirán...)"

# game/cethin.rpy:2904
translate Spanish elvenears_c8acf6a7:

    # lumiehe "(Especially when they're drooping like that!)"
    lumiehe "(¡Especialmente cuando están caídas así!)"

# game/cethin.rpy:2906
translate Spanish elvenears_cdb3365e:

    # "The girl continued staring intently."
    "La chica continuó mirándolo fijamente con intensidad."

# game/cethin.rpy:2908
translate Spanish elvenears_15d94b6e:

    # "The dark elf didn't show any sign of relief despite her clarification, in fact, he looked distraught."
    "El elfo oscuro no mostró señal de alivio a pesar de su aclaración; de hecho, parecía angustiado."

# game/cethin.rpy:2912
translate Spanish elvenears_f9ed3d3a:

    # cethin "Ngh... I suppose-"
    cethin "Ngh... Supongo que-"

# game/cethin.rpy:2914
translate Spanish elvenears_cb83435f:

    # lumiserious "*STAAAAAAAAAAAAAAAAARE*"
    lumiserious "*MIIIIIIIIIIIIIIIIIIIIIRA FIJAMENTE*"

# game/cethin.rpy:2916
translate Spanish elvenears_00dfb902:

    # "The pressure was on."
    "La presión aumentaba."

# game/cethin.rpy:2918
translate Spanish elvenears_2b12a6a2:

    # "Look at those sparkly eyes!"
    "¡Mira esos ojos brillantes!"

# game/cethin.rpy:2920
translate Spanish elvenears_0c939008:

    # "How do you resist that?"
    "¿Cómo se resiste uno a eso?"

# game/cethin.rpy:2924
translate Spanish elvenears_8128bf35:

    # cethin "As long as...{w} you be gentle with them."
    cethin "Mientras...{w} seas delicada con ellas."

# game/cethin.rpy:2926
translate Spanish elvenears_ec3fb5e6:

    # cethin "They're rather sensitive."
    cethin "Son bastante sensibles."

# game/cethin.rpy:2928
translate Spanish elvenears_948c3c03:

    # lumihappy "Oh, really? Wonderful!"
    lumihappy "¿Oh, en serio? ¡Maravilloso!"

# game/cethin.rpy:2932
translate Spanish elvenears_14d02148:

    # "She leaped up excitedly and skipped behind him."
    "Ella dio un salto emocionada y se movió detrás de él con saltitos."

# game/cethin.rpy:2934
translate Spanish elvenears_6049a21e:

    # "... Almost as though she didn't hear his warning."
    "... Casi como si no hubiera escuchado su advertencia."

# game/cethin.rpy:2948
translate Spanish elvenears_36340176:

    # "The princess hesitated at first, but her eyes were definitely focused on the elf's ears, as if she were studying them."
    "La princesa dudó al principio, pero sus ojos estaban claramente enfocados en las orejas del elfo, como si las estudiara."

# game/cethin.rpy:2950
translate Spanish elvenears_9abeee1c:

    # lumiehe "So, this is what they look up close!"
    lumiehe "¡Así que así se ven de cerca!"

# game/cethin.rpy:2952
translate Spanish elvenears_27081bc5:

    # "Slowly, she reached out to one ear and grabbed the tip with her thumb and index finger."
    "Lentamente, extendió la mano hacia una oreja y la sostuvo por la punta con el pulgar y el índice."

# game/cethin.rpy:2954
translate Spanish elvenears_58c3f909:

    # "She then played around with it, albeit gently."
    "Luego empezó a jugar con ella, aunque con suavidad."

# game/cethin.rpy:2956
translate Spanish elvenears_09efec63:

    # lumiblush "(Ah, this is how it feels like.)"
    lumiblush "(Ah, así es como se siente.)"

# game/cethin.rpy:2958
translate Spanish elvenears_593a2e60:

    # lumiehe "(It's so soft, like... like... wet pasta? But a tad harder.)"
    lumiehe "(Es tan suave, como... como... ¿pasta húmeda? Pero un poco más firme.)"

# game/cethin.rpy:2960
translate Spanish elvenears_f11eeb79:

    # cethin "Ngh..." with vpunch
    cethin "Ngh..." with vpunch

# game/cethin.rpy:2962
translate Spanish elvenears_868ffeb8:

    # lumishock "Oh! Was it painful? I'm sorry..."
    lumishock "¡Oh! ¿Te dolió? Lo siento..."

# game/cethin.rpy:2964
translate Spanish elvenears_436d35b1:

    # cethin "N-no... it... just tickled."
    cethin "N-no... solo... me hizo cosquillas."

# game/cethin.rpy:2966
translate Spanish elvenears_e6991067:

    # lumitalk "I see. Are all elves ticklish around their ears?"
    lumitalk "Ya veo. ¿Todos los elfos son sensibles alrededor de las orejas?"

# game/cethin.rpy:2968
translate Spanish elvenears_73daa92b:

    # cethin "I... I don't know."
    cethin "Y... yo no lo sé."

# game/cethin.rpy:2970
translate Spanish elvenears_88e24a9c:

    # cethin "No one would ever dare ask to touch them... normally, anyway."
    cethin "Nadie se atrevería jamás a pedir tocarlas... al menos, en circunstancias normales."

# game/cethin.rpy:2972
translate Spanish elvenears_551fba6b:

    # lumi "Hm? Is that so..."
    lumi "¿Hm? ¿En serio...?"

# game/cethin.rpy:2974
translate Spanish elvenears_d9f8e18c:

    # lumided "(I suppose I really am the only one who finds them adorable.)"
    lumided "(Supongo que realmente soy la única que las encuentra adorables.)"

# game/cethin.rpy:2976
translate Spanish elvenears_0d521bf2:

    # lumitalk "Is it fine to continue?"
    lumitalk "¿Está bien que sigamos?"

# game/cethin.rpy:2978
translate Spanish elvenears_6ab3045d:

    # cethin "Y-yeah... suit yourself."
    cethin "S-sí... haz lo que quieras."

# game/cethin.rpy:2980
translate Spanish elvenears_351bb192:

    # "This time, she traced the edge of his ears with her fingers."
    "Esta vez, ella trazó el borde de sus orejas con los dedos."

# game/cethin.rpy:2982
translate Spanish elvenears_153490d1:

    # cethin "Ghh...!" with vpunch
    cethin "Ghh...!" with vpunch

# game/cethin.rpy:2984
translate Spanish elvenears_27d454d1:

    # lumishock "Hehe... sorry for tickling you."
    lumishock "Hehe... perdón por hacerte cosquillas."

# game/cethin.rpy:2986
translate Spanish elvenears_ed54e4d4:

    # "Cethin just gave her a sheepish smile, coupled with a nod."
    "Cethin solo le dio una sonrisa tímida, acompañada de un asentimiento."

# game/cethin.rpy:2988
translate Spanish elvenears_f2017358:

    # lumi "(Then what about...)"
    lumi "(Entonces, ¿qué tal si...)"

# game/cethin.rpy:2990
translate Spanish elvenears_39e4d19e:

    # "This time, the girl stroked his ears."
    "Esta vez, la chica acarició sus orejas."

# game/cethin.rpy:2992
translate Spanish elvenears_34aa5732:

    # cethin "Ngh... ghh... aah..." with vpunch
    cethin "Ngh... ghh... aah..." with vpunch

# game/cethin.rpy:2994
translate Spanish elvenears_17a4d782:

    # "Slowly, his droopy ears began to harden, until it felt like human ears to the touch."
    "Lentamente, sus orejas caídas comenzaron a endurecerse, hasta que se sintieron como orejas humanas al tacto."

# game/cethin.rpy:2996
translate Spanish elvenears_0876cf75:

    # lumi "(Or actually, it feels quite harder?)"
    lumi "(O en realidad, ¿se sienten más duras?)"

# game/cethin.rpy:2998
translate Spanish elvenears_07bf95e2:

    # "She thought to herself, while comparing his ears with her own."
    "Pensó para sí misma, mientras comparaba sus orejas con las propias."

# game/cethin.rpy:3000
translate Spanish elvenears_b0ca4660:

    # lumiehe "(It sure is smooth though!)"
    lumiehe "(¡Aunque son bastante suaves!)"

# game/cethin.rpy:3002
translate Spanish elvenears_c96b3dcf:

    # cethin "Ha... haa... hahaha..." with vpunch
    cethin "Ja... Jaa... Jajaja..." with vpunch

# game/cethin.rpy:3004
translate Spanish elvenears_4dc43a9f:

    # "Finally noticing Cethin's laborous attempt to hold in his laughter, Lumi retracted her hand."
    "Finalmente, al notar el intento laborioso de Cethin por contener la risa, Lumi retiró su mano."

# game/cethin.rpy:3006
translate Spanish elvenears_657a8f12:

    # lumided "You know, I wouldn't mind if you laugh."
    lumided "Sabes, no me molestaría si te ríes."

# game/cethin.rpy:3008
translate Spanish elvenears_081ba3e8:

    # cethin "But... it's embarrassing..."
    cethin "Pero... es vergonzoso..."

# game/cethin.rpy:3010
translate Spanish elvenears_fa53af1f:

    # "At the moment, his ears drooped again."
    "En ese momento, sus orejas volvieron a caer."

# game/cethin.rpy:3012
translate Spanish elvenears_9f47eb70:

    # lumihappy "You have no need to be ashamed around me."
    lumihappy "No tienes por qué avergonzarte conmigo."

# game/cethin.rpy:3014
translate Spanish elvenears_fa048c6f:

    # lumishy "(Besides, I do want to see you laugh.)"
    lumishy "(Además, quiero verte reír.)"

# game/cethin.rpy:3016
translate Spanish elvenears_1c007488:

    # cethin "I could say the same to you..."
    cethin "Podría decir lo mismo de ti..."

# game/cethin.rpy:3022
translate Spanish elvenears_c1152089:

    # lumided "Well now, no more holding back."
    lumided "Bueno, ya está, nada de contenerse."

# game/cethin.rpy:3024
translate Spanish elvenears_83bf52e1:

    # cethin "Hm?"
    cethin "¿Hm?"

# game/cethin.rpy:3026
translate Spanish elvenears_dafef9a2:

    # "He blinked, moments before carnage-"
    "Parpadeó, momentos antes de la carnicería—"

# game/cethin.rpy:3028
translate Spanish elvenears_383f81de:

    # "The princess first touched the tip of his droopy ears again and then began to stroke them."
    "La princesa primero tocó la punta de sus orejas caídas nuevamente y luego comenzó a acariciarlas."

# game/cethin.rpy:3030
translate Spanish elvenears_0f18ddee:

    # "Like before, they slowly hardened, and while she did her deed..."
    "Como antes, se endurecieron lentamente, y mientras ella continuaba su tarea..."

# game/cethin.rpy:3034
translate Spanish elvenears_372c2367:

    # cethin "Ha... HAHAHAHAHA...! STO- HAHAHAHA...!" with vpunch
    cethin "Ja... JAJAJAJAJA...! PAR- JAJAJAJA...!" with vpunch

# game/cethin.rpy:3036
translate Spanish elvenears_6ccedcca:

    # cethin "STO... Stop... ha... stop... ha... haha..." with vpunch
    cethin "PAR-... Par-... ja... para... ja... jaja..." with vpunch

# game/cethin.rpy:3038
translate Spanish elvenears_ef558039:

    # lumishock "Oh dear, was that too much?"
    lumishock "Oh cielos, ¿fue demasiado?"

# game/cethin.rpy:3040
translate Spanish elvenears_97a1a4ce:

    # cethin "I... it's fine. I am fine. Ha..."
    cethin "Y... está bien. Estoy bien. Ha..."

# game/cethin.rpy:3042
translate Spanish elvenears_5714c251:

    # lumiblush "Good. Round two?"
    lumiblush "Bien. ¿Ronda dos?"

# game/cethin.rpy:3044
translate Spanish elvenears_79399913:

    # cethin "No...! Please, no...!"
    cethin "¡No...! ¡Por favor, no...!"

# game/cethin.rpy:3046
translate Spanish elvenears_fc138734:

    # "Despite his adamant refusal, it was obvious that he was having fun."
    "A pesar de su negativa rotunda, era obvio que se estaba divirtiendo."

# game/cethin.rpy:3048
translate Spanish elvenears_18f362a6:

    # "And the two just roughhoused like children throughout the morning, until Cethin left for his training."
    "Y los dos simplemente jugaron como niños durante toda la mañana, hasta que Cethin se fue a su entrenamiento."

# game/cethin.rpy:3054
translate Spanish elvenears_aff19f42:

    # "Later that afternoon..."
    "Más tarde esa tarde..."

# game/cethin.rpy:3061
translate Spanish elvenears_7a1d720c:

    # reo "You did what?!" with vpunch
    reo "¡¿Hiciste qué?!" with vpunch

# game/cethin.rpy:3063
translate Spanish elvenears_a663dd88:

    # "The butler looked as though he had heard something horrendous."
    "El mayordomo parecía como si hubiera escuchado algo horrendo."

# game/cethin.rpy:3067
translate Spanish elvenears_915f526c:

    # "He then proceeded to massage his temples."
    "Luego procedió a masajearse las sienes."

# game/cethin.rpy:3069
translate Spanish elvenears_80a41b64:

    # "Lumi couldn't help but freeze in place, with her teacup hanging in midair."
    "Lumi no pudo evitar quedarse paralizada, con su taza de té suspendida en el aire."

# game/cethin.rpy:3071
translate Spanish elvenears_2cb294f6:

    # "She suddenly felt like she did something terribly wrong..."
    "De repente sintió que había hecho algo terriblemente mal..."

# game/cethin.rpy:3073
translate Spanish elvenears_cb1e4ce7:

    # reo "Goodness... have you any idea how sensitive an elf's ears are?"
    reo "Dios mío... ¿tienes idea de lo sensibles que son las orejas de un elfo?"

# game/cethin.rpy:3075
translate Spanish elvenears_a306c31d:

    # lumisad "Erm... Cethin did tell me that they were."
    lumisad "Eh... Cethin me dijo que lo eran."

# game/cethin.rpy:3079
translate Spanish elvenears_6f168932:

    # reo "Indeed. But that fool seemed to have downplayed it."
    reo "En efecto. Pero ese tonto parece haberlo minimizado."

# game/cethin.rpy:3081
translate Spanish elvenears_baa02422:

    # "The butler clicked his tongue."
    "El mayordomo chasqueó la lengua."

# game/cethin.rpy:3085
translate Spanish elvenears_902699c2:

    # reo "I suppose it isn't common knowledge, but ears of elves are... their weakpoint."
    reo "Supongo que no es conocimiento común, pero las orejas de los elfos son... su punto débil."

# game/cethin.rpy:3087
translate Spanish elvenears_ef94d11a:

    # reo "Cut them down, and they bleed to death."
    reo "Córtalas, y sangran hasta morir."

# game/cethin.rpy:3091
translate Spanish elvenears_97e8f435:

    # reo "Hold on to them, and the elf in question will be weakened."
    reo "Si las sujetas, el elfo en cuestión se debilitará."

# game/cethin.rpy:3093
translate Spanish elvenears_3bd5d15c:

    # reo "Instantly so, as if their strength had left their bodies."
    reo "Instantáneamente, como si toda su fuerza abandonara su cuerpo."

# game/cethin.rpy:3097
translate Spanish elvenears_6a94e86b:

    # reo "So, under ordinary circumstances... no sane elf would ever allow anyone to touch their ears!"
    reo "Así que, en circunstancias normales... ¡ningún elfo en su sano juicio permitiría que alguien tocara sus orejas!"

# game/cethin.rpy:3101
translate Spanish elvenears_8d50d4f1:

    # reo "Not their friends, not their lovers, not even their own family."
    reo "Ni sus amigos, ni sus amantes, ni siquiera su propia familia."

# game/cethin.rpy:3103
translate Spanish elvenears_027a1e40:

    # reo "Had you asked any other elf such a thing..."
    reo "Si le hubieras pedido tal cosa a cualquier otro elfo..."

# game/cethin.rpy:3107
translate Spanish elvenears_ea146961:

    # reo "They would have spat on you, cursed your family for five generations, and forbidden you to step foot on any elven territory!"
    reo "¡Te habrían escupido, maldecido a tu familia por cinco generaciones y prohibido poner un pie en cualquier territorio élfico!"

# game/cethin.rpy:3110
translate Spanish elvenears_122bdb23:

    # reo "Do. You. Understand?"
    reo "¿Lo. Entiendes?"

# game/cethin.rpy:3112
translate Spanish elvenears_f40ccb4c:

    # "Instead of feeling terrible about it-"
    "En lugar de sentirse terrible por ello—"

# game/cethin.rpy:3114
translate Spanish elvenears_b887ae43:

    # lumiblush "(I feel awful that I feel happy about this...)"
    lumiblush "(Me siento horrible de estar feliz por esto...)"

# game/cethin.rpy:3116
translate Spanish elvenears_7e802984:

    # lumishy "(Cethin trusted me that much...?)"
    lumishy "(¿Cethin confió tanto en mí...?)"

# game/cethin.rpy:3118
translate Spanish elvenears_cbea5e9d:

    # reo "I know that look."
    reo "Conozco esa mirada."

# game/cethin.rpy:3120
translate Spanish elvenears_be47c6a3:

    # "He sneered."
    "Él bufó."

# game/cethin.rpy:3126
translate Spanish elvenears_46cf834c:

    # reo "Tch. What do I do with you two...?"
    reo "Tch. ¿Qué voy a hacer con ustedes dos...?"

# game/cethin.rpy:3132
translate Spanish elvenears_1fe442fc:

    # "After that incident, Lumi could only stare at Cethin's ears longingly."
    "Después de ese incidente, Lumi solo podía mirar las orejas de Cethin con anhelo."

# game/cethin.rpy:3134
translate Spanish elvenears_65c82ab7:

    # "The night elf would offer her to touch them again, but she'd hold back... begrudgingly."
    "El elfo oscuro volvía a ofrecerle que las tocara, pero ella se contenía... a regañadientes."

# game/cethin.rpy:3141
translate Spanish elvenears_76800131:

    # "And thus marked the end of Lumi's {i}'elven ear touching escapades'{/i}."
    "Y así marcó el fin de las {i}'aventuras de Lumi tocando orejas élficas'{/i}."

# game/cethin.rpy:3145
translate Spanish elvenears_b9978196:

    # "... At least until her conscience stops bothering her."
    "... Al menos hasta que su conciencia dejara de molestarla."

# game/cethin.rpy:3152
translate Spanish cethinfinale_ec88d8bb:

    # ".................."
    ".................."

# game/cethin.rpy:3158
translate Spanish cethinfinale_0a000e93:

    # voice "voice2/line91.mp3"
    # "Once upon a time, there was a princess."
    voice "voice2/line91.mp3"
    "Había una vez una princesa."

# game/cethin.rpy:3162
translate Spanish cethinfinale_16731cae:

    # voice "voice2/line92.mp3"
    # "The princess lived a carefree life, and was surrounded by all the luxuries money can buy..."
    voice "voice2/line92.mp3"
    "La princesa vivía una vida despreocupada, rodeada de todos los lujos que el dinero podía comprar..."

# game/cethin.rpy:3166
translate Spanish cethinfinale_3e6e7635:

    # voice "voice2/line93.mp3"
    # "Yet she could not find happiness."
    voice "voice2/line93.mp3"
    "Aun así, no podía encontrar la felicidad."

# game/cethin.rpy:3170
translate Spanish cethinfinale_301626bb:

    # voice "voice2/line94.mp3"
    # "How could she? When she was akin to a bird trapped in a cage."
    voice "voice2/line94.mp3"
    "¿Cómo podría hacerlo? Si era como un ave atrapada en una jaula."

# game/cethin.rpy:3174
translate Spanish cethinfinale_2860901f:

    # voice "voice2/line95.mp3"
    # "She had no freedom of her own."
    voice "voice2/line95.mp3"
    "No tenía libertad propia."

# game/cethin.rpy:3178
translate Spanish cethinfinale_ca5182d2:

    # voice "voice2/line96.mp3"
    # "She was a mere decoration."
    voice "voice2/line96.mp3"
    "Era una simple decoración."

# game/cethin.rpy:3184
translate Spanish cethinfinale_2189e48f:

    # voice "voice2/line97.mp3"
    # "Once upon a time, the princess was kidnapped by an evil king."
    voice "voice2/line97.mp3"
    "Había una vez, la princesa fue secuestrada por un rey malvado."

# game/cethin.rpy:3188
translate Spanish cethinfinale_13fac657:

    # voice "voice2/line98.mp3"
    # "He trapped her in a tower filled with dangerous and monstrous things."
    voice "voice2/line98.mp3"
    "Él la encerró en una torre llena de cosas peligrosas y monstruosas."

# game/cethin.rpy:3192
translate Spanish cethinfinale_e7d949d9:

    # voice "voice2/line99.mp3"
    # "The princess had no choice but to wait in the tower..."
    voice "voice2/line99.mp3"
    "La princesa no tuvo más opción que esperar en la torre..."

# game/cethin.rpy:3196
translate Spanish cethinfinale_7cdb6e10:

    # voice "voice2/line100.mp3"
    # "Until one of valiant heart can brave the trials that lay within..."
    voice "voice2/line100.mp3"
    "Hasta que alguien de corazón valiente pudiera superar las pruebas que yacían dentro..."

# game/cethin.rpy:3200
translate Spanish cethinfinale_814edc1a:

    # voice "voice2/line101.mp3"
    # "And only then, can the princess obtain happiness forevermore."
    voice "voice2/line101.mp3"
    "Y solo entonces, la princesa podría obtener la felicidad para siempre."

# game/cethin.rpy:3211
translate Spanish cethinfinale_9e38e614:

    # "The horned figure snapped the hardcover book to a close."
    "La figura con cuernos cerró el libro de tapa dura de golpe."

# game/cethin.rpy:3215
translate Spanish cethinfinale_0091c042:

    # "His expression was unreadable, as if there was a lot going on inside his head, yet he revealed none of them."
    "Su expresión era indescifrable, como si tuviera mucho en la cabeza, pero no revelaba nada."

# game/cethin.rpy:3217
translate Spanish cethinfinale_5ab6b29f:

    # "He let out a huff, before looking up the sky."
    "Soltó un resoplido antes de mirar hacia el cielo."

# game/cethin.rpy:3221
translate Spanish cethinfinale_b9d5d4c3:

    # voice "voice2/line102.mp3"
    # reo "Ha. What a typical story."
    voice "voice2/line102.mp3"
    reo "Ja. Qué historia tan típica."

# game/cethin.rpy:3227
translate Spanish cethinfinale_9cad03a8:

    # "A strong wind blew, causing some of the red head's hair to sway along."
    "Un viento fuerte sopló, haciendo que parte del cabello del pelirrojo se agitara."

# game/cethin.rpy:3229
translate Spanish cethinfinale_70a66d2e:

    # "He pulled them back and returned his gaze on the castle beyond."
    "Él lo apartó y volvió su mirada hacia el castillo más allá."

# game/cethin.rpy:3233
translate Spanish cethinfinale_6d6118ae:

    # voice "voice2/line103.mp3"
    # reo "How boring."
    voice "voice2/line103.mp3"
    reo "Qué aburrido."

# game/cethin.rpy:3237
translate Spanish cethinfinale_20b73fa0:

    # voice "voice2/line104.mp3"
    # reo "Hm. It's about time I return."
    voice "voice2/line104.mp3"
    reo "Hm. Es hora de regresar."

# game/cethin.rpy:3243
translate Spanish cethinfinale_f6e9ad9d:

    # voice "voice2/line105.mp3"
    # reo "I wouldn't want to miss the ending."
    voice "voice2/line105.mp3"
    reo "No quisiera perderme el final."

# game/cethin.rpy:3251
translate Spanish cethinfinale_62406776:

    # lumisad "Ugh... where?"
    lumisad "Ugh... ¿dónde...?"

# game/cethin.rpy:3257
translate Spanish cethinfinale_9207b6c0:

    # voice "voice3/f22.mp3"
    # who "Oh dear princess, you've finally awakened!"
    voice "voice3/f22.mp3"
    who "Oh querida princesa, ¡por fin has despertado!"

# game/cethin.rpy:3263
translate Spanish cethinfinale_4a4ae1a2:

    # voice "voice3/f23.mp3"
    # hero "How are you feeling?"
    voice "voice3/f23.mp3"
    hero "¿Cómo te sientes?"

# game/cethin.rpy:3267
translate Spanish cethinfinale_d51bb646:

    # lumishock "Y-you...!"
    lumishock "T-tú... ¡tú...!"

# game/cethin.rpy:3269
translate Spanish cethinfinale_27962c10:

    # "She tried to budge, but failed."
    "Intentó moverse, pero falló."

# game/cethin.rpy:3271
translate Spanish cethinfinale_994b1673:

    # "Having gotten over her disorientation, the princess found herself tied up and wrapped around the arms of the so-called hero."
    "Tras superar su desorientación, la princesa se encontró atada y sostenida entre los brazos del supuesto héroe."

# game/cethin.rpy:3273
translate Spanish cethinfinale_478718bf:

    # lumisad "(Ugh... what had happened...?)"
    lumisad "(Ugh... ¿qué había pasado...?)"

# game/cethin.rpy:3275
translate Spanish cethinfinale_631d3909:

    # "She tried to recall her last memories..."
    "Trató de recordar sus últimos recuerdos..."

# game/cethin.rpy:3277
translate Spanish cethinfinale_ca562534:

    # "If she wasn't mistaken, she just bid Cethin goodbye before his training and then..."
    "Si no se equivocaba, acababa de despedirse de Cethin antes de su entrenamiento y luego..."

# game/cethin.rpy:3279
translate Spanish cethinfinale_96daa694:

    # lumisad "(There was a strong explosion, and I passed out...?)"
    lumisad "(¿Hubo una fuerte explosión y perdí el conocimiento...?)"

# game/cethin.rpy:3281
translate Spanish cethinfinale_692f7100:

    # darkmage "The sleep spell worked on her perfectly."
    darkmage "El hechizo del sueño funcionó perfectamente en ella."

# game/cethin.rpy:3283
translate Spanish cethinfinale_6ce916af:

    # mage "Studying the time that drow leaves through the balcony was so smart of you Farol!"
    mage "¡Estudiar la hora en la que el drow sale por el balcón fue muy inteligente de tu parte, Farol!"

# game/cethin.rpy:3287
translate Spanish cethinfinale_30f3b707:

    # hero "It was easy, dear."
    hero "Fue fácil, querida."

# game/cethin.rpy:3289
translate Spanish cethinfinale_48d40221:

    # lumisad "(I see... they figured out Cethin's schedule.)"
    lumisad "(Ya veo... descubrieron el horario de Cethin.)"

# game/cethin.rpy:3291
translate Spanish cethinfinale_77beb8c3:

    # hero "Now princess, I hope you are well?"
    hero "Ahora princesa, ¿espero que se encuentre bien?"

# game/cethin.rpy:3293
translate Spanish cethinfinale_b1b45fdf:

    # "He then turned his attention to the black mage."
    "Luego dirigió su atención a la maga oscura."

# game/cethin.rpy:3297
translate Spanish cethinfinale_8050c515:

    # hero "Could you tell if the princess is still under the drow's spell?"
    hero "¿Podrías decir si la princesa sigue bajo el hechizo del drow?"

# game/cethin.rpy:3299
translate Spanish cethinfinale_f8f774ac:

    # lumided "(Spell...?)"
    lumided "(¿Hechizo...?)"

# game/cethin.rpy:3301
translate Spanish cethinfinale_ea773e68:

    # darkmage "I can't. I'm not familiar with the dark arts."
    darkmage "No puedo. No estoy familiarizado con las artes oscuras."

# game/cethin.rpy:3303
translate Spanish cethinfinale_741e19fd:

    # lumided "(Ah. I think I have a good idea of what is going on here...)"
    lumided "(Ah. Creo que tengo una buena idea de lo que está pasando aquí...)"

# game/cethin.rpy:3305
translate Spanish cethinfinale_d5db631f:

    # lumisad "(I hope Cethin or Reo catches on...)"
    lumisad "(Espero que Cethin o Reo lo noten...)"

# game/cethin.rpy:3307
translate Spanish cethinfinale_3ddd991b:

    # "A pause."
    "Una pausa."

# game/cethin.rpy:3309
translate Spanish cethinfinale_d7454d39:

    # lumisad "(Come to think of it, Reo did not appear the last time they came around...)"
    lumisad "(Ahora que lo pienso, Reo no apareció la última vez que vinieron...)"

# game/cethin.rpy:3311
translate Spanish cethinfinale_ca9251cd:

    # lumisad "(And then he came waltzing in as though nothing happened...?)"
    lumisad "(¿Y luego entró como si nada hubiera pasado...?)"

# game/cethin.rpy:3315
translate Spanish cethinfinale_fb58af13:

    # hero "The princess has been awfully quiet."
    hero "La princesa ha estado terriblemente callada."

# game/cethin.rpy:3320
translate Spanish cethinfinale_d1f8edc9:

    # hero "I take that this is a sign of that cursed spell."
    hero "Tomo eso como una señal de ese hechizo maldito."

# game/cethin.rpy:3322
translate Spanish cethinfinale_001ae65a:

    # mage "Oooh! You're right!"
    mage "¡Oooh! ¡Tienes razón!"

# game/cethin.rpy:3324
translate Spanish cethinfinale_3489c2bf:

    # lumided "(I'd say, it was more because I was observing the situation...)"
    lumided "(Diría que más bien estaba observando la situación...)"

# game/cethin.rpy:3326
translate Spanish cethinfinale_9209fc91:

    # "The hero huffed proudly and gave his chest a pound."
    "El héroe bufó con orgullo y se dio un golpe en el pecho."

# game/cethin.rpy:3330
translate Spanish cethinfinale_d547c132:

    # hero "Well then, let us go onward to destroy the vile demon lord!"
    hero "¡Bien entonces, avancemos para destruir al vil señor demonio!"

# game/cethin.rpy:3332
translate Spanish cethinfinale_47026764:

    # darkmage "We're right behind you."
    darkmage "Estamos justo detrás de ti."

# game/cethin.rpy:3334
translate Spanish cethinfinale_579ba815:

    # mage "I'll make sure to provide support!"
    mage "¡Me aseguraré de brindar apoyo!"

# game/cethin.rpy:3336
translate Spanish cethinfinale_183b3285:

    # lumishock "(They are going straight for it?!)" with vpunch
    lumishock "(¿¡Van directo a eso?!)" with vpunch

# game/cethin.rpy:3338
translate Spanish cethinfinale_9d773e97:

    # lumishock "Hold it! Why would you bring me along?!"
    lumishock "¡Esperen! ¿Por qué me llevarían con ustedes?!"

# game/cethin.rpy:3340
translate Spanish cethinfinale_08b01a44:

    # "The trio were taken aback from her sudden outburst."
    "El trío se sobresaltó ante su repentino arrebato."

# game/cethin.rpy:3344
translate Spanish cethinfinale_f48cd6db:

    # hero "Huh. She only responded when we mentioned the demon lord..."
    hero "Huh. Solo respondió cuando mencionamos al señor demonio..."

# game/cethin.rpy:3348
translate Spanish cethinfinale_dd384e2d:

    # hero "Hm...! Hm...! I see! Then my hypothesis that the princess is under a spell must be true!"
    hero "¡Hm...! ¡Hm...! ¡Ya veo! ¡Entonces mi hipótesis de que la princesa está bajo un hechizo debe ser cierta!"

# game/cethin.rpy:3350
translate Spanish cethinfinale_234da632:

    # "Her question was ignored. They do seem quite convinced that she was not in the right state of mind."
    "Su pregunta fue ignorada. Parecían bastante convencidos de que no estaba en su sano juicio."

# game/cethin.rpy:3352
translate Spanish cethinfinale_d1c75779:

    # lumided "(Gods, he's delusional...)"
    lumided "(Dioses, está delirando...)"

# game/cethin.rpy:3356
translate Spanish cethinfinale_855ffb5a:

    # hero "Worry not, princess. We shan't prolong your suffering."
    hero "No tema, princesa. No prolongaremos su sufrimiento."

# game/cethin.rpy:3360
translate Spanish cethinfinale_722005ab:

    # hero "Once we vanquish the demon lord, you'll be freed from that curse!"
    hero "¡Cuando derrotemos al señor demonio, te liberarás de esa maldición!"

# game/cethin.rpy:3362
translate Spanish cethinfinale_0c1a0fab:

    # "Never mind that..."
    "No importa eso..."

# game/cethin.rpy:3364
translate Spanish cethinfinale_a2e28332:

    # lumisad "(I know I've always wished to be able to leave from here...)"
    lumisad "(Sé que siempre he deseado poder irme de aquí...)"

# game/cethin.rpy:3366
translate Spanish cethinfinale_d65adbf7:

    # lumiuwu "(But not like this!)"
    lumiuwu "(¡Pero no así!)"

# game/cethin.rpy:3368
translate Spanish cethinfinale_e9451aa8:

    # "She wasn't even sure if they were capable enough of defeating it..."
    "Ni siquiera estaba segura de que fueran lo suficientemente capaces de derrotarlo..."

# game/cethin.rpy:3370
translate Spanish cethinfinale_27fe7541:

    # "But the fact that they've managed to sneak into the castle twice, meant that they must have gotten more powerful than before."
    "Pero el hecho de que hubieran logrado colarse en el castillo dos veces significaba que debían haberse vuelto más poderosos que antes."

# game/cethin.rpy:3373
translate Spanish cethinfinale_e0c8ab3d:

    # lumisad "(I mustn't be hasty.)"
    lumisad "(No debo ser imprudente.)"

# game/cethin.rpy:3375
translate Spanish cethinfinale_ef2416e4:

    # lumiserious "(I must find an opening to escape...)"
    lumiserious "(Debo encontrar una oportunidad para escapar...)"

# game/cethin.rpy:3377
translate Spanish cethinfinale_8461b4fd:

    # lumiserious "(For now, it might be best to go along with them.)"
    lumiserious "(Por ahora, lo mejor podría ser seguirles el juego.)"

# game/cethin.rpy:3382
translate Spanish cethinfinale_89722df0:

    # "And thus, they continued onward to their final battle."
    "Y así, continuaron hacia su batalla final."

# game/cethin.rpy:3384
translate Spanish cethinfinale_c103cf35:

    # "There were monsters along the way, but the group managed to fend them off with ease, even while keeping watch on the princess."
    "Había monstruos en el camino, pero el grupo logró defenderse con facilidad, incluso mientras vigilaban a la princesa."

# game/cethin.rpy:3386
translate Spanish cethinfinale_b998aac5:

    # "The trio was surprisingly competent. No wonder they managed to reach this castle."
    "El trío era sorprendentemente competente. No era de extrañar que hubieran logrado llegar a este castillo."

# game/cethin.rpy:3388
translate Spanish cethinfinale_d0822bc9:

    # "They coordinate rather well- with the hero on vanguard, and with the two magic users behind always alert and ready to support."
    "Se coordinaban bastante bien: el héroe iba al frente y las dos magas permanecían detrás, siempre alertas y listas para apoyar."

# game/cethin.rpy:3390
translate Spanish cethinfinale_528db8f8:

    # "The hero, Farol, even wielded a rare fire elemental sword."
    "El héroe, Farol, incluso empuñaba una rara espada elemental de fuego."

# game/cethin.rpy:3396
translate Spanish cethinfinale_13762e98:

    # lumisad "(I believe Cethin had mentioned that the sword is a divine blade called 'Edana'.)"
    lumisad "(Creo que Cethin mencionó que la espada es una hoja divina llamada ‘Edana’.)"

# game/cethin.rpy:3398
translate Spanish cethinfinale_63834f9a:

    # lumisad "(He is rough with the way he handles it, but the raw power he displays is quite astonishing.)"
    lumisad "(Es algo brusco con la forma en que la maneja, pero el poder bruto que demuestra es realmente asombroso.)"

# game/cethin.rpy:3402
translate Spanish cethinfinale_862341ee:

    # lumishock "(His weapon seems like a divine blade.)"
    lumishock "(Su arma parece una espada divina.)"

# game/cethin.rpy:3404
translate Spanish cethinfinale_79bd1a14:

    # lumisad "(I wouldn't have thought that such kind of person would be able to wield one.)"
    lumisad "(No habría pensado que alguien así podría blandir una.)"

# game/cethin.rpy:3408
translate Spanish cethinfinale_87cc59e5:

    # lumisad "(At this rate, they really might be able to defeat the demon lord...)"
    lumisad "(A este paso, realmente podrían derrotar al señor demonio...)"

# game/cethin.rpy:3410
translate Spanish cethinfinale_8cb5dda1:

    # "She started to feel cold. Anxious."
    "Empezó a sentir frío y ansiedad."

# game/cethin.rpy:3412
translate Spanish cethinfinale_40315fa3:

    # "If Farol truly succeeds, then she will be betrothed to him."
    "Si Farol realmente tiene éxito, entonces será prometida con él."

# game/cethin.rpy:3414
translate Spanish cethinfinale_13447beb:

    # "Refusing would mean turning back on her responsibility as a princess."
    "Rechazarlo significaría renunciar a su responsabilidad como princesa."

# game/cethin.rpy:3416
translate Spanish cethinfinale_3285c7bb:

    # lumisad "(Is there a way to notify Cethin or Reo...?)"
    lumisad "(¿Hay alguna forma de avisarle a Cethin o a Reo...?)"

# game/cethin.rpy:3428
translate Spanish cethinfinale_ef404b58:

    # "Just as she was starting to panic, the princess saw something from the corner of her eyes..."
    "Justo cuando comenzaba a entrar en pánico, la princesa vio algo por el rabillo del ojo..."

# game/cethin.rpy:3430
translate Spanish cethinfinale_a94b50d3:

    # "No- rather- it was someone."
    "No... más bien, era alguien."

# game/cethin.rpy:3432
translate Spanish cethinfinale_912834d7:

    # lumishock "(Cethin?!)"
    lumishock "(¿Cethin?!)"

# game/cethin.rpy:3434
translate Spanish cethinfinale_dc8e42c6:

    # "She looked around and saw him peek out from behind a vase."
    "Miró alrededor y lo vio asomarse detrás de un jarrón."

# game/cethin.rpy:3436
translate Spanish cethinfinale_5dd5ce13:

    # "He gestured her to hush."
    "Él le hizo un gesto para que guardara silencio."

# game/cethin.rpy:3438
translate Spanish cethinfinale_c9302e2e:

    # "Lumi nodded in understanding."
    "Lumi asintió en señal de entendimiento."

# game/cethin.rpy:3440
translate Spanish cethinfinale_efe8acbf:

    # "She still worried about the hero's party, but Cethin's presence definitely lifted a huge chunk of anxiety from her."
    "Aún le preocupaba el grupo del héroe, pero la presencia de Cethin definitivamente le quitó gran parte de la ansiedad."

# game/cethin.rpy:3444
translate Spanish cethinfinale_a0aa43e6:

    # darkmage "Farrie, the throne room is up ahead."
    darkmage "Farrie, la sala del trono está más adelante."

# game/cethin.rpy:3446
translate Spanish cethinfinale_6162c416:

    # mage "I'll get ready!"
    mage "¡Me prepararé!"

# game/cethin.rpy:3450
translate Spanish cethinfinale_2f90bdbf:

    # hero "Let's go!"
    hero "¡Vamos!"

# game/cethin.rpy:3452
translate Spanish cethinfinale_1265b061:

    # lumiserious "(The demon lord... this shall be my first seeing them...)"
    lumiserious "(El señor demonio... esta será mi primera vez viéndolo...)"

# game/cethin.rpy:3478
translate Spanish cethinfinale_c1401a09:

    # "Farol pushed the towering throne room entrance."
    "Farol empujó la imponente entrada de la sala del trono."

# game/cethin.rpy:3480
translate Spanish cethinfinale_59388d04:

    # "Cold air escaped from inside, causing everyone to wince."
    "El aire frío escapó desde el interior, haciendo que todos se estremecieran."

# game/cethin.rpy:3495
translate Spanish cethinfinale_e9eb7950:

    # "And there stood... that thing."
    "Y allí estaba... esa cosa."

# game/cethin.rpy:3497
translate Spanish cethinfinale_d5604e46:

    # "It was about five times a human's size."
    "Era unas cinco veces más grande que un humano."

# game/cethin.rpy:3501
translate Spanish cethinfinale_1db4f915:

    # hero "What in the-"
    hero "Qué demon—"

# game/cethin.rpy:3505
translate Spanish cethinfinale_91410809:

    # "The moment it laid eyes on them, it slowly started to move."
    "En el momento en que puso sus ojos sobre ellos, lentamente comenzó a moverse."

# game/cethin.rpy:3507
translate Spanish cethinfinale_6d221663:

    # mage "Ew. It's ugly..."
    mage "Puaj. Es horrible..."

# game/cethin.rpy:3509
translate Spanish cethinfinale_489f2d4a:

    # darkmage "Not the time for that. Start your protection spells."
    darkmage "No es momento para eso. Empieza con tus hechizos de protección."

# game/cethin.rpy:3513
translate Spanish cethinfinale_66883baa:

    # mage "Got it!"
    mage "¡Entendido!"

# game/cethin.rpy:3515
translate Spanish cethinfinale_31733303:

    # darkmage "Farrie, I'll send you support fire. Try to be careful for now and study its movements."
    darkmage "Farrie, te daré fuego de cobertura. Por ahora, ten cuidado y estudia sus movimientos."

# game/cethin.rpy:3522
translate Spanish cethinfinale_f09ab9e4:

    # hero "Very well... let's enter our final battle!"
    hero "Muy bien... ¡entremos a nuestra batalla final!"

# game/cethin.rpy:3528
translate Spanish cethinfinale_6c4b9a82:

    # "Thus, the battle began."
    "Así comenzó la batalla."

# game/cethin.rpy:3545
translate Spanish cethinfinale_d6aaee08:

    # "Just as the black mage had instructed, Farol started off with playing it safe."
    "Tal como había indicado la maga oscura, Farol comenzó jugando con cautela."

# game/cethin.rpy:3547
translate Spanish cethinfinale_c958e4b2:

    # "He would taunt the demon lord to aim for him while the casters attack from a safe space."
    "Provocaba al señor demonio para que lo atacara mientras los magos lanzaban hechizos desde un lugar seguro."

# game/cethin.rpy:3549
translate Spanish cethinfinale_a83bbc02:

    # "Unlike his previous battles, the hero showed that he can be light with his feet and dodged most of the beast's attacks."
    "A diferencia de sus batallas anteriores, el héroe demostró que podía moverse con ligereza y esquivar la mayoría de los ataques de la bestia."

# game/cethin.rpy:3551
translate Spanish cethinfinale_1ade4b89:

    # "Those that managed to go through were blocked by the white mage's protective spells."
    "Los pocos ataques que lograban alcanzarlo eran bloqueados por los hechizos protectores de la maga de luz."

# game/cethin.rpy:3553
translate Spanish cethinfinale_79bbf053:

    # "It helped that the demon lord moved slowly due to its large build."
    "Ayudaba el hecho de que el señor demonio se moviera lentamente debido a su enorme tamaño."

# game/cethin.rpy:3555
translate Spanish cethinfinale_424b7f64:

    # "Though, the group didn't take it lightly, and they were right to do so-"
    "Aunque el grupo no se lo tomó a la ligera, y tenían razón en hacerlo—"

# game/cethin.rpy:3559
translate Spanish cethinfinale_b1cd5f22:

    # "With one slam of its arm, icicle spires would shoot out from the ground." with vpunch
    "Con un solo golpe de su brazo, brotaban del suelo agujas de hielo." with vpunch

# game/cethin.rpy:3561
translate Spanish cethinfinale_f310ef7d:

    # "The first attempt did hit Farol who didn't see it coming."
    "El primer intento alcanzó a Farol, quien no lo vio venir."

# game/cethin.rpy:3563
translate Spanish cethinfinale_3c486832:

    # "Thankfully, their white mage was quick to take action."
    "Por suerte, su maga de luz actuó con rapidez."

# game/cethin.rpy:3565
translate Spanish cethinfinale_22783307:

    # "The hero's party had wholly placed their focus on the beast..."
    "El grupo del héroe había concentrado toda su atención en la bestia..."

# game/cethin.rpy:3569
translate Spanish cethinfinale_d0bb4c0c:

    # "... Neglecting that the princess was left unattended."
    "... descuidando que la princesa había quedado desatendida."

# game/cethin.rpy:3571
translate Spanish cethinfinale_ad887fa8:

    # lumisad "(I'd hate to admit it, but it's quite mesmerizing to watch them like this.)"
    lumisad "(Odio admitirlo, pero es bastante hipnótico verlos así.)"

# game/cethin.rpy:3573
translate Spanish cethinfinale_88545434:

    # who "Psst-"
    who "Psst—"

# game/cethin.rpy:3575
translate Spanish cethinfinale_6eaf322f:

    # "The princess blinked. She turned to the sound-"
    "La princesa parpadeó. Se giró hacia el sonido—"

# game/cethin.rpy:3583
translate Spanish cethinfinale_1e9181fc:

    # lumitalk "Cethin...!"
    lumitalk "¡Cethin...!"

# game/cethin.rpy:3585
translate Spanish cethinfinale_7f687fe2:

    # "She called out in a hushed voice."
    "Lo llamó en voz baja."

# game/cethin.rpy:3587
translate Spanish cethinfinale_479bc05c:

    # "He was just hiding behind the throne room door."
    "Él estaba escondido justo detrás de la puerta de la sala del trono."

# game/cethin.rpy:3592
translate Spanish cethinfinale_8593bb05:

    # "The dark elf then beckoned her to come to his side."
    "El elfo oscuro le hizo un gesto para que se acercara."

# game/cethin.rpy:3599
translate Spanish cethinfinale_173700f3:

    # "Without hesitating, the girl scurried over to him."
    "Sin dudarlo, la chica corrió hacia él."

# game/cethin.rpy:3604
translate Spanish cethinfinale_c10e9584:

    # cethin "I'm sorry, I took a while."
    cethin "Lo siento, tardé un poco."

# game/cethin.rpy:3609
translate Spanish cethinfinale_8764b712:

    # cethin "I noticed the fallen demonic beasts outside, so I hurried back here."
    cethin "Noté las bestias demoníacas caídas afuera, así que regresé apresuradamente."

# game/cethin.rpy:3613
translate Spanish cethinfinale_63e2c595:

    # "Cethin explained while trying to untie Lumi's rope."
    "Explicó Cethin mientras intentaba desatar la cuerda de Lumi."

# game/cethin.rpy:3615
translate Spanish cethinfinale_a34a96db:

    # lumihappy "I am just glad you came..."
    lumihappy "Solo me alegra que hayas venido..."

# game/cethin.rpy:3617
translate Spanish cethinfinale_b9758d81:

    # "She said in relief, resting her head on his chest."
    "Dijo con alivio, apoyando su cabeza en su pecho."

# game/cethin.rpy:3619
translate Spanish cethinfinale_bd281a16:

    # "Perhaps he had felt how scared and anxious she had been... Cethin didn't budge and let her be for a while."
    "Quizá él había sentido lo asustada y ansiosa que ella había estado... Cethin no se movió y la dejó estar por un rato."

# game/cethin.rpy:3624
translate Spanish cethinfinale_e9ff78f1:

    # cethin "It's fine, I'm here now."
    cethin "Está bien, ya estoy aquí."

# game/cethin.rpy:3626
translate Spanish cethinfinale_fd59bf84:

    # "He stroked her head gently, giving her time to process everything."
    "Le acarició la cabeza con suavidad, dándole tiempo para asimilar todo."

# game/cethin.rpy:3628
translate Spanish cethinfinale_bf550d0f:

    # "She may have acted calm throughout the whole situation, but honestly?"
    "Puede que haya actuado con calma durante toda la situación, pero siendo honestos..."

# game/cethin.rpy:3630
translate Spanish cethinfinale_0bcfa9d0:

    # lumisad "(I just wasn't sure how to react...)"
    lumisad "(No estaba segura de cómo reaccionar...)"

# game/cethin.rpy:3632
translate Spanish cethinfinale_d38f239c:

    # "So now that she was in safe arms, everything just came crashing down."
    "Así que ahora que estaba en brazos seguros, todo simplemente se derrumbó."

# game/cethin.rpy:3634
translate Spanish cethinfinale_b9174bfa:

    # "Unfortunately, they can't stay like that for too long..."
    "Desafortunadamente, no podían quedarse así por mucho tiempo..."

# game/cethin.rpy:3636
translate Spanish cethinfinale_fe29c1b8:

    # "Cethin touched her shoulders and gently pushed her back."
    "Cethin tocó sus hombros y la empujó suavemente hacia atrás."

# game/cethin.rpy:3641
translate Spanish cethinfinale_acd23f30:

    # cethin "Stay here. I have to help them."
    cethin "Quédate aquí. Tengo que ayudarlos."

# game/cethin.rpy:3643
translate Spanish cethinfinale_94932818:

    # lumishock "W-what?!" with vpunch
    lumishock "¡¿Q-qué?!" with vpunch

# game/cethin.rpy:3648
translate Spanish cethinfinale_f5e966ca:

    # cethin "I can't explain right now-"
    cethin "No puedo explicarlo ahora-"

# game/cethin.rpy:3650
translate Spanish cethinfinale_c872857b:

    # "He turned his eyes to the battle, and sure enough, the hero's party was being pushed back."
    "Dirigió la mirada hacia la batalla, y en efecto, el grupo del héroe estaba siendo empujado hacia atrás."

# game/cethin.rpy:3652
translate Spanish cethinfinale_c1fc3a46:

    # "It was evident that if it continues on, the party would lose out on stamina."
    "Era evidente que si continuaba así, el grupo perdería resistencia."

# game/cethin.rpy:3657
translate Spanish cethinfinale_8f6efaed:

    # cethin "Reo, take care of her."
    cethin "Reo, cuida de ella."

# game/cethin.rpy:3661
translate Spanish cethinfinale_083fc847:

    # "Having heard the name, the princess turned back and saw the butler behind them."
    "Al escuchar el nombre, la princesa se giró y vio al mayordomo detrás de ellos."

# game/cethin.rpy:3667
translate Spanish cethinfinale_9b909805:

    # reo "Fine... fine. We'll watch from here."
    reo "Bien... bien. Observaremos desde aquí."

# game/cethin.rpy:3669
translate Spanish cethinfinale_a4abdd93:

    # "He gestured the bard to shoo away."
    "Hizo un gesto al bardo para que se alejara."

# game/cethin.rpy:3675
translate Spanish cethinfinale_0e351d1f:

    # "Cethin nodded and discreetly moved in."
    "Cethin asintió y se movió discretamente."

# game/cethin.rpy:3677
translate Spanish cethinfinale_0434847b:

    # lumiserious "Reo...! What is going on?!"
    lumiserious "¡Reo...! ¿Qué está pasando?!"

# game/cethin.rpy:3683
translate Spanish cethinfinale_4cbb8d94:

    # reo "Hm~ Oh princess, I am quite sure you can figure it out."
    reo "Hm~ Oh princesa, estoy bastante seguro de que puede deducirlo."

# game/cethin.rpy:3685
translate Spanish cethinfinale_b28810e1:

    # lumisad "Huh?"
    lumisad "¿Eh?"

# game/cethin.rpy:3687
translate Spanish cethinfinale_7669ddac:

    # "The butler gave her a knowing look."
    "El mayordomo le lanzó una mirada de complicidad."

# game/cethin.rpy:3693
translate Spanish choice1_6a5e0a70:

    # lumisad "(If the hero's party defeats the demon lord...)"
    lumisad "(Si el grupo del héroe derrota al señor demonio...)"

# game/cethin.rpy:3701
translate Spanish choice1_7c349d32:

    # lumisad "I suppose... we can escape together after the battle?"
    lumisad "Supongo... ¿podremos escapar juntos después de la batalla?"

# game/cethin.rpy:3703
translate Spanish choice1_aa208873:

    # lumisad "(The hero's party would likely be too fatigued to give chase.)"
    lumisad "(Es probable que el grupo del héroe esté demasiado agotado para perseguirnos.)"

# game/cethin.rpy:3707
translate Spanish choice1_2d7e95c3:

    # reo "Princess, oh princess... I wish you'd put that imagination of yours into good use."
    reo "Princesa, oh princesa... desearía que pusiera esa imaginación suya en buen uso."

# game/cethin.rpy:3709
translate Spanish choice1_69579ebb:

    # lumisad "(Oh. So it isn't that...)"
    lumisad "(Oh. Entonces no es eso...)"

# game/cethin.rpy:3715
translate Spanish choice1_0608efa0:

    # lumitalk "If the demon lord is vanquished..."
    lumitalk "Si el señor demonio es derrotado..."

# game/cethin.rpy:3717
translate Spanish choice1_563edba9:

    # lumided "You will be left jobless!"
    lumided "¡Se quedará sin trabajo!"

# game/cethin.rpy:3721
translate Spanish choice1_a12e9e86:

    # reo "Haha! Not at all."
    reo "¡Jajaja! Para nada."

# game/cethin.rpy:3725
translate Spanish choice1_b33f5d55:

    # reo "Though I would love to be released from my duties."
    reo "Aunque me encantaría ser liberado de mis deberes."

# game/cethin.rpy:3727
translate Spanish choice1_0efffbcf:

    # lumisad "(I was not sure why I even went here...)"
    lumisad "(No estaba segura ni de por qué vine aquí...)"

# game/cethin.rpy:3731
translate Spanish choice1_a2ea72e6:

    # lumitalk "Then the hero will have the right for the princess' hand..."
    lumitalk "Entonces el héroe tendrá derecho a la mano de la princesa..."

# game/cethin.rpy:3737
translate Spanish choice2_2706589c:

    # lumisad "But why would Cethin help further that goal...?"
    lumisad "Pero, ¿por qué Cethin ayudaría a promover ese objetivo...?"

# game/cethin.rpy:3742
translate Spanish choice2_4e57683f:

    # lumisad "Perhaps he still holds gratitude for the hero despite what they've done to him..."
    lumisad "Quizá aún siente gratitud hacia el héroe a pesar de lo que le hicieron..."

# game/cethin.rpy:3746
translate Spanish choice2_07337482:

    # reo "Oh, come now."
    reo "Oh, vamos."

# game/cethin.rpy:3750
translate Spanish choice2_e84927ac:

    # reo "Even our dear bard isn't that foolish or kindhearted."
    reo "Ni siquiera nuestro querido bardo es tan tonto o bondadoso."

# game/cethin.rpy:3754
translate Spanish choice2_6bea23c3:

    # reo "You can do better than that."
    reo "Puede hacerlo mejor que eso."

# game/cethin.rpy:3756
translate Spanish choice2_11763a8f:

    # lumided "(All right then...)"
    lumided "(De acuerdo entonces...)"

# game/cethin.rpy:3762
translate Spanish choice2_cf43639a:

    # lumitalk "Cethin has been training to earn the hero title for himself..."
    lumitalk "Cethin ha estado entrenando para ganarse el título de héroe por sí mismo..."

# game/cethin.rpy:3764
translate Spanish choice2_cbd16710:

    # lumitalk "So, could it be that he is planning to take the credit for defeating the demon lord?"
    lumitalk "Entonces, ¿podría ser que planea quedarse con el crédito por derrotar al señor demonio?"

# game/cethin.rpy:3766
translate Spanish choice2_3404cb19:

    # "The butler clapped his hands."
    "El mayordomo aplaudió con las manos."

# game/cethin.rpy:3770
translate Spanish choice2_2d32deef:

    # reo "Very good milady!"
    reo "¡Muy bien, milady!"

# game/cethin.rpy:3774
translate Spanish choice2_17d1243d:

    # reo "That drow can be frightening if he tries."
    reo "Ese drow puede ser aterrador si se lo propone."

# game/cethin.rpy:3776
translate Spanish choice2_5f885e4a:

    # lumisad "...?"
    lumisad "¿...?"

# game/cethin.rpy:3780
translate Spanish choice2_286df40e:

    # lumisad "He isn't simply trying to ensure my freedom, is he?"
    lumisad "¿No está simplemente tratando de asegurar mi libertad, verdad?"

# game/cethin.rpy:3784
translate Spanish choice2_ad7109ce:

    # reo "Do you really think he is that shortsighted?"
    reo "¿De verdad cree que es tan corto de vista?"

# game/cethin.rpy:3786
translate Spanish choice2_c314f6b1:

    # lumisad "... No."
    lumisad "... No."

# game/cethin.rpy:3788
translate Spanish choice2_7793685f:

    # lumiserious "(So, it isn't that...)"
    lumiserious "(Entonces, no es eso...)"

# game/cethin.rpy:3792
translate Spanish choice2_d63b977f:

    # "The princess mulled."
    "La princesa reflexionó."

# game/cethin.rpy:3794
translate Spanish choice2_c0548fa9:

    # "Cethin was about to join in the battle to take credit for the demon lord's defeat?"
    "¿Cethin estaba a punto de unirse a la batalla para llevarse el crédito por la derrota del señor demonio?"

# game/cethin.rpy:3798
translate Spanish choice2_58c4f798:

    # lumi "Oh. I see!"
    lumi "Oh. ¡Ya veo!"

# game/cethin.rpy:3800
translate Spanish choice2_2a2918c4:

    # lumisad "(No matter how much Cethin trains, defeating the demon lord on his own would be a difficult feat.)"
    lumisad "(No importa cuánto entrene Cethin, derrotar al señor demonio por sí solo sería una hazaña difícil.)"

# game/cethin.rpy:3802
translate Spanish choice2_53f2c1eb:

    # lumitalk "(Which was why he's using this opportunity to be able to fight the demon lord in its weakened state...!)"
    lumitalk "(Es por eso que está aprovechando esta oportunidad para luchar contra el señor demonio en su estado debilitado...!)"

# game/cethin.rpy:3825
translate Spanish choice2_d64d5a2d:

    # "Lumi's eyes trailed Cethin amidst the chaotic battle."
    "Los ojos de Lumi siguieron a Cethin en medio de la caótica batalla."

# game/cethin.rpy:3842
translate Spanish choice2_122d392f:

    # "He was still unnoticed, biding his time to strike."
    "Aún no había sido notado, esperando el momento oportuno para atacar."

# game/cethin.rpy:3850
translate Spanish choice2_18e153b0:

    # lumisad "Even so... Cethin is a bard."
    lumisad "Aun así... Cethin es un bardo."

# game/cethin.rpy:3852
translate Spanish choice2_8ccddb5f:

    # lumisad "What good can he do...?"
    lumisad "¿Qué bien puede hacer...?"

# game/cethin.rpy:3856
translate Spanish choice2_4cd8c453:

    # voice "voice2/line106.mp3"
    # reo "Whatever else have I been breaking my back for?"
    voice "voice2/line106.mp3"
    reo "¿Para qué otra cosa he estado rompiéndome el lomo?"

# game/cethin.rpy:3860
translate Spanish choice2_502fcc94:

    # lumitalk "...?"
    lumitalk "¿...?"

# game/cethin.rpy:3864
translate Spanish choice2_b63856f2:

    # mage "Farol, look out...!"
    mage "¡Farol, cuidado...!"

# game/cethin.rpy:3886
translate Spanish choice2_baa8aa58:

    # "The white mage's scream made Lumi turn her attention back to the battle."
    "El grito de la maga de luz hizo que Lumi volviera su atención a la batalla."

# game/cethin.rpy:3906
translate Spanish choice2_9f2cdce3:

    # "Farol was on the ground, and his sword had fallen beside him."
    "Farol estaba en el suelo, y su espada había caído a su lado."

# game/cethin.rpy:3908
translate Spanish choice2_241682af:

    # "The beast loomed over him, with it's gigantic arm raised above the man-"
    "La bestia se cernía sobre él, con su gigantesco brazo levantado sobre el hombre-"

# game/cethin.rpy:3927
translate Spanish choice2_08cbfc63:

    # "-And smashed onto the ground where he was." with vpunch
    "-Y golpeó el suelo justo donde él estaba." with vpunch

# game/cethin.rpy:3929
translate Spanish choice2_1cd0f921:

    # darkmage "Farrie...!"
    darkmage "¡Farrie...!"

# game/cethin.rpy:3931
translate Spanish choice2_91a37de4:

    # "Smoke and dust flew about, obscuring the scenery..."
    "Humo y polvo se elevaron, oscureciendo la escena..."

# game/cethin.rpy:3933
translate Spanish choice2_b7904bbf:

    # mage "No..."
    mage "No..."

# game/cethin.rpy:3935
translate Spanish choice2_e556f888:

    # "But once everything settled, there was only a shattered blade from where the beast has struck."
    "Pero una vez que todo se asentó, solo quedó una espada destrozada donde la bestia había golpeado."

# game/cethin.rpy:3937
translate Spanish choice2_07fc8c32:

    # lumisad "(Where...?)"
    lumisad "(¿Dónde...?)"

# game/cethin.rpy:3939
translate Spanish choice2_611f3672:

    # "The princess searched for Cethin's figure within the room."
    "La princesa buscó la figura de Cethin dentro de la habitación."

# game/cethin.rpy:3959
translate Spanish choice2_3cfcadea:

    # "And there, at one corner, was a lone silhouette."
    "Y allí, en una esquina, había una silueta solitaria."

# game/cethin.rpy:3980
translate Spanish choice2_912834d7:

    # lumishock "(Cethin?!)"
    lumishock "(¿Cethin?!)"

# game/cethin.rpy:3982
translate Spanish choice2_ccd53af4:

    # "Cethin was holding onto the hero."
    "Cethin estaba sosteniendo al héroe."

# game/cethin.rpy:3986
translate Spanish choice2_11c98720:

    # hero "You..."
    hero "Tú..."

# game/cethin.rpy:3990
translate Spanish choice2_bb8ae5cc:

    # voice "voice1/line201.mp3"
    # cethin "Don't talk."
    voice "voice1/line201.mp3"
    cethin "No hables."

# game/cethin.rpy:3998
translate Spanish choice2_bcadaad8:

    # voice "voice1/line202.mp3"
    # cethin "It's my turn now."
    voice "voice1/line202.mp3"
    cethin "Ahora es mi turno."

# game/cethin.rpy:4006
translate Spanish choice2_d6151875:

    # "The casters ran toward Farol's direction."
    "Los hechiceros corrieron hacia la dirección de Farol."

# game/cethin.rpy:4008
translate Spanish choice2_73f139f0:

    # "He was heavily injured from the battle, but nothing fatal."
    "Estaba gravemente herido por la batalla, pero nada fatal."

# game/cethin.rpy:4010
translate Spanish choice2_6b6f8f53:

    # "His party members immediately tended to him, whilst still being wary around the dark elf."
    "Sus compañeros de grupo lo atendieron de inmediato, aunque aún con cautela ante el elfo oscuro."

# game/cethin.rpy:4012
translate Spanish choice2_c5590870:

    # lumishock "Hold on... shouldn't they assist Cethin?"
    lumishock "Espera... ¿no deberían ayudar a Cethin?"

# game/cethin.rpy:4014
translate Spanish choice2_0ce32e40:

    # "Lumi felt anxiety bubble up inside her once again."
    "Lumi sintió que la ansiedad volvía a hervir dentro de ella."

# game/cethin.rpy:4020
translate Spanish choice2_bd83a3aa:

    # "The two women had placed all their attention on the hero, ignoring that Cethin was walking toward the monster."
    "Las dos mujeres habían centrado toda su atención en el héroe, ignorando que Cethin caminaba hacia el monstruo."

# game/cethin.rpy:4026
translate Spanish choice2_d9ebe0e7:

    # voice "voice2/line107.mp3"
    # reo "Worry not."
    voice "voice2/line107.mp3"
    reo "No te preocupes."

# game/cethin.rpy:4030
translate Spanish choice2_7346994a:

    # "She felt a hand on her shoulder."
    "Sintió una mano en su hombro."

# game/cethin.rpy:4034
translate Spanish choice2_c486f3c5:

    # voice "voice2/line108.mp3"
    # reo "Just believe in your hero."
    voice "voice2/line108.mp3"
    reo "Solo cree en tu héroe."

# game/cethin.rpy:4038
translate Spanish choice2_aedb2837:

    # "Just as Reo said those words, Cethin picked up his pace."
    "Justo cuando Reo dijo esas palabras, Cethin aceleró el paso."

# game/cethin.rpy:4042
translate Spanish choice2_03a1cb36:

    # "The demon lord swept at the bard, but he easily moved out of the way."
    "El señor demonio arremetió contra el bardo, pero él se apartó fácilmente."

# game/cethin.rpy:4044
translate Spanish choice2_79b97f5e:

    # "His movements were quick and precise that Lumi can barely follow his movements"
    "Sus movimientos eran tan rápidos y precisos que Lumi apenas podía seguirlos."

# game/cethin.rpy:4048
translate Spanish choice2_1d9ebcc1:

    # "The beast continued to swipe at him- to catch him-{w} but to no avail."
    "La bestia continuó atacándolo- tratando de alcanzarlo-{w} pero sin éxito."

# game/cethin.rpy:4050
translate Spanish choice2_797bdd26:

    # "Cethin's movements were simply too fast and nimble, especially for a beast of that size."
    "Los movimientos de Cethin eran simplemente demasiado veloces y ágiles, especialmente para una bestia de ese tamaño."

# game/cethin.rpy:4052
translate Spanish choice2_fb97bce0:

    # lumided "(I am quite sure that isn't how a bard moves???)"
    lumided "(Estoy bastante segura de que así no se mueve un bardo???)"

# game/cethin.rpy:4054
translate Spanish choice2_05f088e7:

    # "The princess can only watch in awe."
    "La princesa solo podía mirar asombrada."

# game/cethin.rpy:4056
translate Spanish choice2_7318d9f7:

    # "Cethin almost seemed like he was just playing around the demon lord."
    "Cethin casi parecía estar jugando con el señor demonio."

# game/cethin.rpy:4058
translate Spanish choice2_60b50751:

    # lumisad "But, at this rate... he would only lose out on stamina."
    lumisad "Pero, a este ritmo... solo perdería resistencia."

# game/cethin.rpy:4060
translate Spanish choice2_09c9e111:

    # lumisad "He could not win without-"
    lumisad "No podría ganar sin-"

# game/cethin.rpy:4064
translate Spanish choice2_d594444c:

    # voice "voice2/line109.mp3"
    # reo "Ohoho! It seems that our friend is showing off."
    voice "voice2/line109.mp3"
    reo "¡Ohoho! Parece que nuestro amigo está presumiendo."

# game/cethin.rpy:4068
translate Spanish choice2_ef0ce15d:

    # lumitalk "-Huh?"
    lumitalk "¿Eh?"

# game/cethin.rpy:4074
translate Spanish choice2_07a90a52:

    # voice "voice2/line110.mp3"
    # reo "Of course, of course he'd want to impress his lady."
    voice "voice2/line110.mp3"
    reo "Claro, claro que quiere impresionar a su chica."

# game/cethin.rpy:4078
translate Spanish choice2_a7ee3e6b:

    # "The butler grinned."
    "El mayordomo sonrió."

# game/cethin.rpy:4101
translate Spanish choice2_7b27ec97:

    # "Just then, Cethin finally stopped zipping around."
    "Justo entonces, Cethin finalmente dejó de moverse de un lado a otro."

# game/cethin.rpy:4105
translate Spanish choice2_53c5a846:

    # "He positioned himself, ready to play his instrument-"
    "Se posicionó, listo para tocar su instrumento-"

# game/cethin.rpy:4116
translate Spanish choice2_c860c2b5:

    # voice "voice1/line203.mp3"
    # cethin "{b}--{/b}This song shall be my testament- a song of mementos{b}--{/b}"
    voice "voice1/line203.mp3"
    cethin "{b}--{/b}Esta canción será mi testamento- una canción de recuerdos{b}--{/b}"

# game/cethin.rpy:4120
translate Spanish choice2_97e53ee1:

    # voice "voice1/line204.mp3"
    # cethin "{b}--{/b}Sovereign of ruin, born of sorrows...{b}--{/b}"
    voice "voice1/line204.mp3"
    cethin "{b}--{/b}Soberano de la ruina, nacido de las penas...{b}--{/b}"

# game/cethin.rpy:4126
translate Spanish choice2_d7309d24:

    # "Dark, shadowy matter began to materialize in the air, shaping themselves into blade-like forms."
    "Materia oscura y sombría comenzó a materializarse en el aire, tomando forma de hojas afiladas."

# game/cethin.rpy:4128
translate Spanish choice2_08fed257:

    # "They looked sinister, with each one surrounded by a dark aura."
    "Parecían siniestras, cada una rodeada por un aura oscura."

# game/cethin.rpy:4130
translate Spanish choice2_d3bebce8:

    # voice "voice1/line205.mp3"
    # cethin "{b}--{/b}A birth that shall engulf all in loss forevermore{b}--{/b}"
    voice "voice1/line205.mp3"
    cethin "{b}--{/b}Un nacimiento que consumirá a todos en la pérdida eterna{b}--{/b}"

# game/cethin.rpy:4136
translate Spanish choice2_3c4d53c0:

    # "The demon lord once again attempted to swipe its arm at the bard, but he just dodged with ease by leaping upward."
    "El señor demonio intentó nuevamente golpear al bardo con su brazo, pero él esquivó con facilidad dando un salto hacia arriba."

# game/cethin.rpy:4138
translate Spanish choice2_73d24985:

    # "With the dark elf in midair, he strummed his strings-"
    "Con el elfo oscuro en el aire, rasgueó las cuerdas-"

# game/cethin.rpy:4140
translate Spanish choice2_ddc4d916:

    # voice "voice1/line206.mp3"
    # cethin "{b}--{/b}Only blood of maiden of lore{b}--{/b}"
    voice "voice1/line206.mp3"
    cethin "{b}--{/b}Solo la sangre de la doncella de las leyendas{b}--{/b}"

# game/cethin.rpy:4144
translate Spanish choice2_fa8730f2:

    # voice "voice1/line207.mp3"
    # cethin "{b}--{/b}May entrap filth within its walls{b}--{/b}"
    voice "voice1/line207.mp3"
    cethin "{b}--{/b}Podrá encerrar la inmundicia dentro de sus muros{b}--{/b}"

# game/cethin.rpy:4148
translate Spanish choice2_d6097744:

    # voice "voice1/line208.mp3"
    # cethin "{b}--{/b}Until this one’s might finally falls{b}--{/b}"
    voice "voice1/line208.mp3"
    cethin "{b}--{/b}Hasta que finalmente caiga la fuerza de este{b}--{/b}"

# game/cethin.rpy:4152
translate Spanish choice2_42c416cd:

    # lumishock "He's not singing...?"
    lumishock "¿No está cantando...?"

# game/cethin.rpy:4154
translate Spanish choice2_05418bfa:

    # voice "voice2/line111.mp3"
    # reo "Hm yes, you hear him."
    voice "voice2/line111.mp3"
    reo "Hm sí, lo escuchas."

# game/cethin.rpy:4158
translate Spanish choice2_477c7bed:

    # voice "voice2/line112.mp3"
    # reo "I've been wondering, actually... as to why he insists on being a bard of songs, if he's so magnificently tone deaf-"
    voice "voice2/line112.mp3"
    reo "He estado preguntándome, en realidad... por qué insiste en ser un bardo de canciones, si es tan magníficamente desafinado-"

# game/cethin.rpy:4162
translate Spanish choice2_8d6706b8:

    # voice "voice2/line113.mp3"
    # reo "... When he could be a bard of poetry."
    voice "voice2/line113.mp3"
    reo "... Cuando podría ser un bardo de poesía."

# game/cethin.rpy:4166
translate Spanish choice2_8f4777f6:

    # lumishock "There's such a thing?!" with vpunch
    lumishock "¡¿Existe tal cosa?!" with vpunch

# game/cethin.rpy:4168
translate Spanish choice2_0065e9c0:

    # voice "voice2/line114.mp3"
    # reo "... Oh dear, I have never felt this old."
    voice "voice2/line114.mp3"
    reo "... Oh cielos, nunca me había sentido tan viejo."

# game/cethin.rpy:4172
translate Spanish choice2_37470f48:

    # voice "voice2/line115.mp3"
    # reo "Of course they exist."
    voice "voice2/line115.mp3"
    reo "Por supuesto que existen."

# game/cethin.rpy:4176
translate Spanish choice2_56d79ccf:

    # voice "voice2/line116.mp3"
    # reo "Bards are masters of songs and poetry, are they not?"
    voice "voice2/line116.mp3"
    reo "Los bardos son maestros de las canciones y de la poesía, ¿no es así?"

# game/cethin.rpy:4180
translate Spanish choice2_258edce5:

    # voice "voice1/line209.mp3"
    # cethin "{b}--{/b}Only then shall the maiden reap her freedom once more{b}--{/b}"
    voice "voice1/line209.mp3"
    cethin "{b}--{/b}Solo entonces la doncella cosechará su libertad una vez más{b}--{/b}"

# game/cethin.rpy:4184
translate Spanish choice2_75d4401d:

    # voice "voice1/line210.mp3"
    # cethin "{b}--{/b}Sound the bells, sound the bells, dim the songs of your cries- {b}--{/b}"
    voice "voice1/line210.mp3"
    cethin "{b}--{/b}Haz sonar las campanas, haz sonar las campanas, apaga los cantos de tu llanto- {b}--{/b}"

# game/cethin.rpy:4190
translate Spanish choice2_cff92ed6:

    # "And the dark matter began shooting toward the beast in a seemingly endless barrage."
    "Y la materia oscura comenzó a dispararse hacia la bestia en una andanada aparentemente interminable."

# game/cethin.rpy:4196
translate Spanish choice2_94238caf:

    # "The demon lord roared in pain, with each shot dissipating as soon as they meet the target." with vpunch
    "El señor demonio rugió de dolor, y cada proyectil se disipaba en cuanto alcanzaba el objetivo." with vpunch

# game/cethin.rpy:4198
translate Spanish choice2_eccd30d9:

    # "The monster started to bathe in its own blood."
    "El monstruo comenzó a bañarse en su propia sangre."

# game/cethin.rpy:4202
translate Spanish choice2_024d035e:

    # voice "voice1/line211.mp3"
    # cethin "{b}--{/b}Oh sovereign of dusk, it passes by, it passes by{b}--{/b}"
    voice "voice1/line211.mp3"
    cethin "{b}--{/b}Oh soberano del ocaso, pasa de largo, pasa de largo{b}--{/b}"

# game/cethin.rpy:4206
translate Spanish choice2_88dbcc28:

    # voice "voice1/line212.mp3"
    # cethin "{b}--{/b}Blood of maiden. Sacrifice, sacrifice{b}--{/b}"
    voice "voice1/line212.mp3"
    cethin "{b}--{/b}Sangre de doncella. Sacrificio, sacrificio{b}--{/b}"

# game/cethin.rpy:4210
translate Spanish choice2_66ba8998:

    # lumided "The way he is fighting... I am quite certain- that isn't a bard!"
    lumided "La forma en que está luchando... Estoy bastante segura- ¡ese no es un bardo!"

# game/cethin.rpy:4212
translate Spanish choice2_bb6d3e26:

    # voice "voice2/line117.mp3"
    # reo "Oh? What makes you decide what a bard is meant to be?"
    voice "voice2/line117.mp3"
    reo "¿Oh? ¿Y qué te hace decidir lo que un bardo debe ser?"

# game/cethin.rpy:4216
translate Spanish choice2_a1d0a9d1:

    # lumisad "Well..."
    lumisad "Bueno..."

# game/cethin.rpy:4218
translate Spanish choice2_02db9f10:

    # "She trailed off."
    "Su voz se desvaneció."

# game/cethin.rpy:4220
translate Spanish choice2_7e38dba7:

    # "Her eyes couldn't leave the battle."
    "Sus ojos no podían apartarse de la batalla."

# game/cethin.rpy:4222
translate Spanish choice2_6b811f73:

    # "Cethin's movements were uncannily graceful."
    "Los movimientos de Cethin eran inquietantemente gráciles."

# game/cethin.rpy:4224
translate Spanish choice2_1da79977:

    # voice "voice1/line213.mp3"
    # cethin "{b}--{/b}Let not its eyes touch the day{b}--{/b}"
    voice "voice1/line213.mp3"
    cethin "{b}--{/b}Que sus ojos no toquen el día{b}--{/b}"

# game/cethin.rpy:4228
translate Spanish choice2_7f152bca:

    # voice "voice1/line214.mp3"
    # cethin "{b}--{/b}Let not its presence here stay{b}--{/b}"
    voice "voice1/line214.mp3"
    cethin "{b}--{/b}Que su presencia no permanezca aquí{b}--{/b}"

# game/cethin.rpy:4235
translate Spanish choice2_ccc631f0:

    # "The bard definitely cannot compare to the hero's strength."
    "El bardo definitivamente no podía compararse con la fuerza del héroe."

# game/cethin.rpy:4237
translate Spanish choice2_536e6897:

    # "Nor could he match up to the black mage's power."
    "Tampoco podía igualar el poder de la maga oscura."

# game/cethin.rpy:4239
translate Spanish choice2_ac004ad4:

    # "Nor did he have defensive or healing support to fall back on."
    "Ni tenía apoyo defensivo o curativo en quien confiar."

# game/cethin.rpy:4241
translate Spanish choice2_ca98d063:

    # "One misstep, and it'd be over for him."
    "Un solo error, y todo habría terminado para él."

# game/cethin.rpy:4243
translate Spanish choice2_2378d15f:

    # lumishock "(His movements seem planned and calculated.)"
    lumishock "(Sus movimientos parecen planeados y calculados.)"

# game/cethin.rpy:4245
translate Spanish choice2_ffede171:

    # lumitalk "(Perhaps that was also why he had watched Farol's party first?)"
    lumitalk "(¿Quizás por eso también observó primero al grupo de Farol?)"

# game/cethin.rpy:4247
translate Spanish choice2_e92f3afb:

    # "-To familiarize with the beast's attack pattern, that is."
    "-Para familiarizarse con el patrón de ataque de la bestia, claro."

# game/cethin.rpy:4249
translate Spanish choice2_4b01ef77:

    # lumishock "(Did he use them as test subjects???)"
    lumishock "(¿Los usó como sujetos de prueba???)"

# game/cethin.rpy:4253
translate Spanish choice2_745216c6:

    # voice "voice1/line215.mp3"
    # cethin "{b}--{/b}Within the walls, entrap it, entrap it with all your life{b}--{/b}"
    voice "voice1/line215.mp3"
    cethin "{b}--{/b}Dentro de los muros, enciérralo, enciérralo con toda tu vida{b}--{/b}"

# game/cethin.rpy:4257
translate Spanish choice2_ca85b0f1:

    # voice "voice1/line216.mp3"
    # cethin "{b}--{/b}Let not its wrath seek its way{b}--{/b}"
    voice "voice1/line216.mp3"
    cethin "{b}--{/b}Que su ira no encuentre su camino{b}--{/b}"

# game/cethin.rpy:4261
translate Spanish choice2_b1d76297:

    # voice "voice2/line118.mp3"
    # reo "The words of a bard are their weapon."
    voice "voice2/line118.mp3"
    reo "Las palabras de un bardo son su arma."

# game/cethin.rpy:4265
translate Spanish choice2_ac8f9911:

    # voice "voice2/line119.mp3"
    # reo "They bring songs and poetry into being."
    voice "voice2/line119.mp3"
    reo "Traen canciones y poesía a la existencia."

# game/cethin.rpy:4269
translate Spanish choice2_2f483334:

    # voice "voice2/line120.mp3"
    # reo "They make you lose sight of truth and falsehood."
    voice "voice2/line120.mp3"
    reo "Hacen que pierdas la noción entre la verdad y la mentira."

# game/cethin.rpy:4273
translate Spanish choice2_0603a82f:

    # voice "voice2/line121.mp3"
    # reo "This song he is playing..."
    voice "voice2/line121.mp3"
    reo "Esta canción que está tocando..."

# game/cethin.rpy:4277
translate Spanish choice2_6c97f864:

    # voice "voice2/line122.mp3"
    # reo "Or I suppose poem? Yes. This poem..."
    voice "voice2/line122.mp3"
    reo "O supongo poema? Sí. Este poema..."

# game/cethin.rpy:4281
translate Spanish choice2_8f5d6acd:

    # voice "voice2/line123.mp3"
    # reo "Is one specifically tailored against a demon lord."
    voice "voice2/line123.mp3"
    reo "Está especialmente hecho contra un señor demonio."

# game/cethin.rpy:4285
translate Spanish choice2_0068a712:

    # voice "voice2/line124.mp3"
    # reo "Akin to a dragon slayer sword against a dragon."
    voice "voice2/line124.mp3"
    reo "Como una espada matadragones contra un dragón."

# game/cethin.rpy:4289
translate Spanish choice2_74e55c18:

    # lumithink "(I had never heard of the song having relations to the demon lord...)"
    lumithink "(Nunca había oído que existiera una canción relacionada con el señor demonio...)"

# game/cethin.rpy:4291
translate Spanish choice2_a16e853a:

    # lumishock "(Perhaps this is knowledge only the demonkin held?)"
    lumishock "(¿Quizás es un conocimiento que solo los demonkin poseían?)"

# game/cethin.rpy:4293
translate Spanish choice2_61befe50:

    # voice "voice2/line125.mp3"
    # reo "Your dear bard isn't adept at being a bard, nor is he adept at being a drow."
    voice "voice2/line125.mp3"
    reo "Tu querido bardo no es hábil siendo bardo, ni hábil siendo drow."

# game/cethin.rpy:4297
translate Spanish choice2_d01a4c56:

    # voice "voice2/line126.mp3"
    # reo "He's barely capable of maintaining those blades."
    voice "voice2/line126.mp3"
    reo "Apenas puede mantener esas hojas."

# game/cethin.rpy:4301
translate Spanish choice2_58600ec5:

    # lumided "(True, they're barely... blade-like.)"
    lumided "(Cierto, apenas parecen... hojas.)"

# game/cethin.rpy:4303
translate Spanish choice2_3bdfeff7:

    # lumi "(I suppose it's something like coating those blades into 'anti-demon lord' magic then?)"
    lumi "(Supongo que es como si las recubriera con magia “anti-señor demonio”, ¿no?)"

# game/cethin.rpy:4305
translate Spanish choice2_883078a5:

    # voice "voice2/line127.mp3"
    # reo "However, simply reciting this song turns these blades into the most fatal, poisonous weapon against this beast."
    voice "voice2/line127.mp3"
    reo "Sin embargo, simplemente recitar esta canción convierte esas hojas en el arma más mortal y venenosa contra esa bestia."

# game/cethin.rpy:4309
translate Spanish choice2_25b6d7f5:

    # voice "voice2/line128.mp3"
    # reo "... As flimsy as both may be-"
    voice "voice2/line128.mp3"
    reo "... Por débiles que ambas sean-"

# game/cethin.rpy:4313
translate Spanish choice2_3414099f:

    # voice "voice2/line129.mp3"
    # reo "Together, I suppose, they are good enough."
    voice "voice2/line129.mp3"
    reo "Juntas, supongo, son lo suficientemente buenas."

# game/cethin.rpy:4317
translate Spanish choice2_9039c0a5:

    # voice "voice2/line130.mp3"
    # reo "Very much like him, don't you think?"
    voice "voice2/line130.mp3"
    reo "Muy parecido a él, ¿no crees?"

# game/cethin.rpy:4323
translate Spanish choice2_4ae30f7d:

    # "Lumi nodded."
    "Lumi asintió."

# game/cethin.rpy:4326
translate Spanish choice2_9233d63b:

    # lumitalk "(I beg to differ...)"
    lumitalk "(No estoy tan segura...)"

# game/cethin.rpy:4328
translate Spanish choice2_c9b950e8:

    # voice "voice2/line131-5.mp3"
    # reo "Well, I suppose you can say that he has found how he'd like to play."
    voice "voice2/line131-5.mp3"
    reo "Bueno, supongo que se puede decir que ha encontrado la forma en que quiere tocar."

# game/cethin.rpy:4332
translate Spanish choice2_d8980e33:

    # voice "voice1/line217.mp3"
    # cethin "{b}--{/b}Let not its eyes touch the day{b}--{/b}"
    voice "voice1/line217.mp3"
    cethin "{b}--{/b}Que sus ojos no toquen el día{b}--{/b}"

# game/cethin.rpy:4336
translate Spanish choice2_1cac061b:

    # voice "voice1/line218.mp3"
    # cethin "{b}--{/b}Let not its presence here stay{b}--{/b}"
    voice "voice1/line218.mp3"
    cethin "{b}--{/b}Que su presencia no permanezca aquí{b}--{/b}"

# game/cethin.rpy:4343
translate Spanish choice2_d3d8f54c:

    # "The drow's movements were swift and precise." with vpunch
    "Los movimientos del drow eran rápidos y precisos" with vpunch

# game/cethin.rpy:4345
translate Spanish choice2_150404dd:

    # "The demon lord was akin to a plaything in his hands."
    "El señor demonio era como un juguete en sus manos."

# game/cethin.rpy:4353
translate Spanish choice2_8f5d7cba:

    # "Once more, it slammed its arms onto the ground." with vpunch
    "Una vez más, golpeó el suelo con sus brazos." with vpunch

# game/cethin.rpy:4355
translate Spanish choice2_5ae47019:

    # "Icicle spires sprung out the ground-"
    "Agujas de hielo brotaron del terreno-"

# game/cethin.rpy:4357
translate Spanish choice2_100a885c:

    # "Lumi couldn't follow his movements..."
    "Lumi no pudo seguir sus movimientos..."

# game/cethin.rpy:4359
translate Spanish choice2_a105cd27:

    # "The dark elf left her sight."
    "El elfo oscuro desapareció de su vista."

# game/cethin.rpy:4361
translate Spanish choice2_9383181c:

    # "The princess held her breath..."
    "La princesa contuvo la respiración..."

# game/cethin.rpy:4367
translate Spanish choice2_c624b700:

    # voice "voice1/line219.mp3"
    # cethin "{b}--{/b}Thrust a blade through its core{b}--{/b}"
    voice "voice1/line219.mp3"
    cethin "{b}--{/b}Clava una hoja en su núcleo{b}--{/b}"

# game/cethin.rpy:4371
translate Spanish choice2_e427b3c6:

    # "-Until she heard another verse come into play."
    "-Hasta que escuchó otro verso entrar en acción."

# game/cethin.rpy:4373
translate Spanish choice2_87d40436:

    # "And Cethin was right beside her."
    "Y Cethin estaba justo a su lado."

# game/cethin.rpy:4375
translate Spanish choice2_12d6ab8e:

    # lumishock "How?!" with vpunch
    lumishock "¡¿Cómo?!" with vpunch

# game/cethin.rpy:4377
translate Spanish choice2_d856c328:

    # "The princess was astonished."
    "La princesa estaba asombrada."

# game/cethin.rpy:4379
translate Spanish choice2_e0a67a1e:

    # "How did he move by her side in mere moments...?"
    "¿Cómo se movió a su lado en tan solo unos momentos...?"

# game/cethin.rpy:4381
translate Spanish choice2_a20cefa7:

    # "..."
    "..."

# game/cethin.rpy:4383
translate Spanish choice2_4d6ef256:

    # "No... in fact, everything finally made sense now."
    "No... de hecho, todo finalmente tenía sentido ahora."

# game/cethin.rpy:4385
translate Spanish choice2_e70fa750:

    # "This was the ability he had been using to slip in and out of the castle unnoticed."
    "Esa era la habilidad que había estado usando para entrar y salir del castillo sin ser visto."

# game/cethin.rpy:4387
translate Spanish choice2_ccf252ca:

    # "His weak presence, coupled with his ridiculous speed..."
    "Su presencia débil, combinada con su ridícula velocidad..."

# game/cethin.rpy:4389
translate Spanish choice2_3a26dad9:

    # "He was also nimble enough to scale castle walls and move through the castle tower's windows."
    "También era lo bastante ágil para escalar los muros del castillo y moverse por las ventanas de la torre."

# game/cethin.rpy:4391
translate Spanish choice2_22b3b2da:

    # lumided "As I've thought... you might have been better off as an assassin."
    lumided "Como pensaba... habrías estado mejor como asesino."

# game/cethin.rpy:4395
translate Spanish choice2_f9b7935e:

    # voice "voice1/line220.mp3"
    # cethin "Please stop changing my profession."
    voice "voice1/line220.mp3"
    cethin "Por favor deja de cambiar mi profesión."

# game/cethin.rpy:4399
translate Spanish choice2_66f0acd0:

    # "And then, he strummed his instrument once more..."
    "Y entonces, volvió a rasguear su instrumento una vez más..."

# game/cethin.rpy:4401
translate Spanish choice2_4763a130:

    # "As he sang the final verse-"
    "Mientras cantaba el verso final-"

# game/cethin.rpy:4405
translate Spanish choice2_fa9f5ef0:

    # voice "voice1/line221.mp3"
    # cethin "~Thus the maiden’s life is once again restored~"
    voice "voice1/line221.mp3"
    cethin "~Así la vida de la doncella vuelve a ser restaurada~"

# game/cethin.rpy:4411
translate Spanish choice2_259128e9:

    # lumiuwu "(He still couldn't hold a tune...!)" with vpunch
    lumiuwu "(¡Sigue sin poder afinar...!)" with vpunch

# game/cethin.rpy:4413
translate Spanish choice2_3ceea840:

    # "A flurry of the insidious looking matter all shot toward the demon lord."
    "Una ráfaga de aquella materia siniestra se disparó hacia el señor demonio."

# game/cethin.rpy:4417
translate Spanish choice2_85c20738:

    # "It howled."
    "Este aulló."

# game/cethin.rpy:4421
translate Spanish choice2_8a848857:

    # "One step.{w} Two steps..."
    "Un paso.{w} Dos pasos..."

# game/cethin.rpy:4423
translate Spanish choice2_26c7a4ad:

    # "... And then it started to crumble into dust."
    "... Y luego comenzó a desmoronarse en polvo."

# game/cethin.rpy:4431
translate Spanish choice2_faacf8c9:

    # "Cethin sighed in relief as he dematerialized his instrument."
    "Cethin suspiró aliviado mientras desmaterializaba su instrumento."

# game/cethin.rpy:4433
translate Spanish choice2_8ca82abf:

    # "Lumi let out a huge huff."
    "Lumi soltó un gran suspiro."

# game/cethin.rpy:4463
translate Spanish choice2_b7ccb05f:

    # "... And then jumped onto Cethin."
    "... Y luego se abalanzó sobre Cethin."

# game/cethin.rpy:4467
translate Spanish choice2_98f759bf:

    # lumihappy "You did it...!"
    lumihappy "Lo lograste...!"

# game/cethin.rpy:4471
translate Spanish choice2_038bb7a5:

    # lumihappy "Cethin, you've done it...!"
    lumihappy "¡Cethin, lo lograste...!"

# game/cethin.rpy:4477
translate Spanish choice2_8a36cb3a:

    # voice "voice2/line131.mp3"
    # reo "Goodness me, must you really show off the way you did?"
    voice "voice2/line131.mp3"
    reo "Dios mío, ¿realmente tienes que presumir de esa manera?"

# game/cethin.rpy:4483
translate Spanish choice2_0ac929b5:

    # "Cethin took the princess into his arms."
    "Cethin tomó a la princesa entre sus brazos."

# game/cethin.rpy:4487
translate Spanish choice2_0fb078ac:

    # voice "voice1/line222.mp3"
    # cethin "Well... Lumi was watching."
    voice "voice1/line222.mp3"
    cethin "Bueno... Lumi estaba mirando."

# game/cethin.rpy:4491
translate Spanish choice2_f5f78a47:

    # lumi "And you were spectacular!"
    lumi "¡Y estuviste espectacular!"

# game/cethin.rpy:4505
translate Spanish choice2_f5452fb4:

    # voice "voice3/f24.mp3"
    # who "Drow."
    voice "voice3/f24.mp3"
    who "Drow."

# game/cethin.rpy:4509
translate Spanish choice2_fb56ffc2:

    # "Just then, they turned their attention to the voice."
    "Justo entonces, dirigieron su atención hacia la voz."

# game/cethin.rpy:4518
translate Spanish choice2_748e6e8f:

    # "Lumi released herself from Cethin's arms, allowing him to step in."
    "Lumi se soltó de los brazos de Cethin, permitiéndole dar un paso al frente."

# game/cethin.rpy:4520
translate Spanish choice2_f9abb853:

    # "She held the dark elf's hand, making him glance at her for a moment."
    "Ella tomó la mano del elfo oscuro, haciendo que él la mirara por un momento."

# game/cethin.rpy:4524
translate Spanish choice2_f1e2198b:

    # "He smiled, happy from her support."
    "Sonrió, feliz por su apoyo."

# game/cethin.rpy:4534
translate Spanish choice2_6c4d32a4:

    # voice "voice1/line223.mp3"
    # cethin "Farol."
    voice "voice1/line223.mp3"
    cethin "Farol."

# game/cethin.rpy:4538
translate Spanish choice2_1ac490bf:

    # "The dark elf then turned his head to the hero."
    "El elfo oscuro entonces giró la cabeza hacia el héroe."

# game/cethin.rpy:4544
translate Spanish choice2_c26dbd59:

    # "And then, the hero bowed his head."
    "Y luego, el héroe inclinó la cabeza."

# game/cethin.rpy:4549
translate Spanish choice2_81487b2a:

    # voice "voice3/f25.mp3"
    # hero "I owe you my gratitude for saving our lives."
    voice "voice3/f25.mp3"
    hero "Te debo mi gratitud por habernos salvado la vida."

# game/cethin.rpy:4555
translate Spanish choice2_ad99682a:

    # voice "voice3/w5.mp3"
    # mage "Farol... bowing to a drow-"
    voice "voice3/w5.mp3"
    mage "Farol... inclinándose ante un drow-"

# game/cethin.rpy:4559
translate Spanish choice2_20b5bb71:

    # voice "voice3/b7.mp3"
    # darkmage "Farrie...! You can't-!"
    voice "voice3/b7.mp3"
    darkmage "¡Farrie...! ¡No puedes-!"

# game/cethin.rpy:4565
translate Spanish choice2_a9370b8f:

    # voice "voice3/f26.mp3"
    # hero "Silence, the both of you."
    voice "voice3/f26.mp3"
    hero "Silencio, las dos."

# game/cethin.rpy:4569
translate Spanish choice2_b16b91f9:

    # "He held a hand out to them, gesturing the two to stop."
    "Levantó una mano hacia ellos, señalando que se detuvieran."

# game/cethin.rpy:4573
translate Spanish choice2_1823913c:

    # voice "voice3/f27.mp3"
    # hero "Had he not stepped in, we all could have become fodder for that thing."
    voice "voice3/f27.mp3"
    hero "De no haber intervenido, todos podríamos haber sido alimento para esa cosa."

# game/cethin.rpy:4577
translate Spanish choice2_cd998fdf:

    # "The two hung their heads low, unable to refute him."
    "Las dos bajaron la cabeza, sin poder refutarlo."

# game/cethin.rpy:4579
translate Spanish choice2_b028af05:

    # voice "voice3/f28.mp3"
    # hero "I am sorry for how we treated you."
    voice "voice3/f28.mp3"
    hero "Lamento cómo te tratamos."

# game/cethin.rpy:4583
translate Spanish choice2_08ef2f74:

    # voice "voice3/f29.mp3"
    # hero "I could not even dare to ask you to come back with us."
    voice "voice3/f29.mp3"
    hero "Ni siquiera podría atreverme a pedirte que regreses con nosotros."

# game/cethin.rpy:4587
translate Spanish choice2_6b4ced1f:

    # voice "voice3/f30.mp3"
    # hero "You do not have to accept my apology..."
    voice "voice3/f30.mp3"
    hero "No tienes que aceptar mi disculpa..."

# game/cethin.rpy:4591
translate Spanish choice2_e8bc8d87:

    # voice "voice3/f31.mp3"
    # hero "But-"
    voice "voice3/f31.mp3"
    hero "Pero-"

# game/cethin.rpy:4599
translate Spanish choice2_96bd4da6:

    # voice "voice1/line224.mp3"
    # cethin "Enough. It's fine."
    voice "voice1/line224.mp3"
    cethin "Basta. Está bien."

# game/cethin.rpy:4605
translate Spanish choice2_2a67def8:

    # voice "voice1/line224-5.mp3"
    # cethin "I accept your apology."
    voice "voice1/line224-5.mp3"
    cethin "Acepto tu disculpa."

# game/cethin.rpy:4611
translate Spanish choice2_ae500de4:

    # voice "voice3/f32.mp3"
    # hero "Eh? Just like that?"
    voice "voice3/f32.mp3"
    hero "¿Eh? ¿Así de fácil?"

# game/cethin.rpy:4617
translate Spanish choice2_9961bbce:

    # voice "voice1/line225.mp3"
    # cethin "Yes."
    voice "voice1/line225.mp3"
    cethin "Sí."

# game/cethin.rpy:4623
translate Spanish choice2_7d14d20c:

    # voice "voice1/line226.mp3"
    # cethin "So, would you mind allowing me and Lumi to have a moment?"
    voice "voice1/line226.mp3"
    cethin "Entonces, ¿te importaría dejarnos un momento a Lumi y a mí?"

# game/cethin.rpy:4635
translate Spanish choice2_acf7400a:

    # "He added, wrapping an arm around her."
    "Agregó, rodeándola con un brazo."

# game/cethin.rpy:4637
translate Spanish choice2_8b596775:

    # lumishy "(...!)" with vpunch
    lumishy "(...!)" with vpunch

# game/cethin.rpy:4642
translate Spanish choice2_140160ce:

    # voice "voice3/f33.mp3"
    # hero "Oh. Okay- you two, let's go!"
    voice "voice3/f33.mp3"
    hero "Oh. Está bien- ustedes dos, ¡vámonos!"

# game/cethin.rpy:4646
translate Spanish choice2_1c0879be:

    # voice "voice3/w6.mp3"
    # mage "Ah, alright..."
    voice "voice3/w6.mp3"
    mage "Ah, de acuerdo..."

# game/cethin.rpy:4650
translate Spanish choice2_01109042:

    # voice "voice3/b8.mp3"
    # darkmage "Got it Farrie..."
    voice "voice3/b8.mp3"
    darkmage "Entendido, Farrie..."

# game/cethin.rpy:4658
translate Spanish choice2_1249278c:

    # "Farol started walking out of the throne room, with the other two following behind."
    "Farol comenzó a salir de la sala del trono, con los otros dos siguiéndolo detrás."

# game/cethin.rpy:4662
translate Spanish choice2_2deb7a51:

    # voice "voice1/line227.mp3"
    # cethin "One more thing."
    voice "voice1/line227.mp3"
    cethin "Una cosa más."

# game/cethin.rpy:4668
translate Spanish choice2_698f8e65:

    # "-When he paused to turn to Cethin's call."
    "-Cuando se detuvo para atender al llamado de Cethin."

# game/cethin.rpy:4670
translate Spanish choice2_fa5972b2:

    # voice "voice1/line228.mp3"
    voice "voice1/line228.mp3"

# game/cethin.rpy:4674
translate Spanish choice2_8b74f6a7:

    # cethin "My name is Cethin. That is all."
    cethin "Mi nombre es Cethin. Eso es todo."

# game/cethin.rpy:4676
translate Spanish choice2_b56c115d:

    # "Cethin. Not drow."
    "Cethin. No drow."

# game/cethin.rpy:4682
translate Spanish choice2_ea3c530b:

    # voice "voice3/f34.mp3"
    # hero "Ah. Yes..."
    voice "voice3/f34.mp3"
    hero "Ah. Sí..."

# game/cethin.rpy:4690
translate Spanish choice2_786611f0:

    # "And they scurried away..."
    "Y se apresuraron a salir..."

# game/cethin.rpy:4694
translate Spanish choice2_db4d2b41:

    # lumishy "Uhm... Cethin..."
    lumishy "Uhm... Cethin..."

# game/cethin.rpy:4696
translate Spanish choice2_211649a2:

    # "Cethin turned his head to Lumi and realized that he was still holding onto her."
    "Cethin giró la cabeza hacia Lumi y se dio cuenta de que aún la sostenía."

# game/cethin.rpy:4700
translate Spanish choice2_57660cbe:

    # voice "voice1/line229.mp3"
    # cethin "Oh, I'm sorry...!"
    voice "voice1/line229.mp3"
    cethin "¡Oh, lo siento...!"

# game/cethin.rpy:4712
translate Spanish choice2_57638344:

    # "He immediately let go of her."
    "Inmediatamente la soltó."

# game/cethin.rpy:4717
translate Spanish choice2_63f78524:

    # voice "voice1/line230.mp3"
    # cethin "I suppose I got lost in the moment."
    voice "voice1/line230.mp3"
    cethin "Supongo que me dejé llevar por el momento."

# game/cethin.rpy:4721
translate Spanish choice2_06b53a21:

    # lumiblush "No, no... it's fine."
    lumiblush "No, no... está bien."

# game/cethin.rpy:4723
translate Spanish choice2_f862443b:

    # lumishy "(I quite liked it.)"
    lumishy "(Me gustó bastante.)"

# game/cethin.rpy:4725
translate Spanish choice2_febbad7c:

    # lumitalk "But is that all right? You let them go just like that...?"
    lumitalk "¿Pero está bien? ¿Los dejaste ir así nada más...?"

# game/cethin.rpy:4727
translate Spanish choice2_804b3dde:

    # lumisad "They used you!"
    lumisad "¡Ellos te usaron!"

# game/cethin.rpy:4732
translate Spanish choice2_17e2c4d6:

    # "The dark elf chuckled."
    "El elfo oscuro soltó una risa baja."

# game/cethin.rpy:4736
translate Spanish choice2_4e832079:

    # voice "voice1/line231.mp3"
    # cethin "Not satisfied?"
    voice "voice1/line231.mp3"
    cethin "¿No estás satisfecha?"

# game/cethin.rpy:4740
translate Spanish choice2_85aadf11:

    # lumiplead "No."
    lumiplead "No."

# game/cethin.rpy:4744
translate Spanish choice2_34738da3:

    # voice "voice1/line232.mp3"
    # cethin "Even when I've taken this?"
    voice "voice1/line232.mp3"
    cethin "¿Ni siquiera cuando me quedé con esto?"

# game/cethin.rpy:4748
translate Spanish choice2_c6920bf6:

    # "Cethin materialized a sword in his hands... it was Farol's."
    "Cethin materializó una espada en sus manos... era la de Farol."

# game/cethin.rpy:4750
translate Spanish choice2_c3c46339:

    # lumishock "The divine blade? When...?"
    lumishock "¿La espada divina? ¿Cuándo...?"

# game/cethin.rpy:4754
translate Spanish choice2_53d9e051:

    # voice "voice1/line233.mp3"
    # cethin "They had thought that it was crushed into pieces by the demon lord..."
    voice "voice1/line233.mp3"
    cethin "Habían creído que había sido destruida en pedazos por el señor demonio..."

# game/cethin.rpy:4758
translate Spanish choice2_5f465369:

    # voice "voice1/line234.mp3"
    # cethin "In truth, I used an illusion spell to make them believe so."
    voice "voice1/line234.mp3"
    cethin "En realidad, usé un hechizo de ilusión para hacerles creer eso."

# game/cethin.rpy:4764
translate Spanish choice2_f7062057:

    # voice "voice1/line235.mp3"
    # cethin "Why else would they be so timid back there?"
    voice "voice1/line235.mp3"
    cethin "¿Por qué más crees que estaban tan tímidos allá atrás?"

# game/cethin.rpy:4768
translate Spanish choice2_3cff4d30:

    # "The princess blinked."
    "La princesa parpadeó."

# game/cethin.rpy:4770
translate Spanish choice2_23da7978:

    # "Put simply:{w} He had tricked them into thinking that they had lost their divine blade..."
    "En pocas palabras:{w} los había engañado haciéndoles creer que habían perdido su espada divina..."

# game/cethin.rpy:4772
translate Spanish choice2_82e19720:

    # "When he had simply stolen it amidst the chaos."
    "Cuando en realidad simplemente la había robado en medio del caos."

# game/cethin.rpy:4774
translate Spanish choice2_07f55fce:

    # lumishock "You..."
    lumishock "Tú..."

# game/cethin.rpy:4785
translate Spanish choice2_07bb7b40:

    # "And then she turned to Reo-"
    "Y entonces miró a Reo-"

# game/cethin.rpy:4789
translate Spanish choice2_3d5532c4:

    # lumiuwu "What have you done to Cethin?!" with vpunch
    lumiuwu "¡¿Qué le has hecho a Cethin?!" with vpunch

# game/cethin.rpy:4791
translate Spanish choice2_6d56faa9:

    # voice "voice2/line132.mp3"
    # reo "Hold on...! Why am I being blamed here?!"
    voice "voice2/line132.mp3"
    reo "¡Espera...! ¡¿Por qué me están culpando a mí?!"

# game/cethin.rpy:4799
translate Spanish choice2_877b5450:

    # "The princess proceeded to run after the butler."
    "La princesa procedió a correr tras el mayordomo."

# game/cethin.rpy:4801
translate Spanish choice2_fe673c53:

    # lumiuwu "You've been a terrible influence...!" with vpunch
    lumiuwu "¡Has sido una pésima influencia...!" with vpunch

# game/cethin.rpy:4803
translate Spanish choice2_dd9aca67:

    # "She chased him around the room, seemingly ready to throw complaints at him."
    "Lo persiguió por la habitación, aparentemente lista para lanzarle quejas."

# game/cethin.rpy:4811
translate Spanish choice2_c2558be3:

    # "Finally, the butler threw himself over the chandelier where she couldn't reach."
    "Finalmente, el mayordomo se lanzó sobre la lámpara de araña, donde ella no podía alcanzarlo."

# game/cethin.rpy:4813
translate Spanish choice2_69334146:

    # lumiuwu "Reo, not fair!"
    lumiuwu "¡Reo, eso no es justo!"

# game/cethin.rpy:4815
translate Spanish choice2_626d8c46:

    # "The butler ignored the princess and kept himself away."
    "El mayordomo ignoró a la princesa y se mantuvo alejado."

# game/cethin.rpy:4817
translate Spanish choice2_54f825e0:

    # "... Not that she could do anything to him either way."
    "... No es que ella pudiera hacerle algo de todos modos."

# game/cethin.rpy:4819
translate Spanish choice2_e9e2b89f:

    # "That said, they were akin to a cat and mouse."
    "Dicho eso, parecían un gato y un ratón."

# game/cethin.rpy:4823
translate Spanish choice2_7da38388:

    # voice "voice1/line236.mp3"
    # cethin "Ahaha... hahahaha...!"
    voice "voice1/line236.mp3"
    cethin "Jajaja... ¡jajajajaja...!"

# game/cethin.rpy:4827
translate Spanish choice2_7a05f88d:

    # "Cethin could only laugh at their antics."
    "Cethin solo podía reírse de sus payasadas."

# game/cethin.rpy:4829
translate Spanish choice2_b0509cfd:

    # lumihappy "(Oh well. I like him this way as well.)"
    lumihappy "(Bueno. También me gusta así.)"

# game/cethin.rpy:4831
translate Spanish choice2_74f2e645:

    # "It's over. It's finally over."
    "Se acabó. Por fin se acabó."

# game/cethin.rpy:4835
translate Spanish choice2_7d428130:

    # "The final battle was brought to a close..."
    "La batalla final había llegado a su fin..."

# game/cethin.rpy:4837
translate Spanish choice2_960cda4e:

    # "The princess had gained her freedom, and the bard had officially obtained the title of {i}'hero'{/i}."
    "La princesa había ganado su libertad, y el bardo había obtenido oficialmente el título de {i}'héroe'{/i}."

# game/cethin.rpy:4843
translate Spanish choice2_f1ccb748:

    # "... But, this could hardly be considered the ending of their story."
    "... Pero, difícilmente podría considerarse el final de su historia."

# game/cethin.rpy:4850
translate Spanish choice2_397b1551:

    # voice "voice2/line133.mp3"
    # reo "So the princess has finally graduated."
    voice "voice2/line133.mp3"
    reo "Así que la princesa finalmente se ha graduado."

# game/cethin.rpy:4856
translate Spanish choice2_b47460c9:

    # voice "voice2/line134.mp3"
    # reo "I am soooo proud."
    voice "voice2/line134.mp3"
    reo "Estoy taaaan orgulloso."

# game/cethin.rpy:4860
translate Spanish choice2_fef10d85:

    # lumided "Must you be sarcastic up until the final moment?"
    lumided "¿Tienes que ser sarcástico hasta el último momento?"

# game/cethin.rpy:4864
translate Spanish choice2_7275531c:

    # voice "voice2/line134-5.mp3"
    # reo "I couldn't help it."
    voice "voice2/line134-5.mp3"
    reo "No pude evitarlo."

# game/cethin.rpy:4868
translate Spanish choice2_200b0dab:

    # "He replied as a matter-of-factly."
    "Respondió con total naturalidad."

# game/cethin.rpy:4874
translate Spanish choice2_43c14e69:

    # voice "voice1/line237.mp3"
    # cethin "Thank you very much, Reo."
    voice "voice1/line237.mp3"
    cethin "Muchas gracias, Reo."

# game/cethin.rpy:4880
translate Spanish choice2_9533d769:

    # voice "voice1/line238.mp3"
    # cethin "I owe you a lot."
    voice "voice1/line238.mp3"
    cethin "Te debo mucho."

# game/cethin.rpy:4886
translate Spanish choice2_460f3b15:

    # voice "voice2/line135.mp3"
    # reo "Yes. Yes you do."
    voice "voice2/line135.mp3"
    reo "Sí. Sí que me debes."

# game/cethin.rpy:4890
translate Spanish choice2_99614613:

    # "He replied without a single drop of shame."
    "Respondió sin una gota de vergüenza."

# game/cethin.rpy:4892
translate Spanish choice2_24fef159:

    # lumided "(I could not imagine what kind of 'training' Reo had given him...)"
    lumided "(No puedo imaginar qué tipo de “entrenamiento” le habrá dado Reo...)"

# game/cethin.rpy:4896
translate Spanish choice2_7305258a:

    # voice "voice2/line136.mp3"
    # reo "Well then, I bid the two of you goodbye."
    voice "voice2/line136.mp3"
    reo "Bueno entonces, me despido de ustedes dos."

# game/cethin.rpy:4900
translate Spanish choice2_5002e8ca:

    # voice "voice2/line137.mp3"
    # reo "The road back to the palace is a long one... so the two of you better be careful on the way."
    voice "voice2/line137.mp3"
    reo "El camino de regreso al palacio es largo... así que más vale que tengan cuidado en el trayecto."

# game/cethin.rpy:4906
translate Spanish choice2_d842a2eb:

    # voice "voice2/line138.mp3"
    # reo "I'd laugh myself to death if I hear news that you died on the way."
    voice "voice2/line138.mp3"
    reo "Me moriría de risa si escucho que murieron en el camino."

# game/cethin.rpy:4910
translate Spanish choice2_1081ee49:

    # lumided "So you are planning to follow us in death?"
    lumided "¿Así que planeas seguirnos en la muerte?"

# game/cethin.rpy:4912
translate Spanish choice2_de400164:

    # lumiplead "My, I did not know you cared so much."
    lumiplead "Vaya, no sabía que te importábamos tanto."

# game/cethin.rpy:4916
translate Spanish choice2_9c41fad1:

    # voice "voice2/line139.mp3"
    # reo "Certainly."
    voice "voice2/line139.mp3"
    reo "Por supuesto."

# game/cethin.rpy:4934
translate Spanish choice2_d0b8280b:

    # "And with that, he bowed to the two for one final time before turning away from them."
    "Y con eso, hizo una reverencia a ambos por última vez antes de alejarse de ellos."

# game/cethin.rpy:4938
translate Spanish choice2_6a095978:

    # "The couple watched him until he disappeared back into the castle."
    "La pareja lo observó hasta que desapareció de nuevo dentro del castillo."

# game/cethin.rpy:4940
translate Spanish choice2_23f87240:

    # lumisad "(I think I'll actually miss him...)"
    lumisad "(Creo que en realidad lo extrañaré...)"

# game/cethin.rpy:4942
translate Spanish choice2_e55bc26b:

    # "As troublesome, mischievous and 'insufferable' he was- as she had put it... she couldn't deny that the butler had played a huge role."
    "Tan problemático, travieso e “insoportable” como era —como ella misma lo había dicho— no podía negar que el mayordomo había tenido un papel enorme."

# game/cethin.rpy:4944
translate Spanish choice2_53895755:

    # "He had trained Cethin, provided them their needs, and enabled every one of her whims."
    "Había entrenado a Cethin, les había proporcionado lo que necesitaban y había hecho posible cada uno de sus caprichos."

# game/cethin.rpy:4946
translate Spanish choice2_00162863:

    # "In her heart, he was a dear friend."
    "En su corazón, era un querido amigo."

# game/cethin.rpy:4948
translate Spanish choice2_899eae8c:

    # lumithink "(I am certain Cethin thinks of him the same way as well.)"
    lumithink "(Estoy segura de que Cethin piensa lo mismo de él.)"

# game/cethin.rpy:4954
translate Spanish choice2_5f5e0105:

    # voice "voice1/line239.mp3"
    # cethin "So... it's just the two of us now."
    voice "voice1/line239.mp3"
    cethin "Así que... ahora solo somos nosotros dos."

# game/cethin.rpy:4958
translate Spanish choice2_8b72def3:

    # lumihappy "I am looking forward to see flowers once again!"
    lumihappy "¡Estoy deseando volver a ver flores otra vez!"

# game/cethin.rpy:4960
translate Spanish choice2_827a85ce:

    # lumihappy "And people, and buildings, and my family..."
    lumihappy "Y gente, y edificios, y a mi familia..."

# game/cethin.rpy:4962
translate Spanish choice2_44b61d3e:

    # "She continued to enumerate things that she was longing to see."
    "Continuó enumerando las cosas que anhelaba ver."

# game/cethin.rpy:4964
translate Spanish choice2_dd1f1129:

    # "Her companion only watched her with a smile."
    "Su compañero solo la observaba con una sonrisa."

# game/cethin.rpy:4968
translate Spanish choice2_60818710:

    # voice "voice1/line240.mp3"
    # cethin "I bet you are."
    voice "voice1/line240.mp3"
    cethin "Apuesto a que sí."

# game/cethin.rpy:4972
translate Spanish choice2_e2ea1157:

    # "He faced the girl and held both her hands."
    "Se volvió hacia la chica y tomó ambas manos."

# game/cethin.rpy:4974
translate Spanish choice2_afb6270f:

    # lumitalk "Cethin...?"
    lumitalk "¿Cethin...?"

# game/cethin.rpy:4979
translate Spanish choice2_2bc1ef95:

    # voice "voice1/line241.mp3"
    # cethin "Lumi... there was something I meant to give you last yule feast, but I couldn't."
    voice "voice1/line241.mp3"
    cethin "Lumi... había algo que quería darte en la última fiesta del yule, pero no pude."

# game/cethin.rpy:4983
translate Spanish choice2_f75137f2:

    # "He fished a hand inside one of his pockets, and produced a ring."
    "Metió una mano en uno de sus bolsillos y sacó un anillo."

# game/cethin.rpy:4988
translate Spanish choice2_38f046f6:

    # voice "voice1/line242.mp3"
    # cethin "I made this from the bone of a bird that I caught..."
    voice "voice1/line242.mp3"
    cethin "Hice esto con el hueso de un ave que cacé..."

# game/cethin.rpy:4995
translate Spanish choice2_07c4a141:

    # voice "voice1/line243.mp3"
    # cethin "I hope you accept it."
    voice "voice1/line243.mp3"
    cethin "Espero que lo aceptes."

# game/cethin.rpy:4999
translate Spanish choice2_092237dc:

    # lumiblush "..."
    lumiblush "..."

# game/cethin.rpy:5001
translate Spanish choice2_ca7df0ba:

    # "Without a word, Lumi held her hand out."
    "Sin decir palabra, Lumi extendió su mano."

# game/cethin.rpy:5006
translate Spanish choice2_e4ce1e1c:

    # "Cethin stared at her, and then smiled sheepishly."
    "Cethin la miró y luego sonrió tímidamente."

# game/cethin.rpy:5010
translate Spanish choice2_df1ed849:

    # "He took her hand and inserted the ring himself."
    "Tomó su mano y le puso él mismo el anillo."

# game/cethin.rpy:5012
translate Spanish choice2_193a27e4:

    # lumihappy "It fits quite perfectly!"
    lumihappy "¡Encaja perfectamente!"

# game/cethin.rpy:5014
translate Spanish choice2_9f2dbf01:

    # lumitalk "But, pray tell why didn't you give it then?"
    lumitalk "Pero, dime, ¿por qué no me lo diste entonces?"

# game/cethin.rpy:5019
translate Spanish choice2_8fe40c04:

    # voice "voice1/line244.mp3"
    # cethin "Well..."
    voice "voice1/line244.mp3"
    cethin "Bueno..."

# game/cethin.rpy:5023
translate Spanish choice2_0750b9b8:

    # "He rubbed the back of his head."
    "Se rascó la parte posterior de la cabeza."

# game/cethin.rpy:5027
translate Spanish choice2_2253bb97:

    # voice "voice1/line245.mp3"
    # cethin "Mutually exchanging gifts during the yule festival... for us... meant..."
    voice "voice1/line245.mp3"
    cethin "Intercambiar regalos mutuamente durante el festival de yule... para nosotros... significaba..."

# game/cethin.rpy:5031
translate Spanish choice2_e0cf0b1c:

    # "He trailed off."
    "Dejó la frase a medias."

# game/cethin.rpy:5033
translate Spanish choice2_bb14d5b4:

    # "Cethin may be able to speak much more comfortably now, but he's still timid at his core."
    "Cethin puede hablar con mucha más soltura ahora, pero sigue siendo tímido en el fondo."

# game/cethin.rpy:5035
translate Spanish choice2_6e233986:

    # "As usual, Lumi gave him time.{w} She waited patiently for him to collect himself."
    "Como siempre, Lumi le dio tiempo.{w} Esperó pacientemente a que se recompusiera."

# game/cethin.rpy:5041
translate Spanish choice2_1721f4cf:

    # voice "voice1/line246.mp3"
    # cethin "... It meant betrothal."
    voice "voice1/line246.mp3"
    cethin "... Significaba compromiso."

# game/cethin.rpy:5045
translate Spanish choice2_de1ecac1:

    # "Lumi blinked."
    "Lumi parpadeó."

# game/cethin.rpy:5049
translate Spanish choice2_ce28567b:

    # lumishy "Ah."
    lumishy "Ah."

# game/cethin.rpy:5051
translate Spanish choice2_e0791a02:

    # "Her heart had almost stopped in that moment."
    "Su corazón casi se detuvo en ese momento."

# game/cethin.rpy:5053
translate Spanish choice2_6fdf473a:

    # "The princess pursed her lips, trying to contain her emotions."
    "La princesa frunció los labios, intentando contener sus emociones."

# game/cethin.rpy:5055
translate Spanish choice2_d66fb9d8:

    # "It finally made sense to her... as to why he had asked her that night-"
    "Finalmente lo comprendió... el motivo por el cual él le había preguntado aquella noche-"

# game/cethin.rpy:5057
translate Spanish choice2_dfc96a46:

    # "-On whether she was fine with marrying anyone."
    "-Sobre si estaba de acuerdo con casarse con cualquiera."

# game/cethin.rpy:5059
translate Spanish choice2_3dee4d0d:

    # "He had wanted to know if she was willing to forfeit her responsibility... {i}for him{/i}."
    "Él quería saber si ella estaba dispuesta a renunciar a su responsabilidad... {i}por él{/i}."

# game/cethin.rpy:5061
translate Spanish choice2_bc8178bd:

    # lumithink "(So that was why he...)"
    lumithink "(Así que por eso...)"

# game/cethin.rpy:5063
translate Spanish choice2_f4bbfbb9:

    # "-That was why he was so down when she replied that she wouldn't abandon her responsibility."
    "-Por eso se sintió tan decaído cuando ella respondió que no abandonaría su responsabilidad."

# game/cethin.rpy:5065
translate Spanish choice2_6c41b19b:

    # "She had unintentionally rejected him."
    "Sin querer, lo había rechazado."

# game/cethin.rpy:5067
translate Spanish choice2_b9510872:

    # voice "voice1/line151.mp3"
    voice "voice1/line151.mp3"

# game/cethin.rpy:5071
translate Spanish choice2_19c95222:

    # cethin "{i}I've decided. I'll do my best to become worthy of standing by your side.{/i}"
    cethin "{i}He decidido. Haré mi mejor esfuerzo para ser digno de estar a tu lado.{/i}"

# game/cethin.rpy:5075
translate Spanish choice2_5fca1c0e:

    # "Those words just completely went by her back then..."
    "Aquellas palabras simplemente le habían pasado por alto en ese entonces..."

# game/cethin.rpy:5077
translate Spanish choice2_3aebdd3c:

    # "But it was his declaration of his intention to continue pursuing her."
    "Pero eran su declaración de intención de seguir cortejándola."

# game/cethin.rpy:5079
translate Spanish choice2_0d8408f3:

    # "To become a worthy hero for her."
    "De convertirse en un héroe digno de ella."

# game/cethin.rpy:5081
translate Spanish choice2_092237dc_1:

    # lumiblush "..."
    lumiblush "..."

# game/cethin.rpy:5085
translate Spanish choice2_5d0f43c4:

    # "She touched the ring on her finger and caressed it."
    "Tocó el anillo en su dedo y lo acarició."

# game/cethin.rpy:5087
translate Spanish choice2_34a2721e:

    # "Cethin watched her lovingly."
    "Cethin la observaba con ternura."

# game/cethin.rpy:5093
translate Spanish choice2_e8e174dd:

    # voice "voice1/line247.mp3"
    # cethin "*Ahem* Well then. We should-"
    voice "voice1/line247.mp3"
    cethin "*Ejem* Bien entonces. Deberíamos-"

# game/cethin.rpy:5123
translate Spanish choice2_6024a7dd:

    # "-But before he can finish, the princess leapt onto him."
    "-Pero antes de que pudiera terminar, la princesa saltó sobre él."

# game/cethin.rpy:5127
translate Spanish choice2_ffe73efe:

    # voice "voice1/line248.mp3"
    # cethin "L-lumi...?"
    voice "voice1/line248.mp3"
    cethin "¿L-Lumi...?"

# game/cethin.rpy:5131
translate Spanish choice2_37284d9f:

    # "Lumi's face was very close to his."
    "El rostro de Lumi estaba muy cerca del suyo."

# game/cethin.rpy:5133
translate Spanish choice2_23dda663:

    # lumishy "I've waited long enough, surely?"
    lumishy "He esperado lo suficiente, ¿no crees?"

# game/cethin.rpy:5137
translate Spanish choice2_823886f5:

    # voice "voice1/line249.mp3"
    # cethin "..."
    voice "voice1/line249.mp3"
    cethin "..."

# game/cethin.rpy:5141
translate Spanish choice2_53696938:

    # "The night elf froze for a moment."
    "El elfo oscuro se quedó paralizado un momento."

# game/cethin.rpy:5145
translate Spanish choice2_d71b834d:

    # voice "voice1/line250.mp3"
    # cethin "Yes. Yes you have."
    voice "voice1/line250.mp3"
    cethin "Sí. Sí que lo has hecho."

# game/cethin.rpy:5151
translate Spanish choice2_ab22990c:

    # "And he pulled her for a kiss."
    "Y la atrajo hacia un beso."

# game/cethin.rpy:5153
translate Spanish choice2_a96f1b4a:

    # "It was warmer than she had imagined."
    "Era más cálido de lo que había imaginado."

# game/cethin.rpy:5155
translate Spanish choice2_6836a17f:

    # "Sweeter than she had hoped for."
    "Más dulce de lo que había esperado."

# game/cethin.rpy:5157
translate Spanish choice2_97d11c60:

    # "Certainly, it was worth the wait."
    "Sin duda, valió la pena la espera."

# game/cethin.rpy:5159
translate Spanish choice2_50b74d72:

    # "Thus, their promise have been fulfilled."
    "Así, su promesa fue cumplida."

# game/cethin.rpy:5161
translate Spanish choice2_4a75c0e5:

    # "The hero she had hoped for was very unlike what she had always dreamt of."
    "El héroe con el que ella había soñado era muy distinto a lo que siempre había imaginado."

# game/cethin.rpy:5163
translate Spanish choice2_e129d433:

    # "He was no powerful warrior wielding a legendary sword."
    "No era un poderoso guerrero empuñando una espada legendaria."

# game/cethin.rpy:5165
translate Spanish choice2_628b8961:

    # "He was no mysterious sorcerer with forbidden spells."
    "No era un misterioso hechicero con conjuros prohibidos."

# game/cethin.rpy:5167
translate Spanish choice2_8d448975:

    # "He was no charming prince in shining armor."
    "No era un encantador príncipe de brillante armadura."

# game/cethin.rpy:5169
translate Spanish choice2_8bf5e3e7:

    # "He was a sham of a bard.{w} A soft hearted night elf, very unlike that of his own kind..."
    "Era un farsante de bardo.{w} Un elfo nocturno de corazón blando, muy distinto a los de su especie..."

# game/cethin.rpy:5171
translate Spanish choice2_0e5c9684:

    # "Unwanted by everyone."
    "Rechazado por todos."

# game/cethin.rpy:5173
translate Spanish choice2_f2737e35:

    # "Yet, he was her hero."
    "Y aun así, él era su héroe."

# game/cethin.rpy:5177
translate Spanish choice2_ec6a5d19:

    # "The only one she could ever want."
    "El único que ella podría desear."

translate Spanish strings:

    # game/cethin.rpy:1254
    old "It must be love"
    new "Debe ser amor"

    # game/cethin.rpy:1254
    old "I don't know"
    new "No lo sé"

    # game/cethin.rpy:3695
    old "The right for the princess' hand..."
    new "El derecho a la mano de la princesa..."

    # game/cethin.rpy:3695
    old "The princess can escape"
    new "La princesa puede escapar"

    # game/cethin.rpy:3695
    old "The butler will lose his job"
    new "El mayordomo perderá su trabajo"

    # game/cethin.rpy:3739
    old "He wants to support the hero"
    new "Quiere apoyar al héroe"

    # game/cethin.rpy:3739
    old "He wants to take credit"
    new "Quiere llevarse el mérito"

    # game/cethin.rpy:3739
    old "He just wants to free the princess"
    new "Solo quiere liberar a la princesa"

translate Spanish strings:

    old "Cethin"
    new "Cethin"

    old "???"
    new "???"

    old "Demon Butler"
    new "{size=-3}Mayordomo Demonio{/size}"

    old "Reo"
    new "Reo"

    old "Hero"
    new "Héroe"

    old "White Mage"
    new "Maga de Luz"

    old "Black Mage"
    new "Maga Oscura" 