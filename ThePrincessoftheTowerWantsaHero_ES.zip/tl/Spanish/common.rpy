translate Spanish python:
    gui.text_font = "OpenDyslexic-Regular.otf"
    
# game/common.rpy:37
translate Spanish commonroute_d3e0f22e:

    # voice "voice1/line1.mp3"
    # "{i}~In this land of eternal winter~{/i}"
    voice "voice1/line1.mp3"
    "{i}~En esta tierra de invierno eterno~{/i}"

# game/common.rpy:46
translate Spanish commonroute_b51bcc14:

    # voice "voice1/line2.mp3"
    # "{i}~We tell a tale of a princess atop a lonely tower~{/i}"
    voice "voice1/line2.mp3"
    "{i}~Contamos la historia de una princesa en lo alto de una torre solitaria~{/i}"

# game/common.rpy:50
translate Spanish commonroute_805655b8:

    # voice "voice1/line3.mp3"
    # "{i}~Awaiting her knight in shining armor~{/i}"
    voice "voice1/line3.mp3"
    "{i}~Esperando a su caballero de brillante armadura~{/i}"

# game/common.rpy:56
translate Spanish commonroute_4d86963e:

    # voice "voice1/line4.mp3"
    # "{i}~For she seeks…~{/i}"
    voice "voice1/line4.mp3"
    "{i}~Pues ella busca…~{/i}"

# game/common.rpy:67
translate Spanish commonroute_1c942f4c:

    # voice "voice1/line5.mp3"
    # "Uhm… what could we add...?"
    voice "voice1/line5.mp3"
    "Uhm… ¿qué podríamos agregar...?"

# game/common.rpy:73
translate Spanish commonroute_c5c2ecf8:

    # voice "voice1/line6.mp3"
    # "Rumor? Femur? Endeavor...?"
    voice "voice1/line6.mp3"
    "¿Rumor? ¿Humor? ¿Valor...?"

# game/common.rpy:79
translate Spanish commonroute_d0450d38:

    # voice "voice1/line7.mp3"
    # "No, doesn't sound right..."
    voice "voice1/line7.mp3"
    "No, no suena bien..."

# game/common.rpy:83
translate Spanish commonroute_194b10dc:

    # voice "voice1/line8.mp3"
    # "Oh! Yes, I've got one..."
    voice "voice1/line8.mp3"
    "¡Oh! Sí, tengo uno..."

# game/common.rpy:87
translate Spanish commonroute_b41de6ff:

    # voice "voice1/line9.mp3"
    # "*Ahem*" with vpunch
    voice "voice1/line9.mp3"
    "*Ejem*" with vpunch

# game/common.rpy:93
translate Spanish commonroute_a8131c11:

    # voice "voice1/line10.mp3"
    # "{i}~For she seeks one who can charm her~{/i}"
    voice "voice1/line10.mp3"
    "{i}~Pues ella busca a quien pueda encantarla~{/i}"

# game/common.rpy:97
translate Spanish commonroute_c0624a75:

    # voice "voice1/line11.mp3"
    # "{i}~Amidst this excruciating winter~{/i}"
    voice "voice1/line11.mp3"
    "{i}~En medio de este invierno insoportable~{/i}"

# game/common.rpy:111
translate Spanish commonroute_2e7a3259:

    # voice "voice1/line12.mp3"
    # who "...!" with vpunch
    voice "voice1/line12.mp3"
    who "...!" with vpunch

# game/common.rpy:115
translate Spanish commonroute_70762575:

    # "She cupped her hands over his mouth, ending the song at that."
    "Ella le tapó la boca con las manos, poniendo fin a la canción."

# game/common.rpy:117
translate Spanish commonroute_6eb4d65f:

    # lumided "That was atrocious..."
    lumided "Eso fue atroz..."

# game/common.rpy:119
translate Spanish commonroute_2e842361:

    # "She cringed, thinking back at his performances. Whew..."
    "Ella se estremeció, recordando sus actuaciones. Uf..."

# game/common.rpy:123
translate Spanish commonroute_84b23a89:

    # lumided "I’ve been listening to you for hours..."
    lumided "Llevo horas escuchándote..."

# game/common.rpy:125
translate Spanish commonroute_87efa828:

    # lumided "Admittedly, that was at least one of your better attempts."
    lumided "A decir verdad, ese fue al menos uno de tus mejores intentos."

# game/common.rpy:129
translate Spanish commonroute_b4cf6e47:

    # voice "voice1/line13.mp3"
    # who "Whhh mhhh mph! ({b}Translation:{/b} Why, thank you!)"
    voice "voice1/line13.mp3"
    who "Whhh mhhh mph! ({b}Traducción:{/b} ¡Vaya, gracias!)"

# game/common.rpy:133
translate Spanish commonroute_4dd737ba:

    # lumided "That is to say, I was most definitely not complimenting you."
    lumided "Es decir, definitivamente no te estaba halagando."

# game/common.rpy:135
translate Spanish commonroute_21a3ebb0:

    # lumiplead "That was a horrendous performance!"
    lumiplead "¡Esa fue una actuación horrenda!"

# game/common.rpy:147
translate Spanish commonroute_f7577b91:

    # "With that, she let go of his mouth and pulled away from the poor guy."
    "Con eso, ella le soltó la boca y se apartó del pobre chico."

# game/common.rpy:149
translate Spanish commonroute_6354b0c6:

    # voice "voice1/line14.mp3"
    # who "Oh..."
    voice "voice1/line14.mp3"
    who "Oh..."

# game/common.rpy:153
translate Spanish commonroute_02cac681:

    # "His ears drooped down in sheer disappointment."
    "Sus orejas cayeron de pura decepción."

# game/common.rpy:155
translate Spanish commonroute_650eb27d:

    # lumisad "(I feel daggers on my chest... come now, I was merely being honest!)"
    lumisad "(Siento como si me clavaran puñales en el pecho... ¡Vamos, solo estaba siendo sincera!)"

# game/common.rpy:157
translate Spanish commonroute_f41901fa:

    # "She sighed."
    "Ella suspiró."

# game/common.rpy:159
translate Spanish commonroute_3a449fb5:

    # lumisad "I know I said I’d help you out, but I am exhausted."
    lumisad "Sé que dije que te ayudaría, pero estoy agotada."

# game/common.rpy:161
translate Spanish commonroute_ba4afac6:

    # lumi "I'd be willing to do something else though."
    lumi "Aunque estaría dispuesta a hacer otra cosa."

# game/common.rpy:163
translate Spanish commonroute_49086c2e:

    # lumided "(... As long as it isn't about {i}indulging{/i} in your music.)"
    lumided "(... Siempre y cuando no se trate de {i}deleitarse{/i} con tu música.)"

# game/common.rpy:168
translate Spanish commonroute_bd2828b6:

    # "Immediately, his ears perked up."
    "De inmediato, sus orejas se levantaron."

# game/common.rpy:170
translate Spanish commonroute_8f8a3ff6:

    # "This was a well known characteristic of elves- their ears conveyed their emotions."
    "Esa era una característica bien conocida de los elfos: sus orejas expresaban sus emociones."

# game/common.rpy:172
translate Spanish commonroute_8a61937e:

    # lumiehe "(I'd hate to admit it, but I do find it rather adorable when they do that.)"
    lumiehe "(Odio admitirlo, pero me parece bastante adorable cuando hacen eso.)"

# game/common.rpy:176
translate Spanish commonroute_4b6838cb:

    # voice "voice1/line15.mp3"
    # who "Of course! As long as you don’t kick me out of here."
    voice "voice1/line15.mp3"
    who "¡Por supuesto! Siempre y cuando no me eches de aquí."

# game/common.rpy:180
translate Spanish commonroute_a6d91887:

    # lumisad "Dearie, I’m not such a deplorable person!"
    lumisad "¡Querido, no soy una persona tan deplorable!"

# game/common.rpy:185
translate Spanish commonroute_6f62b26e:

    # voice "voice1/line16.mp3"
    # who "Oh, sorry...{w} that's not what I..."
    voice "voice1/line16.mp3"
    who "Oh, lo siento...{w} no era lo que yo..."

# game/common.rpy:189
translate Spanish commonroute_c722511c:

    # lumi "Enough. No need for apologies."
    lumi "Basta. No hace falta que te disculpes."

# game/common.rpy:191
translate Spanish commonroute_a20cefa7:

    # "..."
    "..."

# game/common.rpy:195
translate Spanish commonroute_545e1aae:

    # lumisad "(Hm... yes... how did I find myself in this situation?)"
    lumisad "(Hm... sí... ¿cómo terminé en esta situación?)"

# game/common.rpy:199
translate Spanish commonroute_6d1b20c0:

    # "A few hours ago..."
    "Hace unas horas..."

# game/common.rpy:203
translate Spanish commonroute_4ebfc82c:

    # lumiwish "Oh brave hero, I have long been waiting for your arrival!"
    lumiwish "¡Oh, valiente héroe, he esperado largo tiempo tu llegada!"

# game/common.rpy:205
translate Spanish commonroute_5f0017b4:

    # lumided "..."
    lumided "..."

# game/common.rpy:207
translate Spanish commonroute_8c84a0f9:

    # lumisad "Hm, now that I think of it, I am not very fond of this one..."
    lumisad "Hm, ahora que lo pienso, este no me agrada mucho..."

# game/common.rpy:209
translate Spanish commonroute_de2a0c99:

    # "She nodded to herself."
    "Ella asintió para sí misma."

# game/common.rpy:211
translate Spanish commonroute_29b1918c:

    # "The lone girl then continued to recite her lines in the middle of the room-"
    "La chica solitaria entonces continuó recitando sus líneas en medio de la habitación-"

# game/common.rpy:213
translate Spanish commonroute_7375b12b:

    # lumiwish "Brave hero, I hope your weary soul..."
    lumiwish "Valiente héroe, espero que tu alma cansada..."

# game/common.rpy:215
translate Spanish commonroute_eb01d4dc:

    # lumided "-No, scrap that one."
    lumided "—No, descarta ese."

# game/common.rpy:217
translate Spanish commonroute_2681bec4:

    # lumiwish "Oh, you have arrived at last.{w} Long have I awaited for you in my dreams..."
    lumiwish "Oh, por fin has llegado.{w} Largo tiempo te he esperado en mis sueños..."

# game/common.rpy:219
translate Spanish commonroute_7e5353d3:

    # lumihappy "... That one is rather dramatic, but it has some flair."
    lumihappy "... Ese es bastante dramático, pero tiene su gracia."

# game/common.rpy:221
translate Spanish commonroute_83dd139f:

    # lumi "I suppose I'll set that one aside."
    lumi "Supongo que dejaré ese apartado."

# game/common.rpy:223
translate Spanish commonroute_e6e472a7:

    # lumiwish "Hero, you have arrived. State your name."
    lumiwish "Héroe, has llegado. Di tu nombre."

# game/common.rpy:225
translate Spanish commonroute_f03fd134:

    # "She recited once again, offering her hand in the air."
    "Recitó una vez más, ofreciendo su mano en el aire."

# game/common.rpy:227
translate Spanish commonroute_c16afc45:

    # lumihappy "(Simple, subtle and dignified... I think I shall go with this one for now.)"
    lumihappy "(Sencillo, sutil y digno... creo que me quedaré con este por ahora.)"

# game/common.rpy:229
translate Spanish commonroute_47f5d4be:

    # "... At least, until she decides to change it again in a few days' time."
    "... Al menos, hasta que decida cambiarlo de nuevo en unos días."

# game/common.rpy:231
translate Spanish commonroute_264305e1:

    # "Having reached a consensus with herself, the girl felt pretty proud."
    "Habiendo llegado a un consenso consigo misma, la chica se sintió bastante orgullosa."

# game/common.rpy:233
translate Spanish commonroute_c6499e0f:

    # lumisad "How do the other princesses deal with this?"
    lumisad "¿Cómo lidian las otras princesas con esto?"

# game/common.rpy:235
translate Spanish commonroute_b63145c0:

    # lumisad "I don't want to be the last one rescued..."
    lumisad "No quiero ser la última en ser rescatada..."

# game/common.rpy:237
translate Spanish commonroute_1e80c0cd:

    # lumishock "Oh dear... I will not have to wait until I'm old and ailing until my hero arrives, will I?"
    lumishock "Oh cielos... no tendré que esperar hasta estar vieja y enferma para que llegue mi héroe, ¿verdad?"

# game/common.rpy:239
translate Spanish commonroute_63e6b6e8:

    # "She pressed her hands together, forming a praying gesture."
    "Juntó las manos, formando un gesto de oración."

# game/common.rpy:241
translate Spanish commonroute_694897ae:

    # lumiehe "Hero, I wish you'd hurry on your way."
    lumiehe "Héroe, desearía que te apresuraras en tu camino."

# game/common.rpy:243
translate Spanish commonroute_1301ce54:

    # lumiehe "You do not have to be a prince. A rough adventurer would do!"
    lumiehe "No tienes que ser un príncipe. ¡Un aventurero rudo bastaría!"

# game/common.rpy:245
translate Spanish commonroute_ffe02a91:

    # lumiwish "Although I'd love a dashing hero, who can sweep me off my feet."
    lumiwish "Aunque me encantaría un héroe apuesto que pudiera hacerme perder la cabeza."

# game/common.rpy:247
translate Spanish commonroute_6adb5a4c:

    # lumiwish "A brave, handsome hero with strong arms, wielding a legendary sword perhaps?"
    lumiwish "¿Un héroe valiente y apuesto con brazos fuertes, empuñando quizá una espada legendaria?"

# game/common.rpy:249
translate Spanish commonroute_9d16f44d:

    # lumiwish "Oh, or even a wise sorcerer with a mastery of devastating spells!"
    lumiwish "¡Oh, o incluso un sabio hechicero con dominio de conjuros devastadores!"

# game/common.rpy:251
translate Spanish commonroute_24660424:

    # lumiwish "Strong, wise, courageous...!"
    lumiwish "¡Fuerte, sabio, valiente...!"

# game/common.rpy:253
translate Spanish commonroute_3cd20cdb:

    # "She giggled at the thought."
    "Ella soltó una risita al pensarlo."

# game/common.rpy:255
translate Spanish commonroute_47a9ff75:

    # lumiuwu "(Settle down Lumi, don't get ahead of yourself now!)"
    lumiuwu "(Tranquilízate, Lumi, ¡no te adelantes!)"

# game/common.rpy:257
translate Spanish commonroute_49c5eeda:

    # lumithink "No matter-"
    lumithink "No importa—"

# game/common.rpy:259
translate Spanish commonroute_2112c7cf:

    # lumiwish "Whatever my hero shall be like... I am looking forward to meeting him."
    lumiwish "Sea como sea mi héroe... estoy deseando conocerlo."

# game/common.rpy:263
translate Spanish commonroute_db7335cc:

    # "Ending her fantasies at that, the princess walked up to her balcony and stared at her scenery."
    "Terminando sus fantasías, la princesa se acercó a su balcón y contempló el paisaje."

# game/common.rpy:265
translate Spanish commonroute_868a2a55:

    # "A cold breeze lightly kissed her cheeks. The girl momentarily closed her eyes from the chill."
    "Una brisa fría le besó suavemente las mejillas. La chica cerró los ojos un momento ante el escalofrío."

# game/common.rpy:267
translate Spanish commonroute_3d2b03fb:

    # "It had been the same view for who knows how long it had been. Honestly, she had lost track of time."
    "Había sido la misma vista desde quién sabe cuánto tiempo. Honestamente, había perdido la noción del tiempo."

# game/common.rpy:269
translate Spanish commonroute_4446b4ac:

    # "Snow. Snow. And more snow. The familiar white blanket that which covered this region was the only sight to see."
    "Nieve. Nieve. Y más nieve. La familiar manta blanca que cubría esta región era lo único que podía verse."

# game/common.rpy:271
translate Spanish commonroute_8474125a:

    # "Dead trees, gigantic protruding icicle spires, and even more snow."
    "Árboles muertos, enormes agujas de hielo que sobresalían y aún más nieve."

# game/common.rpy:273
translate Spanish commonroute_0b020b15:

    # "A whole lot of nothing."
    "Nada de nada."

# game/common.rpy:275
translate Spanish commonroute_4e22f66c:

    # "She wondered how she had managed to keep her head together all this time..."
    "Se preguntó cómo había logrado mantener la cordura todo ese tiempo..."

# game/common.rpy:277
translate Spanish commonroute_1c8eeeac:

    # "There literally was nothing to do in this wintry land!"
    "¡Literalmente no había nada que hacer en esta tierra invernal!"

# game/common.rpy:279
translate Spanish commonroute_bbf2431a:

    # lumisad "..."
    lumisad "..."

# game/common.rpy:281
translate Spanish commonroute_7c0cc09c:

    # "... Another sigh escaped her lips."
    "... Otro suspiro escapó de sus labios."

# game/common.rpy:284
translate Spanish commonroute_6e1c695d:

    # voice "voice2/line1.mp3"
    # who "Excuse me princess, may I come in?"
    voice "voice2/line1.mp3"
    who "Disculpe, princesa, ¿puedo entrar?"

# game/common.rpy:288
translate Spanish commonroute_339f00e9:

    # "She didn't even turn around, and just continued to stare at nothing in particular."
    "Ni siquiera se dio vuelta, solo siguió mirando a la nada."

# game/common.rpy:290
translate Spanish commonroute_4c4e8b5c:

    # lumi "Yes, you may."
    lumi "Sí, puedes."

# game/common.rpy:292
translate Spanish commonroute_3e668ba5:

    # "Her reply was nonchalant."
    "Su respuesta fue indiferente."

# game/common.rpy:294
translate Spanish commonroute_3aeffd76:

    # voice "voice2/line2.mp3"
    # who "Very well."
    voice "voice2/line2.mp3"
    who "Muy bien."

# game/common.rpy:300
translate Spanish commonroute_f71beb2a:

    # lumitalk "So? Is it lunchtime?"
    lumitalk "¿Y bien? ¿Es hora del almuerzo?"

# game/common.rpy:302
translate Spanish commonroute_24235778:

    # lumi "I'm still quite full, so you may take that back."
    lumi "Aún estoy bastante llena, así que puedes llevártelo de vuelta."

# game/common.rpy:304
translate Spanish commonroute_a4251a9f:

    # lumitalk "I would not mind helping myself to some of your tea and snacks, if you are offering."
    lumitalk "No me importaría servirme un poco de tu té y tus bocadillos, si los ofreces."

# game/common.rpy:312
translate Spanish commonroute_59bdad8f:

    # "She finally turned around to face her visitor."
    "Finalmente, se dio vuelta para enfrentar a su visitante."

# game/common.rpy:316
translate Spanish commonroute_f9ff318a:

    # voice "voice2/line3.mp3"
    # butler "Oho? It seems the princess has become rather fond of my tea."
    voice "voice2/line3.mp3"
    butler "¿Oho? Parece que la princesa le ha tomado bastante gusto a mi té."

# game/common.rpy:322
translate Spanish commonroute_465e30ba:

    # voice "voice2/line4.mp3"
    # butler "I shall brew you a cup after I finish my task then."
    voice "voice2/line4.mp3"
    butler "Entonces te prepararé una taza cuando termine mi tarea."

# game/common.rpy:328
translate Spanish commonroute_99050029:

    # "This was the demon butler who had recently been assigned to her."
    "Este era el mayordomo demonio que le había sido asignado recientemente."

# game/common.rpy:330
translate Spanish commonroute_8a6b9cd5:

    # "The princess had been served by different butlers of the demonkin over the duration of her imprisonment."
    "Durante su cautiverio, la princesa había sido atendida por distintos mayordomos demonkin."

# game/common.rpy:332
translate Spanish commonroute_42771a67:

    # "They were generally unresponsive of her idle chatter and inquiries, but this one would always oblige her with small talk."
    "Por lo general, no respondían a sus charlas ociosas y preguntas, pero este siempre accedía a conversar un poco."

# game/common.rpy:334
translate Spanish commonroute_778ff82f:

    # "He even had the gall to tease her- something that would normally put one's head on the chopping block."
    "Incluso tenía el descaro de burlarse de ella, algo que normalmente le habría costado la cabeza."

# game/common.rpy:336
translate Spanish commonroute_f1d7ee1a:

    # "Of course, he can get away with it, considering the princess' current predicament... not that she would carry out such punishment."
    "Por supuesto, él puede salirse con la suya, considerando la situación actual de la princesa... no es que ella fuera a aplicar tal castigo."

# game/common.rpy:338
translate Spanish commonroute_a5735cd6:

    # "Admittedly, he's the most entertaining thing in her life right now-"
    "A decir verdad, él es lo más entretenido en su vida en este momento—"

# game/common.rpy:340
translate Spanish commonroute_0c87ab99:

    # "He only ever comes over to bring her meals and other necessities, but it seemed that he came empty-handed this time."
    "Solo viene a traerle comidas y otras necesidades, pero parece que esta vez vino con las manos vacías."

# game/common.rpy:342
translate Spanish commonroute_b8c12192:

    # lumisad "Hm? Whatever did you come here for then?"
    lumisad "¿Hm? Entonces, ¿para qué viniste?"

# game/common.rpy:346
translate Spanish commonroute_a034f576:

    # voice "voice2/line5.mp3"
    # butler "Hmm... Should I tell you or should I not tell you, I wonder~?"
    voice "voice2/line5.mp3"
    butler "Hmm... ¿Debería decírtelo o no decírtelo, me pregunto~?"

# game/common.rpy:350
translate Spanish commonroute_bb83318b:

    # "He spoke teasingly."
    "Habló en tono burlón."

# game/common.rpy:352
translate Spanish commonroute_9dc07f69:

    # lumided "Spill your beans, come now. I implore you to brighten this dull day of mine."
    lumided "Suelta lo que sabes, vamos. Te imploro que alegres este día tan aburrido mío."

# game/common.rpy:354
translate Spanish commonroute_47519207:

    # "She said in a very monotonous voice."
    "Ella dijo con una voz muy monótona."

# game/common.rpy:358
translate Spanish commonroute_517a336b:

    # voice "voice2/line6.mp3"
    # butler "Ahaha... oh princess, you never fail to amuse me."
    voice "voice2/line6.mp3"
    butler "Jajaja... oh, princesa, nunca dejas de divertirme."

# game/common.rpy:364
translate Spanish commonroute_c5f7bb5c:

    # voice "voice2/line7.mp3"
    # butler "If only I could chat and stay by your side more frequently... but alas, {i}responsibilities{/i}."
    voice "voice2/line7.mp3"
    butler "Si tan solo pudiera charlar y quedarme a tu lado más a menudo... pero, ay, {i}responsabilidades{/i}."

# game/common.rpy:368
translate Spanish commonroute_0ea2cef8:

    # "The princess rolled her eyes."
    "La princesa puso los ojos en blanco."

# game/common.rpy:372
translate Spanish commonroute_c7174778:

    # lumihappy "Well I suppose having you around would make the passing of time much more tolerable."
    lumihappy "Bueno, supongo que tenerte cerca haría que el paso del tiempo sea mucho más tolerable."

# game/common.rpy:374
translate Spanish commonroute_938b924b:

    # lumided "I'll take anyone, even a demon for that matter."
    lumided "Aceptaría a cualquiera, incluso a un demonio."

# game/common.rpy:378
translate Spanish commonroute_0698d0ff:

    # voice "voice2/line8.mp3"
    # butler "Oh I'm quite flattered!"
    voice "voice2/line8.mp3"
    butler "¡Oh, estoy muy halagado!"

# game/common.rpy:392
translate Spanish commonroute_602e281c:

    # "He bowed to the girl to express some respect, but if anything, he was obviously being sarcastic."
    "Hizo una reverencia a la chica para mostrar algo de respeto, pero en realidad, era obvio que estaba siendo sarcástico."

# game/common.rpy:397
translate Spanish commonroute_4313e12e:

    # voice "voice2/line9.mp3"
    # butler "As for your inquiry..."
    voice "voice2/line9.mp3"
    butler "En cuanto a tu pregunta..."

# game/common.rpy:403
translate Spanish commonroute_1e537fd2:

    # "He stepped inside first and gave her room a once-over before continuing."
    "Entró primero y echó un vistazo rápido a la habitación antes de continuar."

# game/common.rpy:405
translate Spanish commonroute_dcdd9e99:

    # "The demon took moments before finally being ready to carry on back to their original topic."
    "El demonio tardó unos momentos antes de estar finalmente listo para volver al tema original."

# game/common.rpy:412
translate Spanish commonroute_16c21588:

    # voice "voice2/line10.mp3"
    # butler "We've had intruders inside the castle, so I've been tasked to do some {i}'sweeping'{/i}."
    voice "voice2/line10.mp3"
    butler "Hemos tenido intrusos en el castillo, así que me han encargado hacer una pequeña {i}'limpieza'{/i}."

# game/common.rpy:418
translate Spanish commonroute_d010c004:

    # "The butler said as he opened the girl's closet."
    "Dijo el mayordomo mientras abría el armario de la chica."

# game/common.rpy:420
translate Spanish commonroute_86eb51a2:

    # lumisad "Intruders you say..."
    lumisad "¿Intrusos, dices...?"

# game/common.rpy:422
translate Spanish commonroute_cdafb64a:

    # "She mulled."
    "Ella reflexionó."

# game/common.rpy:429
translate Spanish commonroute_176a01df:

    # "{i}One second.{w} Two seconds...{/i}"
    "{i}Un segundo.{w} Dos segundos...{/i}"

# game/common.rpy:436
translate Spanish commonroute_2046c78f:

    # lumishock "Do you mean heroes?!" with vpunch
    lumishock "¿¡Te refieres a héroes?!" with vpunch

# game/common.rpy:438
translate Spanish commonroute_1f5d02a2:

    # "She blurted out."
    "Soltó de repente."

# game/common.rpy:440
translate Spanish commonroute_4fd0bb7b:

    # lumiehe "Has my hero finally come to take me away?"
    lumiehe "¿Mi héroe finalmente ha venido a llevarme?"

# game/common.rpy:442
translate Spanish commonroute_650ad13c:

    # "The demon winced from her sudden outburst."
    "El demonio se estremeció ante su repentino estallido."

# game/common.rpy:448
translate Spanish commonroute_40b7b8e0:

    # voice "voice2/line11.mp3"
    # butler "I suppose you could put it that way...?"
    voice "voice2/line11.mp3"
    butler "¿Supongo que podrías decirlo así...?"

# game/common.rpy:457
translate Spanish commonroute_089b253e:

    # "He replied while shutting her closet and moving on somewhere else."
    "Respondió mientras cerraba su armario y seguía hacia otro lado."

# game/common.rpy:459
translate Spanish commonroute_fd8d7e3e:

    # lumiehe "Where is my hero then? What were they like?"
    lumiehe "¿Dónde está mi héroe entonces? ¿Cómo era?"

# game/common.rpy:461
translate Spanish commonroute_6aebc2fa:

    # lumiehe "Have they reached the throne room? Slain the demon lord? When can I leave this godforsaken place?"
    lumiehe "¿Han llegado a la sala del trono? ¿Derrotaron al señor demonio? ¿Cuándo podré salir de este maldito lugar?"

# game/common.rpy:463
translate Spanish commonroute_2b99bd94:

    # "She threw a barrage of questions at the redhead."
    "Le lanzó una sarta de preguntas al pelirrojo."

# game/common.rpy:465
translate Spanish commonroute_893966bd:

    # "He, on the other hand, simply continued snooping around her room."
    "Él, por su parte, simplemente siguió husmeando por la habitación."

# game/common.rpy:469
translate Spanish commonroute_be4aeb7c:

    # voice "voice2/line12.mp3"
    # butler "Mhm~ sorry to disappoint you milady, but those cowards hightailed it out of here the moment they came face to face against the lord's elite demonic beast."
    voice "voice2/line12.mp3"
    butler "Mhm~ lamento decepcionarla, milady, pero esos cobardes salieron corriendo en cuanto se enfrentaron a la bestia demoníaca de élite del señor."

# game/common.rpy:476
translate Spanish commonroute_f8281788:

    # voice "voice2/line13.mp3"
    # butler "Although, one of them seemed to have stayed behind, as is the cause for my current predicament."
    voice "voice2/line13.mp3"
    butler "Aunque, parece que uno de ellos se quedó atrás, y es la causa de mi actual situación."

# game/common.rpy:481
translate Spanish commonroute_638aba8b:

    # voice "voice2/line14.mp3"
    # butler "It looks to me that my service to your highness shan't be terminated just yet."
    voice "voice2/line14.mp3"
    butler "Parece que mi servicio a su alteza no terminará todavía."

# game/common.rpy:487
translate Spanish commonroute_7f82d90c:

    # "Her shoulders sagged in disappointment."
    "Sus hombros se hundieron en decepción."

# game/common.rpy:489
translate Spanish commonroute_a5edbf53:

    # lumisad "Ah... so they failed..."
    lumisad "Ah... así que fallaron..."

# game/common.rpy:491
translate Spanish commonroute_461a8b5b:

    # lumisad "I'm still trapped here then."
    lumisad "Entonces sigo atrapada aquí."

# game/common.rpy:498
translate Spanish commonroute_a11f86cc:

    # lumisad "(... With no hero in sight.)"
    lumisad "(... Sin héroe a la vista.)"

# game/common.rpy:502
translate Spanish commonroute_44f6ef6c:

    # "She then turned her eyes to the demon and watched him as he rummaged through her bed."
    "Entonces dirigió sus ojos hacia el demonio y lo observó mientras revolvía su cama."

# game/common.rpy:516
translate Spanish entercephin_3a845c2a:

    # "The demon finally walked over to the door and held on to the knob, seemingly ready to leave."
    "El demonio finalmente caminó hacia la puerta y tomó el pomo, aparentemente listo para irse."

# game/common.rpy:520
translate Spanish entercephin_2207d244:

    # butler "Well then, I shall be off."
    butler "Bueno entonces, me retiro."

# game/common.rpy:524
translate Spanish entercephin_6fe95208:

    # butler "Do be careful, princess. We have an intruder within our walls, so if anything happens, just ring my bell and I shall come rushing."
    butler "Ten cuidado, princesa. Tenemos un intruso dentro de los muros, así que si ocurre algo, solo toca mi campana y acudiré enseguida."

# game/common.rpy:528
translate Spanish entercephin_cc8f12ca:

    # lumisad "Yes, yes. I have no need for your concern."
    lumisad "Sí, sí. No necesito tu preocupación."

# game/common.rpy:530
translate Spanish entercephin_7d280b55:

    # lumi "You know that I am fully capable of protecting myself at least."
    lumi "Sabes que soy perfectamente capaz de protegerme, al menos."

# game/common.rpy:532
translate Spanish entercephin_7e83b77b:

    # "She waved her hand as a gesture to shoo him away."
    "Ella agitó la mano como gesto para despedirlo."

# game/common.rpy:534
translate Spanish entercephin_5c4dc826:

    # lumided "(Besides, shouldn't I feel safer with the hero and their companions rather than a demon?)"
    lumided "(Aparte, ¿no debería sentirme más segura con el héroe y sus compañeros que con un demonio?)"

# game/common.rpy:536
translate Spanish entercephin_3c8a5774:

    # lumisad "(I do enjoy his presence, but he still serves the demon lord...)"
    lumisad "(Me agrada su presencia, pero sigue sirviendo al señor demonio...)"

# game/common.rpy:550
translate Spanish entercephin_cf1aa500:

    # "The butler bowed before closing the door."
    "El mayordomo hizo una reverencia antes de cerrar la puerta."

# game/common.rpy:552
translate Spanish entercephin_b9a79e82:

    # lumisad "How disappointing..."
    lumisad "Qué decepcionante..."

# game/common.rpy:556
translate Spanish entercephin_29dc6124:

    # "She plopped elegantly on the bed, with a soft bounce."
    "Se dejó caer elegantemente sobre la cama, con un suave rebote."

# game/common.rpy:558
translate Spanish entercephin_75a91d61:

    # lumihappy "(But I suppose the fact that a party has finally reached this place means that more may come in the future?)"
    lumihappy "(¿Pero supongo que el hecho de que un grupo finalmente haya llegado a este lugar signifique que podrían venir más en el futuro?)"

# game/common.rpy:560
translate Spanish entercephin_2ea9f9f0:

    # lumiehe "(Yes! That must be it! Tis' only the beginning.)"
    lumiehe "(¡Sí! Eso debe ser. Es solo el comienzo.)"

# game/common.rpy:562
translate Spanish entercephin_13383a7a:

    # "She nodded to herself positively."
    "Asintió para sí misma con ánimo."

# game/common.rpy:566
translate Spanish entercephin_71712dea:

    # who "Is it okay to come out now?"
    who "¿Ya puedo salir?"

# game/common.rpy:568
translate Spanish entercephin_6d8735e3:

    # lumishock "...!" with vpunch
    lumishock "...!" with vpunch

# game/common.rpy:570
translate Spanish entercephin_94c4c1d9:

    # "The voice came from behind- the princess almost jumped off her bed for a start."
    "La voz vino desde atrás; la princesa casi salta de la cama del susto."

# game/common.rpy:576
translate Spanish entercephin_ade213ec:

    # "As she turned around, an unfamiliar figure greeted her sight."
    "Al darse la vuelta, una figura desconocida apareció ante su vista."

# game/common.rpy:578
translate Spanish entercephin_f010f911:

    # "He was peeking from behind the drapes of her balcony."
    "Estaba asomándose desde detrás de las cortinas de su balcón."

# game/common.rpy:580
translate Spanish entercephin_fdac558b:

    # "It was where she had just been a little while earlier."
    "Era justo donde ella había estado hacía un rato."

# game/common.rpy:582
translate Spanish entercephin_16aea91f:

    # "She blinked, unconsciously placing a hand over her mouth."
    "Parpadeó, colocando inconscientemente una mano sobre su boca."

# game/common.rpy:586
translate Spanish entercephin_61b7562d:

    # lumishock "Goodness, a night elf?"
    lumishock "Dios mío, ¿un elfo nocturno?"

# game/common.rpy:588
translate Spanish entercephin_60fc447a:

    # "-Were the only words that could escape her."
    "-Fueron las únicas palabras que logró decir."

# game/common.rpy:593
translate Spanish entercephin_9fada6eb:

    # who "Oh. Uhm... yes."
    who "Oh. Uhm... sí."

# game/common.rpy:595
translate Spanish entercephin_2233466c:

    # "He rubbed the back of his head bashfully."
    "Se rascó la nuca con timidez."

# game/common.rpy:597
translate Spanish entercephin_26ee1667:

    # lumishock "(How long has he been hiding there?)"
    lumishock "(¿Cuánto tiempo ha estado escondido ahí?)"

# game/common.rpy:599
translate Spanish entercephin_0281ba12:

    # "She hadn't heard any noise, nor felt any other presence since the demon butler's arrival..."
    "No había oído ningún ruido, ni sentido ninguna otra presencia desde la llegada del mayordomo demonio..."

# game/common.rpy:601
translate Spanish entercephin_e6d2aed8:

    # "Besides that, the butler should have felt this man's presence!"
    "Además, ¡el mayordomo debería haber sentido la presencia de este hombre!"

# game/common.rpy:603
translate Spanish entercephin_9a9758f2:

    # "He was a demon who possessed superior senses after all."
    "Después de todo, era un demonio con sentidos superiores."

# game/common.rpy:608
translate Spanish entercephin_fe89643c:

    # voice "voice1/line17.mp3"
    # who "Thank you for keeping the demon distracted, and for covering for me."
    voice "voice1/line17.mp3"
    who "Gracias por mantener distraído al demonio y por encubrirme."

# game/common.rpy:614
translate Spanish entercephin_9ddbe18c:

    # lumided "(Huh? Huh? I wasn't, though...?)" with vpunch
    lumided "(¿Eh? ¿Eh? Pero yo no lo estaba, ¿no...?)" with vpunch

# game/common.rpy:616
translate Spanish entercephin_75928c07:

    # lumishock "(Although, that would mean that he had been here during the search?)"
    lumishock "(Aunque, ¿eso significaría que ha estado aquí durante la búsqueda...?)"

# game/common.rpy:618
translate Spanish entercephin_c1541fdc:

    # lumisickshock "(HAS HE HEARD MY INCESSANT SELF RAMBLING!?)" with vpunch
    lumisickshock "(¿¡ME HABRÁ ESCUCHADO PARLOTEAR SIN PARAR!?)" with vpunch

# game/common.rpy:620
translate Spanish entercephin_7a8ac75a:

    # "She felt cold sweat run down her back."
    "Sintió un sudor frío recorrerle la espalda."

# game/common.rpy:622
translate Spanish entercephin_b53073b4:

    # "Her practice sessions were for her ears alone."
    "Sus sesiones de práctica eran solo para sus propios oídos."

# game/common.rpy:624
translate Spanish entercephin_c04d49b2:

    # lumiawk "W-why yes. Of course."
    lumiawk "S-sí, claro. Por supuesto."

# game/common.rpy:629
translate Spanish entercephin_378c322d:

    # lumided "You are here for my rescue, are you not?"
    lumided "Has venido a rescatarme, ¿no es así?"

# game/common.rpy:631
translate Spanish entercephin_33759614:

    # "She spoke almost robotically, deciding to follow through with his misunderstanding."
    "Habló casi de forma robótica, decidiendo seguir con su malentendido."

# game/common.rpy:633
translate Spanish entercephin_cabf8b6d:

    # "There's still hope that he hadn't heard her talking to herself..."
    "Aún había esperanza de que no la hubiera escuchado hablar sola..."

# game/common.rpy:638
translate Spanish entercephin_2670c017:

    # voice "voice1/line18.mp3"
    # who "Then I must offer you a song of gratitude."
    voice "voice1/line18.mp3"
    who "Entonces debo ofrecerte una canción de gratitud."

# game/common.rpy:644
translate Spanish entercephin_0536e7c8:

    # "Just then, the elf materialized an instrument cradled in his arms..."
    "Justo en ese momento, el elfo materializó un instrumento entre sus brazos..."

# game/common.rpy:649
translate Spanish entercephin_28576a65:

    # voice "voice1/line19.mp3"
    # who "{i}~Oh lady of the tower~{/i}"
    voice "voice1/line19.mp3"
    who "{i}~Oh dama de la torre~{/i}"

# game/common.rpy:653
translate Spanish entercephin_087a1086:

    # voice "voice1/line20.mp3"
    # who "{i}~To you I sing this song, I offer~{/i}"
    voice "voice1/line20.mp3"
    who "{i}~A ti te canto esta canción, te la ofrezco~{/i}"

# game/common.rpy:657
translate Spanish entercephin_4525c5f7:

    # voice "voice1/line21.mp3"
    # who "{i}~Oh princess who seeks her dashing hero~{/i}"
    voice "voice1/line21.mp3"
    who "{i}~Oh princesa que busca a su heroico galán~{/i}"

# game/common.rpy:661
translate Spanish entercephin_5a32a9dd:

    # "At this point, the girl had, without a thought, covered her ears from his ear grating song."
    "En ese momento, la chica, sin pensarlo, se tapó los oídos ante su canción chirriante."

# game/common.rpy:663
translate Spanish entercephin_93fcfbe5:

    # "But more than that, the lyrics made it clear...{w} he had heard her {i}'hero welcoming practice'{/i}."
    "Pero más allá de eso, las letras lo dejaban claro...{w} había escuchado su {i}'práctica de bienvenida al héroe'{/i}."

# game/common.rpy:665
translate Spanish entercephin_72c206ff:

    # lumiuwu "Sir, please, n-no need!"
    lumiuwu "Sir, por favor, ¡n-no es necesario!"

# game/common.rpy:667
translate Spanish entercephin_24e50477:

    # "It was akin to listening to her embarrassing dark past."
    "Era como escuchar su vergonzoso pasado oscuro."

# game/common.rpy:669
translate Spanish entercephin_8a71de82:

    # "And even worse? In song form."
    "¿Y lo peor? En forma de canción."

# game/common.rpy:671
translate Spanish entercephin_97b054a7:

    # voice "voice1/line22.mp3"
    # who "{i}~With arms imbued with strength to wield-~{/i}"
    voice "voice1/line22.mp3"
    who "{i}~Con brazos imbuidos de fuerza para blandir-~{/i}"

# game/common.rpy:679
translate Spanish entercephin_f2da12e6:

    # voice "voice1/line23.mp3"
    # who "Oh?"
    voice "voice1/line23.mp3"
    who "¿Oh?"

# game/common.rpy:683
translate Spanish entercephin_2abd55b9:

    # voice "voice1/line24.mp3"
    # who "Not to your liking?"
    voice "voice1/line24.mp3"
    who "¿No es de tu agrado?"

# game/common.rpy:689
translate Spanish entercephin_5869bcec:

    # voice "voice1/line25.mp3"
    # who "Ah right, you're a princess... {size=-5}I should have thought this through...{/size}"
    voice "voice1/line25.mp3"
    who "Ah, cierto, eres una princesa... {size=-5}Debí pensarlo mejor...{/size}"

# game/common.rpy:693
translate Spanish entercephin_7dfe5675:

    # "He mulled to himself with a soft mutter."
    "Reflexionó para sí con un suave murmullo."

# game/common.rpy:695
translate Spanish entercephin_72e672f2:

    # "That aside... that song..."
    "Aparte de eso... esa canción..."

# game/common.rpy:697
translate Spanish entercephin_735db38f:

    # lumiuwu "(He definitely heard my ramblings earlier...)" with vpunch
    lumiuwu "(Definitivamente escuchó mis divagaciones antes...)" with vpunch

# game/common.rpy:699
translate Spanish entercephin_6a882b31:

    # "She forced a smile."
    "Forzó una sonrisa."

# game/common.rpy:701
translate Spanish entercephin_6e9414cb:

    # "... But her eyes were twitching.{w} Not that her companion seemed to have noticed."
    "... Pero le temblaba un ojo.{w} Aunque su acompañante no parecía haberlo notado."

# game/common.rpy:703
translate Spanish entercephin_f4f0700f:

    # "He was too busy wallowing about his earlier actions."
    "Estaba demasiado ocupado lamentándose por sus acciones anteriores."

# game/common.rpy:708
translate Spanish entercephin_23be287a:

    # lumiuwu "More importantly-!" with vpunch
    lumiuwu "¡Pero hay algo más importante-!" with vpunch

# game/common.rpy:710
translate Spanish entercephin_522058df:

    # "She clapped her hands together, determined to change the topic and make him forget about that."
    "Ella juntó las manos, decidida a cambiar de tema y hacer que lo olvidara."

# game/common.rpy:712
translate Spanish entercephin_787ed613:

    # lumiplead "Sir, are you the fabled hero who has come to save me?"
    lumiplead "Sir, ¿es usted el héroe legendario que ha venido a salvarme?"

# game/common.rpy:714
translate Spanish entercephin_aa025ccf:

    # "The princess asked with starry eyes. This should make him drop the topic... right?"
    "Preguntó la princesa con ojos brillantes. Eso debería hacerle dejar el tema... ¿verdad?"

# game/common.rpy:716
translate Spanish entercephin_10489fdc:

    # "Besides, she did want to get on point with him- {i}would he be the hero she's been waiting for{/i}?"
    "Además, quería ir al grano con él—{i}¿sería él el héroe que ha estado esperando{/i}?"

# game/common.rpy:720
translate Spanish entercephin_da696989:

    # voice "voice1/line26.mp3"
    # who "F-fabled hero...?"
    voice "voice1/line26.mp3"
    who "¿H-héroe legendario...?"

# game/common.rpy:724
translate Spanish entercephin_9de86381:

    # "He seemed flustered."
    "Parecía nervioso."

# game/common.rpy:726
translate Spanish entercephin_b90e987f:

    # voice "voice1/line27.mp3"
    # who "Uh... erm... I wouldn't say so."
    voice "voice1/line27.mp3"
    who "Uh... erm... no diría eso."

# game/common.rpy:730
translate Spanish entercephin_acbcd7de:

    # "It was evident how his voice lacked confidence."
    "Era evidente que su voz carecía de confianza."

# game/common.rpy:732
translate Spanish entercephin_02a43d52:

    # voice "voice1/line28.mp3"
    # who "I am part of the hero's party, yes... but I'm..."
    voice "voice1/line28.mp3"
    who "Soy parte del grupo del héroe, sí... pero yo..."

# game/common.rpy:736
translate Spanish entercephin_56ce1c5c:

    # lumitalk "Oh, yes. The butler had mentioned... they escaped, did they not?"
    lumitalk "Ah, sí. El mayordomo había mencionado... ¿escaparon, no es así?"

# game/common.rpy:738
translate Spanish entercephin_67861742:

    # "The man pursed his lips."
    "El hombre apretó los labios."

# game/common.rpy:740
translate Spanish entercephin_4206cb94:

    # "It was akin to an acknowledgement. They abandoned him."
    "Era como una especie de reconocimiento. Lo habían abandonado."

# game/common.rpy:747
translate Spanish entercephin_71412dc6:

    # lumiserious "How could they do such a thing?!"
    lumiserious "¡¿Cómo pudieron hacer tal cosa?!"

# game/common.rpy:749
translate Spanish entercephin_a45c3ad2:

    # lumitalk "They've left you here- their companion!"
    lumitalk "¡Te han dejado aquí... a su compañero!"

# game/common.rpy:751
translate Spanish entercephin_8e1c3822:

    # lumiserious "I say, if that is the attitude of the supposed {i}'hero'{/i}, then they've no right to hold the title."
    lumiserious "Digo, si esa es la actitud del supuesto {i}'héroe'{/i}, entonces no tienen derecho a ostentar el título."

# game/common.rpy:753
translate Spanish entercephin_3c03fc4e:

    # "She honestly did get angry with his confirmation."
    "Sinceramente, sí se enojó con su confirmación."

# game/common.rpy:755
translate Spanish entercephin_278a4265:

    # "Sure, they've only just met, but she had always looked up to the 'hero'."
    "Claro, apenas se habían conocido, pero ella siempre había admirado al “héroe”."

# game/common.rpy:757
translate Spanish entercephin_5bcef272:

    # "It was simply disappointing to think that such kind of person could have taken the title."
    "Simplemente era decepcionante pensar que ese tipo de persona pudiera haber llevado el título."

# game/common.rpy:763
translate Spanish entercephin_953d2d5a:

    # "The princess furrowed her brows at the thought of those cowards."
    "La princesa frunció el ceño al pensar en esos cobardes."

# game/common.rpy:765
translate Spanish entercephin_eeb99ef1:

    # lumisad "How could they..."
    lumisad "Cómo pudieron..."

# game/common.rpy:767
translate Spanish entercephin_70308d71:

    # "What kind of hero abandons their companions? It would have dishonored the hero's title."
    "¿Qué clase de héroe abandona a sus compañeros? Eso deshonraría el título de héroe."

# game/common.rpy:769
translate Spanish entercephin_bab35387:

    # "This wasn't the kind of hero she wanted..."
    "Ese no era el tipo de héroe que ella quería..."

# game/common.rpy:771
translate Spanish entercephin_3373aab7:

    # "Noticing the princess' distraught expression, her guest finally spoke up."
    "Al notar la expresión angustiada de la princesa, su invitado finalmente habló."

# game/common.rpy:775
translate Spanish entercephin_07dcf18a:

    # voice "voice1/line29.mp3"
    # who "I-I think we have a misunderstanding...!"
    voice "voice1/line29.mp3"
    who "¡C-creo que tenemos un malentendido...!"

# game/common.rpy:781
translate Spanish entercephin_2c372081:

    # voice "voice1/line30.mp3"
    # who "I wouldn't say that they ran away... I offered to serve as a distraction, so they could escape!"
    voice "voice1/line30.mp3"
    who "No diría que huyeron... me ofrecí a servir de distracción para que pudieran escapar."

# game/common.rpy:785
translate Spanish entercephin_713e04d0:

    # voice "voice1/line31.mp3"
    # who "After all, if we all lose here, then there wouldn't be anyone to save you, princess."
    voice "voice1/line31.mp3"
    who "Después de todo, si todos perdíamos aquí, entonces no habría nadie que la salvara, princesa."

# game/common.rpy:789
translate Spanish entercephin_ee8677e9:

    # "She eyed him.{w} Even if that were the case, the fact that they left him still stood."
    "Ella lo observó.{w} Incluso si ese fuera el caso, el hecho de que lo dejaran seguía siendo un hecho."

# game/common.rpy:791
translate Spanish entercephin_4647183d:

    # lumiawk "Even so-!"
    lumiawk "¡Aun así...!"

# game/common.rpy:793
translate Spanish entercephin_053b9adc:

    # "The girl paused for a moment to calm herself and think this through."
    "La chica hizo una pausa un momento para calmarse y pensarlo bien."

# game/common.rpy:795
translate Spanish entercephin_ae50615b:

    # "{i}Deep breaths.{/i}"
    "{i}Respira profundo.{/i}"

# game/common.rpy:797
translate Spanish entercephin_90ba8ec5:

    # "Yes, that's what this must be- a misunderstanding."
    "Sí, eso debía ser, un malentendido."

# game/common.rpy:799
translate Spanish entercephin_2a10c4f9:

    # "It seemed that she had allowed her emotions to get to her."
    "Parecía que había permitido que sus emociones se apoderaran de ella."

# game/common.rpy:801
translate Spanish entercephin_c9fde4dc:

    # lumithink "{i}*Sigh*{/i} Very well, I suppose that it was rather valiant of you. Foolish, but valiant."
    lumithink "{i}*Suspiro*{/i} Muy bien, supongo que fue bastante valeroso de tu parte. Tonto, pero valeroso."

# game/common.rpy:803
translate Spanish entercephin_e6bfb679:

    # lumisad "I imagine the thought of sacrificing a precious companion must have been a difficult decision for them to bear."
    lumisad "Imagino que la idea de sacrificar a un compañero preciado debió ser una decisión difícil de soportar para ellos."

# game/common.rpy:805
translate Spanish entercephin_40b8a248:

    # voice "voice1/line32.mp3"
    # who "..."
    voice "voice1/line32.mp3"
    who "..."

# game/common.rpy:809
translate Spanish entercephin_752cacce:

    # lumithink "Yes, of course. That must be the case."
    lumithink "Sí, por supuesto. Debe ser eso."

# game/common.rpy:811
translate Spanish entercephin_b1dfaea9:

    # lumiwish "The hero...{w} {b}MY{/b} hero could never have left their precious friend like this."
    lumiwish "El héroe...{w} {b}MI{/b} héroe nunca podría haber dejado a su querido amigo así."

# game/common.rpy:813
translate Spanish entercephin_ba368cdc:

    # lumiehe "Father said he'd choose the heroes himself. Of course he'd only send the best."
    lumiehe "Padre dijo que él mismo elegiría a los héroes. Por supuesto, solo enviaría a los mejores."

# game/common.rpy:815
translate Spanish entercephin_3ae020b0:

    # lumihappy "Not some lousy coward!"
    lumihappy "¡No a un cobarde miserable!"

# game/common.rpy:817
translate Spanish entercephin_57ffa0c8:

    # "She nodded knowingly to herself."
    "Asintió con certeza para sí misma."

# game/common.rpy:819
translate Spanish entercephin_3b9f3ca1:

    # "While she may have been calling them 'hero', in truth, their official title would be 'hero candidate'."
    "Aunque los llamara “héroes”, en verdad, su título oficial sería “candidatos a héroe”."

# game/common.rpy:821
translate Spanish entercephin_405a1836:

    # "The process of candidate selection, as far as she knew, was tedious."
    "El proceso de selección de candidatos, hasta donde ella sabía, era tedioso."

# game/common.rpy:823
translate Spanish entercephin_e917e06f:

    # "Only the cream of the crop should be chosen, and only those of royal blood can bestow the title."
    "Solo se debe elegir a los mejores de los mejores, y solo quienes sean de sangre real pueden otorgar el título."

# game/common.rpy:825
translate Spanish entercephin_5e7dea09:

    # "Multiple hero candidates can be instated at once, but for reasons she wasn't certain of, there was also a limit to how many heroes there can be at a time."
    "Varios candidatos a héroe podían ser designados a la vez, pero, por razones que ella desconocía, también había un límite en el número de héroes que podía haber al mismo tiempo."

# game/common.rpy:828
translate Spanish entercephin_e9c4f53a:

    # "... Which also meant that the king couldn't just simply send an army marching to her rescue."
    "... Lo que también significaba que el rey no podía simplemente enviar un ejército a rescatarla."

# game/common.rpy:830
translate Spanish entercephin_8d91b68a:

    # "Silence hung over them for a while before someone started speaking again."
    "El silencio los envolvió un rato antes de que alguien hablara de nuevo."

# game/common.rpy:835
translate Spanish entercephin_708899f9:

    # lumi "In any case-"
    lumi "En cualquier caso—"

# game/common.rpy:837
translate Spanish entercephin_12fbb16c:

    # "The princess perked up, clapping her hands together."
    "La princesa se animó, juntando las manos."

# game/common.rpy:839
translate Spanish entercephin_da4fd1dc:

    # lumihappy "I believe you have not introduced yourself, dear guest?"
    lumihappy "Creo que aún no te has presentado, querido invitado."

# game/common.rpy:842
translate Spanish entercephin_02b75fef:

    # voice "voice1/line33.mp3"
    # who "Huh? Oh...!"
    voice "voice1/line33.mp3"
    who "¿Eh? Oh...!"

# game/common.rpy:850
translate Spanish entercephin_0b90e973:

    # "The elven guest dematerialized his instrument."
    "El invitado elfo desmaterializó su instrumento."

# game/common.rpy:854
translate Spanish entercephin_7a8de296:

    # "He then stood up straight and placed a hand over his chest."
    "Luego se irguió y colocó una mano sobre su pecho."

# game/common.rpy:857
translate Spanish entercephin_7f17c830:

    # voice "voice1/line34.mp3"
    voice "voice1/line34.mp3"

# game/common.rpy:861
translate Spanish entercephin_70a1043a:

    # cethin "My name is Cethin. Bard."
    cethin "Me llamo Cethin. Soy bardo."

# game/common.rpy:868
translate Spanish entercephin_aed4c5fa:

    # "He then kneeled in respect."
    "Después se arrodilló en señal de respeto."

# game/common.rpy:870
translate Spanish entercephin_9f2be2cb:

    # "A prisoner she may be, but she was still of royal blood."
    "Podría ser una prisionera, pero seguía siendo de sangre real."

# game/common.rpy:872
translate Spanish entercephin_57ea851d:

    # lumiserious "I am Princess Lumi Alba Demetria, first princess of the Kingdom of Demetria."
    lumiserious "Soy la princesa Lumi Alba Demetria, primera princesa del Reino de Demetria."

# game/common.rpy:874
translate Spanish entercephin_007a416d:

    # "She expected him to already know her name, so her introduction was mere formality."
    "Esperaba que él ya supiera su nombre, así que su presentación fue mera formalidad."

# game/common.rpy:878
translate Spanish entercephin_9d1fc1f0:

    # "The princess offered her hand to the man just like she practiced."
    "La princesa ofreció su mano al hombre tal como lo había practicado."

# game/common.rpy:883
translate Spanish entercephin_54a8a739:

    # "The act seemed to have flustered the dark elf-"
    "El acto pareció poner nervioso al elfo oscuro—"

# game/common.rpy:885
translate Spanish entercephin_44e2c93c:

    # "Of course, he must know that rejecting her would be an act of discourtesy..."
    "Por supuesto, debía saber que rechazarla sería un acto de descortesía..."

# game/common.rpy:887
translate Spanish entercephin_ba26c255:

    # "To take her hand meant acknowledgement of her position, and his willingness to serve."
    "Tomar su mano significaba reconocimiento de su posición, y su disposición a servir."

# game/common.rpy:889
translate Spanish entercephin_c4efda0f:

    # "On the flip side, the mere act of offering her hand was a sign of acknowledgement of the other party, depending on their expertise."
    "Por otro lado, el simple acto de ofrecerle la mano era una señal de reconocimiento hacia la otra parte, dependiendo de sus conocimientos."

# game/common.rpy:891
translate Spanish entercephin_547febae:

    # "Aptly put- she was saying that she recognizes the bard as an adventurer of the highest caliber."
    "Bien dicho; estaba diciendo que reconocía al bardo como un aventurero del más alto nivel."

# game/common.rpy:893
translate Spanish entercephin_c56997ce:

    # "It was no easy feat to reach her tower after all."
    "Después de todo, no era fácil llegar hasta su torre."

# game/common.rpy:895
translate Spanish entercephin_b742776e:

    # "This was a custom of their kingdom; many would die for such honor."
    "Era una costumbre de su reino; muchos morirían por tal honor."

# game/common.rpy:898
translate Spanish entercephin_eb3dc885:

    # voice "voice1/line35.mp3"
    # cethin "Princess, are you certain? As you can see, I am a dark elf!"
    voice "voice1/line35.mp3"
    cethin "Princesa, ¿está segura? Como puede ver, soy un elfo oscuro."

# game/common.rpy:902
translate Spanish entercephin_92221914:

    # lumihappy "And? Is there a problem with that?"
    lumihappy "¿Y? ¿Hay algún problema con eso?"

# game/common.rpy:904
translate Spanish entercephin_b9f43df8:

    # voice "voice1/line36.mp3"
    # cethin "Well-"
    voice "voice1/line36.mp3"
    cethin "Bueno—"

# game/common.rpy:911
translate Spanish entercephin_6241ec45:

    # "His gaze fell back on the princess' hand."
    "Su mirada cayó nuevamente sobre la mano de la princesa."

# game/common.rpy:913
translate Spanish entercephin_ad6eb18a:

    # "After hesitating for a bit, he finally accepted and brought her hand to his lips."
    "Tras dudar un poco, finalmente la aceptó y llevó su mano a los labios."

# game/common.rpy:916
translate Spanish entercephin_57cffefe:

    # voice "voice1/line37.mp3"
    # cethin "I offer my service to the princess."
    voice "voice1/line37.mp3"
    cethin "Ofrezco mi servicio a la princesa."

# game/common.rpy:957
translate Spanish entercephin_efd0a14d:

    # lumiserious "You may rise."
    lumiserious "Puedes levantarte."

# game/common.rpy:959
translate Spanish entercephin_cfdc265e:

    # "With that, the dark elf stood up, albeit avoiding her gaze."
    "Con eso, el elfo oscuro se puso de pie, aunque evitando su mirada."

# game/common.rpy:981
translate Spanish entercephin_2e6b1b6b:

    # lumithink "(Come to think of it, he seems rather shy.)"
    lumithink "(Ahora que lo pienso, parece bastante tímido.)"

# game/common.rpy:983
translate Spanish entercephin_9c3dedfd:

    # lumisad "(That, or he's simply nervous to be in the presence of a princess... which is completely understandable.)"
    lumisad "(O eso, o simplemente está nervioso por estar en presencia de una princesa... lo cual es completamente comprensible.)"

# game/common.rpy:985
translate Spanish entercephin_f4b9c807:

    # "She nodded proudly to herself."
    "Asintió orgullosa para sí misma."

# game/common.rpy:987
translate Spanish entercephin_26a8edb6:

    # lumi "Well then, I suppose we'll wait for your party to return?"
    lumi "Bueno entonces, supongo que esperaremos a que tu grupo regrese."

# game/common.rpy:989
translate Spanish entercephin_0803da64:

    # lumihappy "That said, since you are a bard, why don't you entertain me with a performance?"
    lumihappy "Dicho eso, ya que eres un bardo, ¿por qué no me entretienes con una presentación?"

# game/common.rpy:994
translate Spanish entercephin_1e7df443:

    # "At those words, her companion perked up."
    "Ante esas palabras, su acompañante se animó."

# game/common.rpy:999
translate Spanish entercephin_834329aa:

    # "He seemed excited to play-"
    "Parecía emocionado por tocar—"

# game/common.rpy:1003
translate Spanish entercephin_b639be57:

    # cethin "It would be an honor to play for your highness!"
    cethin "¡Sería un honor tocar para su alteza!"

# game/common.rpy:1007
translate Spanish entercephin_dbce2fb5:

    # "He opened his mouth-"
    "Abrió la boca—"

# game/common.rpy:1011
translate Spanish entercephin_4f40cfc3:

    # "... And that was the biggest regret of Princess Lumi Alba Demetria since her imprisonment."
    "... Y ese fue el mayor arrepentimiento de la princesa Lumi Alba Demetria desde su encarcelamiento."

# game/common.rpy:1015
translate Spanish entercephin_9aa7d043:

    # "Back to the present..."
    "De vuelta al presente..."

# game/common.rpy:1019
translate Spanish entercephin_d992e51b:

    # lumiawk "(Ah, yes... that's how it started.)"
    lumiawk "(Ah, sí... así fue como comenzó.)"

# game/common.rpy:1021
translate Spanish entercephin_d152ade5:

    # lumiuwu "(What kind of bard cannot sing?!)" with vpunch
    lumiuwu "(¿¡Qué clase de bardo no sabe cantar?!)" with vpunch

# game/common.rpy:1023
translate Spanish entercephin_2be16792:

    # lumiawk "(I should have figured it out when I first heard him sing...)"
    lumiawk "(Debí haberlo sospechado cuando lo escuché cantar por primera vez...)"

# game/common.rpy:1031
translate Spanish entercephin_6e3ba771:

    # "She paused to watch the so-called night elf tinker with his stringed instrument."
    "Se detuvo para observar al supuesto elfo nocturno mientras tocaba su instrumento de cuerdas."

# game/common.rpy:1033
translate Spanish entercephin_de50a427:

    # "The princess smiled."
    "La princesa sonrió."

# game/common.rpy:1039
translate Spanish entercephin_1e52f0f0:

    # lumihappy "He is quite good with his instrument, I'll give him that."
    lumihappy "Es bastante hábil con su instrumento, eso debo admitirlo."

# game/common.rpy:1043
translate Spanish entercephin_feffb6e3:

    # cethin "...? Did you say something, your highness?"
    cethin "¿...? ¿Dijo algo, su alteza?"

# game/common.rpy:1047
translate Spanish entercephin_5eed08ca:

    # "Immediately, she plastered a fake smile."
    "De inmediato, fingió una sonrisa."

# game/common.rpy:1049
translate Spanish entercephin_8746218f:

    # lumihappy "Ohoho~ Do not mind me. Carry on."
    lumihappy "Ohoho~ No me hagas caso. Continúa."

# game/common.rpy:1053
translate Spanish entercephin_c42bee0f:

    # cethin "Alright then...?"
    cethin "¿De acuerdo entonces...?"

# game/common.rpy:1055
translate Spanish entercephin_a96f62a3:

    # "He turned his attention back to his instrument, but continued to chat with the princess."
    "Volvió a centrar su atención en su instrumento, pero siguió charlando con la princesa."

# game/common.rpy:1060
translate Spanish entercephin_f6e4b466:

    # cethin "I know I'm overstaying my welcome, so I need to get going tonight."
    cethin "Sé que estoy abusando de su hospitalidad, así que debo irme esta noche."

# game/common.rpy:1066
translate Spanish entercephin_69532adc:

    # lumishock "Tonight?"
    lumishock "¿Esta noche?"

# game/common.rpy:1068
translate Spanish entercephin_ab853c2d:

    # "She gasped."
    "Ella jadeó."

# game/common.rpy:1070
translate Spanish entercephin_3e735ed6:

    # lumiawk "Are you not aware that nighttime is most dangerous in this region?"
    lumiawk "¿No sabes que la noche es lo más peligroso en esta región?"

# game/common.rpy:1072
translate Spanish entercephin_4cc5a65e:

    # lumiserious "Not to mention- this is the land of the demon lord! Their demonic spawns lurk the night."
    lumiserious "Sin mencionar que este es el territorio del señor demonio. Sus engendros demoníacos rondan la noche."

# game/common.rpy:1076
translate Spanish entercephin_ddb35b81:

    # "The elf once again paused from his instrument maintenance, and just found himself staring at it."
    "El elfo volvió a pausar el mantenimiento de su instrumento, y simplemente se quedó mirándolo."

# game/common.rpy:1080
translate Spanish entercephin_51b0f1c1:

    # cethin "I don't have a choice... I stand out while the sun is up, and as a {i}night elf{/i}, I move better when the sun sets."
    cethin "No tengo opción... Destaco demasiado mientras el sol está arriba, y como {i}elfo nocturno{/i}, me muevo mejor cuando el sol se pone."

# game/common.rpy:1082
translate Spanish entercephin_c0e85940:

    # "Night elves or dark elves, after all, were beings who lived underground, so their eyes were better adjusted in the darkness."
    "Los elfos nocturnos, o elfos oscuros, después de todo, eran seres que vivían bajo tierra, así que sus ojos estaban mejor adaptados a la oscuridad."

# game/common.rpy:1084
translate Spanish entercephin_e2b5e355:

    # "Not to mention- their powers are at peak under the night sky, for their blessings fall under the jurisdiction of the moon."
    "Sin mencionar que sus poderes alcanzaban su punto máximo bajo el cielo nocturno, pues sus bendiciones caían bajo la jurisdicción de la luna."

# game/common.rpy:1086
translate Spanish entercephin_a617f9f8:

    # "... Whatever that meant? Don't ask. This princess does not know either."
    "... Sea lo que eso signifique. Ni me pregunten. Esta princesa tampoco lo sabe."

# game/common.rpy:1091
translate Spanish entercephin_3dad77c0:

    # lumi "Sir Cethin, you {i}do{/i} have an option."
    lumi "Sir Cethin, usted {i}sí{/i} tiene una opción."

# game/common.rpy:1093
translate Spanish entercephin_9285d1e5:

    # "She smiled."
    "Ella sonrió."

# game/common.rpy:1095
translate Spanish entercephin_3075e5cd:

    # lumihappy "You are free to stay here with me until your party returns to pick you up!"
    lumihappy "¡Eres libre de quedarte aquí conmigo hasta que tu grupo regrese a buscarte!"

# game/common.rpy:1097
translate Spanish entercephin_ac39e4e6:

    # lumiplead "In fact, I had assumed we were clear on that arrangement?"
    lumiplead "De hecho, ¿no habíamos acordado ya eso?"

# game/common.rpy:1101
translate Spanish entercephin_0c346c1f:

    # "At that suggestion, Cethin got up as if shocked by her reply."
    "Ante esa sugerencia, Cethin se levantó como si su respuesta lo hubiera sorprendido."

# game/common.rpy:1107
translate Spanish entercephin_eb7b411a:

    # "He flailed his hands in front of the princess in panic-"
    "Agitó las manos frente a la princesa preso del pánico-"

# game/common.rpy:1112
translate Spanish entercephin_e2144414:

    # cethin "Your highness, I can't stay here overnight!"
    cethin "¡Su alteza, no puedo quedarme aquí toda la noche!"

# game/common.rpy:1116
translate Spanish entercephin_b7cbd792:

    # cethin "You're um... you're a lady! A-and a princess!"
    cethin "Tú eres... ¡una dama! ¡Y- y una princesa!"

# game/common.rpy:1120
translate Spanish entercephin_67bb319f:

    # cethin "It's bad enough that you're letting me stay here in the same space with you..."
    cethin "Ya es bastante malo que me permitas quedarme aquí en el mismo espacio que tú..."

# game/common.rpy:1122
translate Spanish entercephin_9a590aeb:

    # "The princess chuckled."
    "La princesa se rió."

# game/common.rpy:1124
translate Spanish entercephin_ca9290ca:

    # lumided "Earlier, were you not worried sick that I'd kick you out? Now you are begging me to do just that?"
    lumided "Antes estabas tan preocupado porque te echara, ¿y ahora me ruegas que lo haga?"

# game/common.rpy:1126
translate Spanish entercephin_7874083c:

    # lumihappy "You're quite a funny one."
    lumihappy "Eres bastante gracioso."

# game/common.rpy:1128
translate Spanish entercephin_c664c1e6:

    # "Yes, she's just teasing him."
    "Sí, solo lo estaba molestando."

# game/common.rpy:1132
translate Spanish entercephin_eb51d4dc:

    # cethin "T-that's not what I-"
    cethin "N-no es eso lo que yo-"

# game/common.rpy:1141
translate Spanish entercephin_5e33cf37:

    # cethin "I'm sorry I've been insolent!"
    cethin "¡Perdón por ser tan insolente!"

# game/common.rpy:1143
translate Spanish entercephin_5ca45019:

    # "This time, he got down on his knees."
    "Esta vez, se arrodilló."

# game/common.rpy:1145
translate Spanish entercephin_c0960b17:

    # lumided "(Ah... perhaps that was too much?)"
    lumided "(Ah... ¿quizá fue demasiado?)"

# game/common.rpy:1150
translate Spanish entercephin_db7641f3:

    # "The princess sighed."
    "La princesa suspiró."

# game/common.rpy:1154
translate Spanish entercephin_28e51ef2:

    # lumisad "If that is truly how you feel, then you may leave tonight."
    lumisad "Si realmente te sientes así, entonces puedes irte esta noche."

# game/common.rpy:1156
translate Spanish entercephin_9b3bbdf9:

    # lumisad "I wish you luck on your journey."
    lumisad "Te deseo suerte en tu viaje."

# game/common.rpy:1158
translate Spanish entercephin_eddfc791:

    # "The dark elf nodded."
    "El elfo oscuro asintió."

# game/common.rpy:1163
translate Spanish entercephin_4232c7b4:

    # cethin "I-I promise that I'll find help for the princess!"
    cethin "¡P-prometo que encontraré ayuda para la princesa!"

# game/common.rpy:1165
translate Spanish entercephin_22a077a4:

    # lumithink "Oh goodness... you're still thinking of me?"
    lumithink "Oh cielos... ¿aún sigues pensando en mí?"

# game/common.rpy:1167
translate Spanish entercephin_2042c7c0:

    # "She let out a small smile."
    "Dejó escapar una pequeña sonrisa."

# game/common.rpy:1169
translate Spanish entercephin_1c760bdd:

    # "It was nice to have someone care for her after being trapped for so long, away from her friends and family."
    "Era agradable que alguien se preocupara por ella después de haber estado atrapada tanto tiempo, lejos de sus amigos y familia."

# game/common.rpy:1173
translate Spanish entercephin_c534915b:

    # lumihappy "I'd better see you again, you hear?"
    lumihappy "Más te vale que te vuelva a ver, ¿me oyes?"

# game/common.rpy:1175
translate Spanish entercephin_c016e368:

    # "She meant this from the bottom of her heart."
    "Lo decía de todo corazón."

# game/common.rpy:1179
translate Spanish entercephin_351a0982:

    # cethin "I...{w} yes!"
    cethin "Yo...{w} ¡sí!"

# game/common.rpy:1184
translate Spanish entercephin_fb180c09:

    # "That night, Cethin quietly left through the balcony..."
    "Esa noche, Cethin se marchó en silencio por el balcón..."

# game/common.rpy:1188
translate Spanish entercephin_b195831d:

    # "I waited... and waited... and waited..."
    "Esperé... y esperé... y esperé..."

# game/common.rpy:1190
translate Spanish entercephin_6fe88bdd:

    # "Snow continued to fall. The scenery was unchanging."
    "La nieve seguía cayendo. El paisaje no cambiaba."

# game/common.rpy:1192
translate Spanish entercephin_1b404471:

    # "The promise we made? I suppose...{w} it could never be fulfilled."
    "¿La promesa que hicimos? Supongo...{w} que nunca podría cumplirse."

# game/common.rpy:1194
translate Spanish entercephin_3905f1a5:

    # "Trapped in a tower. An everlasting winter. Alone forever."
    "Atrapada en una torre. Un invierno eterno. Sola para siempre."

# game/common.rpy:1201
translate Spanish entercephin_edd2e1a3:

    # "BAD END."
    "FINAL MALO."

# game/common.rpy:1210
translate Spanish entercephin_a39f0b5f:

    # lumitalk "Sir Cethin, please rise."
    lumitalk "Sir Cethin, por favor, levántese."

# game/common.rpy:1214
translate Spanish entercephin_9ce32fe6:

    # lumithink "Come now, this is your life on the line."
    lumithink "Vamos, es tu vida la que está en juego."

# game/common.rpy:1216
translate Spanish entercephin_36c1ca38:

    # lumi "The least I can do is provide you with shelter-"
    lumi "Lo mínimo que puedo hacer es ofrecerte refugio-"

# game/common.rpy:1218
translate Spanish entercephin_216f19e6:

    # "-Shelter that she totally doesn't own."
    "-Un refugio que ni siquiera le pertenece."

# game/common.rpy:1222
translate Spanish entercephin_a8d5ffce:

    # lumihappy "And you've no need to act polite or modest around me!"
    lumihappy "¡Y no necesitas actuar con tanta educación o modestia conmigo!"

# game/common.rpy:1224
translate Spanish entercephin_69b717ea:

    # lumisad "It's already quite lonely staying here on my own... couldn't you at least keep me company?"
    lumisad "Ya es bastante solitario quedarme aquí sola... ¿no podrías al menos hacerme compañía?"

# game/common.rpy:1228
translate Spanish entercephin_02a189b0:

    # lumihappy "This is a favor from me. Please?"
    lumihappy "Es un favor de mi parte. ¿Por favor?"

# game/common.rpy:1230
translate Spanish entercephin_eb6bbae0:

    # "Cethin didn't get up, but he did seem to have lost some tension on his shoulders."
    "Cethin no se levantó, pero parecía haber perdido algo de tensión en los hombros."

# game/common.rpy:1232
translate Spanish entercephin_0194b352:

    # "The princess patiently waited for her companion to collect his thoughts, not uttering a word herself."
    "La princesa esperó pacientemente a que su compañero reuniera sus pensamientos, sin pronunciar una palabra."

# game/common.rpy:1234
translate Spanish entercephin_5489a08a:

    # "Finally, the bard raised his head, though he didn't get up and stayed on his knee."
    "Finalmente, el bardo levantó la cabeza, aunque no se puso de pie y permaneció de rodillas."

# game/common.rpy:1238
translate Spanish entercephin_b9b77c3b:

    # cethin "If the princess insists, then...{w} I'll stay."
    cethin "Si la princesa insiste, entonces...{w} me quedaré."

# game/common.rpy:1243
translate Spanish entercephin_67c43933:

    # cethin "I'll try my best to not be a burden."
    cethin "Trataré de no ser una carga."

# game/common.rpy:1247
translate Spanish entercephin_d6d40fe4:

    # lumihappy "Good answer."
    lumihappy "Buena respuesta."

# game/common.rpy:1251
translate Spanish entercephin_69d3dd83:

    # lumi "Though, didn't I just ask you to stop with the formalities?"
    lumi "Aunque, ¿no acabo de pedirte que dejaras las formalidades?"

# game/common.rpy:1253
translate Spanish entercephin_1ff01926:

    # "The girl pouted."
    "La chica hizo un puchero."

# game/common.rpy:1255
translate Spanish entercephin_3bfb8ac9:

    # lumihappy "I've given you the permission to call me by name."
    lumihappy "Te he dado permiso para llamarme por mi nombre."

# game/common.rpy:1259
translate Spanish entercephin_46c85f95:

    # cethin "..."
    cethin "..."

# game/common.rpy:1263
translate Spanish entercephin_cc10bd14:

    # cethin "I'm sorry... that's..."
    cethin "Lo siento... eso es..."

# game/common.rpy:1265
translate Spanish entercephin_2699679a:

    # "He just trailed off. It seemed name calling was too much for him."
    "Simplemente se quedó callado. Parecía que llamarla por su nombre era demasiado para él."

# game/common.rpy:1267
translate Spanish entercephin_19a32ddc:

    # lumithink "(Oh well. Baby steps, as they say.)"
    lumithink "(Oh, bueno. Paso a paso, como dicen.)"

# game/common.rpy:1269
translate Spanish entercephin_dd9ff618:

    # lumihappy "(That said, my days should become far more entertaining from now on.)"
    lumihappy "(Dicho eso, mis días deberían volverse mucho más entretenidos a partir de ahora.)"

# game/common.rpy:1271
translate Spanish entercephin_6d6ddb95:

    # "She thought to herself giddily."
    "Pensó para sí misma con entusiasmo."

# game/common.rpy:1273
translate Spanish entercephin_105aa02b:

    # "... And that was how the princess of the tower inadvertently found herself a tower roommate."
    "... Y así fue como la princesa de la torre, sin querer, terminó con un compañero de torre."

# game/common.rpy:1278
translate Spanish entercephin_4a993ab1:

    # "It was a quiet day."
    "Era un día tranquilo."

# game/common.rpy:1280
translate Spanish entercephin_23f7dcbe:

    # "Nothing eventful, as usual...{w} was what she'd normally narrate to herself-"
    "Nada fuera de lo común, como de costumbre...{w} era lo que normalmente se narraría a sí misma-"

# game/common.rpy:1282
translate Spanish entercephin_9930c225:

    # "But these days, she's had a companion to chat with."
    "Pero estos días, tenía un compañero con quien charlar."

# game/common.rpy:1284
translate Spanish entercephin_79e521ac:

    # "It certainly made living in that tower more tolerable..."
    "Sin duda hacía la vida en esa torre más tolerable..."

# game/common.rpy:1286
translate Spanish entercephin_d759a5d0:

    # "Which wasn't really saying much, since it's only been three days since she started hiding the night elf in her room."
    "Lo cual no decía mucho, ya que solo habían pasado tres días desde que empezó a esconder al elfo nocturno en su habitación."

# game/common.rpy:1293
translate Spanish entercephin_1d5d4d7f:

    # "At the moment, the princess was idly sitting on her bed, while her elven roommate was on the floor, tinkering with his tool of trade."
    "En ese momento, la princesa estaba sentada ociosamente en su cama, mientras su compañero élfico estaba en el suelo, trasteando con su herramienta de trabajo."

# game/common.rpy:1295
translate Spanish entercephin_259574a3:

    # lumiplead "You have been adjusting that instrument of yours for days."
    lumiplead "Has estado ajustando ese instrumento tuyo durante días."

# game/common.rpy:1297
translate Spanish entercephin_0d710e24:

    # "She said while watching him."
    "Dijo mientras lo observaba."

# game/common.rpy:1301
translate Spanish entercephin_bcf2af3f:

    # cethin "This was my mother's so it's quite old."
    cethin "Era de mi madre, así que es bastante antiguo."

# game/common.rpy:1305
translate Spanish entercephin_3ddd991b:

    # "A pause."
    "Una pausa."

# game/common.rpy:1309
translate Spanish entercephin_99414dc5:

    # cethin "... Very old."
    cethin "... Muy antiguo."

# game/common.rpy:1311
translate Spanish entercephin_3379ebf8:

    # "Elves, and by extension, dark elves, had long life spans, so the princess could only imagine how old that thing was."
    "Los elfos, y por extensión, los elfos oscuros, tenían una larga esperanza de vida, así que la princesa solo podía imaginar cuán viejo sería ese objeto."

# game/common.rpy:1313
translate Spanish entercephin_33c75ee2:

    # "It was quite impressive how well-maintained it looked despite its implied age."
    "Era impresionante lo bien conservado que se veía a pesar de su evidente antigüedad."

# game/common.rpy:1315
translate Spanish entercephin_eaefe2ab:

    # cethin "I couldn't bear to part with it, so I have to make sure it's always in top condition."
    cethin "No podría separarme de él, así que debo asegurarme de que siempre esté en perfectas condiciones."

# game/common.rpy:1317
translate Spanish entercephin_aeb0e17e:

    # cethin "Thankfully, it's an elven craft so it's made to last for centuries."
    cethin "Por suerte, es una artesanía élfica, así que está hecho para durar siglos."

# game/common.rpy:1321
translate Spanish entercephin_3731e6ed:

    # lumihappy "(This is the first time he has spoken much about himself.)"
    lumihappy "(Es la primera vez que habla tanto de sí mismo.)"

# game/common.rpy:1323
translate Spanish entercephin_f5187bd7:

    # "For the past few days, she was the one who'd been doing most of the talking, and whenever he did speak, they'd often be short responses."
    "Durante los últimos días, ella había sido quien hablaba la mayor parte del tiempo, y cuando él lo hacía, sus respuestas solían ser cortas."

# game/common.rpy:1325
translate Spanish entercephin_7d054d1c:

    # "If not chatting, she'd watch him do his maintenance like what he's doing at the moment."
    "Si no estaban conversando, ella lo observaba hacer su mantenimiento, como ahora."

# game/common.rpy:1327
translate Spanish entercephin_78974c36:

    # "Otherwise... he'd practice his singing, while she tries to take note of his improvement, or lack thereof."
    "De lo contrario... él practicaba su canto, mientras ella intentaba notar su mejora, o la falta de ella."

# game/common.rpy:1329
translate Spanish entercephin_8b046ffb:

    # "... Which begs the question, if he was so bad at being a bard, why be one in the first place?"
    "... Lo que plantea la pregunta: si era tan malo siendo bardo, ¿por qué ser uno en primer lugar?"

# game/common.rpy:1335
translate Spanish entercephin_21fa0097:

    # lumitalk "Did your mother like music?"
    lumitalk "¿A tu madre le gustaba la música?"

# game/common.rpy:1337
translate Spanish entercephin_ff5eb8c4:

    # "The question just spilled out of her."
    "La pregunta simplemente se le escapó."

# game/common.rpy:1339
translate Spanish entercephin_1fc7eadb:

    # "Judging from the look on his face, he was rather surprised."
    "Por la expresión en su rostro, parecía bastante sorprendido."

# game/common.rpy:1344
translate Spanish entercephin_3d444832:

    # "... And he seemed to be hesitating."
    "... Y dudó un poco."

# game/common.rpy:1357
translate Spanish day2_e686aeb0:

    # lumiehe "Ah yes! Why don't you tell me-"
    lumiehe "¡Ah, sí! ¿Por qué no me cuentas-"

# game/common.rpy:1377
translate Spanish day3_c47399b1:

    # lumihappy "Oh! Would you mind telling me about the current state of the kingdom?"
    lumihappy "¡Oh! ¿Podrías contarme sobre el estado actual del reino?"

# game/common.rpy:1379
translate Spanish day3_69f113c8:

    # lumisad "I hadn't heard anything from father, mother, or even brother..."
    lumisad "No he tenido noticias de mi padre, mi madre ni siquiera de mi hermano..."

# game/common.rpy:1383
translate Spanish day3_64f54a1a:

    # lumi "How is everyone? I hope the demonic beasts haven't reached the capital!"
    lumi "¿Cómo están todos? ¡Espero que las bestias demoníacas no hayan llegado a la capital!"

# game/common.rpy:1385
translate Spanish day3_1e1e1082:

    # "Cethin seemed taken aback by her sudden burst of excitement."
    "Cethin pareció desconcertado por su repentino estallido de emoción."

# game/common.rpy:1387
translate Spanish day3_ff3512de:

    # "Of course, it was understandable given that she hadn't been outside for years."
    "Por supuesto, era comprensible, dado que no había salido en años."

# game/common.rpy:1391
translate Spanish day3_4b6999f3:

    # "After a moment, the dark elf smiled softly."
    "Después de un momento, el elfo oscuro sonrió suavemente."

# game/common.rpy:1393
translate Spanish day3_2bf048bf:

    # cethin "The kingdom is peaceful. There hadn't been a wave of attack for years."
    cethin "El reino está en paz. No ha habido una oleada de ataques en años."

# game/common.rpy:1397
translate Spanish day3_179eb454:

    # cethin "I don't know much about the royal family, but last I've heard, the crown prince had been engaged."
    cethin "No sé mucho sobre la familia real, pero lo último que supe es que el príncipe heredero se había comprometido."

# game/common.rpy:1401
translate Spanish day3_cd6e6496:

    # lumihappy "I see... I am happy for brother!"
    lumihappy "Ya veo... ¡me alegra por mi hermano!"

# game/common.rpy:1403
translate Spanish day3_474f9491:

    # lumided "(Although I'd hardly say we're fond of each other...)"
    lumided "(Aunque no diría que nos llevemos muy bien...)"

# game/common.rpy:1405
translate Spanish day3_c9471749:

    # lumihappy "I'm glad everyone's safe. Truly."
    lumihappy "Me alegra que todos estén a salvo. De verdad."

# game/common.rpy:1407
translate Spanish day3_fadf970f:

    # "Cethin's words had given her a sliver of relief."
    "Las palabras de Cethin le dieron un pequeño alivio."

# game/common.rpy:1409
translate Spanish day3_24ee5d70:

    # lumiplead "I know this might be a stretch, but what of the other princesses?"
    lumiplead "Sé que puede que sea pedir demasiado, pero ¿qué hay de las otras princesas?"

# game/common.rpy:1411
translate Spanish day3_a9cb60fe:

    # lumitalk "Have you heard anything about the other kingdoms?"
    lumitalk "¿Has oído algo sobre los otros reinos?"

# game/common.rpy:1413
translate Spanish day3_9b7a8e6e:

    # "He nodded."
    "Él asintió."

# game/common.rpy:1417
translate Spanish day3_ff79ed31:

    # cethin "I've traveled across some neighboring kingdoms."
    cethin "He viajado por algunos reinos vecinos."

# game/common.rpy:1421
translate Spanish day3_aa123331:

    # cethin "The princesses of Celes, Almia, and Odio have been freed a couple of years ago."
    cethin "Las princesas de Celes, Almia y Odio fueron liberadas hace un par de años."

# game/common.rpy:1425
translate Spanish day3_eb782081:

    # cethin "I'm not sure about the princess of Atlanis, but I've heard that the king had called forth another tournament to find her a hero."
    cethin "No estoy seguro sobre la princesa de Atlanis, pero he oído que el rey había convocado otro torneo para encontrarle un héroe."

# game/common.rpy:1427
translate Spanish day3_e076f51c:

    # lumisad "I see... Arien is still captive."
    lumisad "Ya veo... Arien sigue cautiva."

# game/common.rpy:1431
translate Spanish day3_cdafb64a:

    # "She mulled."
    "Ella reflexionó."

# game/common.rpy:1433
translate Spanish day3_142fedb8:

    # lumiuwu "(But goodness... at this rate, I'll indeed find myself as the last princess...!)"
    lumiuwu "(Pero cielos... ¡a este paso, realmente terminaré siendo la última princesa...!)"

# game/common.rpy:1435
translate Spanish day3_f76e9f0c:

    # lumihappy "Oh well. I'm quite sure that father is also doing his best to find me more heroes."
    lumihappy "Oh bueno. Estoy bastante segura de que padre también está haciendo todo lo posible por encontrarme más héroes."

# game/common.rpy:1437
translate Spanish day3_21ce16cb:

    # "The princess nodded to herself."
    "La princesa asintió para sí misma."

# game/common.rpy:1441
translate Spanish day3_cbf01d72:

    # "She then clapped her hands together, looking rather excited."
    "Luego juntó las manos, luciendo bastante emocionada."

# game/common.rpy:1443
translate Spanish day3_981ae41a:

    # lumiehe "Then...!"
    lumiehe "¡Entonces...!"

# game/common.rpy:1445
translate Spanish day3_b9d9de42:

    # lumihappy "It's news to me that you've traveled outside of our Demetria as well."
    lumihappy "Es una novedad para mí que también hayas viajado fuera de nuestra Demetria."

# game/common.rpy:1447
translate Spanish day3_3fee88ab:

    # lumiwish "I'd love to hear about your travels!"
    lumiwish "¡Me encantaría oír sobre tus viajes!"

# game/common.rpy:1449
translate Spanish day3_00ac4dcf:

    # lumi "I've heard Atlanis was a kingdom underwater?"
    lumi "¿Tengo entendido que Atlanis es un reino bajo el agua?"

# game/common.rpy:1451
translate Spanish day3_00ba67c4:

    # lumihappy "Princess Arien had described their kingdom to me when I met her at a party once..."
    lumihappy "La princesa Arien me lo describió cuando la conocí en una fiesta una vez..."

# game/common.rpy:1453
translate Spanish day3_9be16eef:

    # lumiwish "Oh! And is it true that Celes is protected by the faes? And are there truly dragons in Almia?"
    lumiwish "¡Oh! ¿Y es cierto que Celes está protegida por las hadas? ¿Y que realmente hay dragones en Almia?"

# game/common.rpy:1455
translate Spanish day3_5aefc74b:

    # "Cethin could only blink from her second (or third?) barrage of questions."
    "Cethin solo pudo parpadear ante su segunda (¿o tercera?) avalancha de preguntas."

# game/common.rpy:1459
translate Spanish day3_9450f44d:

    # "... But he couldn't help but feel at ease with her."
    "... Pero no pudo evitar sentirse cómodo con ella."

# game/common.rpy:1465
translate Spanish day3_2dfa993d:

    # cethin "Let's see, allow me tell my tales in song..."
    cethin "Veamos, permíteme contar mis historias en canción..."

# game/common.rpy:1467
translate Spanish day3_6c0eed63:

    # lumided "Eh?"
    lumided "¿Eh?"

# game/common.rpy:1469
translate Spanish day3_04eec329:

    # "Right. He's a bard.{w} A tone deaf bard."
    "Cierto. Es un bardo.{w} Un bardo sin oído musical."

# game/common.rpy:1471
translate Spanish day3_d8d44609:

    # "... Of course he'll tell his tales of adventure in song."
    "... Por supuesto que contará sus aventuras en canción."

# game/common.rpy:1473
translate Spanish day3_7321477b:

    # "And it's too late to back out."
    "Y ya es demasiado tarde para echarse atrás."

# game/common.rpy:1479
translate Spanish day3_800484ac:

    # voice "voice1/line38.mp3"
    # cethin "~There was once a kingdom, sunken underneath the sea~"
    voice "voice1/line38.mp3"
    cethin "~Había una vez un reino, hundido bajo el mar~"

# game/common.rpy:1483
translate Spanish day3_15c8e065:

    # voice "voice1/line39.mp3"
    # cethin "~Tis' a secret told to reach the forbidden land with ease~"
    voice "voice1/line39.mp3"
    cethin "~Un secreto contado para alcanzar la tierra prohibida con facilidad~"

# game/common.rpy:1489
translate Spanish day3_669ffcc9:

    # "At first, the princess regretted it."
    "Al principio, la princesa se arrepintió."

# game/common.rpy:1491
translate Spanish day3_c2b70404:

    # "His singing was... {i}subpar{/i} as usual."
    "Su canto era... {i}mediocre{/i}, como siempre."

# game/common.rpy:1493
translate Spanish day3_f8ab9cd6:

    # "...{w} Alright, it was plain {b}bad{/b}."
    "...{w} De acuerdo, era simplemente {b}horrible{/b}."

# game/common.rpy:1495
translate Spanish day3_7da3eb73:

    # "As usual, he sounded like a dying goat, and Lumi didn't even know what that sounded like!"
    "Como de costumbre, sonaba como una cabra moribunda, ¡y Lumi ni siquiera sabía cómo sonaba eso!"

# game/common.rpy:1499
translate Spanish day3_190a9455:

    # voice "voice1/line40.mp3"
    # cethin "~Through the north, through the north, one must cross the valley of weeping harpies~"
    voice "voice1/line40.mp3"
    cethin "~Por el norte, por el norte, uno debe cruzar el valle de las arpías lloronas~"

# game/common.rpy:1503
translate Spanish day3_6332f8c9:

    # voice "voice1/line41.mp3"
    # cethin "~Offer thy humble gifts, keep them happy and repay you kindness they shall~"
    voice "voice1/line41.mp3"
    cethin "~Ofréceles humildes regalos, mantenlas felices y su bondad te devolverán~"

# game/common.rpy:1509
translate Spanish day3_5f60dd05:

    # "But as he went on, his words tugged her further and further."
    "Pero a medida que continuaba, sus palabras la atrapaban más y más."

# game/common.rpy:1511
translate Spanish day3_6810fdd7:

    # "The princess began to picture them in her mind..."
    "La princesa comenzó a imaginarlas en su mente..."

# game/common.rpy:1515
translate Spanish day3_d938d786:

    # voice "voice1/line42.mp3"
    # cethin "~Open the passage through their sacred grotto~"
    voice "voice1/line42.mp3"
    cethin "~Abre el paso a través de su sagrado cenote~"

# game/common.rpy:1519
translate Spanish day3_26745f41:

    # voice "voice1/line43.mp3"
    # cethin "~Find thyself upon the figure of the folk of scales~"
    voice "voice1/line43.mp3"
    cethin "~Encuéntrate ante la figura del pueblo de escamas~"

# game/common.rpy:1525
translate Spanish day3_7c4fb722:

    # "It was as though she was part of the tale itself."
    "Era como si ella formara parte del relato mismo."

# game/common.rpy:1527
translate Spanish day3_8f1a44e0:

    # "She couldn't help but find herself immersed in the story."
    "No pudo evitar sentirse inmersa en la historia."

# game/common.rpy:1531
translate Spanish day3_1e283d11:

    # voice "voice1/line44.mp3"
    # cethin "~Fear not the sirens in thy presence~"
    voice "voice1/line44.mp3"
    cethin "~No temas a las sirenas en tu presencia~"

# game/common.rpy:1535
translate Spanish day3_7de872c4:

    # voice "voice1/line45.mp3"
    # cethin "~Whose beauty shall enchant and allure~"
    voice "voice1/line45.mp3"
    cethin "~Cuyo encanto seducirá y atraerá~"

# game/common.rpy:1539
translate Spanish day3_20d310ef:

    # voice "voice1/line46.mp3"
    # cethin "~Whose voices bewitch and enthrall~"
    voice "voice1/line46.mp3"
    cethin "~Cuyas voces hechizan y embrujan~"

# game/common.rpy:1543
translate Spanish day3_e45fe7d1:

    # voice "voice1/line47.mp3"
    # cethin "~Close thy eyes and cover thy ears, then offer thy heart~"
    voice "voice1/line47.mp3"
    cethin "~Cierra los ojos y cubre tus oídos, luego ofrece tu corazón~"

# game/common.rpy:1547
translate Spanish day3_506a67af:

    # voice "voice1/line48.mp3"
    # cethin "~Need not yours, but hunt a boar to ease your fears~"
    voice "voice1/line48.mp3"
    cethin "~No necesitas el tuyo, sino caza un jabalí para calmar tus temores~"

# game/common.rpy:1551
translate Spanish day3_277dc072:

    # voice "voice1/line49.mp3"
    # cethin "~Passage they give for the humble gift...~"
    voice "voice1/line49.mp3"
    cethin "~El paso te darán por el humilde regalo...~"

# game/common.rpy:1557
translate Spanish day3_44568e8b:

    # "The dark elf continued to entertain the princess with his tales for the rest of the day."
    "El elfo oscuro continuó entreteniendo a la princesa con sus relatos durante el resto del día."

# game/common.rpy:1559
translate Spanish day3_be6b4a6f:

    # "There was nothing to praise about his performance, but for the princess of Demetria..."
    "No había nada que elogiar en su interpretación, pero para la princesa de Demetria..."

# game/common.rpy:1563
translate Spanish day3_9da9b4f1:

    # "... It was most enjoyable."
    "... Fue sumamente agradable."

# game/common.rpy:1572
translate Spanish day3_71820734:

    # butler "Princess, has the cold been bothering you?"
    butler "Princesa, ¿le ha estado molestando el frío?"

# game/common.rpy:1576
translate Spanish day3_6392118f:

    # butler "I can bring over additional blankets, just say the word."
    butler "Puedo traerle mantas adicionales, solo diga la palabra."

# game/common.rpy:1580
translate Spanish day3_bead3340:

    # "The redhead said as he took the plates away and loaded them on his butler trolley."
    "Dijo el pelirrojo mientras retiraba los platos y los colocaba en su carrito de mayordomo."

# game/common.rpy:1584
translate Spanish day3_7b2ec225:

    # lumithink "Whatever brought this on?"
    lumithink "¿Qué habrá causado esto?"

# game/common.rpy:1586
translate Spanish day3_c7e251d7:

    # "It's been a couple of weeks since the princess admitted the hero's companion as her roommate."
    "Habían pasado un par de semanas desde que la princesa aceptó al compañero del héroe como su compañero de cuarto."

# game/common.rpy:1588
translate Spanish day3_b30b6dcf:

    # "Currently, her bard had himself hidden inside her closet."
    "Actualmente, su bardo se escondía dentro de su armario."

# game/common.rpy:1590
translate Spanish day3_951c3c46:

    # "Apparently, elves didn't even need sleep. Meditation was enough for them, and the same was true for Cethin."
    "Aparentemente, los elfos ni siquiera necesitaban dormir. La meditación era suficiente para ellos, y lo mismo aplicaba para Cethin."

# game/common.rpy:1592
translate Spanish day3_b8a0785d:

    # "This was convenient for them, in case anyone tried to enter their room during nighttime."
    "Esto les resultaba conveniente, en caso de que alguien intentara entrar a la habitación durante la noche."

# game/common.rpy:1594
translate Spanish day3_eef3f07c:

    # "It had been rather easy to keep him in secret, since only the demon butler ever visits her, and he'd always knock before entering."
    "Había sido bastante fácil mantenerlo en secreto, ya que solo el mayordomo demonio la visitaba, y siempre llamaba antes de entrar."

# game/common.rpy:1596
translate Spanish day3_6a3e65d7:

    # "It also helped that her room had an enchantment which disallowed sound from leaking out..."
    "También ayudaba que su habitación tuviera un encantamiento que impedía que el sonido saliera..."

# game/common.rpy:1598
translate Spanish day3_59ba70d4:

    # "So the roommates were free to make all the noise and music that they wanted."
    "Así que los compañeros de torre podían hacer todo el ruido y música que quisieran."

# game/common.rpy:1602
translate Spanish day3_8cc1502d:

    # butler "You have been consuming larger servings for your meals..."
    butler "Ha estado consumiendo porciones más grandes en sus comidas..."

# game/common.rpy:1606
translate Spanish day3_98b62445:

    # butler "Have you been feeling unwell? I could also call over a doctor and-"
    butler "¿Se ha sentido mal? También podría llamar a un médico y-"

# game/common.rpy:1608
translate Spanish day3_eb3a8f1b:

    # lumided "Come now. No need for that. I feel fine!"
    lumided "Vamos. No hay necesidad de eso. ¡Me siento bien!"

# game/common.rpy:1610
translate Spanish day3_a144ce9d:

    # "She cut him off."
    "Lo interrumpió."

# game/common.rpy:1612
translate Spanish day3_60003dad:

    # lumihappy "The cold doesn't bother me either."
    lumihappy "El frío tampoco me molesta."

# game/common.rpy:1614
translate Spanish day3_fafeaccd:

    # lumitalk "In fact, shouldn't you be glad that I am eating well?"
    lumitalk "De hecho, ¿no deberías alegrarte de que esté comiendo bien?"

# game/common.rpy:1616
translate Spanish day3_f99a8057:

    # lumided "The moment I refuse to eat is the only time you should express concern."
    lumided "El momento en que me niegue a comer será el único en el que debas preocuparte."

# game/common.rpy:1618
translate Spanish day3_bbaefcc7:

    # butler "I suppose so..."
    butler "Supongo que sí..."

# game/common.rpy:1622
translate Spanish day3_76301848:

    # butler "You have been rather cheerful as of late."
    butler "Ha estado bastante alegre últimamente."

# game/common.rpy:1624
translate Spanish day3_3b59c74c:

    # lumitalk "Oh?"
    lumitalk "¿Oh?"

# game/common.rpy:1626
translate Spanish day3_50902832:

    # lumithink "(Have I now?{w} I suppose it's been quite fun with Cethin around.)"
    lumithink "(¿Lo he estado?{w} Supongo que ha sido bastante divertido con Cethin cerca.)"

# game/common.rpy:1630
translate Spanish day3_ea055882:

    # butler "Either way, if something is bothering you... know that I am here to listen."
    butler "De cualquier modo, si algo la preocupa... sepa que estoy aquí para escuchar."

# game/common.rpy:1634
translate Spanish day3_d5634fb1:

    # butler "Whether or not I could help though, is another subject."
    butler "Aunque si puedo ayudar o no, es otro asunto."

# game/common.rpy:1636
translate Spanish day3_a164a548:

    # lumided "Yes... that has always been your stance."
    lumided "Sí... esa siempre ha sido tu postura."

# game/common.rpy:1638
translate Spanish day3_82dcc3ba:

    # lumiserious "Quite half hearted."
    lumiserious "Bastante poco entusiasta."

# game/common.rpy:1642
translate Spanish day3_783a1028:

    # butler "What can I say? My loyalty is not yours to keep."
    butler "¿Qué puedo decir? Mi lealtad no te pertenece."

# game/common.rpy:1646
translate Spanish day3_4730ab69:

    # "He smirked."
    "Él sonrió con ironía."

# game/common.rpy:1648
translate Spanish day3_81f71147:

    # lumiserious "Yes, yes, I am aware."
    lumiserious "Sí, sí, ya lo sé."

# game/common.rpy:1650
translate Spanish day3_a333173c:

    # "She sneered at the demonkin."
    "Ella hizo una mueca de disgusto hacia el demonkin."

# game/common.rpy:1652
translate Spanish day3_f55d9873:

    # lumi "Speaking of- how has your {i}'sweeping'{/i} been going?"
    lumi "Hablando de eso, ¿cómo te ha ido con la {i}'limpieza'{/i}?"

# game/common.rpy:1654
translate Spanish day3_3c40ce84:

    # lumisad "You haven't been coming over for my tea and snacks."
    lumisad "No has venido a tomar el té y los bocadillos."

# game/common.rpy:1658
translate Spanish day3_b018e724:

    # butler "Ah, yes..."
    butler "Ah, sí..."

# game/common.rpy:1660
translate Spanish day3_53528287:

    # butler "Honestly, I am still working on that."
    butler "Honestamente, todavía estoy trabajando en eso."

# game/common.rpy:1664
translate Spanish day3_f2c6c819:

    # butler "We have not found a single trace of that intruder... I do wonder if they have actually managed to sneak out?"
    butler "No hemos encontrado ni rastro de ese intruso... me pregunto si realmente logró escapar."

# game/common.rpy:1668
translate Spanish day3_b34972ae:

    # lumihappy "I see..."
    lumihappy "Ya veo..."

# game/common.rpy:1670
translate Spanish day3_b39527ba:

    # lumihappy "(Which means he does not suspect Cethin being here? Wonderful.)"
    lumihappy "(¿Eso significa que no sospecha que Cethin está aquí? Maravilloso.)"

# game/common.rpy:1674
translate Spanish day3_8c3749f1:

    # butler "Anything else?"
    butler "¿Algo más?"

# game/common.rpy:1676
translate Spanish day3_572e8531:

    # lumihappy "No. Now, leave. {b}Please?{/b}"
    lumihappy "No. Ahora vete. {b}¿Por favor?{/b}"

# game/common.rpy:1680
translate Spanish day3_c083eb9a:

    # butler "You've been awfully eager to send me out lately, haven't you?"
    butler "Últimamente has estado muy ansiosa por echarme, ¿no?"

# game/common.rpy:1682
translate Spanish day3_6c8d2cfe:

    # "He sighed."
    "Suspiró."

# game/common.rpy:1686
translate Spanish day3_a334e2ca:

    # butler "Very well, if that is all..."
    butler "Muy bien, si eso es todo..."

# game/common.rpy:1697
translate Spanish day3_a752962a:

    # "The butler bowed."
    "El mayordomo hizo una reverencia."

# game/common.rpy:1699
translate Spanish day3_fb1bd257:

    # butler "Then I shall come over again to serve dinner."
    butler "Entonces regresaré más tarde para servir la cena."

# game/common.rpy:1706
translate Spanish day3_25a85e73:

    # "The princess waited a few minutes before she called out-"
    "La princesa esperó unos minutos antes de llamar-"

# game/common.rpy:1708
translate Spanish day3_13194d76:

    # lumithink "Cethin dear, you may come out now."
    lumithink "Cethin querido, ya puedes salir."

# game/common.rpy:1716
translate Spanish day3_399aae3e:

    # cethin "Thank you for covering for me again..."
    cethin "Gracias por cubrirme otra vez..."

# game/common.rpy:1718
translate Spanish day3_83a81723:

    # lumithink "You do not have to thank me every time."
    lumithink "No tienes que agradecerme cada vez."

# game/common.rpy:1722
translate Spanish day3_440f2a82:

    # lumihappy "Besides, you seem to be quite good at hiding your presence. I say the credit is all yours!"
    lumihappy "Además, pareces bastante bueno ocultando tu presencia. ¡Diría que el mérito es todo tuyo!"

# game/common.rpy:1726
translate Spanish day3_97d3b2db:

    # cethin "Well... everyone says I have a weak presence."
    cethin "Bueno... todos dicen que tengo una presencia débil."

# game/common.rpy:1728
translate Spanish day3_ce44a04d:

    # "He replied bashfully."
    "Respondió con timidez."

# game/common.rpy:1730
translate Spanish day3_cbc849cf:

    # lumiuwu "(Isn't a weak presence a detriment for a bard?!)" with vpunch
    lumiuwu "(¿¡Acaso una presencia débil no es un inconveniente para un bardo?!)" with vpunch

# game/common.rpy:1732
translate Spanish day3_bb4d3b64:

    # lumided "Perhaps you are in the wrong profession..."
    lumided "Quizá estás en la profesión equivocada..."

# game/common.rpy:1734
translate Spanish day3_58d42547:

    # "She whispered inaudibly."
    "Susurró inaudiblemente."

# game/common.rpy:1738
translate Spanish day3_1a707a7c:

    # cethin "Still, I'm really grateful. You even take care of my meals..."
    cethin "Aun así, te lo agradezco mucho. Incluso te encargas de mis comidas..."

# game/common.rpy:1742
translate Spanish day3_28530788:

    # lumihappy "Think nothing of it!"
    lumihappy "¡No es nada!"

# game/common.rpy:1744
translate Spanish day3_cf6db732:

    # "It's not like she's the one doing the cooking."
    "No es como si ella fuera quien cocinara."

# game/common.rpy:1746
translate Spanish day3_e4bc0499:

    # lumisad "Although, I couldn't really commend the meals they serve here. They are quite bad, no?"
    lumisad "Aunque, realmente no podría elogiar las comidas que sirven aquí. Son bastante malas, ¿no crees?"

# game/common.rpy:1748
translate Spanish day3_69f0a2d9:

    # lumiuwu "If not too bland, they'd have strange textures; gooey, sticky and sometimes even sandy..."
    lumiuwu "Si no son demasiado insípidas, tienen texturas extrañas; pastosas, pegajosas y a veces incluso arenosas..."

# game/common.rpy:1750
translate Spanish day3_40791789:

    # "She cringed just thinking about them."
    "Ella se estremeció solo de pensarlo."

# game/common.rpy:1754
translate Spanish day3_c070dd7d:

    # cethin "I-it wasn't bad..."
    cethin "N-no estuvo mal..."

# game/common.rpy:1758
translate Spanish day3_0b9aeced:

    # cethin "I'd say, they are even better than our travel rations."
    cethin "Diría que son incluso mejores que nuestras raciones de viaje."

# game/common.rpy:1760
translate Spanish day3_14eed195:

    # lumihappy "Truly? Mhm... then I suppose it must be because I have a gourmet's palate."
    lumihappy "¿En serio? Mhm... entonces supongo que debe ser porque tengo un paladar gourmet."

# game/common.rpy:1762
translate Spanish day3_1db5d0d9:

    # "Her tone was rather proud when she stated this."
    "Su tono fue bastante orgulloso al decir esto."

# game/common.rpy:1764
translate Spanish day3_a3006840:

    # "Being a princess, she had been raised on the palace chef's cooking after all."
    "Al ser una princesa, había crecido comiendo la comida del chef del palacio, después de todo."

# game/common.rpy:1769
translate Spanish day3_41f51a67:

    # lumiehe "Oh, how I miss the palace meals...!"
    lumiehe "¡Oh, cómo extraño las comidas del palacio...!"

# game/common.rpy:1771
translate Spanish day3_5ad00731:

    # "She added, wiping a nonexistent tear from her eye."
    "Agregó, secándose una lágrima inexistente del ojo."

# game/common.rpy:1775
translate Spanish day3_59692944:

    # cethin "Mhm... oh!"
    cethin "Mhm... ¡oh!"

# game/common.rpy:1779
translate Spanish day3_9442c5ce:

    # cethin "I see... maybe I can..."
    cethin "Ya veo... tal vez pueda..."

# game/common.rpy:1781
translate Spanish day3_93864cfe:

    # lumisad "Cethin? Are you listening?"
    lumisad "¿Cethin? ¿Estás escuchando?"

# game/common.rpy:1785
translate Spanish day3_a6477c5f:

    # cethin "Huh? Ah, sorry."
    cethin "¿Eh? Ah, perdón."

# game/common.rpy:1789
translate Spanish day3_330d3fe6:

    # cethin "I... was just thinking about what I should play today."
    cethin "Yo... solo estaba pensando en qué debería tocar hoy."

# game/common.rpy:1791
translate Spanish day3_56039b33:

    # "Ever since that day when Cethin started singing tales of what he had seen during his travels, he had continued to do the same day in and day out."
    "Desde aquel día en que Cethin comenzó a cantar historias de lo que había visto durante sus viajes, había continuado haciendo lo mismo día tras día."

# game/common.rpy:1793
translate Spanish day3_189a3811:

    # "The princess seemed to have become fond of his stories..."
    "La princesa parecía haberse encariñado con sus historias..."

# game/common.rpy:1795
translate Spanish day3_cc67f0c1:

    # "He had basically become her personal bard."
    "Básicamente se había convertido en su bardo personal."

# game/common.rpy:1797
translate Spanish day3_07161bf1:

    # "Singing aside, anyway. He still couldn't hold a tune."
    "Bueno, dejando el canto de lado. Aún no podía mantener el tono."

# game/common.rpy:1799
translate Spanish day3_36068dcf:

    # lumihappy "Then would you mind continuing the story of your journeys in Celes?"
    lumihappy "Entonces, ¿te importaría continuar la historia de tus viajes en Celes?"

# game/common.rpy:1803
translate Spanish day3_db1dd894:

    # cethin "Ha... very well."
    cethin "Ha... muy bien."

# game/common.rpy:1807
translate Spanish day3_09e99ecc:

    # cethin "It's not as exciting as you might imagine though."
    cethin "Aunque no es tan emocionante como podrías imaginar."

# game/common.rpy:1813
translate Spanish day3_3dcb1ca0:

    # cethin "Let's see..."
    cethin "Veamos..."

# game/common.rpy:1819
translate Spanish day3_ea9e7ddf:

    # voice "voice1/line49-5.mp3"
    # cethin "~When the forest of faes sings, the soul it soothes~"
    voice "voice1/line49-5.mp3"
    cethin "~Cuando el bosque de las hadas canta, el alma consuela~"

# game/common.rpy:1823
translate Spanish day3_20a8fcc4:

    # voice "voice1/line50.mp3"
    # cethin "~But as the sun sets, the music slowly fades along~"
    voice "voice1/line50.mp3"
    cethin "~Pero al ponerse el sol, la música lentamente se desvanece~"

# game/common.rpy:1827
translate Spanish day3_0b76e3a5:

    # voice "voice1/line51.mp3"
    # cethin "~When darkness falls, the fairies dance~"
    voice "voice1/line51.mp3"
    cethin "~Cuando cae la oscuridad, las hadas bailan~"

# game/common.rpy:1831
translate Spanish day3_5f044eb5:

    # voice "voice1/line52.mp3"
    # cethin "~And it's time for you to sing alooong~"
    voice "voice1/line52.mp3"
    cethin "~Y es hora de que tú cantes también~"

# game/common.rpy:1835
translate Spanish day3_bfbbdc31:

    # voice "voice1/line53.mp3"
    # cethin "~For when the lights prance around, thus the gates unlatch~"
    voice "voice1/line53.mp3"
    cethin "~Pues cuando las luces danzan, así se abren las puertas~"

# game/common.rpy:1839
translate Spanish day3_6f26b4bc:

    # voice "voice1/line54.mp3"
    # cethin "~Through the twin trees of millenia you must pass~"
    voice "voice1/line54.mp3"
    cethin "~A través de los árboles gemelos del milenio debes pasar~"

# game/common.rpy:1843
translate Spanish day3_be2547d1:

    # voice "voice1/line55.mp3"
    # cethin "~And thus shall you behold upon your eyes, the land of Celes...~"
    voice "voice1/line55.mp3"
    cethin "~Y así contemplarás ante tus ojos, la tierra de Celes...~"

# game/common.rpy:1849
translate Spanish day3_fe4b4c2f:

    # "The rest of their day was once again spent on storytelling."
    "El resto de su día volvió a pasar entre historias."

# game/common.rpy:1851
translate Spanish day3_54335b5f:

    # "This had been their routine for the past few weeks."
    "Esa había sido su rutina durante las últimas semanas."

# game/common.rpy:1853
translate Spanish day3_30465e9d:

    # "For someone who had spent her life trapped within castle walls, as a princess who was not allowed to freely step out of the palace..."
    "Para alguien que había pasado su vida atrapada entre los muros de un castillo, como una princesa a la que no se le permitía salir libremente del palacio..."

# game/common.rpy:1855
translate Spanish day3_b3860264:

    # "... And then as a prisoner of the demon lord."
    "... Y luego como prisionera del señor demonio."

# game/common.rpy:1861
translate Spanish day3_d352533e:

    # "Hearing about tales of the outside from someone who had actually been from the {i}outside{/i} was such a wonder."
    "Escuchar historias del exterior de alguien que realmente venía del {i}exterior{/i} era todo un asombro."

# game/common.rpy:1863
translate Spanish day3_a924f0d7:

    # "Dragons, fairies, elves, orcs, ogres, mermaids, sirens, harpies...{w} she had always known of their existence, but she had never heard tales of their lives."
    "Dragones, hadas, elfos, orcos, ogros, sirenas, tritones, arpías...{w} siempre había sabido de su existencia, pero nunca había escuchado relatos sobre sus vidas."

# game/common.rpy:1866
translate Spanish day3_87a58bb2:

    # "From a lake of honey, cities made of bones to a forest of gems... the world was filled with many wonders she had never known."
    "Desde un lago de miel, ciudades hechas de huesos hasta un bosque de gemas... el mundo estaba lleno de maravillas que nunca había conocido."

# game/common.rpy:1868
translate Spanish day3_f521d203:

    # "Admittedly, her experience would have been more enthralling had Cethin just been more... skilled as a bard."
    "Ciertamente, su experiencia habría sido más fascinante si Cethin hubiera sido un poco más... hábil como bardo."

# game/common.rpy:1872
translate Spanish day3_4b94aa59:

    # "Still, everyday felt like a new day for once."
    "Aun así, cada día se sentía como uno nuevo por primera vez."

# game/common.rpy:1874
translate Spanish day3_f3b8ca2c:

    # "However..."
    "Sin embargo..."

# game/common.rpy:1879
translate Spanish day3_841d08cc:

    # lumisad "(He isn't here either...)"
    lumisad "(Tampoco está aquí...)"

# game/common.rpy:1881
translate Spanish day3_56791391:

    # "Lumi thought to herself as she closed her closet."
    "Pensó Lumi mientras cerraba su armario."

# game/common.rpy:1885
translate Spanish day3_6e5f701e:

    # lumisad "Perhaps..."
    lumisad "Tal vez..."

# game/common.rpy:1887
translate Spanish day3_d684a322:

    # "She gulped. Her eyes naturally gravitated by the balcony area."
    "Tragó saliva. Sus ojos se dirigieron naturalmente hacia el balcón."

# game/common.rpy:1889
translate Spanish day3_149cefec:

    # "Her hands which she had balled to a fist felt colder than usual."
    "Sus manos, que había cerrado en puños, se sentían más frías de lo habitual."

# game/common.rpy:1891
translate Spanish day3_9ab85ee0:

    # "There was nothing different that day."
    "No había nada diferente ese día."

# game/common.rpy:1893
translate Spanish day3_5b903c2b:

    # "Sure, the demon butler seemed to have taken notice of her increase in food intake, but otherwise... everything else was just as usual."
    "Claro, el mayordomo demonio parecía haberse dado cuenta de su aumento en el consumo de comida, pero aparte de eso... todo lo demás seguía igual que siempre."

# game/common.rpy:1895
translate Spanish day3_b108d199:

    # "Cethin told her stories, they chatted, and then they turned in for the day."
    "Cethin le contó historias, charlaron y luego se retiraron a descansar."

# game/common.rpy:1897
translate Spanish day3_372d738c:

    # "... Until she woke up a tad early."
    "... Hasta que ella despertó un poco temprano."

# game/common.rpy:1899
translate Spanish day3_ad0b5e0b:

    # "She tried to call out to Cethin, and he'd normally reply right away, but not this time."
    "Intentó llamarlo, y normalmente él respondería de inmediato, pero esta vez no."

# game/common.rpy:1901
translate Spanish day3_b25fd744:

    # "The princess had already searched around the room, not that there was much area to search."
    "La princesa ya había buscado por toda la habitación, aunque no había mucho espacio para buscar."

# game/common.rpy:1903
translate Spanish day3_d862cb05:

    # "The bathroom, the closet, under her bed... there weren't really that many places to hide a full grown dark elf."
    "El baño, el armario, debajo de la cama... realmente no había tantos lugares donde pudiera esconderse un elfo oscuro adulto."

# game/common.rpy:1907
translate Spanish day3_afb6270f:

    # lumitalk "Cethin...?"
    lumitalk "¿Cethin...?"

# game/common.rpy:1909
translate Spanish day3_c5bd6724:

    # "She called out weakly as she walked up the balcony to look for her companion- but he wasn't there either."
    "Lo llamó débilmente mientras se acercaba al balcón para buscar a su compañero, pero él tampoco estaba allí."

# game/common.rpy:1911
translate Spanish day3_6716772b:

    # "The princess also took a quick peek below- at the very least, he wasn't splattered on the ground either."
    "La princesa también echó un vistazo rápido hacia abajo; al menos, no estaba hecho papilla contra el suelo."

# game/common.rpy:1913
translate Spanish day3_0d08271b:

    # "Or he didn't seem to have."
    "O al menos no parecía estarlo."

# game/common.rpy:1915
translate Spanish day3_fffdbc7e:

    # "Still, he was nowhere to be found."
    "Aun así, no se encontraba por ningún lado."

# game/common.rpy:1919
translate Spanish day3_bfdbd3b5:

    # lumisad "(Did he... leave?)"
    lumisad "(¿Se... fue?)"

# game/common.rpy:1921
translate Spanish day3_f814e7c4:

    # "She wanted to deny the thought, but that was the only explanation."
    "Quería negar el pensamiento, pero esa era la única explicación."

# game/common.rpy:1933
translate Spanish day3_80fbe609:

    # lumisad "(Without saying word to me, no less...)"
    lumisad "(Sin decirme una palabra, nada menos...)"

# game/common.rpy:1935
translate Spanish day3_209958f1:

    # "The princess suddenly felt cold."
    "La princesa sintió un frío repentino."

# game/common.rpy:1937
translate Spanish day3_76fbe9d8:

    # "A soft breeze passed by her, making the girl shiver a little."
    "Una suave brisa pasó junto a ella, haciendo que la chica se estremeciera un poco."

# game/common.rpy:1939
translate Spanish day3_5f3df18c:

    # lumisad "Why did he suddenly run off like that?"
    lumisad "¿Por qué se fue así de repente?"

# game/common.rpy:1941
translate Spanish day3_bf529b48:

    # "Their time together had been short, but his sudden departure made her remember how lonely it was in that room."
    "Su tiempo juntos había sido corto, pero su partida repentina le recordó lo sola que estaba en esa habitación."

# game/common.rpy:1957
translate Spanish day3_c48c55eb:

    # "She crouched into a ball, leaning by the balcony railings."
    "Se acurrucó hecha un ovillo, apoyándose en las barandillas del balcón."

# game/common.rpy:1959
translate Spanish day3_afc8bd67:

    # "It was very unprincess-like, but she didn't care."
    "No era nada propio de una princesa, pero no le importó."

# game/common.rpy:1963
translate Spanish day3_e1e9d81a:

    # lumisad "Have I done something wrong?"
    lumisad "¿He hecho algo mal?"

# game/common.rpy:1965
translate Spanish day3_41a78af3:

    # lumisad "(Did I offend him in some way...?)"
    lumisad "(¿Lo habré ofendido de alguna manera...?)"

# game/common.rpy:1967
translate Spanish day3_c7839a1d:

    # "Memories of their short time together flashed back in her mind."
    "Los recuerdos de su breve tiempo juntos pasaron por su mente."

# game/common.rpy:1969
translate Spanish day3_04a8d06c:

    # "-His clumsy songs, his timid gestures, and his awkward expressions..."
    "-Sus canciones torpes, sus gestos tímidos y sus expresiones incómodas..."

# game/common.rpy:1971
translate Spanish day3_843c073c:

    # "The Cethin in her memories didn't seem upset at all."
    "El Cethin de sus recuerdos no parecía molesto en absoluto."

# game/common.rpy:1973
translate Spanish day3_76828f47:

    # "She couldn't tell why he would leave all of a sudden."
    "No podía entender por qué se iría de repente."

# game/common.rpy:1975
translate Spanish day3_1ca6ba6f:

    # "{i}'Did I push him around too much? Have I gone too far in teasing him? Have I been making him uncomfortable...?'{/i}"
    "{i}“¿Lo presioné demasiado? ¿Me pasé al burlarme de él? ¿Lo estuve haciendo sentir incómodo...?”{/i}"

# game/common.rpy:1977
translate Spanish day3_91e9c803:

    # "{i}'Was he doing well? Did he manage to escape from the demonic beasts? Has he reconvened with his party?'{/i}"
    "{i}“¿Estará bien? ¿Habrá logrado escapar de las bestias demoníacas? ¿Se habrá reunido con su grupo?”{/i}"

# game/common.rpy:1979
translate Spanish day3_cc8d7ef9:

    # "{i}'Will he ever return to rescue me...?'{/i}"
    "{i}“¿Volverá alguna vez para rescatarme...?”{/i}"

# game/common.rpy:1981
translate Spanish day3_e1c1d7cf:

    # "-Such thoughts crossed her mind."
    "-Tales pensamientos cruzaron por su mente."

# game/common.rpy:1983
translate Spanish day3_066e6989:

    # "The princess hugged herself tighter."
    "La princesa se abrazó con más fuerza."

# game/common.rpy:1985
translate Spanish day3_9f249866:

    # lumisad "Mother... father... you promised that you'd send me a hero..."
    lumisad "Madre... padre... ustedes prometieron que me enviarían un héroe..."

# game/common.rpy:1987
translate Spanish day3_79dd044b:

    # "She muttered weakly."
    "Murmuró débilmente."

# game/common.rpy:1989
translate Spanish day3_933f5fc9:

    # "Somehow, unwanted memories returned to her, now of all times."
    "De alguna manera, recuerdos no deseados regresaron a ella, justo en ese momento."

# game/common.rpy:1991
translate Spanish day3_5e558c1f:

    # "The memory of her first arrival in the tower."
    "El recuerdo de su primera llegada a la torre."

# game/common.rpy:1993
translate Spanish day3_6b00877b:

    # "On the first night of her capture, she couldn't help but huddle into a ball just like how she was right now."
    "En la primera noche de su captura, no pudo evitar acurrucarse en una bola, tal como estaba ahora."

# game/common.rpy:1995
translate Spanish day3_f20de348:

    # "She cried the whole night back then."
    "Lloró toda la noche en aquel entonces."

# game/common.rpy:1997
translate Spanish day3_57ccad48:

    # "Princess Lumi had always known that she will be taken by the demon lord sooner or later."
    "La princesa Lumi siempre había sabido que tarde o temprano sería tomada por el señor demonio."

# game/common.rpy:1999
translate Spanish day3_0702eca0:

    # "Everyone had known-{w} that it was the time for the demon lords to awaken, thus, all chosen princesses of the generation were to experience the ordeal."
    "Todos lo sabían—{w} que era el tiempo en que los señores demonio despertaban, y por tanto, todas las princesas elegidas de la generación debían pasar por la prueba."

# game/common.rpy:2002
translate Spanish day3_2e4e78aa:

    # "It was a custom. A coming of age."
    "Era una costumbre. Un rito de iniciación."

# game/common.rpy:2004
translate Spanish day3_fb73e17a:

    # "At least, that's what she had always been taught."
    "Al menos, eso era lo que siempre le habían enseñado."

# game/common.rpy:2006
translate Spanish day3_52ad4621:

    # "She had always prepared herself for her turn."
    "Siempre se había preparado para su turno."

# game/common.rpy:2008
translate Spanish day3_71c2f27c:

    # "She had always dreamt of having her own hero."
    "Siempre había soñado con tener su propio héroe."

# game/common.rpy:2010
translate Spanish day3_fa24f3f2:

    # "-Becoming the female lead of her own fairy tale."
    "-Convertirse en la protagonista de su propio cuento de hadas."

# game/common.rpy:2012
translate Spanish day3_11b9fcc3:

    # "She had looked forward for that day-"
    "Esperaba con ansias ese día—"

# game/common.rpy:2014
translate Spanish day3_339f6249:

    # "But when the time actually came..."
    "Pero cuando finalmente llegó..."

# game/common.rpy:2016
translate Spanish day3_d7cf7672:

    # "She couldn't help but feel scared, alone and lonely."
    "No pudo evitar sentirse asustada, sola y abandonada."

# game/common.rpy:2018
translate Spanish day3_5680a2e0:

    # "It had been very different from how she had imagined."
    "Había sido muy diferente de como lo había imaginado."

# game/common.rpy:2020
translate Spanish day3_af64fcc2:

    # "It was nothing like the stories in her books."
    "No se parecía en nada a las historias de sus libros."

# game/common.rpy:2022
translate Spanish day3_d0deab70:

    # "All of them had brushed aside the princesses' experience of being locked up.{w} Of being the damsel in distress."
    "Todos pasaban por alto la experiencia de las princesas encerradas.{w} De ser la damisela en apuros."

# game/common.rpy:2024
translate Spanish day3_4639411f:

    # "They were always all about the hero's exciting adventure, and lastly, the princess' happy ending."
    "Siempre trataban sobre la emocionante aventura del héroe y, por último, el final feliz de la princesa."

# game/common.rpy:2026
translate Spanish day3_04c7d2a5:

    # "It never occurred to her before, of what {i}she{/i} would experience."
    "Nunca antes se le había ocurrido pensar en lo que {i}ella{/i} viviría."

# game/common.rpy:2028
translate Spanish day3_5f2da889:

    # "Unfortunate, but she couldn't just skip to the final page of her own story-"
    "Desafortunadamente, no podía simplemente pasar a la última página de su propia historia—"

# game/common.rpy:2030
translate Spanish day3_01cd983b:

    # "-The {i}{b}'happily ever after'{/b}{/i}."
    "-El {i}{b}'felices para siempre'{/b}{/i}."

# game/common.rpy:2032
translate Spanish day3_d8acf084:

    # "If there was one."
    "Si es que había uno."

# game/common.rpy:2034
translate Spanish day3_c549c0d7:

    # "Instead, she had broken down several times after months of imprisonment."
    "En cambio, se había derrumbado varias veces tras meses de encarcelamiento."

# game/common.rpy:2036
translate Spanish day3_20e158e6:

    # "At some point, she just... got used to it."
    "En algún momento, simplemente... se acostumbró."

# game/common.rpy:2038
translate Spanish day3_b736b2db:

    # "Or better yet, she had forced herself to accept this loneliness."
    "O mejor dicho, se obligó a aceptar esa soledad."

# game/common.rpy:2040
translate Spanish day3_12007a32:

    # "One could say that she had forgotten what it was like to be free."
    "Podría decirse que había olvidado cómo era ser libre."

# game/common.rpy:2042
translate Spanish day3_30bf268a:

    # "The only beacon of light that kept her going was the thought of her {i}'hero'{/i}- that someone would would whisk her away from that wintry land."
    "El único faro de luz que la mantenía en pie era el pensamiento de su {i}“héroe”{/i}: que alguien vendría a llevarla lejos de esa tierra invernal."

# game/common.rpy:2045
translate Spanish day3_d46b8bde:

    # "... The thought of a charming prince, a dashing adventurer or a mysterious sorcerer carrying her in their arms-"
    "... La idea de un príncipe encantador, un aventurero valiente o un misterioso hechicero cargándola en sus brazos—"

# game/common.rpy:2047
translate Spanish day3_da369b05:

    # "... The thought of being warmly welcomed back by her kingdom after suffering from the eternal cold."
    "... La idea de ser recibida calurosamente de nuevo por su reino después de sufrir en el frío eterno."

# game/common.rpy:2049
translate Spanish day3_a3f629df:

    # "... The thought of walking down the aisle with her savior, with her family by her side."
    "... La idea de caminar hacia el altar con su salvador, con su familia a su lado."

# game/common.rpy:2051
translate Spanish day3_1de748e1:

    # "These were all what she had been enduring this ordeal for."
    "Por todo eso había soportado esta prueba."

# game/common.rpy:2053
translate Spanish day3_863234d5:

    # "She deluded herself with her fantasies."
    "Se engañaba a sí misma con sus fantasías."

# game/common.rpy:2055
translate Spanish day3_e5906ea1:

    # "Anything to keep herself together."
    "Cualquier cosa con tal de mantenerse firme."

# game/common.rpy:2057
translate Spanish day3_3d7d8543:

    # "... But how much longer must she wait? How much longer could she keep that up?"
    "... Pero ¿cuánto más debía esperar? ¿Cuánto más podría soportarlo?"

# game/common.rpy:2059
translate Spanish day3_f88cc96c:

    # "It's been weeks, even Cethin's party hadn't picked him up yet."
    "Habían pasado semanas, incluso el grupo de Cethin aún no había venido por él."

# game/common.rpy:2061
translate Spanish day3_cfc9ae83:

    # "There was not a single peep from the outside either- other hero parties aiming to save her."
    "Tampoco había ni un solo indicio del exterior—ningún grupo de héroes intentando rescatarla."

# game/common.rpy:2063
translate Spanish day3_5ee2cbbc:

    # "The fear she had buried deep in her mind had resurfaced:"
    "El miedo que había enterrado en lo más profundo de su mente volvió a resurgir:"

# game/common.rpy:2065
translate Spanish day3_79cb9722:

    # "{i}{b}'What if no one ever comes?'{/b}{/i}"
    "{i}{b}“¿Y si nadie viene jamás?”{/b}{/i}"

# game/common.rpy:2067
translate Spanish day3_9a8e0df9:

    # "It frightened her.{w} So, so much..."
    "Le aterraba.{w} Mucho, muchísimo..."

# game/common.rpy:2069
translate Spanish day3_e609b264:

    # "Those were the thoughts she couldn't voice, even toward the demon butler."
    "Esos eran los pensamientos que no podía expresar, ni siquiera ante el mayordomo demonio."

# game/common.rpy:2071
translate Spanish day3_dbddaee1:

    # lumisad "Cethin..."
    lumisad "Cethin..."

# game/common.rpy:2073
translate Spanish day3_b2084e88:

    # "Really, the only thing that had kept her distracted these days were her companion's tales."
    "En verdad, lo único que la mantenía distraída en esos días eran los relatos de su compañero."

# game/common.rpy:2075
translate Spanish day3_e391e21d:

    # "Instead of agonizing over her fear, or fantasizing about her hero, and what comes after..."
    "En lugar de atormentarse con su miedo o fantasear con su héroe y lo que vendría después..."

# game/common.rpy:2077
translate Spanish day3_8a1f00bc:

    # "Her mind was instead pre-occupied with the world outside."
    "Su mente estaba ocupada con el mundo exterior."

# game/common.rpy:2079
translate Spanish day3_4c220dd9:

    # "Tales of the world she had yet to see, people, beings and races she had yet to meet..."
    "Relatos de un mundo que aún no había visto, personas, seres y razas que aún no había conocido..."

# game/common.rpy:2081
translate Spanish day3_f9983e05:

    # "Even though she was still cooped up, the night elf's songs allowed her imagination to wander and break free."
    "Aunque seguía encerrada, las canciones del elfo nocturno permitían que su imaginación vagara y se liberara."

# game/common.rpy:2083
translate Spanish day3_f72693e8:

    # "Within that small room, her world expanded on its own."
    "Dentro de esa pequeña habitación, su mundo se expandía por sí solo."

# game/common.rpy:2085
translate Spanish day3_801b63fa:

    # "The night elf, Cethin, had shared his world with hers."
    "El elfo nocturno, Cethin, había compartido su mundo con el de ella."

# game/common.rpy:2087
translate Spanish day3_7c8e5d0d:

    # "Thanks to him, her world felt brighter. Warmer."
    "Gracias a él, su mundo se sentía más brillante. Más cálido."

# game/common.rpy:2089
translate Spanish day3_0e7bea51:

    # lumithink "(It seems that I miss him already...)"
    lumithink "(Parece que ya lo extraño...)"

# game/common.rpy:2093
translate Spanish day3_ed3c90ee:

    # voice "voice1/line56.mp3"
    # who "Princess...? What happened-"
    voice "voice1/line56.mp3"
    who "¿Princesa...? ¿Qué pasó—"

# game/common.rpy:2103
translate Spanish day3_c63845b7:

    # "Immediately, her head flicked to the direction of the familiar voice."
    "De inmediato, su cabeza giró hacia la dirección de la voz familiar."

# game/common.rpy:2105
translate Spanish day3_bea8964e:

    # lumisickshock "Cethin...!"
    lumisickshock "¡Cethin...!"

# game/common.rpy:2107
translate Spanish day3_7c5b1b76:

    # "She was teary eyed."
    "Tenía los ojos llorosos."

# game/common.rpy:2109
translate Spanish day3_5a65ac1e:

    # voice "voice1/line57.mp3"
    # cethin "I didn't expect you to wake up early..."
    voice "voice1/line57.mp3"
    cethin "No esperaba que despertaras tan temprano..."

# game/common.rpy:2113
translate Spanish day3_361ab4db:

    # "The dark elf was atop the balcony railing. He wasn't wearing his usual cape, but he seemed to be holding something he covered with it."
    "El elfo oscuro estaba sobre la barandilla del balcón. No llevaba su capa habitual, pero parecía sostener algo cubierto con ella."

# game/common.rpy:2119
translate Spanish day3_c4263e58:

    # "Without wasting another moment, Cethin hopped off the railing and walked up the to girl."
    "Sin perder otro momento, Cethin saltó de la barandilla y se acercó a la chica."

# game/common.rpy:2121
translate Spanish day3_2cbde8f3:

    # voice "voice1/line58.mp3"
    # cethin "Did something happen? Why were you down there?"
    voice "voice1/line58.mp3"
    cethin "¿Pasó algo? ¿Por qué estabas ahí abajo?"

# game/common.rpy:2125
translate Spanish day3_c0e281cc:

    # "He asked with worry."
    "Preguntó con preocupación."

# game/common.rpy:2127
translate Spanish day3_5edc8310:

    # "So many emotions struggled within her."
    "Dentro de ella se agitaban muchas emociones."

# game/common.rpy:2129
translate Spanish day3_b5da1cec:

    # "She was unsure how to express them all."
    "No estaba segura de cómo expresarlas todas."

# game/common.rpy:2131
translate Spanish day3_18787ae1:

    # "-That everything just spilled out."
    "—Y entonces, todo simplemente se desbordó."

# game/common.rpy:2133
translate Spanish day3_a4fe63a0:

    # lumisad "{i}I am fine...{/i}{w} -to say that would be a lie."
    lumisad "{i}Estoy bien...{/i}{w} —decir eso sería una mentira."

# game/common.rpy:2137
translate Spanish day3_2bfeb7c9:

    # lumiserious "This is all your fault...!"
    lumiserious "¡Esto es todo tu culpa...!"

# game/common.rpy:2139
translate Spanish day3_1c8b4c09:

    # "She replied with a trembling voice."
    "Respondió con una voz temblorosa."

# game/common.rpy:2141
translate Spanish day3_13ba36fa:

    # lumisad "I had thought you left!"
    lumisad "¡Pensé que te habías ido!"

# game/common.rpy:2143
translate Spanish day3_998177b3:

    # lumisad "I was worried...{w} I was scared!{w} I was lonely..."
    lumisad "Estaba preocupada...{w} ¡Tenía miedo!{w} Estaba sola..."

# game/common.rpy:2148
translate Spanish day3_ebb2c24d:

    # voice "voice1/line59.mp3"
    # cethin "...Oh."
    voice "voice1/line59.mp3"
    cethin "...Oh."

# game/common.rpy:2152
translate Spanish day3_f890059e:

    # "The dark elf's gaze fell to the ground, clearly, he felt bad about it."
    "La mirada del elfo oscuro cayó al suelo; claramente, se sentía mal por ello."

# game/common.rpy:2154
translate Spanish day3_0e11cb10:

    # voice "voice1/line60.mp3"
    # cethin "I'm sorry I didn't tell you. I was hoping to return before you wake up."
    voice "voice1/line60.mp3"
    cethin "Lamento no habértelo dicho. Esperaba volver antes de que despertaras."

# game/common.rpy:2158
translate Spanish day3_46c85f95:

    # cethin "..."
    cethin "..."

# game/common.rpy:2162
translate Spanish day3_7ab232bb:

    # "He slowly tried to return his gaze on the girl, only to see that she still looked rather upset."
    "Lentamente intentó volver a mirarla, solo para ver que ella seguía bastante molesta."

# game/common.rpy:2166
translate Spanish day3_03ee6747:

    # "In the end, he couldn't bring himself to look at her."
    "Al final, no pudo obligarse a sostener su mirada."

# game/common.rpy:2170
translate Spanish day3_3c7f0ac5:

    # voice "voice1/line61.mp3"
    # cethin "I'm really, really sorry..."
    voice "voice1/line61.mp3"
    cethin "Lo siento... de verdad, lo siento mucho..."

# game/common.rpy:2174
translate Spanish day3_fd1d0502:

    # voice "voice1/line62.mp3"
    # cethin "I just wanted to repay you for everything you've done for me..."
    voice "voice1/line62.mp3"
    cethin "Solo quería compensarte por todo lo que has hecho por mí..."

# game/common.rpy:2178
translate Spanish day3_4c9aff8b:

    # voice "voice1/line63.mp3"
    # cethin "So..."
    voice "voice1/line63.mp3"
    cethin "Así que..."

# game/common.rpy:2182
translate Spanish day3_46c85f95_1:

    # cethin "..."
    cethin "..."

# game/common.rpy:2184
translate Spanish day3_a9998d73:

    # "Once again, he clammed up."
    "Una vez más, se quedó callado."

# game/common.rpy:2186
translate Spanish day3_700ceeb7:

    # "His grip on the item he was holding tightened."
    "Su agarre sobre el objeto que sostenía se tensó."

# game/common.rpy:2188
translate Spanish day3_288f3432:

    # voice "voice1/line64.mp3"
    # cethin "... A-actually, never mind."
    voice "voice1/line64.mp3"
    cethin "... E-en realidad, olvídalo."

# game/common.rpy:2192
translate Spanish day3_e6b63ada:

    # voice "voice1/line65.mp3"
    # cethin "What was I thinking..."
    voice "voice1/line65.mp3"
    cethin "¿En qué estaba pensando...?"

# game/common.rpy:2196
translate Spanish day3_a32ea71d:

    # "The princess' eyes then fell on the item he had been tightly clinging onto."
    "Los ojos de la princesa se posaron entonces en el objeto que él había estado aferrando con fuerza."

# game/common.rpy:2198
translate Spanish day3_1ef4cc60:

    # lumiserious "Speak."
    lumiserious "Habla."

# game/common.rpy:2202
translate Spanish day3_3a82031a:

    # voice "voice1/line66.mp3"
    # cethin "... Huh?"
    voice "voice1/line66.mp3"
    cethin "¿Eh...?"

# game/common.rpy:2206
translate Spanish day3_6a1b5096:

    # lumitalk "Speak what you'd like to say."
    lumitalk "Di lo que quieras decir."

# game/common.rpy:2208
translate Spanish day3_c4d8e74e:

    # lumisad "It isn't fair if I am the only one to speak my mind."
    lumisad "No es justo que solo yo diga lo que pienso."

# game/common.rpy:2210
translate Spanish day3_d1e9de30:

    # lumisad "I am upset that you took off without a word."
    lumisad "Me molesta que te hayas ido sin decir una palabra."

# game/common.rpy:2212
translate Spanish day3_c643cc63:

    # lumisad "I was afraid that I'd be alone again."
    lumisad "Tenía miedo de volver a quedarme sola."

# game/common.rpy:2214
translate Spanish day3_224964aa:

    # lumisad "I was worried that you may have been captured!"
    lumisad "Me preocupaba que te hubieran capturado."

# game/common.rpy:2216
translate Spanish day3_21b8d72e:

    # lumishy "Your short time of absence reminded me how lonely it was being here..."
    lumishy "Tu breve ausencia me recordó lo solitario que es estar aquí..."

# game/common.rpy:2220
translate Spanish day3_8dba728a:

    # lumisad "Cethin, I wish you would give more credit to yourself."
    lumisad "Cethin, desearía que reconocieras más tus propios méritos."

# game/common.rpy:2222
translate Spanish day3_7045b58b:

    # lumisad "I owe you as much as you owe me, if not more."
    lumisad "Te debo tanto como tú me debes a mí, si no más."

# game/common.rpy:2226
translate Spanish day3_7dab3246:

    # lumisad "Your songs allowed me to experience the world you have seen."
    lumisad "Tus canciones me permitieron experimentar el mundo que has visto."

# game/common.rpy:2228
translate Spanish day3_d06ef1a2:

    # lumisad "Your mere presence brings warmth to this cold, desolate place."
    lumisad "Tu mera presencia trae calidez a este lugar frío y desolado."

# game/common.rpy:2230
translate Spanish day3_96a217d3:

    # lumisad "You have no idea how much joy you've brought me..."
    lumisad "No tienes idea de cuánta alegría me has dado..."

# game/common.rpy:2232
translate Spanish day3_079c512a:

    # lumitalk "So, if I had offended you, or if I had been suffocating you here with me, just tell me."
    lumitalk "Así que, si te ofendí, o si te he estado asfixiando teniéndote aquí conmigo, solo dímelo."

# game/common.rpy:2234
translate Spanish day3_a0a6f742:

    # lumisad "If you truly wish to leave...{w} I'll even accept it."
    lumisad "Si realmente deseas irte...{w} lo aceptaré."

# game/common.rpy:2236
translate Spanish day3_3d4145bd:

    # lumisad "But...{w} just...{w} Please don't just leave without a word..."
    lumisad "Pero...{w} solo...{w} por favor no te vayas sin decir nada..."

# game/common.rpy:2238
translate Spanish day3_96723f33:

    # "Her words were blunt. There was no hesitation to them."
    "Sus palabras fueron directas. No había vacilación en ellas."

# game/common.rpy:2240
translate Spanish day3_e4cd2f7c:

    # "Cethin himself looked rather taken aback by her honest words."
    "El propio Cethin parecía sorprendido por su sinceridad."

# game/common.rpy:2242
translate Spanish day3_810c4017:

    # lumitalk "So, speak to me. Do not hesitate."
    lumitalk "Así que, háblame. No dudes."

# game/common.rpy:2244
translate Spanish day3_69d9672a:

    # "She said sternly."
    "Dijo con firmeza."

# game/common.rpy:2246
translate Spanish day3_2563f552:

    # voice "voice1/line67.mp3"
    # cethin "... Princess Lumi-"
    voice "voice1/line67.mp3"
    cethin "... Princesa Lumi—"

# game/common.rpy:2250
translate Spanish day3_0750b9b8:

    # "He rubbed the back of his head."
    "Se rascó la nuca."

# game/common.rpy:2252
translate Spanish day3_60c5daa0:

    # voice "voice1/line68.mp3"
    # cethin "I just wanted to repay you for everything you've done for me."
    voice "voice1/line68.mp3"
    cethin "Solo quería devolverte algo por todo lo que has hecho por mí."

# game/common.rpy:2256
translate Spanish day3_87845d0a:

    # voice "voice1/line69.mp3"
    # cethin "There's not much I can offer..."
    voice "voice1/line69.mp3"
    cethin "No tengo mucho que ofrecer..."

# game/common.rpy:2259
translate Spanish day3_a4fd56b5:

    # voice "voice1/line70.mp3"
    # cethin "But when I heard your wish yesterday..."
    voice "voice1/line70.mp3"
    cethin "Pero cuando escuché tu deseo ayer..."

# game/common.rpy:2264
translate Spanish day3_e629c5c3:

    # lumisad "(Wish?)"
    lumisad "(¿Deseo?)"

# game/common.rpy:2266
translate Spanish day3_c431325d:

    # cethin "I thought... I might give it a try."
    cethin "Pensé... que podría intentarlo."

# game/common.rpy:2273
translate Spanish day3_58d308db:

    # "He walked inside the princess' room and set down the item covered in his cape on the table."
    "Entró en la habitación de la princesa y colocó el objeto cubierto con su capa sobre la mesa."

# game/common.rpy:2275
translate Spanish day3_aabcfb53:

    # "The princess had been out for quite a while, making it almost time for breakfast."
    "La princesa había estado afuera un buen rato, ya casi era hora del desayuno."

# game/common.rpy:2277
translate Spanish day3_03249802:

    # "Without another word, he unwrapped the cloth, revealing two plates stacked on top of each other."
    "Sin decir nada más, desenvolvió la tela, revelando dos platos apilados uno sobre otro."

# game/common.rpy:2279
translate Spanish day3_ca669cf3:

    # "The top plate was stacked upside down, covering the bottom one."
    "El plato superior estaba boca abajo, cubriendo el inferior."

# game/common.rpy:2283
translate Spanish day3_f2dca559:

    # "He seemed to have also brought some utensils on the side."
    "También parecía haber traído algunos cubiertos al lado."

# game/common.rpy:2292
translate Spanish day3_e3756cf1:

    # "The princess peered curiously, when the dark elf finally lifted the top plate, releasing a warm scent."
    "La princesa miró con curiosidad, cuando el elfo oscuro finalmente levantó el plato superior, dejando escapar un aroma cálido."

# game/common.rpy:2294
translate Spanish day3_438029d5:

    # "There were fried eggs, bread, a few slices of meat...{w} and they looked simply scrumptious."
    "Había huevos fritos, pan, unas cuantas rebanadas de carne...{w} y se veían simplemente deliciosos."

# game/common.rpy:2296
translate Spanish day3_5a352c8e:

    # lumishock "This is...?"
    lumishock "Esto es...?"

# game/common.rpy:2298
translate Spanish day3_725016bf:

    # "She blinked."
    "Parpadeó."

# game/common.rpy:2305
translate Spanish day3_acdb5678:

    # cethin "I um... tried to cook you breakfast."
    cethin "Yo, eh... intenté prepararte el desayuno."

# game/common.rpy:2307
translate Spanish day3_8463eb98:

    # cethin "I'm sorry... this was foolish of me, I should have considered that you're-"
    cethin "Lo siento... fue una tontería de mi parte, debí considerar que tú—"

# game/common.rpy:2311
translate Spanish day3_7cfe62b0:

    # "Before he could finish, the princess had picked up a piece of bread and took a nibble."
    "Antes de que pudiera terminar, la princesa tomó un pedazo de pan y le dio un pequeño mordisco."

# game/common.rpy:2313
translate Spanish day3_e1decf32:

    # cethin "Ah-"
    cethin "Ah—"

# game/common.rpy:2317
translate Spanish day3_26844df0:

    # lumishock "Goodness...!"
    lumishock "¡Dios mío...!"

# game/common.rpy:2319
translate Spanish day3_e7d29c1e:

    # "... And from a nibble, she took a bite."
    "... Y de un mordisco pequeño, dio una gran mordida."

# game/common.rpy:2321
translate Spanish day3_d87836f5:

    # "Cethin could only watch anxiously."
    "Cethin solo pudo mirar con ansiedad."

# game/common.rpy:2325
translate Spanish day3_cfbeaec4:

    # lumihappy "Cethin, this is heavenly!"
    lumihappy "¡Cethin, esto es celestial!"

# game/common.rpy:2329
translate Spanish day3_b6e7bd3a:

    # lumi "Well, I would not say it is as good as the palace's, but this is truly good!"
    lumi "Bueno, no diría que es tan bueno como el del palacio, ¡pero esto está realmente delicioso!"

# game/common.rpy:2331
translate Spanish day3_026279db:

    # lumitalk "Did you make this?"
    lumitalk "¿Lo hiciste tú?"

# game/common.rpy:2333
translate Spanish day3_3cf173a5:

    # cethin "Er... I'm not well accustomed to baking, but yes."
    cethin "Eh... No estoy muy acostumbrado a hornear, pero sí."

# game/common.rpy:2335
translate Spanish day3_af762926:

    # "With that, she sat on the chair and started on the rest of the meal on the plate."
    "Con eso, ella se sentó en la silla y comenzó con el resto de la comida en el plato."

# game/common.rpy:2337
translate Spanish day3_fb399a0f:

    # lumishock "My! The eggs are cooked just right. I could tell that you've added some sugar?"
    lumishock "¡Vaya! Los huevos están cocidos en su punto. ¿Se nota que les has añadido algo de azúcar?"

# game/common.rpy:2339
translate Spanish day3_96ec6afd:

    # lumihappy "The meat is crisp and the seasoning isn't overpowering at all."
    lumihappy "La carne está crujiente y el condimento no es nada abrumador."

# game/common.rpy:2341
translate Spanish day3_eb87a5d4:

    # lumiwish "The bread is soft and moist, very unlike the usual crusty ones they've been serving me here."
    lumiwish "El pan es suave y húmedo, muy diferente de los habituales panes crujientes que me han estado sirviendo aquí."

# game/common.rpy:2343
translate Spanish day3_2909e260:

    # "She continued with her early breakfast, until the plate was left clean..."
    "Continuó con su desayuno temprano, hasta que el plato quedó limpio..."

# game/common.rpy:2345
translate Spanish day3_01ee2f21:

    # lumihappy "I haven't had such good meal in such a long time."
    lumihappy "No había tenido una comida tan buena en tanto tiempo."

# game/common.rpy:2347
translate Spanish day3_21149ac5:

    # "The princess declared contentedly, almost as if she had forgotten what happened earlier."
    "Declaró la princesa con satisfacción, casi como si hubiera olvidado lo ocurrido antes."

# game/common.rpy:2351
translate Spanish day3_37b559d9:

    # cethin "I'm glad you enjoyed it... but you don't need to force yourself to give compliments..."
    cethin "Me alegra que lo hayas disfrutado... pero no tienes que obligarte a dar cumplidos..."

# game/common.rpy:2355
translate Spanish day3_98d5cf97:

    # lumided "Oh, make no mistake- it's quite good, but it still pales in comparison to food in the palace!"
    lumided "Oh, no te equivoques— está bastante bueno, ¡pero aún palidece en comparación con la comida del palacio!"

# game/common.rpy:2357
translate Spanish day3_0863381a:

    # "She replied casually."
    "Respondió con naturalidad."

# game/common.rpy:2361
translate Spanish day3_4fda1114:

    # lumihappy "Though, it does beat the food here."
    lumihappy "Aunque, sí supera la comida de aquí."

# game/common.rpy:2365
translate Spanish day3_314cbf55:

    # cethin "Oh. I see."
    cethin "Oh. Ya veo."

# game/common.rpy:2367
translate Spanish day3_9846f4a6:

    # "Somehow, he seemed to have felt better about this?"
    "De alguna forma, pareció sentirse mejor con eso."

# game/common.rpy:2369
translate Spanish day3_de50a427:

    # "The princess smiled."
    "La princesa sonrió."

# game/common.rpy:2371
translate Spanish day3_764d9cb5:

    # "The anxiety she had been carrying just a while back had instantly melted off."
    "La ansiedad que había cargado hasta hace un momento se desvaneció al instante."

# game/common.rpy:2373
translate Spanish day3_1eb14885:

    # lumisad "(So... this was what he had busied himself with.)"
    lumisad "(Entonces... en esto fue en lo que se ocupó.)"

# game/common.rpy:2375
translate Spanish day3_2fc5bc8d:

    # lumisad "(In the end, I had no reason to worry about?)"
    lumisad "(Al final, ¿no tenía razón para preocuparme?)"

# game/common.rpy:2377
translate Spanish day3_13f0a71d:

    # "His gesture sparked happiness for her once again."
    "Su gesto volvió a encender la felicidad en ella."

# game/common.rpy:2379
translate Spanish day3_946851c6:

    # "Yet, she couldn't help but feel something heavy within her heart."
    "Y aun así, no pudo evitar sentir algo pesado en su corazón."

# game/common.rpy:2381
translate Spanish day3_db406a49:

    # "-The thought that he went through all the trouble just so he could express his gratitude."
    "—El pensamiento de que él se había tomado tantas molestias solo para expresar su gratitud."

# game/common.rpy:2383
translate Spanish day3_c2970786:

    # "And from a simple passing complaint from her at that."
    "Y todo por una simple queja pasajera de ella."

# game/common.rpy:2385
translate Spanish day3_3f12d94c:

    # lumisad "(He really didn't have to...)"
    lumisad "(Realmente no tenía que hacerlo...)"

# game/common.rpy:2387
translate Spanish day3_97c2f9d4:

    # lumishy "(Why does he make me too happy?)"
    lumishy "(¿Por qué me hace tan feliz?)"

# game/common.rpy:2391
translate Spanish day3_9e4c2c7f:

    # cethin "Then... then if you'd like, I can keep cooking your meals?"
    cethin "Entonces... entonces, si quieres, ¿puedo seguir cocinando tus comidas?"

# game/common.rpy:2393
translate Spanish day3_30bd73df:

    # lumisad "As much as I'd love to... wouldn't it be dangerous on your part?"
    lumisad "Por más que me encantaría... ¿no sería peligroso para ti?"

# game/common.rpy:2397
translate Spanish day3_1d47321f:

    # cethin "Worry not, it's not difficult to slip out and borrow the kitchen."
    cethin "No te preocupes, no es difícil escabullirme y tomar prestada la cocina."

# game/common.rpy:2399
translate Spanish day3_e156207f:

    # lumided "(Somehow, there's so much wrong with that...)"
    lumided "(De alguna forma, hay tantas cosas mal con eso...)"

# game/common.rpy:2401
translate Spanish day3_f8381938:

    # lumihappy "If you are certain about it, then by all means."
    lumihappy "Si estás seguro de ello, entonces adelante."

# game/common.rpy:2403
translate Spanish day3_e3adea67:

    # lumisad "(If he is capable of moving about, I have no reason to detain him...)"
    lumisad "(Si él es capaz de moverse, no tengo razón para detenerlo...)"

# game/common.rpy:2405
translate Spanish day3_3137cba7:

    # lumisad "(Otherwise, he'd be a prisoner of mine.)"
    lumisad "(De lo contrario, sería un prisionero mío.)"

# game/common.rpy:2407
translate Spanish day3_39325199:

    # lumisad "(I'd be no better than the demon lord...)"
    lumisad "(No sería mejor que el señor demonio...)"

# game/common.rpy:2411
translate Spanish day3_ad31ebb6:

    # lumitalk "Do know that if we get caught, you might get punished..."
    lumitalk "Debes saber que si nos atrapan, podrías ser castigado..."

# game/common.rpy:2413
translate Spanish day3_d3b7e19a:

    # lumisad "They would never lay a hand on me... you, however... well, who knows?"
    lumisad "Jamás se atreverían a tocarme... tú, sin embargo... bueno, quién sabe."

# game/common.rpy:2417
translate Spanish day3_99bb121e:

    # lumitalk "They might feed you to the demonic beast in the basement."
    lumitalk "Quizás te den de comer a la bestia demoníaca del sótano."

# game/common.rpy:2421
translate Spanish day3_46c85f95_2:

    # cethin "..."
    cethin "..."

# game/common.rpy:2423
translate Spanish day3_a1a81655:

    # "The dark elf gulped."
    "El elfo oscuro tragó saliva."

# game/common.rpy:2425
translate Spanish day3_ec093166:

    # lumihappy "I will try my best to aid your escape in case that happens, so do not think much of it."
    lumihappy "Haré todo lo posible por ayudarte a escapar si eso ocurre, así que no pienses mucho en ello."

# game/common.rpy:2429
translate Spanish day3_46c85f95_3:

    # cethin "..."
    cethin "..."

# game/common.rpy:2431
translate Spanish day3_ef257015:

    # "He's definitely unconvinced."
    "Definitivamente no está convencido."

# game/common.rpy:2435
translate Spanish day3_921bb2fc:

    # cethin "I'll be careful, Princess Lumi."
    cethin "Tendré cuidado, Princesa Lumi."

# game/common.rpy:2439
translate Spanish day3_1d5098f6:

    # "Even still, he seemed determined to keep up with that."
    "Aun así, parecía decidido a seguir con eso."

# game/common.rpy:2441
translate Spanish day3_a9374e95:

    # lumitalk "All right, but promise me..."
    lumitalk "Está bien, pero prométeme algo..."

# game/common.rpy:2445
translate Spanish day3_6cf4e054:

    # lumi "Do not leave again without a word, yes?"
    lumi "No vuelvas a irte sin decir nada, ¿sí?"

# game/common.rpy:2450
translate Spanish day3_e2a0ad73:

    # cethin "... I-{w} Okay..."
    cethin "... E-{w} Está bien..."

# game/common.rpy:2454
translate Spanish day3_d6d40fe4:

    # lumihappy "Good answer."
    lumihappy "Buena respuesta."

# game/common.rpy:2458
translate Spanish day3_a184cea7:

    # lumisad "And-{w} I'd also like to apologize about earlier."
    lumisad "Y-{w} También me gustaría disculparme por lo de antes."

# game/common.rpy:2460
translate Spanish day3_cbfe97a1:

    # lumisad "Perhaps I may have acted irrationally."
    lumisad "Quizás actué de forma irracional."

# game/common.rpy:2462
translate Spanish day3_2986022b:

    # lumisad "I mean, you were only gone for a moment after all."
    lumisad "Digo, después de todo, solo te habías ido un momento."

# game/common.rpy:2464
translate Spanish day3_a9f142b3:

    # "The princess lowered her head."
    "La princesa bajó la cabeza."

# game/common.rpy:2468
translate Spanish day3_32a60d06:

    # cethin "Oh, no... You don't need to apologize for that!"
    cethin "Oh, no... ¡No necesitas disculparte por eso!"

# game/common.rpy:2473
translate Spanish day3_184eb525:

    # cethin "Certainly, I was surprised... but..."
    cethin "Ciertamente, me sorprendió... pero..."

# game/common.rpy:2475
translate Spanish day3_77db852f:

    # "He trailed off for a bit."
    "Se detuvo por un momento."

# game/common.rpy:2480
translate Spanish day3_72568569:

    # cethin "{size=-5}It actually made me happy...{/size}"
    cethin "{size=-5}En realidad me hizo feliz...{/size}"

# game/common.rpy:2482
translate Spanish day3_1c4b92b4:

    # lumitalk "Huh? What was that?"
    lumitalk "¿Eh? ¿Qué fue eso?"

# game/common.rpy:2487
translate Spanish day3_7d213dba:

    # cethin "Ah- no! No... never mind!" with vpunch
    cethin "Ah- no! No... ¡olvídalo!" with vpunch

# game/common.rpy:2492
translate Spanish day3_46c85f95_4:

    # cethin "..."
    cethin "..."

# game/common.rpy:2496
translate Spanish day3_83b9d7c2:

    # lumi "...?"
    lumi "¿...?"

# game/common.rpy:2502
translate Spanish sickvisit_af05fed7:

    # "Ever since Cethin's arrival, Lumi's quality of life had improved."
    "Desde la llegada de Cethin, la calidad de vida de Lumi había mejorado."

# game/common.rpy:2504
translate Spanish sickvisit_3d9cc337:

    # "Each passing day became much more tolerable."
    "Cada día que pasaba se volvía mucho más tolerable."

# game/common.rpy:2506
translate Spanish sickvisit_938c3229:

    # "She found herself having more and more things to look forward to."
    "Cada vez tenía más cosas que esperar con ilusión."

# game/common.rpy:2508
translate Spanish sickvisit_8ed321e4:

    # "No longer did she have to talk to herself for entertainment."
    "Ya no tenía que hablar sola para entretenerse."

# game/common.rpy:2510
translate Spanish sickvisit_6c937a06:

    # "No longer did she have to eat bland or overly seasoned meals."
    "Ya no tenía que comer comidas insípidas o demasiado condimentadas."

# game/common.rpy:2512
translate Spanish sickvisit_bf5470eb:

    # "No longer was she alone."
    "Ya no estaba sola."

# game/common.rpy:2514
translate Spanish sickvisit_27102562:

    # "Weeks have passed, yet there still was no sign of the hero's party returning, nor of another hero's party on the way."
    "Pasaron semanas, y aún no había señales del regreso del grupo del héroe, ni de otro grupo de héroes en camino."

# game/common.rpy:2516
translate Spanish sickvisit_cb44dfda:

    # "... Not that she had paid mind to it, as her attention was almost always on her new friend's tales, or his meals... or whatever new thing he decided to share with her."
    "... No es que ella le prestara atención, pues casi siempre tenía sus pensamientos centrados en las historias de su nuevo amigo, o en sus comidas... o en cualquier cosa nueva que él decidiera compartir con ella."

# game/common.rpy:2519
translate Spanish sickvisit_ccf6913b:

    # "But that one particular day, neither expected that they'd be sharing more..."
    "Pero ese día en particular, ninguno de los dos esperaba que acabaran compartiendo más..."

# game/common.rpy:2525
translate Spanish sickvisit_f5cfbd89:

    # lumisick "(I feel heavy... my throat hurts... my head aches...)"
    lumisick "(Me siento pesada... me duele la garganta... me duele la cabeza...)"

# game/common.rpy:2527
translate Spanish sickvisit_6654bdb2:

    # lumisick "(I might have caught a cold...?)"
    lumisick "(¿Podría haberme resfriado...?)"

# game/common.rpy:2529
translate Spanish sickvisit_0a10fb2c:

    # lumisick "..."
    lumisick "..."

# game/common.rpy:2531
translate Spanish sickvisit_376ff93d:

    # lumisickshock "(Could this be the {i}sick visit{/i} event?!)" with vpunch
    lumisickshock "(¿¡Podría ser este el evento de {i}visita por enfermedad{/i}?!)" with vpunch

# game/common.rpy:2533
translate Spanish sickvisit_4442878b:

    # lumisicksmile "(... Nonsense. It isn't like there's anyone who would visit.)"
    lumisicksmile "(... Tonterías. No es como si hubiera alguien que viniera a visitarme.)"

# game/common.rpy:2535
translate Spanish sickvisit_cda6cd73:

    # lumisicksmile "(Well... there's Cethin.)"
    lumisicksmile "(Bueno... está Cethin.)"

# game/common.rpy:2537
translate Spanish sickvisit_2b0ae4c7:

    # lumisick "(Not that I am expecting him to take care of me...)"
    lumisick "(No es que espere que él cuide de mí...)"

# game/common.rpy:2539
translate Spanish sickvisit_0a10fb2c_1:

    # lumisick "..."
    lumisick "..."

# game/common.rpy:2541
translate Spanish sickvisit_ad700ec1:

    # lumisickshock "(O-of course, Cethin would no doubt care for me since he is kind...)"
    lumisickshock "(P-por supuesto, Cethin sin duda se preocuparía por mí, ya que es amable...)"

# game/common.rpy:2543
translate Spanish sickvisit_9b320944:

    # lumisick "(... He would, right?)"
    lumisick "(... Lo haría, ¿verdad?)"

# game/common.rpy:2545
translate Spanish sickvisit_172b4874:

    # lumisickhappy "(I can certainly imagine him making porridge...)"
    lumisickhappy "(Puedo imaginarlo preparando una papilla...)"

# game/common.rpy:2547
translate Spanish sickvisit_b7aafe5c:

    # lumisicksmile "(And then he'll help me up, and insist that he feeds me despite my objections...)"
    lumisicksmile "(Y luego me ayudaría a levantarme, e insistiría en alimentarme a pesar de mis objeciones...)"

# game/common.rpy:2549
translate Spanish sickvisit_9bbdb1ac:

    # lumisicksmile "(In the end, I'd accept his kindness, and then he'd help put me to sleep.)"
    lumisicksmile "(Al final, aceptaría su amabilidad, y luego él me ayudaría a dormir.)"

# game/common.rpy:2551
translate Spanish sickvisit_8ae5786f:

    # lumisicksmile "(He'd probably try to sing me to sleep, but it'll be out of tune as always.)"
    lumisicksmile "(Probablemente intentaría cantarme para dormir, pero estaría desafinado como siempre.)"

# game/common.rpy:2553
translate Spanish sickvisit_0a10fb2c_2:

    # lumisick "..."
    lumisick "..."

# game/common.rpy:2555
translate Spanish sickvisit_d2f19648:

    # lumisickshock "(Goodness...! What am I thinking?!)" with vpunch
    lumisickshock "(¡Dios mío...! ¿En qué estoy pensando?!)" with vpunch

# game/common.rpy:2559
translate Spanish sickvisit_3fddce52:

    # "She pulled a blanket over her face and closed her eyes, feeling even hotter."
    "Se cubrió la cara con la manta y cerró los ojos, sintiéndose aún más acalorada."

# game/common.rpy:2561
translate Spanish sickvisit_0262b568:

    # lumisick "(Why am I thinking of such things? How embarrassing...)"
    lumisick "(¿Por qué estoy pensando en esas cosas? Qué vergüenza...)"

# game/common.rpy:2563
translate Spanish sickvisit_f5b25bf8:

    # lumisick "(Thankfully, night elves have no ability to read minds.)"
    lumisick "(Afortunadamente, los elfos nocturnos no tienen la capacidad de leer mentes.)"

# game/common.rpy:2565
translate Spanish sickvisit_0a10fb2c_3:

    # lumisick "..."
    lumisick "..."

# game/common.rpy:2567
translate Spanish sickvisit_75f81f1c:

    # lumisick "... They don't, right?"
    lumisick "... ¿Verdad?"

# game/common.rpy:2569
translate Spanish sickvisit_2f56c88e:

    # lumisick "(This isn't good for my health...)"
    lumisick "(Esto no es bueno para mi salud...)"

# game/common.rpy:2573
translate Spanish sickvisit_8a4df4c7:

    # "The princess took a few deep breaths before taking the blanket off and sat herself up."
    "La princesa respiró profundamente unas cuantas veces antes de quitarse la manta y sentarse."

# game/common.rpy:2575
translate Spanish sickvisit_342888a0:

    # lumisick "(Speaking of... where is he?)"
    lumisick "(Hablando de eso... ¿dónde está él?)"

# game/common.rpy:2577
translate Spanish sickvisit_c39c99dc:

    # lumisick "Cethin...?"
    lumisick "¿Cethin...?"

# game/common.rpy:2579
translate Spanish sickvisit_5207a632:

    # "She tried to call out to him in a hoarse voice."
    "Trató de llamarlo con una voz ronca."

# game/common.rpy:2581
translate Spanish sickvisit_16e908d5:

    # lumisick "(Oh dear, my condition might be worse than I had thought...)"
    lumisick "(Oh, cielos, mi condición podría ser peor de lo que pensé...)"

# game/common.rpy:2583
translate Spanish sickvisit_a066b28a:

    # "The girl slowly forced herself off the bed."
    "La chica lentamente se obligó a levantarse de la cama."

# game/common.rpy:2585
translate Spanish sickvisit_fba35797:

    # "Her head throbbed, and she winced in pain."
    "Su cabeza palpitaba, y frunció el ceño de dolor."

# game/common.rpy:2587
translate Spanish sickvisit_fd4a78fd:

    # lumisick "(He hadn't left to cook breakfast yet, has he...?)"
    lumisick "(Él no se habrá ido a cocinar el desayuno todavía, ¿verdad...?)"

# game/common.rpy:2589
translate Spanish sickvisit_be38236f:

    # "Just as he had promised, Cethin would always tell her whenever he planned to leave the room."
    "Tal como había prometido, Cethin siempre le avisaba cuando planeaba salir de la habitación."

# game/common.rpy:2591
translate Spanish sickvisit_0119bf0e:

    # "Otherwise, he'd leave her a note by the bedside."
    "De lo contrario, le dejaba una nota junto a la cama."

# game/common.rpy:2593
translate Spanish sickvisit_e019d575:

    # "Today, he hadn't done so yet, and he wouldn't have left on his own, right...?"
    "Hoy no lo había hecho todavía, y no se habría ido por su cuenta, ¿cierto...?"

# game/common.rpy:2597
translate Spanish sickvisit_3b2c7022:

    # lumisick "(Perhaps he's in the closet?)"
    lumisick "(¿Quizás está en el armario?)"

# game/common.rpy:2599
translate Spanish sickvisit_38c4863f:

    # "Groggily, the princess took a few steps toward her wardrobe."
    "Adormilada, la princesa dio unos pasos hacia su guardarropa."

# game/common.rpy:2603
translate Spanish sickvisit_72354c8a:

    # "Her fingers wrapped around the cold handles of her closet..."
    "Sus dedos se aferraron a las frías manijas de su armario..."

# game/common.rpy:2612
translate Spanish sickvisit_77140eee:

    # lumisickshock "...!" with vpunch
    lumisickshock "...!" with vpunch

# game/common.rpy:2614
translate Spanish sickvisit_c68078bd:

    # "The dark elf just tumbled down on the floor as soon as she opened the wardrobe."
    "El elfo oscuro simplemente cayó al suelo tan pronto como ella abrió el armario."

# game/common.rpy:2616
translate Spanish sickvisit_7f432bff:

    # lumisickshock "Oh dear... C-cethin?"
    lumisickshock "Oh cielos... ¿C-cethin?"

# game/common.rpy:2618
translate Spanish sickvisit_2d4e0833:

    # "She crouched down to and touched his forehead."
    "Se agachó y tocó su frente."

# game/common.rpy:2620
translate Spanish sickvisit_f1e57a10:

    # lumisick "He's burning up..."
    lumisick "Está ardiendo..."

# game/common.rpy:2622
translate Spanish sickvisit_bd0aab31:

    # lumisick "(Did we somehow fall ill at the same time?)"
    lumisick "(¿Nos habremos enfermado los dos al mismo tiempo?)"

# game/common.rpy:2624
translate Spanish sickvisit_e41a1870:

    # cethin "... Pri... Lumi...?"
    cethin "... Pri... ¿Lumi...?"

# game/common.rpy:2626
translate Spanish sickvisit_cef1cfa4:

    # "His eyes flickered open, but he barely managed to speak."
    "Sus ojos parpadearon al abrirse, pero apenas logró hablar."

# game/common.rpy:2628
translate Spanish sickvisit_f276a6d2:

    # cethin "What... time? Need... to cook..."
    cethin "¿Qué... hora...? Necesito... cocinar..."

# game/common.rpy:2643
translate Spanish sickvisit_1ae03e28:

    # "He said weakly as he tried to get up, but he immediately ended up giving in and fell back on the floor."
    "Dijo débilmente mientras intentaba levantarse, pero inmediatamente cedió y volvió a caer al suelo."

# game/common.rpy:2645
translate Spanish sickvisit_aba3e490:

    # lumisick "It seems we've both fallen ill. You shouldn't go out today."
    lumisick "Parece que ambos hemos enfermado. No deberías salir hoy."

# game/common.rpy:2647
translate Spanish sickvisit_28261f92:

    # lumisick "(Oh dear... oh dear... what do we do? What does one do when someone is sick?)"
    lumisick "(Oh cielos... oh cielos... ¿qué hacemos? ¿Qué se hace cuando alguien está enfermo?)"

# game/common.rpy:2649
translate Spanish sickvisit_cc615ae0:

    # "She looked around, hoping to figure something out."
    "Miró a su alrededor, esperando encontrar una idea."

# game/common.rpy:2651
translate Spanish sickvisit_06eb110d:

    # "... Until her eyes just fell on the bed."
    "... Hasta que su mirada se posó en la cama."

# game/common.rpy:2653
translate Spanish sickvisit_216c799b:

    # lumisicksmile "Come Cethin, let's get ourselves on the bed."
    lumisicksmile "Ven, Cethin, vayamos a la cama."

# game/common.rpy:2655
translate Spanish sickvisit_1126c92f:

    # "She tried to help him up, but he pulled back."
    "Intentó ayudarlo a levantarse, pero él se apartó."

# game/common.rpy:2657
translate Spanish sickvisit_dadf5131:

    # cethin "I... I can't."
    cethin "Yo... no puedo."

# game/common.rpy:2659
translate Spanish sickvisit_919bdfcb:

    # cethin "Can't share... bed..."
    cethin "No puedo compartir... cama..."

# game/common.rpy:2661
translate Spanish sickvisit_97f2659a:

    # "He was a little flustered, though he can barely speak."
    "Estaba un poco nervioso, aunque apenas podía hablar."

# game/common.rpy:2663
translate Spanish sickvisit_5c980b24:

    # lumisick "Come on now, this isn't the time to fuss."
    lumisick "Vamos ahora, este no es momento para hacer escándalo."

# game/common.rpy:2665
translate Spanish sickvisit_139f6e7c:

    # lumisicksmile "Your condition is clearly worse than mine, and I couldn't possibly keep you in that wardrobe!"
    lumisicksmile "Tu condición está claramente peor que la mía, ¡y no podría dejarte en ese armario!"

# game/common.rpy:2667
translate Spanish sickvisit_f8c0e1c0:

    # cethin "... O-okay then."
    cethin "... E-está bien entonces."

# game/common.rpy:2673
translate Spanish sickvisit_ce092441:

    # "Perhaps it was because he was sick, but it didn't really take much effort to convince him."
    "Quizás porque estaba enfermo, no le costó mucho convencerlo."

# game/common.rpy:2675
translate Spanish sickvisit_e56468a7:

    # "With much difficulty, the princess managed to help him up the bed."
    "Con gran dificultad, la princesa logró ayudarlo a subir a la cama."

# game/common.rpy:2683
translate Spanish sickvisit_71da517c:

    # lumisickhappy "This isn't so bad now, is it?"
    lumisickhappy "Esto no está tan mal ahora, ¿verdad?"

# game/common.rpy:2685
translate Spanish sickvisit_bf9a40a8:

    # voice "voice1/line71.mp3"
    # cethin "... I'm sorry... for the trouble."
    voice "voice1/line71.mp3"
    cethin "... Lo siento... por las molestias."

# game/common.rpy:2689
translate Spanish sickvisit_19f4916c:

    # lumisicksmile "Goodness, is that still what you are worrying about?"
    lumisicksmile "Cielos, ¿eso es lo que todavía te preocupa?"

# game/common.rpy:2691
translate Spanish sickvisit_05e9ed17:

    # "She flicked his forehead."
    "Le dio un golpecito en la frente."

# game/common.rpy:2693
translate Spanish sickvisit_848eee0b:

    # lumisicksmile "Instead of apologizing, I'd much prefer to hear words of gratitude."
    lumisicksmile "En lugar de disculpas, preferiría escuchar palabras de gratitud."

# game/common.rpy:2695
translate Spanish sickvisit_34fcd7c7:

    # voice "voice1/line72.mp3"
    # cethin "... Alright then.{w} Thank you."
    voice "voice1/line72.mp3"
    cethin "... Está bien entonces.{w} Gracias."

# game/common.rpy:2699
translate Spanish sickvisit_6d218ddd:

    # lumisickhappy "Now, was that so hard?"
    lumisickhappy "¿Ves? No fue tan difícil."

# game/common.rpy:2701
translate Spanish sickvisit_bd08c164:

    # lumisicksmile "You've made me feel warm and fuzzy inside."
    lumisicksmile "Me has hecho sentir cálida y reconfortada por dentro."

# game/common.rpy:2703
translate Spanish sickvisit_4902edb1:

    # voice "voice1/line73.mp3"
    # cethin "Is... that... good? You're... already burning."
    voice "voice1/line73.mp3"
    cethin "¿E... eso es bueno? Tú... ya estás ardiendo."

# game/common.rpy:2707
translate Spanish sickvisit_4d1cee76:

    # lumisickhappy "Really now? You jest when you can barely speak."
    lumisickhappy "¿En serio? Bromeas cuando apenas puedes hablar."

# game/common.rpy:2709
translate Spanish sickvisit_c94fe9ed:

    # voice "voice1/line74.mp3"
    # cethin "Hehe..."
    voice "voice1/line74.mp3"
    cethin "Jeje..."

# game/common.rpy:2713
translate Spanish sickvisit_aaf2df2d:

    # lumisickshock "(He laughed...!)"
    lumisickshock "(¡Rió...!)"

# game/common.rpy:2715
translate Spanish sickvisit_f82f8582:

    # lumisicksmile "(I think this is the first time I've heard him stifle a laugh.)"
    lumisicksmile "(Creo que es la primera vez que lo oigo contener la risa.)"

# game/common.rpy:2717
translate Spanish sickvisit_c1bde541:

    # lumisickhappy "(It's... cute.)"
    lumisickhappy "(Es... tierno.)"

# game/common.rpy:2719
translate Spanish sickvisit_8627b4bb:

    # lumisicksmile "I shall let you slide this time."
    lumisicksmile "Te dejaré pasar esta vez."

# game/common.rpy:2721
translate Spanish sickvisit_3318ce30:

    # lumisicksmile "Let's sleep for now."
    lumisicksmile "Durmamos por ahora."

# game/common.rpy:2723
translate Spanish sickvisit_bad6371f:

    # voice "voice1/line75.mp3"
    # cethin "Lumi..."
    voice "voice1/line75.mp3"
    cethin "Lumi..."

# game/common.rpy:2727
translate Spanish sickvisit_4a3ee9e3:

    # lumisick "Hm?"
    lumisick "¿Hm?"

# game/common.rpy:2729
translate Spanish sickvisit_8de71c4d:

    # "He was practically half-asleep when he spoke."
    "Estaba prácticamente medio dormido cuando habló."

# game/common.rpy:2731
translate Spanish sickvisit_c3f29763:

    # voice "voice1/line76.mp3"
    # cethin "Can I... hold... your hand?"
    voice "voice1/line76.mp3"
    cethin "¿Puedo... sostener... tu mano?"

# game/common.rpy:2735
translate Spanish sickvisit_5c152aad:

    # lumisicksmile "Ah. Of course."
    lumisicksmile "Ah. Por supuesto."

# game/common.rpy:2740
translate Spanish sickvisit_99604bf5:

    # "His hands felt hot, but it was comfortable."
    "Sus manos se sentían calientes, pero era una sensación cómoda."

# game/common.rpy:2742
translate Spanish sickvisit_2c3d86fa:

    # "She could feel his calluses brushing against her soft fingers."
    "Podía sentir sus callos rozando sus suaves dedos."

# game/common.rpy:2744
translate Spanish sickvisit_02c18602:

    # lumisick "(Our hands are like night and day...)"
    lumisick "(Nuestras manos son como la noche y el día...)"

# game/common.rpy:2746
translate Spanish sickvisit_2bf646be:

    # lumisickhappy "(But I like it.)"
    lumisickhappy "(Pero me gusta.)"

# game/common.rpy:2748
translate Spanish sickvisit_b076ac83:

    # "As a princess, she had never worked in her life, naturally, her hands were very unlike the bard's."
    "Como princesa, nunca había trabajado en su vida; naturalmente, sus manos eran muy diferentes a las del bardo."

# game/common.rpy:2750
translate Spanish sickvisit_de290056:

    # "She could also feel small wounds around his fingers. It was no wonder- he often practiced with his instrument."
    "También podía sentir pequeñas heridas alrededor de sus dedos. No era de extrañar: él practicaba a menudo con su instrumento."

# game/common.rpy:2752
translate Spanish sickvisit_ad83e6b8:

    # lumisicksmile "(I could tell that he works hard.)"
    lumisicksmile "(Puedo notar que trabaja duro.)"

# game/common.rpy:2754
translate Spanish sickvisit_a2081c27:

    # voice "voice1/line77.mp3"
    # cethin "... Thank you."
    voice "voice1/line77.mp3"
    cethin "... Gracias."

# game/common.rpy:2758
translate Spanish sickvisit_54384211:

    # "His voice brought her fading consciousness back."
    "Su voz hizo que recuperara un poco la conciencia que se le estaba desvaneciendo."

# game/common.rpy:2760
translate Spanish sickvisit_a09ca352:

    # voice "voice1/line78.mp3"
    # cethin "Thank you... for everything."
    voice "voice1/line78.mp3"
    cethin "Gracias... por todo."

# game/common.rpy:2764
translate Spanish sickvisit_f9719ec0:

    # "His voice, his touch, his presence... everything about him made her feel comfortably warm."
    "Su voz, su tacto, su presencia... todo en él la hacía sentir cálida y reconfortada."

# game/common.rpy:2766
translate Spanish sickvisit_1066c92c:

    # lumisickhappy "Sleep well, Cethin."
    lumisickhappy "Duerme bien, Cethin."

# game/common.rpy:2768
translate Spanish sickvisit_2a574709:

    # voice "voice1/line79.mp3"
    # cethin "You too, Lumi..."
    voice "voice1/line79.mp3"
    cethin "Tú también, Lumi..."

# game/common.rpy:2772
translate Spanish sickvisit_ff73f119:

    # "It only took a moment for the two sleep soundly once again."
    "Solo pasó un momento antes de que ambos volvieran a dormir profundamente."

# game/common.rpy:2776
translate Spanish sickvisit_579b3821:

    # "...................................."
    "...................................."

# game/common.rpy:2783
translate Spanish sickvisit_3e2a9689:

    # "The princess felt something cold touch her forehead. It was oddly comforting."
    "La princesa sintió algo frío tocar su frente. Era extrañamente reconfortante."

# game/common.rpy:2785
translate Spanish sickvisit_65db341c:

    # voice "voice2/line15.mp3"
    # who "My goodness... so this is where our little pest had run off to?"
    voice "voice2/line15.mp3"
    who "Dios mío... ¿así que aquí fue donde se escondió nuestra pequeña plaga?"

# game/common.rpy:2789
translate Spanish sickvisit_6906ee73:

    # lumisick "(Who...? Cethin...?)"
    lumisick "(¿Quién...? ¿Cethin...?)"

# game/common.rpy:2791
translate Spanish sickvisit_49cbad87:

    # voice "voice2/line16.mp3"
    # who "...Even had the gall to take her side. Tch."
    voice "voice2/line16.mp3"
    who "...Y hasta tuvo el descaro de ponerse de su lado. Tch."

# game/common.rpy:2795
translate Spanish sickvisit_8ec99692:

    # voice "voice2/line17.mp3"
    # "She was barely conscious, but Lumi could definitely hear someone talking, although muddled."
    voice "voice2/line17.mp3"
    "Apenas estaba consciente, pero Lumi podía oír claramente que alguien hablaba, aunque no distinguía bien lo que decía."

# game/common.rpy:2801
translate Spanish sickvisit_22a44c2f:

    # "It was a familiar voice...{w} the demon butler?"
    "Era una voz familiar...{w} ¿el mayordomo demoníaco?"

# game/common.rpy:2803
translate Spanish sickvisit_4874d2cc:

    # lumisick "(Oh no... it slipped my mind.)"
    lumisick "(Oh no... se me pasó por completo.)"

# game/common.rpy:2805
translate Spanish sickvisit_41c33477:

    # lumisick "(Cethin... how's... Cethin...?)"
    lumisick "(Cethin... ¿cómo está... Cethin...?)"

# game/common.rpy:2807
translate Spanish sickvisit_ba064d62:

    # "Her hand instinctively searched for the dark elf's..."
    "Su mano instintivamente buscó la del elfo oscuro..."

# game/common.rpy:2809
translate Spanish sickvisit_fe59718f:

    # "... She didn't have to look much as it seemed that they hadn't even let go of each other, even in sleep."
    "... No tuvo que buscar mucho, pues parecía que ni siquiera se habían soltado, ni dormidos."

# game/common.rpy:2811
translate Spanish sickvisit_afd4dcf3:

    # voice "voice2/line18.mp3"
    # who "Rest with ease milady; we shall discuss this when you've recovered."
    voice "voice2/line18.mp3"
    who "Descanse tranquila, milady; hablaremos de esto cuando se haya recuperado."

# game/common.rpy:2815
translate Spanish sickvisit_93b6a601:

    # lumisick "Butler...? Please... don't... Cethin..."
    lumisick "¿Mayordomo...? Por favor... no... Cethin..."

# game/common.rpy:2817
translate Spanish sickvisit_1481ad17:

    # voice "voice2/line19.mp3"
    # butler "Sleep. I promise not to touch your drow."
    voice "voice2/line19.mp3"
    butler "Duerma. Prometo no tocar a su drow."

# game/common.rpy:2821
translate Spanish sickvisit_a9aef87b:

    # "A sweet smell wafted around her."
    "Un dulce aroma flotó a su alrededor."

# game/common.rpy:2823
translate Spanish sickvisit_ad4b4fb6:

    # "It felt ever so comforting... that she couldn't keep her eyes open."
    "Era tan reconfortante... que no pudo mantener los ojos abiertos."

# game/common.rpy:2825
translate Spanish sickvisit_1904ed02:

    # voice "voice2/line20-5.mp3"
    # butler "What a troublesome princess I ended up serving."
    voice "voice2/line20-5.mp3"
    butler "Qué princesa tan problemática me ha tocado servir."

# game/common.rpy:2831
translate Spanish sickvisit_0bd8de27:

    # "... A few days later."
    "... Unos días después."

# game/common.rpy:2840
translate Spanish sickvisit_0964890e:

    # voice "voice2/line20.mp3"
    # butler "What were the two of you thinking?!" with vpunch
    voice "voice2/line20.mp3"
    butler "¿¡En qué estaban pensando los dos?!" with vpunch

# game/common.rpy:2844
translate Spanish sickvisit_dae58c59:

    # "With hands on his hips, the butler continued to nag at the two newly recovered patients."
    "Con las manos en la cintura, el mayordomo continuó regañando a los dos pacientes recién recuperados."

# game/common.rpy:2846
translate Spanish sickvisit_d45d3d4c:

    # voice "voice2/line21.mp3"
    # butler "Princess, how could you allow a complete stranger to stay in your living quarters?"
    voice "voice2/line21.mp3"
    butler "Princesa, ¿cómo pudo permitir que un completo desconocido se quedara en sus aposentos?"

# game/common.rpy:2850
translate Spanish sickvisit_d4a88330:

    # "Having finally gotten rid of their colds, the butler had requested their explanation..."
    "Tras haberse librado por fin del resfriado, el mayordomo había pedido una explicación..."

# game/common.rpy:2852
translate Spanish sickvisit_31cef993:

    # "... And before they knew it, they've been listening to the butler's tirade for over an hour now."
    "... Y antes de darse cuenta, llevaban más de una hora escuchando su sermón."

# game/common.rpy:2854
translate Spanish sickvisit_60dd96f5:

    # voice "voice2/line22.mp3"
    # butler "Have you any idea how it felt- to find the two of you passed out on the bed?"
    voice "voice2/line22.mp3"
    butler "¿Tiene idea de lo que se siente encontrar a los dos desmayados en la cama?"

# game/common.rpy:2858
translate Spanish sickvisit_94aaa527:

    # voice "voice2/line23.mp3"
    # butler "...To find an unknown {i}drow{/i} sleeping next to the princess?"
    voice "voice2/line23.mp3"
    butler "¿...Encontrar a un {i}drow{/i} desconocido durmiendo junto a la princesa?"

# game/common.rpy:2862
translate Spanish sickvisit_9f3d8fbf:

    # voice "voice2/line24.mp3"
    # butler "And to top it off, both burning with fever whilst holding each other's hands in your sleep?!"
    voice "voice2/line24.mp3"
    butler "Y para colmo, ¡ambos ardiendo de fiebre mientras se tomaban de las manos dormidos!"

# game/common.rpy:2866
translate Spanish sickvisit_0cc65519:

    # voice "voice2/line25.mp3"
    # butler "It was so sickeningly sweet that I wanted to gag!"
    voice "voice2/line25.mp3"
    butler "¡Fue tan empalagoso que casi me hace vomitar!"

# game/common.rpy:2870
translate Spanish sickvisit_ae22d4cf:

    # voice "voice2/line26.mp3"
    # butler "Yet I couldn't just pull the two of you apart, what with milady just {i}begging{/i} me so, despite being in a barely conscious state."
    voice "voice2/line26.mp3"
    butler "Y aun así, no podía separarlos, con milady {i}suplicándome{/i} así, a pesar de estar medio inconsciente."

# game/common.rpy:2874
translate Spanish sickvisit_ab0ce52e:

    # "He wiped a nonexistent tear from his eye."
    "Se secó una lágrima inexistente del ojo."

# game/common.rpy:2876
translate Spanish sickvisit_41d32989:

    # voice "voice2/line27.mp3"
    # butler "Even then, this was extremely irresponsible of you two."
    voice "voice2/line27.mp3"
    butler "Aun así, esto fue sumamente irresponsable de su parte."

# game/common.rpy:2880
translate Spanish sickvisit_72a5a9cf:

    # voice "voice2/line28.mp3"
    # butler "Had I not come over, your conditions could have gotten worse."
    voice "voice2/line28.mp3"
    butler "De no haber venido, su estado podría haber empeorado."

# game/common.rpy:2884
translate Spanish sickvisit_8570a500:

    # voice "voice2/line29.mp3"
    # butler "Especially you, drow."
    voice "voice2/line29.mp3"
    butler "Especialmente tú, drow."

# game/common.rpy:2888
translate Spanish sickvisit_db35b966:

    # "He pointed at Cethin."
    "Él señaló a Cethin."

# game/common.rpy:2890
translate Spanish sickvisit_b6fae6e5:

    # voice "voice2/line30.mp3"
    # butler "You should have known better!"
    voice "voice2/line30.mp3"
    butler "¡Deberías haberlo sabido!"

# game/common.rpy:2894
translate Spanish sickvisit_0615c991:

    # voice "voice2/line31.mp3"
    # butler "To stay in the room of a lone girl, and a princess at that!"
    voice "voice2/line31.mp3"
    butler "¡Quedarte en la habitación de una chica sola, y una princesa además!"

# game/common.rpy:2898
translate Spanish sickvisit_7b620650:

    # voice "voice2/line32.mp3"
    # butler "For goodness sakes... I couldn't fathom how you could think that such a thing is acceptable."
    voice "voice2/line32.mp3"
    butler "Por el amor de Dios... No podía imaginar cómo podrías pensar que algo así es aceptable."

# game/common.rpy:2902
translate Spanish sickvisit_8078af7d:

    # voice "voice2/line33.mp3"
    # butler "Had this been anywhere else, the princess would have been a subject of rumors! Or scandal!"
    voice "voice2/line33.mp3"
    butler "¡Si esto hubiera sido en otro lugar, la princesa habría sido objeto de rumores! ¡O de un escándalo!"

# game/common.rpy:2906
translate Spanish sickvisit_22838a17:

    # voice "voice1/line80.mp3"
    # cethin "S-sorry...?"
    voice "voice1/line80.mp3"
    cethin "¿L-lo siento...?"

# game/common.rpy:2910
translate Spanish sickvisit_72ad930c:

    # "He squeaked."
    "Chilló."

# game/common.rpy:2912
translate Spanish sickvisit_5b16128f:

    # "If the dark elf had a shell, he would have already withdrawn inside."
    "Si el elfo oscuro tuviera un caparazón, ya se habría escondido dentro."

# game/common.rpy:2914
translate Spanish sickvisit_b67ccc01:

    # lumiserious "Come now, do not lay all the blame on Cethin."
    lumiserious "Vamos ahora, no pongas toda la culpa sobre Cethin."

# game/common.rpy:2916
translate Spanish sickvisit_56826ea6:

    # lumitalk "I was the one who insisted on letting him stay."
    lumitalk "Fui yo quien insistió en dejarlo quedarse."

# game/common.rpy:2918
translate Spanish sickvisit_b2de4385:

    # "The butler sneered."
    "El mayordomo se burló."

# game/common.rpy:2920
translate Spanish sickvisit_72a01c59:

    # voice "voice2/line34.mp3"
    # butler "I could see that, yes."
    voice "voice2/line34.mp3"
    butler "Puedo ver eso, sí."

# game/common.rpy:2924
translate Spanish sickvisit_2a60729e:

    # voice "voice2/line35.mp3"
    # butler "You, as well, have a long list of offences."
    voice "voice2/line35.mp3"
    butler "Tú también tienes una larga lista de ofensas."

# game/common.rpy:2928
translate Spanish sickvisit_14d7c995:

    # voice "voice2/line36.mp3"
    # butler "No wonder you have been asking for larger servings of your meal a few weeks back."
    voice "voice2/line36.mp3"
    butler "No es de extrañar que estuvieras pidiendo porciones más grandes de comida hace unas semanas."

# game/common.rpy:2932
translate Spanish sickvisit_271c8358:

    # voice "voice2/line37.mp3"
    # butler "I should have figured it out then..."
    voice "voice2/line37.mp3"
    butler "Debería haberlo imaginado entonces..."

# game/common.rpy:2936
translate Spanish sickvisit_01105574:

    # voice "voice2/line38.mp3"
    # butler "But I dismissed such thoughts as I trusted that you, as a lady and a princess, would know better."
    voice "voice2/line38.mp3"
    butler "Pero descarté tales pensamientos confiando en que tú, como dama y princesa, sabrías comportarte mejor."

# game/common.rpy:2940
translate Spanish sickvisit_0ddc3b8b:

    # voice "voice2/line39.mp3"
    # butler "And more than that, you lied to cover up for the drow."
    voice "voice2/line39.mp3"
    butler "Y más aún, mentiste para encubrir al drow."

# game/common.rpy:2944
translate Spanish sickvisit_32f1e9eb:

    # voice "voice2/line40.mp3"
    # butler "Is that how little you trust me?"
    voice "voice2/line40.mp3"
    butler "¿Tan poco confías en mí?"

# game/common.rpy:2948
translate Spanish sickvisit_905fc00f:

    # lumi "Yes?"
    lumi "¿Sí?"

# game/common.rpy:2950
translate Spanish sickvisit_cb6fc118:

    # voice "voice2/line41.mp3"
    # butler "Oh, you wound me..."
    voice "voice2/line41.mp3"
    butler "Oh, me hieres..."

# game/common.rpy:2954
translate Spanish sickvisit_a1705387:

    # voice "voice1/line81.mp3"
    # cethin "Uhm... excuse me."
    voice "voice1/line81.mp3"
    cethin "Uhm... disculpe."

# game/common.rpy:2958
translate Spanish sickvisit_101df856:

    # "He raised a hand."
    "Levantó una mano."

# game/common.rpy:2960
translate Spanish sickvisit_4547a988:

    # voice "voice1/line82.mp3"
    # cethin "So... what happens now?"
    voice "voice1/line82.mp3"
    cethin "Entonces... ¿qué pasa ahora?"

# game/common.rpy:2964
translate Spanish sickvisit_653b4d8b:

    # voice "voice2/line42.mp3"
    # butler "I kick you out."
    voice "voice2/line42.mp3"
    butler "Te echo."

# game/common.rpy:2968
translate Spanish sickvisit_dce19ab4:

    # voice "voice1/line83.mp3"
    # cethin "...!"
    voice "voice1/line83.mp3"
    cethin "...!"

# game/common.rpy:2972
translate Spanish sickvisit_a6e58ae2:

    # lumiserious "Hold it right there!"
    lumiserious "¡Detente ahí mismo!"

# game/common.rpy:2974
translate Spanish sickvisit_924b34c5:

    # lumitalk "Cethin isn't going anywhere."
    lumitalk "Cethin no va a ningún lado."

# game/common.rpy:2983
translate Spanish sickvisit_fb3843eb:

    # "She stood in front of the dark elf with arms crossed."
    "Se colocó frente al elfo oscuro con los brazos cruzados."

# game/common.rpy:2985
translate Spanish sickvisit_58c02c16:

    # lumitalk "It is far too dangerous for him to go out on his own!"
    lumitalk "¡Es demasiado peligroso para él salir solo!"

# game/common.rpy:2987
translate Spanish sickvisit_c89d24f1:

    # lumiserious "I am not allowing him to leave just like that."
    lumiserious "No voy a permitir que se marche así como así."

# game/common.rpy:2991
translate Spanish sickvisit_4be627df:

    # butler "Are you certain?"
    butler "¿Estás segura?"

# game/common.rpy:2995
translate Spanish sickvisit_995a16af:

    # butler "Isn't this the same drow who has been sneaking past our security- in broad daylight at that- without getting caught?"
    butler "¿No es este el mismo drow que se ha estado colando entre nuestra seguridad —y a plena luz del día, además— sin ser detectado?"

# game/common.rpy:2997
translate Spanish sickvisit_9fd8fc1a:

    # butler "He has been using the kitchen everyday without anyone's notice!"
    butler "¡Ha estado usando la cocina todos los días sin que nadie se dé cuenta!"

# game/common.rpy:2999
translate Spanish sickvisit_61d1506d:

    # butler "Even I, a demonkin, was not able to detect his presence in this very room."
    butler "Incluso yo, un demonkin, no fui capaz de detectar su presencia en esta misma habitación."

# game/common.rpy:3001
translate Spanish sickvisit_cbb14988:

    # butler "I'd hardly consider this one a {i}helpless drow{/i} who cannot survive on his own."
    butler "Difícilmente consideraría a este un {i}drow indefenso{/i} que no puede sobrevivir por su cuenta."

# game/common.rpy:3005
translate Spanish sickvisit_e45a25a1:

    # butler "I say, he's plenty capable of living off out there in the woods!"
    butler "Yo digo que es perfectamente capaz de vivir allá afuera en el bosque."

# game/common.rpy:3007
translate Spanish sickvisit_d52298ab:

    # lumided "Well, perhaps your security is simply faulty."
    lumided "Bueno, tal vez tu seguridad simplemente es defectuosa."

# game/common.rpy:3009
translate Spanish sickvisit_bbfcbf70:

    # "She huffed."
    "Bufó."

# game/common.rpy:3011
translate Spanish sickvisit_fff1803b:

    # lumiplead "That isn't our fault now, is it?"
    lumiplead "Eso no es culpa nuestra ahora, ¿verdad?"

# game/common.rpy:3013
translate Spanish sickvisit_971b594b:

    # "The demon butler sighed."
    "El mayordomo demonio suspiró."

# game/common.rpy:3017
translate Spanish sickvisit_964ff86a:

    # butler "I cannot believe you are this attached to that drow..."
    butler "No puedo creer que estés tan encariñada con ese drow..."

# game/common.rpy:3029
translate Spanish sickvisit_19852ac3:

    # "He turned his eyes at the dark elf."
    "Volteó sus ojos hacia el elfo oscuro."

# game/common.rpy:3033
translate Spanish sickvisit_d2e8e389:

    # butler "You-"
    butler "Tú—"

# game/common.rpy:3035
translate Spanish sickvisit_0a1df52d:

    # cethin "...?"
    cethin "¿...?"

# game/common.rpy:3039
translate Spanish sickvisit_d2b67a83:

    # butler "I suppose I can bend a few rules for milady."
    butler "Supongo que puedo hacer una excepción con algunas reglas por milady."

# game/common.rpy:3043
translate Spanish sickvisit_8e4ad961:

    # butler "Be thankful to the princess."
    butler "Sé agradecido con la princesa."

# game/common.rpy:3048
translate Spanish sickvisit_6a33a849:

    # lumihappy "I see that you do have a heart."
    lumihappy "Veo que sí tienes corazón."

# game/common.rpy:3052
translate Spanish sickvisit_9c9dc354:

    # butler "Three of them, thank you very much."
    butler "Tres, muchas gracias."

# game/common.rpy:3057
translate Spanish sickvisit_26f68650:

    # butler "That aside, I did promise to oblige your requests."
    butler "Dejando eso de lado, prometí cumplir con tus peticiones."

# game/common.rpy:3059
translate Spanish sickvisit_3e36367a:

    # lumitalk "Oh? You are following through with that?"
    lumitalk "¿Oh? ¿Vas a seguir con eso?"

# game/common.rpy:3061
translate Spanish sickvisit_d3f52999:

    # lumided "I had always assumed they were but empty words."
    lumided "Siempre asumí que eran solo palabras vacías."

# game/common.rpy:3065
translate Spanish sickvisit_bfee6f22:

    # butler "It pains me that you think so little of me..."
    butler "Me duele que pienses tan poco de mí..."

# game/common.rpy:3069
translate Spanish sickvisit_6573a0a2:

    # butler "As a butler, it would shame me if I could not honor something so simple."
    butler "Como mayordomo, me avergonzaría no poder cumplir algo tan simple."

# game/common.rpy:3073
translate Spanish sickvisit_e6ec0c45:

    # butler "Besides, I could not bear to make you cry, milady."
    butler "Además, no podría soportar hacerte llorar, milady."

# game/common.rpy:3075
translate Spanish sickvisit_ac0e39ec:

    # "He said in a dramatic tone."
    "Dijo en un tono dramático."

# game/common.rpy:3077
translate Spanish sickvisit_5f0017b4:

    # lumided "..."
    lumided "..."

# game/common.rpy:3079
translate Spanish sickvisit_aeb105a1:

    # "Lumi rolled her eyes."
    "Lumi puso los ojos en blanco."

# game/common.rpy:3081
translate Spanish sickvisit_2ab45d59:

    # "Though, she was thankful that the butler was willing to turn a blind eye for them."
    "Aunque, estaba agradecida de que el mayordomo estuviera dispuesto a hacer la vista gorda por ellos."

# game/common.rpy:3083
translate Spanish sickvisit_a41da1dd:

    # lumisad "Wouldn't you get in trouble?"
    lumisad "¿No te meterías en problemas?"

# game/common.rpy:3087
translate Spanish sickvisit_c156b0a3:

    # butler "Not if I deny all accusations."
    butler "No si niego todas las acusaciones."

# game/common.rpy:3091
translate Spanish sickvisit_f2e36d5b:

    # butler "He is a drow, a specialist of the dark arts... so I could simply pin everything on him."
    butler "Él es un drow, un especialista en artes oscuras... así que simplemente podría echarle toda la culpa."

# game/common.rpy:3096
translate Spanish sickvisit_46c85f95:

    # cethin "..."
    cethin "..."

# game/common.rpy:3098
translate Spanish sickvisit_3e7dc9e0:

    # "Cethin seemed to be unsure how to feel about that, so he turned his attention to the princess instead."
    "Cethin no estaba seguro de cómo sentirse al respecto, así que dirigió su atención hacia la princesa."

# game/common.rpy:3103
translate Spanish sickvisit_26b73e39:

    # cethin "Thank you for sticking up for me, Lumi."
    cethin "Gracias por defenderme, Lumi."

# game/common.rpy:3105
translate Spanish sickvisit_92daa86e:

    # lumihappy "Didn't I tell you I'd handle this?"
    lumihappy "¿No te dije que me encargaría de esto?"

# game/common.rpy:3109
translate Spanish sickvisit_c27c01a7:

    # cethin "Yeah. I'll repay you somehow."
    cethin "Sí. Te lo recompensaré de alguna manera."

# game/common.rpy:3113
translate Spanish sickvisit_abc0dfe0:

    # butler "Hm. In your own world again, I see."
    butler "Hm. Otra vez ustedes dos en su propio mundo, ya veo."

# game/common.rpy:3115
translate Spanish sickvisit_f88394b6:

    # butler "It seems I may have underestimated your relationship..."
    butler "Parece que subestimé su relación..."

# game/common.rpy:3119
translate Spanish sickvisit_02158583:

    # butler "To be calling each other by your first names... it seems the two of you are more fond of each other than I had anticipated."
    butler "Llamándose por sus nombres de pila... parece que ustedes dos se tienen más aprecio del que anticipaba."

# game/common.rpy:3124
translate Spanish sickvisit_4f3e3cfd:

    # cethin "Huh? Whu- wha- what relationship-"
    cethin "¿Eh? ¿Q-qué r-relación—"

# game/common.rpy:3126
translate Spanish sickvisit_1d2ba637:

    # lumiplead "Hm? Are you jealous then?"
    lumiplead "¿Hm? ¿Estás celoso entonces?"

# game/common.rpy:3128
translate Spanish sickvisit_0917299e:

    # cethin "Lumi...!"
    cethin "¡Lumi...!"

# game/common.rpy:3132
translate Spanish sickvisit_6581ea99:

    # butler "Not in the slightest, but this would either entertain me, or be a cause for more headache."
    butler "Ni un poco, pero esto o me entretendrá o me causará más dolor de cabeza."

# game/common.rpy:3136
translate Spanish sickvisit_96bf7940:

    # butler "What a bother."
    butler "Qué fastidio."

# game/common.rpy:3141
translate Spanish sickvisit_bd1ebc37:

    # lumihappy "Cethin, just ignore him."
    lumihappy "Cethin, solo ignóralo."

# game/common.rpy:3146
translate Spanish sickvisit_a4fb6c53:

    # cethin "Okay."
    cethin "Está bien."

# game/common.rpy:3148
translate Spanish sickvisit_53b9d765:

    # butler "Tch. And you lot even dare to go up against me?"
    butler "Tch. ¿Y ustedes dos se atreven siquiera a enfrentarse a mí?"

# game/common.rpy:3150
translate Spanish sickvisit_a2d99d80:

    # lumihappy "Naturally! Cethin and I are a team, aren't we?"
    lumihappy "¡Naturalmente! Cethin y yo somos un equipo, ¿verdad?"

# game/common.rpy:3155
translate Spanish sickvisit_8dd27c6e:

    # cethin "Huh? Uhm... Yes. Yes we are..."
    cethin "¿Eh? Uhm... Sí. Sí lo somos..."

# game/common.rpy:3159
translate Spanish sickvisit_51eaf36d:

    # "His words lacked confidence, but that was good enough for Lumi."
    "Sus palabras carecían de confianza, pero eso bastaba para Lumi."

# game/common.rpy:3161
translate Spanish sickvisit_70db91ac:

    # "Before, this dark elf can barely hold a conversation with her."
    "Antes, este elfo oscuro apenas podía mantener una conversación con ella."

# game/common.rpy:3163
translate Spanish sickvisit_0c3bd344:

    # "Before, this bard can barely call out to her..."
    "Antes, este bardo apenas podía llamarla..."

# game/common.rpy:3165
translate Spanish sickvisit_0b28c25d:

    # "Now, she could even hear her name being uttered by him everyday."
    "Ahora, incluso podía oír su nombre ser pronunciado por él cada día."

# game/common.rpy:3167
translate Spanish sickvisit_1c336ddd:

    # "It was a simple gesture, but to her, it meant so much more..."
    "Era un gesto simple, pero para ella, significaba mucho más..."

# game/common.rpy:3169
translate Spanish sickvisit_07bdde05:

    # "....."
    "....."

# game/common.rpy:3179
translate Spanish route_split_48482a0c:

    # voice "voice1/line107.mp3"
    # cethin "~This song shall be my testament- a song of mementos~"
    voice "voice1/line107.mp3"
    cethin "~Esta canción será mi testamento— una canción de recuerdos~"

# game/common.rpy:3183
translate Spanish route_split_88a5bb55:

    # voice "voice1/line108.mp3"
    # cethin "~A sovereign of ruin, born of sorrows...~"
    voice "voice1/line108.mp3"
    cethin "~Un soberano de ruina, nacido de penas...~"

# game/common.rpy:3187
translate Spanish route_split_33652e62:

    # voice "voice1/line109.mp3"
    # cethin "~A birth that shall engulf all in loss forevermore...~"
    voice "voice1/line109.mp3"
    cethin "~Un nacimiento que envolverá todo en pérdida para siempre...~"

# game/common.rpy:3191
translate Spanish route_split_200652b4:

    # voice "voice1/line110.mp3"
    # cethin "~Only blood of maiden of lore~"
    voice "voice1/line110.mp3"
    cethin "~Solo sangre de doncella de leyenda~"

# game/common.rpy:3207
translate Spanish route_split_76538d42:

    # butler "{b}STOP!{/b}" with vpunch
    butler "{b}¡BASTA!{/b}" with vpunch

# game/common.rpy:3209
translate Spanish route_split_3d41cbeb:

    # cethin "Yes...?"
    cethin "¿Sí...?"

# game/common.rpy:3213
translate Spanish route_split_95e22b96:

    # butler "Milady, is this what you have been listening to?"
    butler "Milady, ¿esto es lo que ha estado escuchando?"

# game/common.rpy:3219
translate Spanish route_split_31eebf75:

    # butler "It's... it's...{w} {b}horrendous!{/b}"
    butler "Es... es...{w} {b}¡horrendo!{/b}"

# game/common.rpy:3221
translate Spanish route_split_6dfd5d03:

    # butler "How could one call yourself a bard of songs if you cannot perform this one classic?"
    butler "¿Cómo puedes llamarte a ti mismo un bardo de canciones si no puedes interpretar este clásico?"

# game/common.rpy:3227
translate Spanish route_split_e6424c5d:

    # lumiplead "Yes, yes, I am fully aware how terrible Cethin is."
    lumiplead "Sí, sí, soy plenamente consciente de lo terrible que es Cethin."

# game/common.rpy:3229
translate Spanish route_split_a0f0421d:

    # "She replied lazily."
    "Respondió con pereza."

# game/common.rpy:3249
translate Spanish route_split_66ac2877:

    # cethin "Ghk..." with vpunch
    cethin "Kgh..." with vpunch

# game/common.rpy:3254
translate Spanish route_split_887abf08:

    # lumihappy "But it's rather fun to listen to him."
    lumihappy "Pero es bastante divertido escucharlo."

# game/common.rpy:3256
translate Spanish route_split_86ca9356:

    # lumi "If you do not like it, then leave."
    lumi "Si no te gusta, entonces vete."

# game/common.rpy:3260
translate Spanish route_split_ce561aca:

    # lumiserious "Or better yet, perish."
    lumiserious "O mejor aún, perece."

# game/common.rpy:3264
translate Spanish route_split_8ca562c4:

    # butler "Is it just me or have you become rather vindictive when it comes to me?"
    butler "¿Soy yo o te has vuelto bastante vengativa cuando se trata de mí?"

# game/common.rpy:3266
translate Spanish route_split_b1d3625e:

    # lumihappy "Oh, so you have noticed."
    lumihappy "Oh, así que lo has notado."

# game/common.rpy:3270
translate Spanish route_split_d25a9950:

    # butler "And you are very much self aware. Wonderful."
    butler "Y eres muy consciente de ti misma. Maravilloso."

# game/common.rpy:3272
translate Spanish route_split_d8f82d23:

    # lumiserious "Well, if you haven't been mean to Cethin then I'd play nice with you."
    lumiserious "Bueno, si no hubieras sido malo con Cethin, entonces yo me comportaría bien contigo."

# game/common.rpy:3277
translate Spanish route_split_d9c71535:

    # butler "Ah... so it comes down to that drow once again."
    butler "Ah... así que todo vuelve a ese drow."

# game/common.rpy:3281
translate Spanish route_split_b40457dc:

    # butler "You two are really attached. It's rather painful to watch."
    butler "Ustedes dos están realmente unidos. Es bastante doloroso de ver."

# game/common.rpy:3283
translate Spanish route_split_49ab7d1f:

    # lumitalk "If you have nothing better to say, then just leave."
    lumitalk "Si no tienes nada mejor que decir, entonces vete."

# game/common.rpy:3285
translate Spanish route_split_5b599918:

    # lumiserious "Actually, why are you even here?"
    lumiserious "En realidad, ¿por qué estás siquiera aquí?"

# game/common.rpy:3287
translate Spanish route_split_1ca615d0:

    # lumitalk "You have been visiting rather often lately... did you not tell me before that you cannot stay here long because of your duties?"
    lumitalk "Últimamente has estado viniendo bastante seguido... ¿no me dijiste antes que no podías quedarte mucho tiempo por tus deberes?"

# game/common.rpy:3289
translate Spanish route_split_2c74dd6d:

    # lumided "Don't you have anything better to do?"
    lumided "¿No tienes nada mejor que hacer?"

# game/common.rpy:3293
translate Spanish route_split_03e6307c:

    # butler "Oh? I apologize that I am interrupting your alone time together."
    butler "¿Oh? Pido disculpas por interrumpir su momento a solas."

# game/common.rpy:3295
translate Spanish route_split_0ea2cef8:

    # "The princess rolled her eyes."
    "La princesa puso los ojos en blanco."

# game/common.rpy:3299
translate Spanish route_split_634b119e:

    # butler "I assure you, I have mountains of work."
    butler "Te aseguro que tengo montañas de trabajo."

# game/common.rpy:3303
translate Spanish route_split_cf497413:

    # butler "But because of your request, I have to make sure to keep an eye on that drow... lest he does something inappropriate."
    butler "Pero por tu solicitud, tengo que asegurarme de vigilar a ese drow... no sea que haga algo inapropiado."

# game/common.rpy:3305
translate Spanish route_split_2a2c6af7:

    # lumiplead "Cethin would never do such a thing."
    lumiplead "Cethin nunca haría tal cosa."

# game/common.rpy:3310
translate Spanish route_split_323a15fb:

    # lumihappy "Right, dear?"
    lumihappy "¿Verdad, querido?"

# game/common.rpy:3312
translate Spanish route_split_26ede214:

    # "She turned to his direction."
    "Giró en su dirección."

# game/common.rpy:3316
translate Spanish route_split_f60da0a9:

    # cethin "H-huh?!" with vpunch
    cethin "¿¡E-eh?!" with vpunch

# game/common.rpy:3321
translate Spanish route_split_3e271071:

    # cethin "O-of course I wouldn't!"
    cethin "¡P-por supuesto que no lo haría!"

# game/common.rpy:3323
translate Spanish route_split_a74b9c2d:

    # lumihappy "See?"
    lumihappy "¿Ves?"

# game/common.rpy:3327
translate Spanish route_split_8c44ab24:

    # butler "Dear me... you're really set on trusting that drow?"
    butler "Dios mío... ¿realmente estás empeñada en confiar en ese drow?"

# game/common.rpy:3329
translate Spanish route_split_6c8d2cfe:

    # "He sighed."
    "Suspiró."

# game/common.rpy:3333
translate Spanish route_split_f22cbcaf:

    # butler "Whatever do you see in him?"
    butler "¿Qué ves en él?"

# game/common.rpy:3342
translate Spanish route_split_a35698b0:

    # lumihappy "I find him adorable."
    lumihappy "Lo encuentro adorable."

# game/common.rpy:3346
translate Spanish route_split_7650935a:

    # cethin "L-lumi...!"
    cethin "L-lumi...!"

# game/common.rpy:3348
translate Spanish route_split_cfd41d95:

    # lumiehe "See? Don't you just want to pull those cheeks?"
    lumiehe "¿Ves? ¿No te dan ganas de pellizcarle las mejillas?"

# game/common.rpy:3350
translate Spanish route_split_3e87c922:

    # lumiwish "(And the way his ears droop... it makes me want to play with them!)"
    lumiwish "(¡Y la forma en que sus orejas se caen... me dan ganas de jugar con ellas!)"

# game/common.rpy:3354
translate Spanish route_split_c053201d:

    # butler "The look in your eyes tells me that I shouldn't ask..."
    butler "La mirada en tus ojos me dice que no debería preguntar..."

# game/common.rpy:3358
translate Spanish route_split_0a1df52d:

    # cethin "...?"
    cethin "¿...?"

# game/common.rpy:3367
translate Spanish route_split_3d82af23:

    # lumihappy "Cethin is the kindest, most thoughtful person I know."
    lumihappy "Cethin es la persona más amable y considerada que conozco."

# game/common.rpy:3369
translate Spanish route_split_f9a642d8:

    # lumi "How could I not become fond of him?"
    lumi "¿Cómo no podría encariñarme con él?"

# game/common.rpy:3374
translate Spanish route_split_d77a362b:

    # cethin "No, Lumi is kinder..."
    cethin "No, Lumi es más amable..."

# game/common.rpy:3376
translate Spanish route_split_3d4288ce:

    # cethin "You allowed a stranger like me to stay..."
    cethin "Permitiste que un extraño como yo se quedara..."

# game/common.rpy:3378
translate Spanish route_split_d3052b97:

    # cethin "You keep putting up with my songs..."
    cethin "Sigues soportando mis canciones..."

# game/common.rpy:3382
translate Spanish route_split_93e25829:

    # cethin "You're... the only one who has ever shown me this much kindness."
    cethin "Eres... la única que alguna vez me ha mostrado tanta amabilidad."

# game/common.rpy:3384
translate Spanish route_split_ac385284:

    # lumishy "Come now, you are exaggerating..."
    lumishy "Vamos ahora, estás exagerando..."

# game/common.rpy:3388
translate Spanish route_split_59358b84:

    # butler "I think I'd like to vomit."
    butler "Creo que voy a vomitar."

# game/common.rpy:3390
translate Spanish route_split_4cb217f1:

    # lumiserious "(You're the one who asked.)"
    lumiserious "(Fuiste tú quien preguntó.)"

# game/common.rpy:3396
translate Spanish route_split_1c0b0e4d:

    # lumihappy "He's hilarious."
    lumihappy "Es gracioso."

# game/common.rpy:3401
translate Spanish route_split_3fdf90c8:

    # cethin "Eh...?"
    cethin "¿Eh...?"

# game/common.rpy:3403
translate Spanish route_split_bd95c33d:

    # lumiehe "See that look on his face? Priceless."
    lumiehe "¿Ves esa expresión en su cara? No tiene precio."

# game/common.rpy:3408
translate Spanish route_split_8ab397d5:

    # cethin "I don't really understand..."
    cethin "No entiendo muy bien..."

# game/common.rpy:3412
translate Spanish route_split_48089882:

    # butler "So, you fancy a jester..."
    butler "Así que te gusta un bufón..."

# game/common.rpy:3421
translate Spanish route_split_4bef4471:

    # lumihappy "What can I say? He's fun to tease."
    lumihappy "¿Qué puedo decir? Es divertido molestarlo."

# game/common.rpy:3425
translate Spanish route_split_363e0f41:

    # cethin "I've noticed that you do seem to have a teasing streak."
    cethin "He notado que tienes tu lado bromista."

# game/common.rpy:3427
translate Spanish route_split_6c84086e:

    # lumiplead "Only sometimes!"
    lumiplead "¡Solo a veces!"

# game/common.rpy:3431
translate Spanish route_split_6184c147:

    # cethin "I don't mind, as long as that makes you happy."
    cethin "No me importa, mientras eso te haga feliz."

# game/common.rpy:3433
translate Spanish route_split_1f1af8d7:

    # lumishy "... Are you teasing me?"
    lumishy "¿... Me estás tomando el pelo?"

# game/common.rpy:3437
translate Spanish route_split_dbf50aba:

    # butler "I feel forgotten."
    butler "Me siento olvidado."

# game/common.rpy:3439
translate Spanish route_split_aca3a25e:

    # butler "Ah, youth."
    butler "Ah, la juventud."

# game/common.rpy:3445
translate Spanish route_split_be60c946:

    # lumihappy "Above all, Cethin is a dear friend."
    lumihappy "Por encima de todo, Cethin es un querido amigo."

# game/common.rpy:3447
translate Spanish route_split_51d503ba:

    # lumi "Does that satisfy you?"
    lumi "¿Eso te satisface?"

# game/common.rpy:3449
translate Spanish route_split_871ba6e7:

    # lumihappy "If so, please leave us in peace."
    lumihappy "Si es así, por favor déjanos en paz."

# game/common.rpy:3451
translate Spanish route_split_5a118837:

    # "She smiled sweetly at him."
    "Le sonrió dulcemente."

# game/common.rpy:3456
translate Spanish route_split_ec6b4149:

    # cethin "Um... I don't mind having sir butler to stay though...?"
    cethin "¿Um... aunque no me importaría que el señor mayordomo se quedara...?"

# game/common.rpy:3460
translate Spanish route_split_97c10993:

    # lumiehe "Oh Cethin... you really are too adorable."
    lumiehe "Oh Cethin... eres demasiado adorable."

# game/common.rpy:3465
translate Spanish route_split_47616baf:

    # cethin "N-no...! I'm not..."
    cethin "¡N-no...! No lo soy..."

# game/common.rpy:3469
translate Spanish route_split_f492e985:

    # butler "{size=-5}Flirting again...{/size}"
    butler "{size=-5}Coqueteando otra vez...{/size}"

# game/common.rpy:3473
translate Spanish route_split_b33bf423:

    # lumided "Cethin, you are too kind for your own good."
    lumided "Cethin, eres demasiado amable para tu propio bien."

# game/common.rpy:3478
translate Spanish route_split_3d07b912:

    # cethin "I just figured that it'd be nicer for you to have another companion."
    cethin "Solo pensé que sería más agradable para ti tener otra compañía."

# game/common.rpy:3480
translate Spanish route_split_5c089ba2:

    # lumiplead "You hear that?"
    lumiplead "¿Escuchaste eso?"

# game/common.rpy:3484
translate Spanish route_split_e12d1daf:

    # butler "Yes, yes... quit staring at me like that."
    butler "Sí, sí... deja de mirarme así."

# game/common.rpy:3494
translate Spanish route_split_03b088ab:

    # voice "voice2/line44.mp3"
    # butler "Anyways, it is almost yule season so it's been rather busy out there."
    voice "voice2/line44.mp3"
    butler "De todos modos, casi es temporada de yule, así que ha estado bastante ocupado allá afuera."

# game/common.rpy:3501
translate Spanish route_split_913d3266:

    # voice "voice2/line45.mp3"
    # butler "Don't you think I deserve a break? I don't even get paid for this!"
    voice "voice2/line45.mp3"
    butler "¿No crees que merezco un descanso? ¡Ni siquiera me pagan por esto!"

# game/common.rpy:3505
translate Spanish route_split_73c6b66e:

    # lumishock "(They do not pay him?)"
    lumishock "(¿No le pagan?)"

# game/common.rpy:3507
translate Spanish route_split_1e78324d:

    # lumisad "(I suppose demonkin do not have labor laws...)"
    lumisad "(Supongo que los demonkin no tienen leyes laborales...)"

# game/common.rpy:3511
translate Spanish route_split_f4ee73d6:

    # voice "voice2/line46.mp3"
    # butler "So, just let me hide away here until the season tides over."
    voice "voice2/line46.mp3"
    butler "Así que, solo déjame esconderme aquí hasta que pase la temporada."

# game/common.rpy:3517
translate Spanish route_split_35cb3c57:

    # lumiehe "Never mind that! You mentioned yule? It's almost yule?!" with vpunch
    lumiehe "¡Olvida eso! ¿Has dicho Yule? ¿¡Ya casi es Yule?!" with vpunch

# game/common.rpy:3519
translate Spanish route_split_4512ff21:

    # lumiwish "Oh my. I've lost sense of time... I did not realize we're already at that season."
    lumiwish "Oh cielos. He perdido la noción del tiempo... no me di cuenta de que ya estábamos en esa temporada."

# game/common.rpy:3523
translate Spanish route_split_f5bf3f70:

    # voice "voice1/line88.mp3"
    # cethin "Yule huh? I haven't celebrated it in years..."
    voice "voice1/line88.mp3"
    cethin "¿Yule, eh? No lo he celebrado en años..."

# game/common.rpy:3527
translate Spanish route_split_f6208236:

    # lumitalk "Because you've been out traveling?"
    lumitalk "¿Porque has estado viajando?"

# game/common.rpy:3531
translate Spanish route_split_cd3ab5f4:

    # "Cethin nodded."
    "Cethin asintió."

# game/common.rpy:3535
translate Spanish route_split_2e1bb3d5:

    # lumihappy "You could say the same for me."
    lumihappy "Podrías decir lo mismo de mí."

# game/common.rpy:3537
translate Spanish route_split_4dea30b6:

    # lumisad "Before this demon butler, the ones who came before him barely ever uttered a word to me."
    lumisad "Antes de este mayordomo demonio, los que vinieron antes apenas me dirigían la palabra."

# game/common.rpy:3541
translate Spanish route_split_f0994117:

    # voice "voice2/line47.mp3"
    # butler "So do appreciate me more."
    voice "voice2/line47.mp3"
    butler "Así que agradéceme más."

# game/common.rpy:3545
translate Spanish route_split_a69b4e60:

    # lumihappy "Do not worry, I do."
    lumihappy "No te preocupes, lo hago."

# game/common.rpy:3547
translate Spanish route_split_5b5defbf:

    # lumihappy "... And even more if you bring over some tea and snacks for me and Cethin right now?"
    lumihappy "¿... Y aún más si traes un poco de té y bocadillos para mí y Cethin ahora mismo?"

# game/common.rpy:3550
translate Spanish route_split_e22e3409:

    # voice "voice2/line48.mp3"
    # butler "You could have just asked, you know?"
    voice "voice2/line48.mp3"
    butler "Podrías haberlo pedido directamente, ¿sabes?"

# game/common.rpy:3554
translate Spanish route_split_f1469002:

    # "He deadpanned."
    "Dijo con tono apagado."

# game/common.rpy:3558
translate Spanish route_split_85b3913d:

    # voice "voice2/line49.mp3"
    # butler "I shall return with your request."
    voice "voice2/line49.mp3"
    butler "Regresaré con tu pedido."

# game/common.rpy:3576
translate Spanish route_split_ef078bd9:

    # "The butler then proceeded to bow before leaving."
    "El mayordomo procedió entonces a hacer una reverencia antes de irse."

# game/common.rpy:3582
translate Spanish route_split_416d7593:

    # lumided "He's finally left. Thank goodness."
    lumided "Por fin se ha ido. Gracias a los cielos."

# game/common.rpy:3584
translate Spanish route_split_236a7b6e:

    # "She crossed her arms over her chest and upturned her chin."
    "Cruzó los brazos sobre el pecho y levantó el mentón."

# game/common.rpy:3586
translate Spanish route_split_bd139568:

    # lumisad "I wish he'd stop calling you {i}drow{/i}."
    lumisad "Desearía que dejara de llamarte {i}drow{/i}."

# game/common.rpy:3590
translate Spanish route_split_edbea220:

    # voice "voice1/line89.mp3"
    # cethin "It's fine, I don't mind, really."
    voice "voice1/line89.mp3"
    cethin "Está bien, no me molesta, de verdad."

# game/common.rpy:3596
translate Spanish route_split_c9f9741f:

    # voice "voice1/line90.mp3"
    # cethin "{i}Drow{/i} is an old term for us dark elves. We don't find it offensive."
    voice "voice1/line90.mp3"
    cethin "{i}Drow{/i} es un término antiguo para nosotros los elfos oscuros. No lo consideramos ofensivo."

# game/common.rpy:3600
translate Spanish route_split_3e2ae8a7:

    # lumisad "Even still, you have a name."
    lumisad "Aun así, tienes un nombre."

# game/common.rpy:3605
translate Spanish route_split_fe2ea14b:

    # lumisad "It'd be as though if Cethin started calling me {i}human{/i} all the time."
    lumisad "Sería como si Cethin empezara a llamarme {i}humana{/i} todo el tiempo."

# game/common.rpy:3609
translate Spanish route_split_c36f6c34:

    # "The princess huffed."
    "La princesa bufó."

# game/common.rpy:3613
translate Spanish route_split_3ad92897:

    # "Her companion could only smile bashfully in response."
    "Su compañero solo pudo sonreír tímidamente en respuesta."

# game/common.rpy:3618
translate Spanish route_split_0c413ba5:

    # voice "voice1/line91.mp3"
    # cethin "Come to think of it, we haven't been calling him by name either..."
    voice "voice1/line91.mp3"
    cethin "Ahora que lo pienso, nosotros tampoco lo hemos estado llamando por su nombre..."

# game/common.rpy:3622
translate Spanish route_split_267a5f02:

    # lumishock "...*Gasp*{w} Oh dear, that is true."
    lumishock "...*Jadeo*{w} Oh cielos, es verdad."

# game/common.rpy:3624
translate Spanish route_split_33df9400:

    # lumided "... Actually, what is his name?"
    lumided "... En realidad, ¿cuál es su nombre?"

# game/common.rpy:3629
translate Spanish route_split_d5a988f7:

    # voice "voice1/line92.mp3"
    # cethin "You... didn't know?"
    voice "voice1/line92.mp3"
    cethin "¿Tú... no lo sabías?"

# game/common.rpy:3633
translate Spanish route_split_9a2e3015:

    # lumided "Ahaha..."
    lumided "Jajaja..."

# game/common.rpy:3635
translate Spanish route_split_e36f44ae:

    # "A moment later..."
    "Un momento después..."

# game/common.rpy:3647
translate Spanish route_split_c3c169b1:

    # voice "voice2/line50.mp3"
    # butler "Here are your snacks, and some tea perfect for the cold."
    voice "voice2/line50.mp3"
    butler "Aquí tienen sus bocadillos, y un poco de té perfecto para el frío."

# game/common.rpy:3653
translate Spanish route_split_e2ecbd0e:

    # voice "voice2/line51.mp3"
    # butler "I hope you enjoy."
    voice "voice2/line51.mp3"
    butler "Espero que lo disfruten."

# game/common.rpy:3657
translate Spanish route_split_d111b093:

    # lumihappy "Thank you!"
    lumihappy "¡Gracias!"

# game/common.rpy:3661
translate Spanish route_split_9950a17a:

    # voice "voice1/line93.mp3"
    # cethin "Thanks."
    voice "voice1/line93.mp3"
    cethin "Gracias."

# game/common.rpy:3669
translate Spanish route_split_078d4df3:

    # voice "voice2/line52.mp3"
    # butler "My pleasure."
    voice "voice2/line52.mp3"
    butler "Un placer."

# game/common.rpy:3675
translate Spanish route_split_e1e71402:

    # lumiplead "So-"
    lumiplead "Así que–"

# game/common.rpy:3679
translate Spanish route_split_457845b0:

    # voice "voice2/line53.mp3"
    # butler "Anything else? I'd be happy to serve."
    voice "voice2/line53.mp3"
    butler "¿Algo más? Estaré encantado de servirles."

# game/common.rpy:3685
translate Spanish route_split_a6ca8daa:

    # "The butler seemed to have switched back to being cordial."
    "El mayordomo parecía haber vuelto a mostrarse cordial."

# game/common.rpy:3687
translate Spanish route_split_67e74d58:

    # "Then again, his separation between being casual and professional was very thin."
    "Aunque, de nuevo, su separación entre lo casual y lo profesional era muy delgada."

# game/common.rpy:3691
translate Spanish route_split_84cad455:

    # voice "voice2/line54.mp3"
    # butler "I do have the privilege to play truant from my usual duties, as long as I am under your orders."
    voice "voice2/line54.mp3"
    butler "Tengo el privilegio de escabullirme de mis deberes habituales, siempre y cuando esté bajo sus órdenes."

# game/common.rpy:3697
translate Spanish route_split_3ebcaa3c:

    # "Aaaand there we go. Professionalism go poof."
    "Y ahí está. El profesionalismo se fue al traste."

# game/common.rpy:3699
translate Spanish route_split_47b00851:

    # lumided "(Why do you sound proud of playing hooky?)"
    lumided "(¿Por qué suenas tan orgulloso de haberte escapado del trabajo?)"

# game/common.rpy:3704
translate Spanish route_split_94f0fd4d:

    # voice "voice1/line94.mp3"
    # cethin "Actually, we just wanted to apologize."
    voice "voice1/line94.mp3"
    cethin "En realidad, solo queríamos disculparnos."

# game/common.rpy:3712
translate Spanish route_split_2bc043fc:

    # voice "voice2/line55.mp3"
    # butler "Oh? What's this? Have you two realized that it is lonely without me?"
    voice "voice2/line55.mp3"
    butler "¿Oh? ¿Qué es esto? ¿Han descubierto que se sienten solos sin mí?"

# game/common.rpy:3716
translate Spanish route_split_ac45c64b:

    # lumided "*Coughs* Not at all."
    lumided "*Tose* Para nada."

# game/common.rpy:3718
translate Spanish route_split_3dfe9991:

    # lumisad "It's just that..."
    lumisad "Es solo que..."

# game/common.rpy:3725
translate Spanish route_split_444d3f09:

    # voice "voice1/line95.mp3"
    # cethin "We've just realized that we hadn't known your name."
    voice "voice1/line95.mp3"
    cethin "Nos dimos cuenta de que no sabíamos tu nombre."

# game/common.rpy:3729
translate Spanish route_split_6f9a7147:

    # "He raised a brow."
    "Él arqueó una ceja."

# game/common.rpy:3731
translate Spanish route_split_f9beba5d:

    # voice "voice2/line56.mp3"
    # butler "Why are you looking so apologetic?"
    voice "voice2/line56.mp3"
    butler "¿Por qué parecen tan apenados?"

# game/common.rpy:3735
translate Spanish route_split_f18d7bd9:

    # lumisad "I mean... you have been serving me for quite a while now, so..."
    lumisad "Bueno... has estado sirviéndome por un buen tiempo ya, así que..."

# game/common.rpy:3739
translate Spanish route_split_8114e526:

    # "The butler just shrugged."
    "El mayordomo simplemente se encogió de hombros."

# game/common.rpy:3744
translate Spanish route_split_51cad16b:

    # voice "voice2/line57.mp3"
    # butler "A mere butler's name matters not to a princess. I doubt you knew the names of your guards back home."
    voice "voice2/line57.mp3"
    butler "El nombre de un simple mayordomo no importa a una princesa. Dudo que conocieras los nombres de tus guardias en casa."

# game/common.rpy:3750
translate Spanish route_split_9b954ac6:

    # "Lumi could only fiddle with her thumbs."
    "Lumi no pudo hacer más que juguetear con los pulgares."

# game/common.rpy:3752
translate Spanish route_split_6af597a2:

    # "His words ring true. She didn't even know the names of most of her personal maids..."
    "Sus palabras eran ciertas. Ni siquiera conocía los nombres de la mayoría de sus doncellas personales..."

# game/common.rpy:3754
translate Spanish route_split_30c761a1:

    # "The atmosphere between them suddenly felt cold."
    "El ambiente entre ellos de pronto se volvió frío."

# game/common.rpy:3756
translate Spanish route_split_f1e60b8d:

    # "It's always been like that with the butler-"
    "Siempre ha sido así con el mayordomo–"

# game/common.rpy:3758
translate Spanish route_split_dff7fa7a:

    # "He always acted friendly, but it always felt like he had drawn a line between them."
    "Siempre se mostraba amistoso, pero siempre parecía que había trazado una línea entre ellos."

# game/common.rpy:3760
translate Spanish route_split_8e54dfe2:

    # "Lumi wondered...{w} had this always been how he felt?"
    "Lumi se preguntó...{w} ¿siempre se había sentido así?"

# game/common.rpy:3762
translate Spanish route_split_ac752cbf:

    # "... That he's just another one of her nameless servants?"
    "¿... Que él no era más que otro de sus sirvientes sin nombre?"

# game/common.rpy:3764
translate Spanish route_split_4e473d93:

    # "As painful as it was to admit, he was indeed a {i}nameless{/i} servant in the end."
    "Tan doloroso como era admitirlo, al final, él era efectivamente un sirviente {i}sin nombre{/i}."

# game/common.rpy:3768
translate Spanish route_split_7bbe3cce:

    # voice "voice2/line58.mp3"
    # butler "See? So, no need to feel bad for it."
    voice "voice2/line58.mp3"
    butler "¿Ves? Así que no hay necesidad de sentirse mal por eso."

# game/common.rpy:3774
translate Spanish route_split_a4308185:

    # voice "voice2/line59.mp3"
    # butler "You, drow, are especially lucky to have the princess even bat an eye on you."
    voice "voice2/line59.mp3"
    butler "Tú, drow, tienes mucha suerte de que la princesa siquiera te preste atención."

# game/common.rpy:3778
translate Spanish route_split_71ad8751:

    # lumiserious "Butler, cease that."
    lumiserious "Mayordomo, detente."

# game/common.rpy:3780
translate Spanish route_split_b73c520c:

    # "She frowned."
    "Frunció el ceño."

# game/common.rpy:3782
translate Spanish route_split_73c4d399:

    # "Lumi felt like she had wronged him, but it still didn't sit well with her- of how he treats Cethin."
    "Lumi sentía que le había hecho mal, pero aun así no le agradaba cómo trataba a Cethin."

# game/common.rpy:3784
translate Spanish route_split_03c24fc5:

    # "Just as how the butler was a {i}nameless{/i} servant, Cethin was but a {i}nameless{/i} night elf to him."
    "Así como el mayordomo era un sirviente {i}sin nombre{/i}, Cethin no era más que un elfo nocturno {i}sin nombre{/i} para él."

# game/common.rpy:3788
translate Spanish route_split_c44f36ca:

    # voice "voice2/line60.mp3"
    # butler "... As you command."
    voice "voice2/line60.mp3"
    butler "... Como ordene."

# game/common.rpy:3794
translate Spanish route_split_8105e406:

    # "He made a gesture of zipping his lips."
    "Hizo el gesto de cerrarse la boca con cremallera."

# game/common.rpy:3796
translate Spanish route_split_50b17cce:

    # "While he may have followed her order, his attitude was still slightly mocking."
    "Aunque obedeció su orden, su actitud seguía siendo un poco burlona."

# game/common.rpy:3798
translate Spanish route_split_8aaa5e92:

    # "It was but part of his usual antics, but this time, the princess felt a stab to her."
    "Era parte de sus payasadas habituales, pero esta vez, la princesa sintió una punzada en el pecho."

# game/common.rpy:3800
translate Spanish route_split_13d62c16:

    # "The separation between them became as clear as ever."
    "La separación entre ellos quedó tan clara como siempre."

# game/common.rpy:3802
translate Spanish route_split_02524940:

    # lumisad "(I see...{w} it wasn't him alone who drew a line between us.)"
    lumisad "(Ya veo...{w} no fue solo él quien trazó una línea entre nosotros.)"

# game/common.rpy:3804
translate Spanish route_split_f6d7b317:

    # lumisad "(I did too.)"
    lumisad "(Yo también lo hice.)"

# game/common.rpy:3806
translate Spanish route_split_18e0bded:

    # "The princess turned to the dark elf, somewhat concerned about how he felt about that."
    "La princesa se volvió hacia el elfo oscuro, algo preocupada por cómo se sentía al respecto."

# game/common.rpy:3811
translate Spanish route_split_3c298f6f:

    # voice "voice1/line96.mp3"
    # cethin "Lumi, it's fine."
    voice "voice1/line96.mp3"
    cethin "Lumi, está bien."

# game/common.rpy:3815
translate Spanish route_split_4e7fd704:

    # "He seemed all right, at least?"
    "¿Parecía estar bien, al menos?"

# game/common.rpy:3819
translate Spanish route_split_22b6942a:

    # "Lumi could only shoot her butler a glare, and in turn, he simply snubbed her."
    "Lumi solo pudo lanzar una mirada fulminante a su mayordomo, y él simplemente la ignoró."

# game/common.rpy:3823
translate Spanish route_split_bb24a4c6:

    # "Suddenly, it became difficult to ask him."
    "De repente, se volvió difícil preguntarle."

# game/common.rpy:3825
translate Spanish route_split_abc3f0d0:

    # voice "voice1/line97.mp3"
    # cethin "As we were saying... there's just something we wanted to know from you-"
    voice "voice1/line97.mp3"
    cethin "Como decíamos... hay algo que queríamos saber de ti–"

# game/common.rpy:3831
translate Spanish route_split_80ace3fd:

    # voice "voice1/line98.mp3"
    # cethin "What is your name? If you don't mind."
    voice "voice1/line98.mp3"
    cethin "¿Cuál es tu nombre? Si no te molesta."

# game/common.rpy:3835
translate Spanish route_split_9161cd8c:

    # "Thankfully, Cethin jumped in to ask in her place."
    "Por suerte, Cethin intervino para preguntar en su lugar."

# game/common.rpy:3839
translate Spanish route_split_7b482172:

    # voice "voice2/line61.mp3"
    # butler "..."
    voice "voice2/line61.mp3"
    butler "..."

# game/common.rpy:3843
translate Spanish route_split_7a57ccfc:

    # "He seemed to have been taken aback."
    "Parecía haberse sorprendido."

# game/common.rpy:3847
translate Spanish route_split_92dd4c36:

    # "The demon butler hesitated for a moment, before finally opening his mouth."
    "El mayordomo demonio dudó por un momento, antes de finalmente abrir la boca."

# game/common.rpy:3852
translate Spanish route_split_4118b198:

    # voice "voice2/line62.mp3"
    # butler "...Reo."
    voice "voice2/line62.mp3"
    butler "...Reo."

# game/common.rpy:3856
translate Spanish route_split_36c3c17c:

    # "His reply lacked the usual sass or sarcasm he usually had."
    "Su respuesta carecía del sarcasmo o picardía habitual que solía tener."

# game/common.rpy:3858
translate Spanish route_split_c459abfe:

    # lumihappy "(Ah...)"
    lumihappy "(Ah...)"

# game/common.rpy:3860
translate Spanish route_split_d42176ab:

    # lumihappy "(So, he has a side like that as well.)"
    lumihappy "(Así que también tiene un lado así.)"

# game/common.rpy:3862
translate Spanish route_split_9285d1e5:

    # "She smiled."
    "Ella sonrió."

# game/common.rpy:3864
translate Spanish route_split_d7c87c78:

    # "That small gesture felt like it melted something in an instant."
    "Ese pequeño gesto pareció derretir algo al instante."

# game/common.rpy:3866
translate Spanish route_split_389745ce:

    # "Just as how it meant so much to her to have someone call her by name..."
    "Así como significaba tanto para ella que alguien la llamara por su nombre..."

# game/common.rpy:3870
translate Spanish route_split_4eccf0f6:

    # "Perhaps, this demon butler felt the same as well?"
    "¿Quizá este mayordomo demonio sentía lo mismo?"

# game/common.rpy:3872
translate Spanish route_split_54cc6ab1:

    # "At that very moment, it felt like she understood him better, even by a little."
    "En ese momento, sintió que lo comprendía un poco mejor, aunque fuera solo un poco."

# game/common.rpy:3874
translate Spanish route_split_4a71c652:

    # lumihappy "Oh! I see. Reo."
    lumihappy "¡Oh! Ya veo. Reo."

# game/common.rpy:3878
translate Spanish route_split_bdd70c2f:

    # voice "voice1/line99.mp3"
    # cethin "Good to be acquainted with you, Reo."
    voice "voice1/line99.mp3"
    cethin "Encantado de conocerte, Reo."

# game/common.rpy:3886
translate Spanish route_split_7b1cc6db:

    # voice "voice2/line61.mp3"
    # reo "..."
    voice "voice2/line61.mp3"
    reo "..."

# game/common.rpy:3892
translate Spanish route_split_e8562769:

    # lumi "What is so strange about using your name, Reo?"
    lumi "¿Qué tiene de extraño usar tu nombre, Reo?"

# game/common.rpy:3894
translate Spanish route_split_b73795b4:

    # voice "voice1/line100.mp3"
    # cethin "Reo is just a fine name, I think."
    voice "voice1/line100.mp3"
    cethin "Reo es un nombre perfectamente bueno, creo."

# game/common.rpy:3900
translate Spanish route_split_e640b655:

    # lumihappy "Right? Reo."
    lumihappy "¿Verdad? Reo."

# game/common.rpy:3904
translate Spanish route_split_67fe9ddc:

    # voice "voice1/line101.mp3"
    # cethin "Mhm. Reo."
    voice "voice1/line101.mp3"
    cethin "Mhm. Reo."

# game/common.rpy:3908
translate Spanish route_split_8bb055ea:

    # lumided "Reo."
    lumided "Reo."

# game/common.rpy:3912
translate Spanish route_split_3db07abb:

    # voice "voice1/line102.mp3"
    # cethin "Reo."
    voice "voice1/line102.mp3"
    cethin "Reo."

# game/common.rpy:3918
translate Spanish route_split_65875311:

    # voice "voice2/line63.mp3"
    # reo "STOP IT. THE TWO OF YOU. You are both doing this on purpose...!" with vpunch
    voice "voice2/line63.mp3"
    reo "¡BASTA YA. LOS DOS. Lo están haciendo a propósito...!" with vpunch

# game/common.rpy:3924
translate Spanish route_split_e76f6b26:

    # "The two chuckled."
    "Los dos se rieron."

# game/common.rpy:3928
translate Spanish route_split_d7ef80c2:

    # voice "voice2/line64.mp3"
    # reo "Oh well. If this is what it takes to keep the princess happy..."
    voice "voice2/line64.mp3"
    reo "Bueno, si esto es lo que se necesita para mantener feliz a la princesa..."

# game/common.rpy:3932
translate Spanish route_split_4e58404d:

    # "He shrugged."
    "Se encogió de hombros."

# game/common.rpy:3936
translate Spanish route_split_860a8380:

    # voice "voice2/line65.mp3"
    # reo "I suppose this is thanks to you as well, drow."
    voice "voice2/line65.mp3"
    reo "Supongo que esto también se lo debo a ti, drow."

# game/common.rpy:3943
translate Spanish route_split_c70ca22f:

    # voice "voice1/line103.mp3"
    # cethin "H-huh? What did I-"
    voice "voice1/line103.mp3"
    cethin "¿H-huh? ¿Qué hice yo–?"

# game/common.rpy:3950
translate Spanish route_split_62d37f7e:

    # voice "voice2/line66.mp3"
    # reo "I am still not quite pleased with the two of you sharing a room, nor do I fully trust you."
    voice "voice2/line66.mp3"
    reo "Todavía no estoy del todo satisfecho con que ustedes dos compartan habitación, ni confío plenamente en ti."

# game/common.rpy:3954
translate Spanish route_split_dea55965:

    # voice "voice2/line67.mp3"
    # "He mutters something under his breath..."
    voice "voice2/line67.mp3"
    "Murmuró algo entre dientes..."

# game/common.rpy:3963
translate Spanish route_split_786e652b:

    # voice "voice2/line68.mp3"
    # reo "Alas... her wishes come first."
    voice "voice2/line68.mp3"
    reo "Pero... sus deseos van primero."

# game/common.rpy:3969
translate Spanish route_split_e0d53bf8:

    # "The butler ignored Cethin's attempted denial."
    "El mayordomo ignoró el intento de negación de Cethin."

# game/common.rpy:3973
translate Spanish route_split_7b3450a5:

    # lumiplead "Yes, speaking of wishes!"
    lumiplead "¡Sí, hablando de deseos!"

# game/common.rpy:3975
translate Spanish route_split_9fc6a71a:

    # "She clapped her hands together with an unusual cheer."
    "Ella aplaudió con un entusiasmo inusual."

# game/common.rpy:3980
translate Spanish route_split_d22311dc:

    # lumiplead "I wish you'd call our dear Cethin by his name. {b}Properly.{/b}"
    lumiplead "Deseo que llames a nuestro querido Cethin por su nombre. {b}Como es debido.{/b}"

# game/common.rpy:3984
translate Spanish route_split_0bf0a27e:

    # voice "voice2/line70.mp3"
    # reo "Tch.. I bit that one hard didn't I..."
    voice "voice2/line70.mp3"
    reo "Tch... caí en la trampa, ¿no...?"

# game/common.rpy:3990
translate Spanish route_split_808e6965:

    # voice "voice1/line104.mp3"
    # cethin "Lumi, you don't have to-"
    voice "voice1/line104.mp3"
    cethin "Lumi, no tienes que–"

# game/common.rpy:3996
translate Spanish route_split_96310367:

    # voice "voice2/line71.mp3"
    # reo "Fine. Cethin, yes?"
    voice "voice2/line71.mp3"
    reo "Bien. Cethin, ¿sí?"

# game/common.rpy:4004
translate Spanish route_split_fe60cc65:

    # voice "voice1/line105.mp3"
    # cethin "...!"
    voice "voice1/line105.mp3"
    cethin "...!"

# game/common.rpy:4010
translate Spanish route_split_ba29b53e:

    # voice "voice1/line106.mp3"
    # cethin "Yes."
    voice "voice1/line106.mp3"
    cethin "Sí."

# game/common.rpy:4014
translate Spanish route_split_eddfc791:

    # "The dark elf nodded."
    "El elfo oscuro asintió."

# game/common.rpy:4019
translate Spanish route_split_cd368319:

    # voice "voice2/line72.mp3"
    # reo "There, are you happy now, milady?"
    voice "voice2/line72.mp3"
    reo "Ahí tienes, ¿contenta ahora, milady?"

# game/common.rpy:4023
translate Spanish route_split_e9f7e172:

    # lumihappy "Very."
    lumihappy "Mucho."

# game/common.rpy:4027
translate Spanish route_split_f57f9956:

    # "The butler's presence had become ever more apparent in the coming days."
    "La presencia del mayordomo se hizo aún más evidente en los días siguientes."

# game/common.rpy:4029
translate Spanish route_split_2fc17a4d:

    # "He may never admit it, but it was obvious that he had formed a soft spot for the two."
    "Puede que nunca lo admitiera, pero era obvio que había desarrollado cierto cariño por los dos."

# game/common.rpy:4031
translate Spanish route_split_0e00580d:

    # "Thus, the princess' room had become livelier than ever."
    "Así, la habitación de la princesa se volvió más animada que nunca."

# game/common.rpy:4033
translate Spanish route_split_5c59b799:

    # "... For better or for worse."
    "... Para bien o para mal."

# game/common.rpy:4035
translate Spanish route_split_2a1dfaaa:

    # "But, one thing was certain... there had never been a dull moment since then."
    "Pero, una cosa era segura... desde entonces, nunca hubo un momento aburrido."

# game/common.rpy:4051
translate Spanish route_split_48aa51c7:

    # reo "Remind me why am I working overtime?"
    reo "Recuérdenme por qué estoy trabajando horas extra."

# game/common.rpy:4053
translate Spanish route_split_e716adbc:

    # "The butler was holding on to decorations."
    "El mayordomo sostenía unas decoraciones."

# game/common.rpy:4055
translate Spanish route_split_37f69f06:

    # "He had a conflicted expression plastered on his face."
    "Tenía una expresión de conflicto interno en el rostro."

# game/common.rpy:4060
translate Spanish route_split_9e0b741b:

    # cethin "You said that this is part of your work?"
    cethin "¿Dijiste que esto era parte de tu trabajo?"

# game/common.rpy:4064
translate Spanish route_split_34ae1792:

    # lumihappy "Listening to my requests, that is."
    lumihappy "Escuchar mis peticiones, eso sí."

# game/common.rpy:4068
translate Spanish route_split_ae1d843f:

    # "Cethin was standing on a stool while putting up some garlands on the wall."
    "Cethin estaba de pie sobre un taburete mientras colgaba unas guirnaldas en la pared."

# game/common.rpy:4070
translate Spanish route_split_6b3382bf:

    # "Reo would hand over those that were stored in the box whenever the dark elf would finish one."
    "Reo le pasaba las que estaban guardadas en la caja cada vez que el elfo oscuro terminaba una."

# game/common.rpy:4072
translate Spanish route_split_e21356f2:

    # "... And then there's the princess, idly sampling some cookies on the table."
    "... Y luego está la princesa, probando distraídamente unas galletas en la mesa."

# game/common.rpy:4076
translate Spanish route_split_14fbac79:

    # reo "Well... yes- but preferably when it benefits me as well."
    reo "Bueno... sí, pero preferiblemente cuando también me beneficia."

# game/common.rpy:4080
translate Spanish route_split_fdaf8c0b:

    # reo "However, it is already past my working hours..."
    reo "Sin embargo, ya ha pasado mi horario laboral..."

# game/common.rpy:4082
translate Spanish route_split_59cb9120:

    # lumided "Why does it matter? You said that you do not get paid either way, didn't you?"
    lumided "¿Por qué importa? Dijiste que no te pagan de todas formas, ¿no es así?"

# game/common.rpy:4086
translate Spanish route_split_812ba59d:

    # reo "Naturally, I'd like to sit back and rest after a long day of hard work."
    reo "Naturalmente, me gustaría relajarme y descansar después de un largo día de trabajo."

# game/common.rpy:4091
translate Spanish route_split_03785f73:

    # cethin "But haven't you been here almost the whole day?"
    cethin "¿Pero no has estado aquí casi todo el día?"

# game/common.rpy:4096
translate Spanish route_split_c31d926d:

    # reo "Still work."
    reo "Aun así, es trabajo."

# game/common.rpy:4098
translate Spanish route_split_47ac1ee6:

    # lumided "You were just lounging around, criticising Cethin's performance."
    lumided "Solo estabas descansando, criticando el desempeño de Cethin."

# game/common.rpy:4102
translate Spanish route_split_8f244a1f:

    # reo "... Perhaps you'd fancy a break? Would you like some tea? Or perhaps refreshments?"
    reo "... ¿Quizás te apetezca un descanso? ¿Quieres un poco de té? ¿O tal vez algo para comer?"

# game/common.rpy:4104
translate Spanish route_split_a39e883b:

    # lumided "... Mhm, I'd thought so."
    lumided "... Mhm, eso pensé."

# game/common.rpy:4106
translate Spanish route_split_abfc287a:

    # lumi "And no, perhaps later. Cethin, you?"
    lumi "Y no, tal vez más tarde. ¿Cethin, tú?"

# game/common.rpy:4110
translate Spanish route_split_606df946:

    # cethin "I'm okay. I'd like to finish the decoration here."
    cethin "Estoy bien. Me gustaría terminar la decoración aquí."

# game/common.rpy:4125
translate Spanish yuleprep_fd34b344:

    # cethin "Well then. I suppose we are done with the decorations."
    cethin "Bueno entonces. Supongo que hemos terminado con las decoraciones."

# game/common.rpy:4129
translate Spanish yuleprep_512ee5db:

    # reo "Are you happy now, princess?"
    reo "¿Estás feliz ahora, princesa?"

# game/common.rpy:4131
translate Spanish yuleprep_d5993144:

    # "She gleefully put her hands together."
    "Ella juntó las manos alegremente."

# game/common.rpy:4133
translate Spanish yuleprep_039d6113:

    # lumiehe "Quite excited, more like."
    lumiehe "Más bien, bastante emocionada."

# game/common.rpy:4135
translate Spanish yuleprep_e195ca58:

    # lumiwish "I do not know why it hadn't occurred to me to at least celebrate such festivities!"
    lumiwish "¡No sé por qué no se me había ocurrido al menos celebrar estas festividades!"

# game/common.rpy:4137
translate Spanish yuleprep_b68d47a4:

    # lumi "It's been truly dull staying here. This should change up some things."
    lumi "Ha sido realmente aburrido quedarme aquí. Esto debería cambiar un poco las cosas."

# game/common.rpy:4141
translate Spanish yuleprep_ecc13d0c:

    # reo "Good for you."
    reo "Bien por ti."

# game/common.rpy:4147
translate Spanish yuleprep_3660c1ae:

    # reo "Well, then I suppose I shall turn in for the night."
    reo "Bueno, entonces supongo que me retiraré a descansar."

# game/common.rpy:4149
translate Spanish yuleprep_c27780c6:

    # lumitalk "Hold that thought."
    lumitalk "Espera un momento."

# game/common.rpy:4151
translate Spanish yuleprep_e67754c7:

    # lumi "Wait a moment Reo."
    lumi "Espera un momento, Reo."

# game/common.rpy:4158
translate Spanish yuleprep_7ae98f11:

    # reo "Tch. What is it, princess?"
    reo "Tch. ¿Qué pasa, princesa?"

# game/common.rpy:4160
translate Spanish yuleprep_bdeca137:

    # lumided "(Is it just me or has he been... disinclined to do work as of late?)"
    lumided "(¿Soy solo yo o ha estado... reacio a trabajar últimamente?)"

# game/common.rpy:4162
translate Spanish yuleprep_84060b4a:

    # lumitalk "I simply wanted to ask you to give assistance to Cethin- with accessing the kitchen, that is."
    lumitalk "Solo quería pedirte que ayudes a Cethin a entrar en la cocina, eso es."

# game/common.rpy:4164
translate Spanish yuleprep_a6691773:

    # lumihappy "We've talked about it before, and he said he's willing to cook us a feast for the festival!"
    lumihappy "¡Ya lo hablamos antes, y dijo que está dispuesto a cocinarnos un banquete para el festival!"

# game/common.rpy:4166
translate Spanish yuleprep_8d278a4d:

    # lumided "You should know how terrible the usual chef is..."
    lumided "Deberías saber lo terrible que es el chef habitual..."

# game/common.rpy:4170
translate Spanish yuleprep_e2b4f43b:

    # reo "Milady... I am already turning a blind eye on your dear smuggled bard."
    reo "Milady... ya estoy haciendo la vista gorda con tu querido bardo de contrabando."

# game/common.rpy:4174
translate Spanish yuleprep_0cb23de6:

    # reo "Don't you think that you are asking me too much?"
    reo "¿No crees que me estás pidiendo demasiado?"

# game/common.rpy:4176
translate Spanish yuleprep_5e7522c0:

    # lumisad "But you said you'd oblige my requests..."
    lumisad "Pero dijiste que accederías a mis peticiones..."

# game/common.rpy:4180
translate Spanish yuleprep_aca4ca8b:

    # reo "Would this mean you trust me then?"
    reo "¿Significaría eso que confías en mí entonces?"

# game/common.rpy:4182
translate Spanish yuleprep_b923f17e:

    # lumi "I trust you enough to take care of Cethin."
    lumi "Confío lo suficiente en ti como para que cuides de Cethin."

# game/common.rpy:4186
translate Spanish yuleprep_077ee0a4:

    # "The butler sighed."
    "El mayordomo suspiró."

# game/common.rpy:4190
translate Spanish yuleprep_fc0cfb1e:

    # reo "Very well. If this will please you, then I shall see what I can do."
    reo "Muy bien. Si esto te complace, entonces veré qué puedo hacer."

# game/common.rpy:4192
translate Spanish yuleprep_f779890a:

    # lumihappy "Thank you, dear!"
    lumihappy "¡Gracias, querido!"

# game/common.rpy:4200
translate Spanish yuleprep_2a1d3233:

    # "With that, the butler bowed and left."
    "Con eso, el mayordomo hizo una reverencia y se fue."

# game/common.rpy:4217
translate Spanish routelock_344ede53:

    # "Lumi turned her attention to Cethin."
    "Lumi dirigió su atención hacia Cethin."

translate Spanish strings:

    # renpy/common/00accessibility.rpy:28
    old "Self-voicing disabled."
    new "La lectura en voz alta está desactivada."

    # renpy/common/00accessibility.rpy:29
    old "Clipboard voicing enabled. "
    new "La lectura del portapapeles está activada. "

    # renpy/common/00accessibility.rpy:30
    old "Self-voicing enabled. "
    new "La lectura en voz alta está activada. "

    # renpy/common/00accessibility.rpy:32
    old "bar"
    new "barra"

    # renpy/common/00accessibility.rpy:33
    old "selected"
    new "seleccionado"

    # renpy/common/00accessibility.rpy:34
    old "viewport"
    new "ventana de visualización"

    # renpy/common/00accessibility.rpy:35
    old "horizontal scroll"
    new "desplazamiento horizontal"

    # renpy/common/00accessibility.rpy:36
    old "vertical scroll"
    new "desplazamiento vertical"

    # renpy/common/00accessibility.rpy:37
    old "activate"
    new "activar"

    # renpy/common/00accessibility.rpy:38
    old "deactivate"
    new "desactivar"

    # renpy/common/00accessibility.rpy:39
    old "increase"
    new "aumentar"

    # renpy/common/00accessibility.rpy:40
    old "decrease"
    new "disminuir"

    # renpy/common/00accessibility.rpy:138
    old "Font Override"
    new "Fuente alternativa"

    # renpy/common/00accessibility.rpy:142
    old "Default"
    new "Predeterminada"

    # renpy/common/00accessibility.rpy:146
    old "DejaVu Sans"
    new "DejaVu Sans"

    # renpy/common/00accessibility.rpy:150
    old "Opendyslexic"
    new "Opendyslexic"

    # renpy/common/00accessibility.rpy:156
    old "Text Size Scaling"
    new "Escala del tamaño del texto"

    # renpy/common/00accessibility.rpy:162
    old "Reset"
    new "Restablecer"

    # renpy/common/00accessibility.rpy:168
    old "Line Spacing Scaling"
    new "Escala del interlineado"

    # renpy/common/00accessibility.rpy:180
    old "High Contrast Text"
    new "Texto de alto contraste"

    # renpy/common/00accessibility.rpy:182
    old "Enable"
    new "Activar"

    # renpy/common/00accessibility.rpy:193
    old "Self-Voicing"
    new "Lectura en voz alta"

    # renpy/common/00accessibility.rpy:197
    old "Off"
    new "Desactivado"

    # renpy/common/00accessibility.rpy:201
    old "Text-to-speech"
    new "Texto a voz"

    # renpy/common/00accessibility.rpy:205
    old "Clipboard"
    new "Portapapeles"

    # renpy/common/00accessibility.rpy:209
    old "Debug"
    new "Depuración"

    # renpy/common/00accessibility.rpy:215
    old "Self-Voicing Volume Drop"
    new "Reducción del volumen de la lectura en voz alta"

    # renpy/common/00accessibility.rpy:224
    old "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."
    new "Las opciones de este menú están destinadas a mejorar la accesibilidad. Es posible que no funcionen con todos los juegos y que algunas combinaciones de opciones hagan que el juego no se pueda jugar. Esto no es un problema del juego ni del motor. Para obtener los mejores resultados al cambiar las fuentes, intenta mantener el mismo tamaño de texto que tenía originalmente."

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Monday"
    new "{#weekday}Lunes"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Tuesday"
    new "{#weekday}Martes"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Wednesday"
    new "{#weekday}Miércoles"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Thursday"
    new "{#weekday}Jueves"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Friday"
    new "{#weekday}Viernes"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Saturday"
    new "{#weekday}Sábado"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Sunday"
    new "{#weekday}Domingo"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Mon"
    new "{#weekday_short}Lun"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Tue"
    new "{#weekday_short}Mar"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Wed"
    new "{#weekday_short}Mié"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Thu"
    new "{#weekday_short}Jue"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Fri"
    new "{#weekday_short}Vie"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sat"
    new "{#weekday_short}Sáb"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sun"
    new "{#weekday_short}Dom"

    # renpy/common/00action_file.rpy:47
    old "{#month}January"
    new "{#month}Enero"

    # renpy/common/00action_file.rpy:47
    old "{#month}February"
    new "{#month}Febrero"

    # renpy/common/00action_file.rpy:47
    old "{#month}March"
    new "{#month}Marzo"

    # renpy/common/00action_file.rpy:47
    old "{#month}April"
    new "{#month}Abril"

    # renpy/common/00action_file.rpy:47
    old "{#month}May"
    new "{#month}Mayo"

    # renpy/common/00action_file.rpy:47
    old "{#month}June"
    new "{#month}Junio"

    # renpy/common/00action_file.rpy:47
    old "{#month}July"
    new "{#month}Julio"

    # renpy/common/00action_file.rpy:47
    old "{#month}August"
    new "{#month}Agosto"

    # renpy/common/00action_file.rpy:47
    old "{#month}September"
    new "{#month}Septiembre"

    # renpy/common/00action_file.rpy:47
    old "{#month}October"
    new "{#month}Octubre"

    # renpy/common/00action_file.rpy:47
    old "{#month}November"
    new "{#month}Noviembre"

    # renpy/common/00action_file.rpy:47
    old "{#month}December"
    new "{#month}Diciembre"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jan"
    new "{#month_short}Ene"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Feb"
    new "{#month_short}Feb"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Mar"
    new "{#month_short}Mar"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Apr"
    new "{#month_short}Abr"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}May"
    new "{#month_short}May"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jun"
    new "{#month_short}Jun"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jul"
    new "{#month_short}Jul"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Aug"
    new "{#month_short}Ago"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Sep"
    new "{#month_short}Sep"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Oct"
    new "{#month_short}Oct"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Nov"
    new "{#month_short}Nov"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Dec"
    new "{#month_short}Dic"

    # renpy/common/00action_file.rpy:250
    old "%b %d, %H:%M"
    new "%b %d, %H:%M"

    # renpy/common/00action_file.rpy:364
    old "Save slot %s: [text]"
    new "Ranura de guardado %s: [text]"

    # renpy/common/00action_file.rpy:445
    old "Load slot %s: [text]"
    new "Cargar ranura %s: [text]"

    # renpy/common/00action_file.rpy:498
    old "Delete slot [text]"
    new "Eliminar ranura [text]"

    # renpy/common/00action_file.rpy:577
    old "File page auto"
    new "Página de archivos automática"

    # renpy/common/00action_file.rpy:579
    old "File page quick"
    new "Página de archivos rápidos"

    # renpy/common/00action_file.rpy:581
    old "File page [text]"
    new "Página de archivos [text]"

    # renpy/common/00action_file.rpy:780
    old "Next file page."
    new "Siguiente página de archivos."

    # renpy/common/00action_file.rpy:852
    old "Previous file page."
    new "Página de archivos anterior."

    # renpy/common/00action_file.rpy:913
    old "Quick save complete."
    new "Guardado rápido completado."

    # renpy/common/00action_file.rpy:931
    old "Quick save."
    new "Guardado rápido."

    # renpy/common/00action_file.rpy:950
    old "Quick load."
    new "Carga rápida."

    # renpy/common/00action_other.rpy:381
    old "Language [text]"
    new "Idioma [text]"

    # renpy/common/00action_other.rpy:703
    old "Open [text] directory."
    new "Abrir directorio de [text]."

    # renpy/common/00director.rpy:708
    old "The interactive director is not enabled here."
    new "El director interactivo no está habilitado aquí."

    # renpy/common/00director.rpy:1481
    old "⬆"
    new "⬆"

    # renpy/common/00director.rpy:1487
    old "⬇"
    new "⬇"

    # renpy/common/00director.rpy:1551
    old "Done"
    new "Listo"

    # renpy/common/00director.rpy:1561
    old "(statement)"
    new "(declaración)"

    # renpy/common/00director.rpy:1562
    old "(tag)"
    new "(etiqueta)"

    # renpy/common/00director.rpy:1563
    old "(attributes)"
    new "(atributos)"

    # renpy/common/00director.rpy:1564
    old "(transform)"
    new "(transformación)"

    # renpy/common/00director.rpy:1589
    old "(transition)"
    new "(transición)"

    # renpy/common/00director.rpy:1601
    old "(channel)"
    new "(canal)"

    # renpy/common/00director.rpy:1602
    old "(filename)"
    new "(nombre del archivo)"

    # renpy/common/00director.rpy:1631
    old "Change"
    new "Cambiar"

    # renpy/common/00director.rpy:1633
    old "Add"
    new "Añadir"

    # renpy/common/00director.rpy:1636
    old "Cancel"
    new "Cancelar"

    # renpy/common/00director.rpy:1639
    old "Remove"
    new "Eliminar"

    # renpy/common/00director.rpy:1674
    old "Statement:"
    new "Declaración:"

    # renpy/common/00director.rpy:1695
    old "Tag:"
    new "Etiqueta:"

    # renpy/common/00director.rpy:1711
    old "Attributes:"
    new "Atributos:"

    # renpy/common/00director.rpy:1729
    old "Transforms:"
    new "Transformaciones:"

    # renpy/common/00director.rpy:1748
    old "Behind:"
    new "Detrás:"

    # renpy/common/00director.rpy:1767
    old "Transition:"
    new "Transición:"

    # renpy/common/00director.rpy:1785
    old "Channel:"
    new "Canal:"

    # renpy/common/00director.rpy:1803
    old "Audio Filename:"
    new "Nombre del archivo de audio:"

    # renpy/common/00gui.rpy:435
    old "Are you sure?"
    new "¿Estás seguro?"

    # renpy/common/00gui.rpy:436
    old "Are you sure you want to delete this save?"
    new "¿Estás seguro de que quieres eliminar este guardado?"

    # renpy/common/00gui.rpy:437
    old "Are you sure you want to overwrite your save?"
    new "¿Estás seguro de que quieres sobrescribir este guardado?"

    # renpy/common/00gui.rpy:438
    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "Cargar hará que pierdas el progreso no guardado.\n¿Estás seguro de que quieres hacerlo?"

    # renpy/common/00gui.rpy:439
    old "Are you sure you want to quit?"
    new "¿Estás seguro de que quieres salir?"

    # renpy/common/00gui.rpy:440
    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "¿Estás seguro de que quieres volver al menú principal?\nPerderás el progreso no guardado."

    # renpy/common/00gui.rpy:441
    old "Are you sure you want to end the replay?"
    new "¿Estás seguro de que quieres finalizar la repetición?"

    # renpy/common/00gui.rpy:442
    old "Are you sure you want to begin skipping?"
    new "¿Estás seguro de que quieres comenzar a saltar?"

    # renpy/common/00gui.rpy:443
    old "Are you sure you want to skip to the next choice?"
    new "¿Estás seguro de que quieres saltar hasta la siguiente elección?"

    # renpy/common/00gui.rpy:444
    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "¿Estás seguro de que quieres saltar los diálogos no vistos hasta la siguiente elección?"

    # renpy/common/00keymap.rpy:310
    old "Failed to save screenshot as %s."
    new "No se pudo guardar la captura de pantalla como %s."

    # renpy/common/00keymap.rpy:322
    old "Saved screenshot as %s."
    new "Captura de pantalla guardada como %s."

    # renpy/common/00library.rpy:211
    old "Skip Mode"
    new "Modo de salto"

    # renpy/common/00library.rpy:297
    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new "Este programa contiene software libre bajo varias licencias, incluidas la Licencia MIT y la Licencia Pública General Reducida de GNU. Puedes encontrar una lista completa del software, incluidos los enlaces al código fuente completo, {a=https://www.renpy.org/l/license}aquí{/a}."

    # renpy/common/00preferences.rpy:259
    old "display"
    new "pantalla"

    # renpy/common/00preferences.rpy:271
    old "transitions"
    new "transiciones"

    # renpy/common/00preferences.rpy:280
    old "skip transitions"
    new "saltar transiciones"

    # renpy/common/00preferences.rpy:282
    old "video sprites"
    new "sprites de video"

    # renpy/common/00preferences.rpy:291
    old "show empty window"
    new "mostrar ventana vacía"

    # renpy/common/00preferences.rpy:300
    old "text speed"
    new "velocidad del texto"

    # renpy/common/00preferences.rpy:308
    old "joystick"
    new "joystick"

    # renpy/common/00preferences.rpy:308
    old "joystick..."
    new "joystick..."

    # renpy/common/00preferences.rpy:315
    old "skip"
    new "saltar"

    # renpy/common/00preferences.rpy:318
    old "skip unseen [text]"
    new "saltar [text] no visto"

    # renpy/common/00preferences.rpy:323
    old "skip unseen text"
    new "saltar texto no visto"

    # renpy/common/00preferences.rpy:325
    old "begin skipping"
    new "comenzar a saltar"

    # renpy/common/00preferences.rpy:329
    old "after choices"
    new "después de las elecciones"

    # renpy/common/00preferences.rpy:336
    old "skip after choices"
    new "saltar después de las elecciones"

    # renpy/common/00preferences.rpy:338
    old "auto-forward time"
    new "tiempo de avance automático"

    # renpy/common/00preferences.rpy:352
    old "auto-forward"
    new "avance automático"

    # renpy/common/00preferences.rpy:359
    old "Auto forward"
    new "Avance automático"

    # renpy/common/00preferences.rpy:362
    old "auto-forward after click"
    new "avance automático después de hacer clic"

    # renpy/common/00preferences.rpy:371
    old "automatic move"
    new "movimiento automático"

    # renpy/common/00preferences.rpy:380
    old "wait for voice"
    new "esperar la voz"

    # renpy/common/00preferences.rpy:389
    old "voice sustain"
    new "mantener la voz"

    # renpy/common/00preferences.rpy:398
    old "self voicing"
    new "lectura en voz alta"

    # renpy/common/00preferences.rpy:407
    old "self voicing volume drop"
    new "reducción del volumen de la lectura en voz alta"

    # renpy/common/00preferences.rpy:415
    old "clipboard voicing"
    new "lectura del portapapeles"

    # renpy/common/00preferences.rpy:424
    old "debug voicing"
    new "lectura de depuración"

    # renpy/common/00preferences.rpy:433
    old "emphasize audio"
    new "enfatizar audio"

    # renpy/common/00preferences.rpy:442
    old "rollback side"
    new "lado del retroceso"

    # renpy/common/00preferences.rpy:452
    old "gl powersave"
    new "ahorro de energía de GL"

    # renpy/common/00preferences.rpy:458
    old "gl framerate"
    new "frecuencia de fotogramas de GL"

    # renpy/common/00preferences.rpy:461
    old "gl tearing"
    new "desgarro de GL"

    # renpy/common/00preferences.rpy:464
    old "font transform"
    new "transformación de fuente"

    # renpy/common/00preferences.rpy:467
    old "font size"
    new "tamaño de fuente"

    # renpy/common/00preferences.rpy:475
    old "font line spacing"
    new "interlineado de fuente"

    # renpy/common/00preferences.rpy:483
    old "system cursor"
    new "cursor del sistema"

    # renpy/common/00preferences.rpy:492
    old "renderer menu"
    new "menú del renderizador"

    # renpy/common/00preferences.rpy:495
    old "accessibility menu"
    new "menú de accesibilidad"

    # renpy/common/00preferences.rpy:498
    old "high contrast text"
    new "texto de alto contraste"

    # renpy/common/00preferences.rpy:507
    old "audio when minimized"
    new "audio al minimizar"

    # renpy/common/00preferences.rpy:527
    old "main volume"
    new "volumen principal"

    # renpy/common/00preferences.rpy:528
    old "music volume"
    new "volumen de música"

    # renpy/common/00preferences.rpy:529
    old "sound volume"
    new "volumen de efectos"

    # renpy/common/00preferences.rpy:530
    old "voice volume"
    new "volumen de voz"

    # renpy/common/00preferences.rpy:531
    old "mute main"
    new "silenciar volumen principal"

    # renpy/common/00preferences.rpy:532
    old "mute music"
    new "silenciar música"

    # renpy/common/00preferences.rpy:533
    old "mute sound"
    new "silenciar efectos"

    # renpy/common/00preferences.rpy:534
    old "mute voice"
    new "silenciar voz"

    # renpy/common/00preferences.rpy:535
    old "mute all"
    new "silenciar todo"

    # renpy/common/00preferences.rpy:616
    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new "La lectura del portapapeles está activada. Pulsa 'shift+C' para desactivarla."

    # renpy/common/00preferences.rpy:618
    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new "La lectura en voz alta diría \"[renpy.display.tts.last]\". Pulsa 'alt+shift+V' para desactivarla."

    # renpy/common/00preferences.rpy:620
    old "Self-voicing enabled. Press 'v' to disable."
    new "La lectura en voz alta está activada. Pulsa 'v' para desactivarla."

    # renpy/common/_compat/gamemenu.rpym:198
    old "Empty Slot."
    new "Espacio vacío."

    # renpy/common/_compat/gamemenu.rpym:355
    old "Previous"
    new "Anterior"

    # renpy/common/_compat/gamemenu.rpym:362
    old "Next"
    new "Siguiente"

    # renpy/common/_compat/preferences.rpym:428
    old "Joystick Mapping"
    new "Configuración del joystick"

    # renpy/common/_developer/developer.rpym:38
    old "Developer Menu"
    new "Menú para desarrolladores"

    # renpy/common/_developer/developer.rpym:43
    old "Interactive Director (D)"
    new "Director de Interactivos (D)"

    # renpy/common/_developer/developer.rpym:45
    old "Reload Game (Shift+R)"
    new "Recargar juego (Shift+R)"

    # renpy/common/_developer/developer.rpym:47
    old "Console (Shift+O)"
    new "Consola (Shift+O)"

    # renpy/common/_developer/developer.rpym:49
    old "Variable Viewer"
    new "Visor de variables"

    # renpy/common/_developer/developer.rpym:51
    old "Image Location Picker"
    new "Selector de ubicación de imágenes"

    # renpy/common/_developer/developer.rpym:53
    old "Filename List"
    new "Lista de nombres de archivos"

    # renpy/common/_developer/developer.rpym:57
    old "Show Image Load Log (F4)"
    new "Mostrar registro de carga de imágenes (F4)"

    # renpy/common/_developer/developer.rpym:60
    old "Hide Image Load Log (F4)"
    new "Ocultar el registro de carga de imágenes (F4)"

    # renpy/common/_developer/developer.rpym:63
    old "Image Attributes"
    new "Atributos de la imagen"

    # renpy/common/_developer/developer.rpym:90
    old "[name] [attributes] (hidden)"
    new "[name] [attributes] (oculto)"

    # renpy/common/_developer/developer.rpym:94
    old "[name] [attributes]"
    new "[name] [attributes]"

    # renpy/common/_developer/developer.rpym:143
    old "Nothing to inspect."
    new "No hay nada que inspeccionar."

    # renpy/common/_developer/developer.rpym:154
    old "Hide deleted"
    new "Ocultar los elementos eliminados"

    # renpy/common/_developer/developer.rpym:154
    old "Show deleted"
    new "Mostrar eliminados"

    # renpy/common/_developer/developer.rpym:278
    old "Return to the developer menu"
    new "Regresar al menú de desarrolladores"

    # renpy/common/_developer/developer.rpym:443
    old "Rectangle: %r"
    new "Rectangle: %r"

    # renpy/common/_developer/developer.rpym:448
    old "Mouse position: %r"
    new "Posición del ratón: %r"

    # renpy/common/_developer/developer.rpym:453
    old "Right-click or escape to quit."
    new "Haz clic con el botón derecho o presiona la tecla Escape para salir."

    # renpy/common/_developer/developer.rpym:485
    old "Rectangle copied to clipboard."
    new "Se copió el rectángulo al portapapeles."

    # renpy/common/_developer/developer.rpym:488
    old "Position copied to clipboard."
    new "La posición se ha copiado al portapapeles."

    # renpy/common/_developer/developer.rpym:506
    old "Type to filter: "
    new "Escribe para filtrar: "

    # renpy/common/_developer/developer.rpym:631
    old "Textures: [tex_count] ([tex_size_mb:.1f] MB)"
    new "Texturas: [tex_count] ([tex_size_mb:.1f] MB)"

    # renpy/common/_developer/developer.rpym:635
    old "Image cache: [cache_pct:.1f]% ([cache_size_mb:.1f] MB)"
    new "Caché de imágenes: [cache_pct:.1f]% ([cache_size_mb:.1f] MB)"

    # renpy/common/_developer/developer.rpym:645
    old "✔ "
    new "✔"

    # renpy/common/_developer/developer.rpym:648
    old "✘ "
    new "✘"

    # renpy/common/_developer/developer.rpym:653
    old "\n{color=#cfc}✔ predicted image (good){/color}\n{color=#fcc}✘ unpredicted image (bad){/color}\n{color=#fff}Drag to move.{/color}"
    new "\n{color=#cfc}✔ imagen prevista (good){/color}\n{color=#fcc}✘ imagen inesperada (bad){/color}\n{color=#fff}Arrastra para mover{/color}"

    # renpy/common/_developer/inspector.rpym:38
    old "Displayable Inspector"
    new "Inspector visualizable"

    # renpy/common/_developer/inspector.rpym:61
    old "Size"
    new "Tamaño"

    # renpy/common/_developer/inspector.rpym:65
    old "Style"
    new "Estilo"

    # renpy/common/_developer/inspector.rpym:71
    old "Location"
    new "Ubicación"

    # renpy/common/_developer/inspector.rpym:122
    old "Inspecting Styles of [displayable_name!q]"
    new "Análisis de los estilos de [displayable_name!q]"

    # renpy/common/_developer/inspector.rpym:139
    old "displayable:"
    new "displayable:"

    # renpy/common/_developer/inspector.rpym:145
    old "        (no properties affect the displayable)"
    new "        (ninguna propiedad afecta a lo que se puede mostrar)"

    # renpy/common/_developer/inspector.rpym:147
    old "        (default properties omitted)"
    new "        (Se omiten las propiedades predeterminadas)"

    # renpy/common/_developer/inspector.rpym:185
    old "<repr() failed>"
    new "<repr() failed>"

    # renpy/common/_layout/classic_load_save.rpym:170
    old "a"
    new "a"

    # renpy/common/_layout/classic_load_save.rpym:179
    old "q"
    new "q"

    # game/common.rpy:504
    old "'Couldn't {b}you{/b} just take me away?'"
    new "'¿No podrías {b}tú{/b} simplemente llevarme?'"

    # game/common.rpy:504
    old "'Couldn't you pull some strings...?'"
    new "'¿No podrías usar tus influencias...?'"

    # game/common.rpy:742
    old "Get mad"
    new "Enojarse"

    # game/common.rpy:742
    old "Leave it be"
    new "Dejarlo pasar"

    # game/common.rpy:1147
    old "Let him go"
    new "Dejarlo marchar"

    # game/common.rpy:1147
    old "Convince him to stay"
    new "Convencerlo de quedarse"

    # game/common.rpy:1346
    old "Ask"
    new "Preguntar"

    # game/common.rpy:1346
    old "Drop it"
    new "Dejarlo"

    # game/common.rpy:1359
    old "About dark elves"
    new "Sobre los elfos oscuros"

    # game/common.rpy:1359
    old "About Cethin"
    new "Sobre Cethin"

    # game/common.rpy:1359
    old "About the hero"
    new "Sobre el héroe"

    # game/common.rpy:1943
    old "Call the demon butler for help"
    new "Pedir ayuda al mayordomo demonio"

    # game/common.rpy:1943
    old "Give up"
    new "Rendirse"

    # game/common.rpy:3336
    old "He's cute"
    new "Es adorable"

    # game/common.rpy:3336
    old "He's kind"
    new "Es amable"

    # game/common.rpy:3336
    old "He's funny?"
    new "¿Es gracioso?"

    # game/common.rpy:3336
    old "He's fun to tease"
    new "Es divertido tomarle el pelo"

    # game/common.rpy:4114
    old "Talk to Cethin"
    new "Hablar con Cethin"

    # game/common.rpy:4114
    old "Talk to Reo"
    new "Hablar con Reo"

    # game/common.rpy:4214
    old "About night elven yule"
    new "Sobre el Yule de los elfos nocturnos"

    # renpy/common/00iap.rpy:219
    old "Contacting App Store\nPlease Wait..."
    new "Conectando con la App Store\nEspera..."

    # renpy/common/00updater.rpy:419
    old "The Ren'Py Updater is not supported on mobile devices."
    new "El Ren'Py Updater no es compatible con dispositivos móviles."

    # renpy/common/00updater.rpy:548
    old "An error is being simulated."
    new "Se está simulando un error."

    # renpy/common/00updater.rpy:738
    old "Either this project does not support updating, or the update status file was deleted."
    new "Este proyecto no admite actualizaciones o se eliminó el archivo de estado de actualización."

    # renpy/common/00updater.rpy:752
    old "This account does not have permission to perform an update."
    new "Esta cuenta no tiene permiso para realizar una actualización."

    # renpy/common/00updater.rpy:755
    old "This account does not have permission to write the update log."
    new "Esta cuenta no tiene permiso para escribir el registro de actualización."

    # renpy/common/00updater.rpy:783
    old "Could not verify update signature."
    new "No se pudo verificar la firma de la actualización."

    # renpy/common/00updater.rpy:1084
    old "The update file was not downloaded."
    new "No se descargó el archivo de actualización."

    # renpy/common/00updater.rpy:1102
    old "The update file does not have the correct digest - it may have been corrupted."
    new "El archivo de actualización no tiene la suma de comprobación correcta; es posible que esté dañado."

    # renpy/common/00updater.rpy:1252
    old "While unpacking {}, unknown type {}."
    new "Al descomprimir {}, tipo desconocido {}."

    # renpy/common/00updater.rpy:1624
    old "Updater"
    new "Actualizador"

    # renpy/common/00updater.rpy:1631
    old "An error has occured:"
    new "Se ha producido un error:"

    # renpy/common/00updater.rpy:1633
    old "Checking for updates."
    new "Buscando actualizaciones."

    # renpy/common/00updater.rpy:1635
    old "This program is up to date."
    new "Este programa está actualizado."

    # renpy/common/00updater.rpy:1637
    old "[u.version] is available. Do you want to install it?"
    new "[u.version] está disponible. ¿Quieres instalarla?"

    # renpy/common/00updater.rpy:1639
    old "Preparing to download the updates."
    new "Preparándose para descargar las actualizaciones."

    # renpy/common/00updater.rpy:1641
    old "Downloading the updates."
    new "Descargando las actualizaciones."

    # renpy/common/00updater.rpy:1643
    old "Unpacking the updates."
    new "Descomprimiendo las actualizaciones."

    # renpy/common/00updater.rpy:1645
    old "Finishing up."
    new "Finalizando."

    # renpy/common/00updater.rpy:1647
    old "The updates have been installed. The program will restart."
    new "Las actualizaciones se han instalado. El programa se reiniciará."

    # renpy/common/00updater.rpy:1649
    old "The updates have been installed."
    new "Las actualizaciones se han instalado."

    # renpy/common/00updater.rpy:1651
    old "The updates were cancelled."
    new "Las actualizaciones fueron canceladas."

    # renpy/common/00updater.rpy:1666
    old "Proceed"
    new "Continuar"

    # renpy/common/00gallery.rpy:627
    old "Image [index] of [count] locked."
    new "Imagen [index] de [count] bloqueada."

    # renpy/common/00gallery.rpy:647
    old "prev"
    new "anterior"

    # renpy/common/00gallery.rpy:648
    old "next"
    new "siguiente"

    # renpy/common/00gallery.rpy:649
    old "slideshow"
    new "presentación"

    # renpy/common/00gallery.rpy:650
    old "return"
    new "volver"

    # renpy/common/00gltest.rpy:89
    old "Renderer"
    new "Renderizador"

    # renpy/common/00gltest.rpy:93
    old "Automatically Choose"
    new "Elegir automáticamente"

    # renpy/common/00gltest.rpy:100
    old "Force GL Renderer"
    new "Renderizador Force GL"

    # renpy/common/00gltest.rpy:105
    old "Force ANGLE Renderer"
    new "Forzar el renderizador ANGLE"

    # renpy/common/00gltest.rpy:110
    old "Force GLES Renderer"
    new "Forzar el renderizador GLES"

    # renpy/common/00gltest.rpy:116
    old "Force GL2 Renderer"
    new "Forzar renderizador GL2"

    # renpy/common/00gltest.rpy:121
    old "Force ANGLE2 Renderer"
    new "Forzar renderizador ANGLE2"

    # renpy/common/00gltest.rpy:126
    old "Force GLES2 Renderer"
    new "Forzar renderizador GLES2"

    # renpy/common/00gltest.rpy:136
    old "Enable (No Blocklist)"
    new "Activar (sin lista de bloqueo)"

    # renpy/common/00gltest.rpy:159
    old "Powersave"
    new "Ahorro de energía"

    # renpy/common/00gltest.rpy:173
    old "Framerate"
    new "Frecuencia de fotogramas"

    # renpy/common/00gltest.rpy:177
    old "Screen"
    new "Pantalla"

    # renpy/common/00gltest.rpy:181
    old "60"
    new "60"

    # renpy/common/00gltest.rpy:185
    old "30"
    new "30"

    # renpy/common/00gltest.rpy:191
    old "Tearing"
    new "Desgarro"

    # renpy/common/00gltest.rpy:207
    old "Changes will take effect the next time this program is run."
    new "Los cambios surtirán efecto la próxima vez que se ejecute este programa."

    # renpy/common/00gltest.rpy:242
    old "Performance Warning"
    new "Advertencia de rendimiento"

    # renpy/common/00gltest.rpy:247
    old "This computer is using software rendering."
    new "Este equipo está utilizando renderizado por software."

    # renpy/common/00gltest.rpy:249
    old "This game requires use of GL2 that can't be initialised."
    new "Este juego requiere GL2, pero no se puede inicializar."

    # renpy/common/00gltest.rpy:251
    old "This computer has a problem displaying graphics: [problem]."
    new "Este equipo tiene un problema al mostrar los gráficos: [problem]."

    # renpy/common/00gltest.rpy:255
    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."
    new "Es posible que los controladores gráficos estén desactualizados o no funcionen correctamente. Esto puede provocar que los gráficos se muestren lentamente o de forma incorrecta."

    # renpy/common/00gltest.rpy:259
    old "The {a=edit:1:log.txt}log.txt{/a} file may contain information to help you determine what is wrong with your computer."
    new "El archivo {a=edit:1:log.txt}log.txt{/a} puede contener información que te ayude a determinar qué ocurre con tu equipo."

    # renpy/common/00gltest.rpy:264
    old "More details on how to fix this can be found in the {a=[url]}documentation{/a}."
    new "Puedes encontrar más información sobre cómo solucionar esto en la {a=[url]}documentación{/a}."

    # renpy/common/00gltest.rpy:269
    old "Continue, Show this warning again"
    new "Continuar, mostrar esta advertencia de nuevo"

    # renpy/common/00gltest.rpy:273
    old "Continue, Don't show warning again"
    new "Continuar, no volver a mostrar esta advertencia"

    # renpy/common/00gltest.rpy:281
    old "Change render options"
    new "Cambiar opciones de renderizado"

    # renpy/common/00gamepad.rpy:32
    old "Select Gamepad to Calibrate"
    new "Selecciona el mando que quieres calibrar"

    # renpy/common/00gamepad.rpy:35
    old "No Gamepads Available"
    new "No hay mandos disponibles"

    # renpy/common/00gamepad.rpy:54
    old "Calibrating [name] ([i]/[total])"
    new "Calibrando [name] ([i]/[total])"

    # renpy/common/00gamepad.rpy:58
    old "Press or move the '[control!s]' [kind]."
    new "Pulsa o mueve '[control!s]' [kind]."

    # renpy/common/00gamepad.rpy:68
    old "Skip (A)"
    new "Saltar (A)"

    # renpy/common/00gamepad.rpy:71
    old "Back (B)"
    new "Atrás (B)"

    # renpy/common/_errorhandling.rpym:555
    old "Open"
    new "Abrir"

    # renpy/common/_errorhandling.rpym:557
    old "Opens the traceback.txt file in a text editor."
    new "Abre el archivo traceback.txt en un editor de texto."

    # renpy/common/_errorhandling.rpym:559
    old "Copy BBCode"
    new "Copiar BBCode"

    # renpy/common/_errorhandling.rpym:561
    old "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "Copia el archivo traceback.txt al portapapeles como BBCode para foros como https://lemmasoft.renai.us/."

    # renpy/common/_errorhandling.rpym:563
    old "Copy Markdown"
    new "Copiar Markdown"

    # renpy/common/_errorhandling.rpym:565
    old "Copies the traceback.txt file to the clipboard as Markdown for Discord."
    new "Copia el archivo traceback.txt al portapapeles como Markdown para Discord."

    # renpy/common/_errorhandling.rpym:594
    old "An exception has occurred."
    new "Se ha producido una excepción."

    # renpy/common/_errorhandling.rpym:617
    old "Rollback"
    new "Retroceder"

    # renpy/common/_errorhandling.rpym:619
    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "Intenta retroceder a un momento anterior para que puedas guardar o elegir una opción diferente."

    # renpy/common/_errorhandling.rpym:622
    old "Ignore"
    new "Ignorar"

    # renpy/common/_errorhandling.rpym:626
    old "Ignores the exception, allowing you to continue."
    new "Ignora la excepción y te permite continuar."

    # renpy/common/_errorhandling.rpym:628
    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "Ignora la excepción y te permite continuar. Esto suele provocar errores adicionales."

    # renpy/common/_errorhandling.rpym:632
    old "Reload"
    new "Recargar"

    # renpy/common/_errorhandling.rpym:634
    old "Reloads the game from disk, saving and restoring game state if possible."
    new "Recarga el juego desde el disco, guardando y restaurando el estado del juego si es posible."

    # renpy/common/_errorhandling.rpym:637
    old "Console"
    new "Consola"

    # renpy/common/_errorhandling.rpym:639
    old "Opens a console to allow debugging the problem."
    new "Abre una consola para permitir la depuración del problema."

    # renpy/common/_errorhandling.rpym:652
    old "Quits the game."
    new "Sale del juego."

    # renpy/common/_errorhandling.rpym:673
    old "Parsing the script failed."
    new "No se pudo analizar el script."

