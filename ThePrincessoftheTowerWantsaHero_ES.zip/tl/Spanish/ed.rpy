# TODO: Translation updated at 2024-02-08 08:02

# game/ed.rpy:181
translate Spanish finale_e6c9bcb4:

    # voice "voice1/last1.mp3"
    # "And this is where we say:"
    voice "voice1/last1.mp3"
    "Y aquí es donde decimos:"

# game/ed.rpy:185
translate Spanish finale_59c31dab:

    # voice "voice1/last2.mp3"
    # "They all lived happily ever after."
    voice "voice1/last2.mp3"
    "Todos vivieron felices para siempre."

# game/ed.rpy:189
translate Spanish finale_c987f318:

    # voice "voice1/last3.mp3"
    voice "voice1/last3.mp3"

# game/ed.rpy:196
translate Spanish finale_1ed28da5:

    # "{b}The End.{/b}"
    "{b}Fin.{/b}"

