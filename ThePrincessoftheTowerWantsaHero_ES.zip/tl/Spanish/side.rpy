# TODO: Translation updated at 2024-02-08 08:02

# game/side.rpy:12
translate Spanish musings_28ba018d:

    # story "How bothersome.{p}\n They really pushed this bothersome job onto me...{w} I am not looking forward to babysitting a spoiled little lady.{p}\n {i}*sigh*{/i}{p}\n Well, what can I do? No one else was willing to take the job, and the head butler decided this himself.{w} I might as well accept this work."
    story "Qué molesto.{p}\n Realmente me empujaron este trabajo molesto...{w} No tengo ganas de cuidar a una pequeña dama mimada.{p}\n {i}*suspiro*{/i}{p}\n Bueno, ¿qué puedo hacer? Nadie más estaba dispuesto a tomar el trabajo, y el mayordomo principal decidió esto por sí mismo.{w} Bien puedo aceptar este trabajo."

# game/side.rpy:20
translate Spanish musings_8d4d148d:

    # nvl clear
    # story "{b}'Oh? You're a new face. It is a pleasure to meet you.'{/b}{p}\n The little lady smiled at me, all naive and innocent-like.{w} For someone who had been taken captive in such a godforsaken wasteland, she seemed to be taking this rather well."
    nvl clear
    story "{b}'¿Oh? Es una cara nueva. Es un placer conocerlo.'{/b}{p}\n La joven me sonrió con un aire ingenuo e inocente.{w} Para alguien cautiva en un páramo tan maldito, parecía estar llevándolo bastante bien."

# game/side.rpy:28
translate Spanish musings_a9d384e1:

    # story "... Or perhaps she has gotten used to this.{w} In a way, that is rather pitiful.{p}\n Well, no matter. That isn't my concern."
    story "... O quizás ella ya se haya acostumbrado a esto.{w} En cierto modo, eso es bastante triste.{p}\n Bueno, no importa. Eso no es asunto mío."

# game/side.rpy:32
translate Spanish musings_5b73a769:

    # nvl clear
    # story "{b}'Indeed. I shall be serving milady from today onward.'{/b} I bowed to the princess, as per etiquette.{p}\n {b}'Ah, I see... as I've thought...'{/b} her gaze fell on the floor.{w} I could tell from her voice that she was rather disappointed.{p}\n Was she perhaps fond of the one who came before me?{w} What was his name...?{w} Ah, yes, Sebas.{w} I recall that he had recently received a job opportunity in the capital."
    nvl clear
    story "{b}'Así es. Estaré al servicio de milady a partir de hoy.'{/b} Me incliné ante la princesa, como dicta la etiqueta.{p}\n {b}'Ah, ya veo... tal como pensaba...'{/b} Bajó la mirada al suelo.{w} Por su voz, pude notar que estaba bastante decepcionada.{p}\n ¿Quizá le tenía cariño a quien estuvo antes que yo?{w} ¿Cómo se llamaba...?{w} Ah, sí, Sebas.{w} Recuerdo que recientemente recibió una oferta de trabajo en la capital."

# game/side.rpy:41
translate Spanish musings_907b9476:

    # story "Tch. That lucky scamp. {i}-Oh? Do you perhaps miss him already?{/i}- was what I held my tongue from saying.{w} I could not possibly express such rudeness to the lady.{p}\n Instead, I merely bowed my head and flashed her my professional smile.{w} Yes, just as how I had been trained."
    story "Tch. Ese mocoso con suerte. {i}-¿Oh? ¿Acaso ya lo extrañas?{/i}- fue lo que me contuve de decir.{w} No podría expresar tal grosería a la dama.{p}\n En su lugar, solo incliné la cabeza y le mostré mi sonrisa profesional.{w} Sí, justo como me habían entrenado."

# game/side.rpy:47
translate Spanish musings_5a8f9b1e:

    # nvl clear
    # story "The princess perked up and clapped her hands together.{w} {b}'Then, please take care of me. I hope we can get along!'{/b}{p}\n Again, I merely flashed her a smile."
    nvl clear
    story "La princesa se animó y juntó las manos con una palmada.{w} {b}'Entonces, por favor, cuídeme. ¡Espero que podamos llevarnos bien!'{/b}{p}\n Una vez más, me limité a dedicarle una sonrisa."

# game/side.rpy:55
translate Spanish musings_6877c1f9:

    # story "{b}'It's a lovely day today, I hope it stays like this. A while back, it was rather cold so-'{/b}{p}\n ... And she went on and on.{w} Oh dear, I did not expect her to be such a chatterbox.{p}\n It's always like this whenever I come over to serve her."
    story "{b}'Es un día encantador hoy, espero que se mantenga así. Hace un tiempo hacía bastante frío, así que-'{/b}{p}\n ... Y siguió y siguió.{w} Oh cielos, no esperaba que fuera tan parlanchina.{p}\n Siempre es así cada vez que vengo a atenderla."

# game/side.rpy:61
translate Spanish musings_6a077aa1:

    # story "What is she even saying? What is lovely about today?{w} All I see is a boring wasteland of ice and snow- the same one since my birth, never changing.{p}\n As much as I wanted to roll my eyes and give her a nice dose of reality, I couldn't.{w} I am a mere butler, and I must remain cordial.{w} I must zip my lips and smile."
    story "¿Qué está diciendo siquiera? ¿Qué tiene de encantador hoy?{w} Todo lo que veo es un aburrido yermo de hielo y nieve —el mismo desde mi nacimiento, sin cambiar.{p}\n Por mucho que quisiera poner los ojos en blanco y darle una buena dosis de realidad, no podía.{w} Soy un simple mayordomo, y debo permanecer cordial.{w} Debo cerrar la boca y sonreír."

# game/side.rpy:69
translate Spanish musings_734178e4:

    # story "{b}'... I do wish the food here isn't as bland. Sometimes, it's already cold! Otherwise...'{/b}{p}\n Oh gods, she's still at it.{w} Just smile, Reo. Just smile.{p}\n The head butler had instructed us not to indulge her... how could she not tire of this?"
    story "{b}'... Desearía que la comida aquí no fuera tan insípida. A veces, ya está fría. De lo contrario...'{/b}{p}\n Oh dioses, aún sigue.{w} Solo sonríe, Reo. Solo sonríe.{p}\n El mayordomo principal nos había instruido no complacerla... ¿cómo no se cansa de esto?"

# game/side.rpy:75
translate Spanish musings_673be979:

    # nvl clear
    nvl clear

# game/side.rpy:79
translate Spanish musings_bebd4d4d:

    # story "{b}'Milady, I apologize, but if you need nothing else, then I must get going.'{/b}{w} I had to cut her off today, or else we'd be at it for the whole evening.{p}\n It had been this way since my assignment to her.{w} Goodness, does she not get tired of speaking?{p}\n ... Then again, it isn't as though she has anywhere else to direct her energy to."
    story "{b}'Milady, me disculpo, pero si no necesita nada más, debo retirarme.'{/b}{w} Tuve que interrumpirla hoy, o estaríamos así toda la tarde.{p}\n Ha sido así desde que me asignaron a ella.{w} Dios mío, ¿no se cansa de hablar?{p}\n ... Aunque, bueno, no es como si tuviera otro lugar donde dirigir su energía."

# game/side.rpy:88
translate Spanish musings_5bec70f4:

    # story "{b}'O-oh... I see.'{/b} her brows furrowed, {b}'I'm sorry for holding you up. You are free to go.'{/b} it wasn't difficult to notice how dejected she was.{p}\n Gh...{w} Now I feel bad.{p}\n {b}'Until next time then.'{/b} I replied, biting my lips."
    story "{b}'O-oh... Ya veo.'{/b} frunció el ceño, {b}'Lamento haberle hecho perder el tiempo. Puede retirarse.'{/b} no fue difícil notar lo abatida que estaba.{p}\n Gh...{w} Ahora me siento mal.{p}\n {b}'Hasta la próxima entonces.'{/b} respondí, mordiéndome los labios."

# game/side.rpy:95
translate Spanish musings_eb731e77:

    # story "Instantly, the girl lifted her head and her eyes sparkled with excitement {b}'Ah, of course! I am looking forward to your return then!'{/b}{p}\n How baffling. For such a small thing?{p}\n ..."
    story "De inmediato, la chica levantó la cabeza y sus ojos brillaron con emoción {b}'¡Ah, por supuesto! ¡Espero con ansias su regreso entonces!'{/b}{p}\n Qué desconcertante. ¿Por algo tan pequeño?{p}\n ..."

# game/side.rpy:101
translate Spanish musings_194ffd2f:

    # story "Ah.{w} No.{w} Of course I understand.{w} The lass must have been lonely.{p}\n Pried away from her home, her family and her friends...{p}\n Dear me, I should say that it is even more baffling how no one else had realized this.{w} Had they actually been doing their work?{p}\n As usual, it seems that I must clean up after those fools."
    story "Ah.{w} No.{w} Por supuesto que lo entiendo.{w} La joven debe haber estado sola.{p}\n Alejada de su hogar, su familia y sus amigos...{p}\n Por los cielos, debería decir que es aún más desconcertante cómo nadie más se había dado cuenta de esto.{w} ¿Acaso habían estado haciendo su trabajo?{p}\n Como de costumbre, parece que debo limpiar los errores de esos tontos."

# game/side.rpy:109
translate Spanish musings_a96bae36:

    # nvl clear
    # story "As a butler, I must not allow my personal sentiments get in the way of my work...{w} but it is part of my job to take care of the little lady's needs.{w} That includes both her physical and mental well-being."
    nvl clear
    story "Como mayordomo, no debo permitir que mis sentimientos personales interfieran con mi trabajo...{w} pero parte de él consiste en atender las necesidades de la joven.{w} Eso incluye tanto su bienestar físico como mental."

# game/side.rpy:116
translate Spanish musings_de468715:

    # story "{b}'Milady, I hope you had not forgotten your etiquette? Imagine if the hero finds you with your mouth stuffed like a squirrel?'{b}"
    story "{b}'Milady, espero que no haya olvidado sus modales. ¿Se imagina que el héroe la encontrara con la boca llena como una ardilla?'{/b}"

# game/side.rpy:118
translate Spanish musings_98ff10a0:

    # story "{b}'Well... I blame you for making such exquisite snacks!'{/b} she pouted rather cutely.{w} It made me want to pull on her cheeks."
    story "{b}'Bueno... ¡Le culpo a usted por hacer bocadillos tan exquisitos!'{/b} hizo un puchero de forma bastante adorable.{w} Me dieron ganas de tirarle de las mejillas."

# game/side.rpy:120
translate Spanish musings_b2976e5e:

    # story "{b}'Haha. I suppose it would be a fine tale to tell in history books- 'The Squirrel Princess'. Wouldn't that just be simply adorable?'{/b}"
    story "{b}'Jaja. Supongo que sería una buena historia para contar en los libros de historia —‘La Princesa Ardilla’. ¿No sería simplemente adorable?'{/b}"

# game/side.rpy:122
translate Spanish musings_eee23d48:

    # story "Therefore, as a butler, I must adapt my services accordingly.{w} If being casual toward milady is what she needs... then etiquette be damned."
    story "Por lo tanto, como mayordomo, debo adaptar mis servicios en consecuencia.{w} Si ser informal con milady es lo que necesita... entonces, al diablo la etiqueta."

# game/side.rpy:124
translate Spanish musings_c5934ef2:

    # story "{b}'You truly are insufferable...'{/b} she says, while chucking another piece of biscuit in her mouth.{w} Despite her words of frustration, it was evident how contradictory her mood was."
    story "{b}'De verdad eres insoportable...'{/b}, dice mientras se mete otro trozo de galleta en la boca.{w} A pesar de sus palabras de frustración, era evidente lo contradictorio de su estado de ánimo."

# game/side.rpy:127
translate Spanish musings_32d5f807:

    # story "I could tell- she shined much brighter than when I first met her.{p}\n {b}'My pleasure~'{/b} I replied with a smile.{w} She scoffed."
    story "Podía notarlo: brillaba mucho más que cuando la conocí.{p}\n {b}'Un placer~'{/b} respondí con una sonrisa.{w} Ella resopló."

# game/side.rpy:131
translate Spanish musings_38264c67:

    # nvl clear
    # story "How troublesome.{w} When I accepted this job, I never imagined...{w} that I'd find myself this entertained.{p}\n I turned my eyes toward the castle balcony, only to see the same old scenery.{p}\n {i}Snow. Snow... and more snow.{/i}{w} Honestly? I hate it.{w} If only I could leave this place..."
    nvl clear
    story "Qué fastidio.{w} Cuando acepté este trabajo, jamás imaginé...{w} que acabaría divirtiéndome tanto.{p}\n Dirigí la mirada al balcón del castillo, solo para encontrar el mismo paisaje de siempre.{p}\n {i}Nieve. Nieve... y más nieve.{/i}{w} ¿La verdad? La odio.{w} Ojalá pudiera irme de este lugar..."

# game/side.rpy:139
translate Spanish musings_477b23c9:

    # story "{b}'Butler, has anything interesting happened today?'{/b}{p}\n {b}'Oh, none at all. You know how dull this place is.'{/b}{p}\n Yes. Such a dull place.{w} I am quite certain that you feel the same."
    story "{b}'Mayordomo, ¿ha pasado algo interesante hoy?'{/b}{p}\n {b}'Oh, en absoluto. Ya sabe qué tan aburrido es este lugar.'{/b}{p}\n Sí. Qué lugar tan aburrido.{w} Estoy bastante seguro de que siente lo mismo."

# game/side.rpy:145
translate Spanish musings_a76d1b83:

    # story "{b}'I see... the soup tasted rather different, so I was wondering if-'{/b}{p}\n Truly. What a chatterbox.{w} I could not help but smile.{p}\n To treat me, a mere butler and a demonkin, as though you would a friend?{w} How foolish."
    story "{b}'Ya veo... la sopa sabía algo diferente, así que me preguntaba si-'{/b}{p}\n De verdad. Qué parlanchina.{w} No pude evitar sonreír.{p}\n ¿Tratarme a mí, un simple mayordomo y un demonkin, como si fuera un amigo?{w} Qué tonta."

# game/side.rpy:151
translate Spanish musings_617855c9:

    # story "I... do not dislike it,{w} but I do not condone it.{w} At the end of the day, I am a mere butler, and you, a princess.{p}\n I know that you feel the same deep down.{w} A line must be drawn between us."
    story "Yo... no lo desapruebo,{w} pero tampoco lo apruebo.{w} Al final del día, soy un simple mayordomo, y usted, una princesa.{p}\n Sé que en el fondo usted siente lo mismo.{w} Debe haber una línea que nos separe."

# game/side.rpy:155
translate Spanish musings_4f9767e5:

    # story "Ah.{w} Still, I wish...{w} I can maintain that smile of yours as well, until the time you are able to leave this shared prison of ours.{p}\n Until then, I shall serve as your faithful butler and stay by your side.{p}\n ... Not that you'd ever hear these words straight from me."
    story "Ah.{w} Aun así, deseo...{w} poder conservar esa sonrisa suya hasta que llegue el momento en que pueda abandonar esta prisión que compartimos.{p}\n Hasta entonces, serviré como su fiel mayordomo y permaneceré a su lado.{p}\n ... Aunque jamás me oiría decirle estas palabras directamente."

# game/side.rpy:161
translate Spanish musings_673be979_1:

    # nvl clear
    nvl clear

# game/side.rpy:172
translate Spanish reality_cb4308fc:

    # story "Five? Four? Six?{w} How many days has it been?{p}\n I'm scared. I'm cold. I'm hungry.{p}\n I'd cry if I could, but I'm too tired even for that.{w} How could I not? I've done nothing but {i}{b}just that{/b}{/i} these past few days.{p}\n I couldn't help but huddle with myself in the corner of the room."
    story "¿Cinco? ¿Cuatro? ¿Seis?{w} ¿Cuántos días han pasado?{p}\n Tengo miedo. Tengo frío. Tengo hambre.{p}\n Lloraría si pudiera, pero estoy demasiado cansada incluso para eso.{w} ¿Cómo no estaría así? No he hecho nada más que {i}{b}solo eso{/b}{/i} estos últimos días.{p}\n No pude evitar acurrucarme en una esquina de la habitación."

# game/side.rpy:181
translate Spanish reality_c265f789:

    # nvl clear
    # story "If my teacher could see me now, I'd surely get a scolding...{p}\n {i}'Princess! The way you are sitting, and your appearance...! How unsightly!'{/i}{p}\n ... Something like that.{w} I bit my lips. They felt dry.{p}\n ..."
    nvl clear
    story "Si mi maestra pudiera verme ahora, seguro que me regañaría...{p}\n {i}'¡Princesa! ¡La forma en que está sentada y su aspecto...! ¡Qué poco decoroso!'{/i}{p}\n ... Algo así.{w} Me mordí los labios. Los sentía secos.{p}\n ..."

# game/side.rpy:191
translate Spanish reality_f1726087:

    # nvl clear
    # story "In the end, I just closed my eyes, hoping that when I open them again, I'd be greeted by someone who will take me back home.{p}\n {b}'Mother... father... I miss you...'{/b}{w} I muttered.{w} How I wish this was all just a dream...{p}\n Slowly, my consciouness slipped away...{w} and everything went black."
    nvl clear
    story "Al final, cerré los ojos, esperando que, cuando volviera a abrirlos, alguien me recibiera y me llevara de vuelta a casa.{p}\n {b}'Mamá... papá... los extraño...'{/b}{w} murmuré.{w} Ojalá todo esto fuera solo un sueño...{p}\n Poco a poco, perdí la consciencia...{w} y todo se volvió negro."

# game/side.rpy:201
translate Spanish reality_56362f69:

    # story "When I woke up, I had been placed on the bed.{w} It was already nighttime when I came to.{p}\n There was a bowl of soup and a piece of bread on the table.{w} They were frozen cold.{p}\n I ended up consuming them. It's not like I have any better choice.{p}\n As I thought, they were bad."
    story "Cuando desperté, me habían puesto en la cama.{w} Ya era de noche cuando recobré la conciencia.{p}\n Había un cuenco de sopa y un trozo de pan en la mesa.{w} Estaban helados.{p}\n Terminé comiéndolos. No es como si tuviera una mejor opción.{p}\n Como pensé, sabían mal."

# game/side.rpy:209
translate Spanish reality_c9ce52bf:

    # story "I wouldn't consider myself picky, but it's probably just because our chef was really good.{w} We often get praises from guests.{w} I've never really thought much about it back then... but now, I feel quite proud.{p}\n I've never met our chef, but I wish I could thank them.{p}\n I nodded to myself.{w} Yes... I'll definitely thank them when I get back."
    story "No me consideraría quisquillosa, pero probablemente sea solo porque nuestro chef era realmente bueno.{w} A menudo recibíamos elogios de los invitados.{w} Nunca lo pensé mucho en ese entonces... pero ahora, me siento bastante orgullosa.{p}\n Nunca conocí a nuestro chef, pero desearía poder agradecerle.{p}\n Asentí para mí misma.{w} Sí... definitivamente le agradeceré cuando regrese."

# game/side.rpy:216
translate Spanish reality_673be979:

    # nvl clear
    nvl clear

# game/side.rpy:220
translate Spanish reality_6a021ae5:

    # story "Again, I found myself on the bed.{w} By my bedside was a platter of my supposed breakfast.{p}\n The horned people...{w} those demons... I believe they're the ones who brought these.{w} They're also the ones who tuck me in bed.{p}\n I admit, I was scared of them at first...{w} but I don't think they mean harm."
    story "Una vez más, me encontré en la cama.{w} Junto a mí había una bandeja con mi supuesto desayuno.{p}\n Las personas con cuernos...{w} esos demonios... creo que son los que traen esto.{w} También son los que me arropan en la cama.{p}\n Lo admito, al principio les tenía miedo...{w} pero no creo que quieran hacerme daño."

# game/side.rpy:226
translate Spanish reality_47d4b6b1:

    # story "I think they try to stay out of my sight as best as they could... but I'd like to talk to them.{p}\n ...or not."
    story "Creo que intentan mantenerse fuera de mi vista tanto como pueden... pero me gustaría hablar con ellos.{p}\n ... o tal vez no."

# game/side.rpy:230
translate Spanish reality_7676b9fc:

    # story "I don't know.{w} They serve the demon lord, so aren't they supposed to be bad?{p}\n But when they do come here to check on me, they always seemed troubled...{w} actually, I think they feel bad for me.{p}\n They try to avoid any form of contact.{w} They don't even look me in the eyes.{p}\n ..."
    story "No lo sé.{w} Sirven al señor demonio, ¿así que no se supone que son malos?{p}\n Pero cuando vienen a revisarme, siempre parecen preocupados...{w} en realidad, creo que se sienten mal por mí.{p}\n Intentan evitar cualquier tipo de contacto.{w} Ni siquiera me miran a los ojos.{p}\n ..."

# game/side.rpy:238
translate Spanish reality_3cd71e44:

    # story "Perhaps I'm just overthinking this.{w} I rubbed an arm over my eyes.{w} The idle thoughts distracted me for a moment, but now I'm reminded of my situation.{p}\n Right... I'm still trapped here.{w} Alone.{p}\n I ended up curling into a ball at a corner of the bed once more, hoping that this would end soon."
    story "Quizá solo le estoy dando demasiadas vueltas.{w} Me pasé el brazo por los ojos.{w} Esos pensamientos me distrajeron un momento, pero ahora vuelvo a recordar mi situación.{p}\n Cierto... sigo atrapada aquí.{w} Sola.{p}\n Volví a acurrucarme en una esquina de la cama, esperando que esto terminara pronto."

# game/side.rpy:245
translate Spanish reality_673be979_1:

    # nvl clear
    nvl clear

# game/side.rpy:249
translate Spanish reality_ab1fe6ff:

    # story "How long has it been?{w} It's the same thing every day. The same routine.{w} The same cold room.{p}\n They said a hero would come for me...{w} father promised me that he'll send me the best hero he could find.{p}\n I wonder if they are on the way?"
    story "¿Cuánto tiempo ha pasado?{w} Es lo mismo todos los días. La misma rutina.{w} La misma habitación fría.{p}\n Dijeron que un héroe vendría por mí...{w} padre me prometió que enviaría al mejor héroe que pudiera encontrar.{p}\n Me pregunto si ya está en camino."

# game/side.rpy:256
translate Spanish reality_81c362ff:

    # story "Ah...{w} I suppose there's something new this time;{w} the butler was new.{p}\n This one was younger.{w} Green haired, curious ram-like horns."
    story "Ah...{w} Supongo que hay algo nuevo esta vez;{w} el mayordomo era nuevo.{p}\n Este era más joven.{w} Cabello verde, cuernos curiosos como de carnero."

# game/side.rpy:260
translate Spanish reality_58e2d9b5:

    # story "He was quiet, but when he heard that my food was cold, he replaced it without a word.{p}\n I'd like to try and talk to him tomorrow.{w} He seemed nice."
    story "Era callado, pero cuando escuchó que mi comida estaba fría, la reemplazó sin decir una palabra.{p}\n Me gustaría intentar hablarle mañana.{w} Parecía amable."

# game/side.rpy:264
translate Spanish reality_673be979_2:

    # nvl clear
    nvl clear

# game/side.rpy:268
translate Spanish reality_d755983d:

    # story "Has it been long already?{w} The butler from before was replaced again. I wonder if he's all right?{p}\n The new one has pink hair.{w} It's cute... he reminded me of flowers.{p}\n He also wouldn't respond to me, but he does smile when I try to talk to him."
    story "¿Ya ha pasado mucho tiempo?{w} El mayordomo anterior volvió a ser reemplazado. Me pregunto si estará bien.{p}\n El nuevo tiene el cabello rosado.{w} Es lindo... me recuerda a las flores.{p}\n Tampoco me responde, pero sí sonríe cuando intento hablar con él."

# game/side.rpy:277
translate Spanish reality_6e117f85:

    # story "...{p}\n I hadn't heard anything about the outside.{w} I hope everyone is doing fine.{p}\n When will my hero come?"
    story "...{p}\n No he escuchado nada sobre el exterior.{w} Espero que todos estén bien.{p}\n ¿Cuándo vendrá mi héroe?"

# game/side.rpy:285
translate Spanish reality_64e151dc:

    # story "...{p}\n They have not forgotten me, have they?{p}\n They will send me a hero, right...?{p}\n How much longer must I wait?{w} I... want to go home."
    story "...{p}\n No me habrán olvidado, ¿verdad?{p}\n Enviarán a un héroe por mí, ¿cierto...?{p}\n ¿Cuánto más debo esperar?{w} Yo... quiero ir a casa."

# game/side.rpy:293
translate Spanish reality_673be979_3:

    # nvl clear
    nvl clear

# game/side.rpy:297
translate Spanish reality_6e6f3239:

    # story "{b}'Oh brave hero! I have been waiting for you...!'{/b}{w} I think that sounded fine.{w} That sounded fine, right?{p}\n These days, I pre-occupy myself with preparing for my hero's arrival.{w} Oh dear. When will they arrive?{w} I have to always prepare myself for their arrival... wouldn't it be embarrassing if they chance upon me while I am half-asleep?"
    story "{b}'¡Oh valiente héroe! ¡He estado esperando por ti...!'{/b}{w} Creo que sonó bien.{w} Sonó bien, ¿verdad?{p}\n Estos días me entretengo preparándome para la llegada de mi héroe.{w} Oh cielos. ¿Cuándo llegará?{w} Debo estar siempre lista para su llegada... ¿no sería vergonzoso si me encontrara medio dormida?"

# game/side.rpy:302
translate Spanish reality_9a1e7fb7:

    # nvl clear
    # story "This may seem foolish.{w} Ridiculous, even.{p}\n ... But none of that matters.{w} Anything will do.{p}\n Anything that can distract me. Anything will do.{p}\n New butlers.{w} Food.{w} Daydreams.{w} Anything."
    nvl clear
    story "Esto puede parecer tonto.{w} Incluso ridículo.{p}\n ... Pero nada de eso importa.{w} Cualquier cosa sirve.{p}\n Cualquier cosa que pueda distraerme. Cualquier cosa sirve.{p}\n Mayordomos nuevos.{w} Comida.{w} Soñar despierta.{w} Lo que sea."

# game/side.rpy:312
translate Spanish reality_d88f92b0:

    # story "\n\n\n {b}'A little more, right? Just a little more... my hero should arrive soon.'{/b}"
    story "\n\n\n {b}'Un poco más, ¿verdad? Solo un poco más... mi héroe debería llegar pronto.'{/b}"

# game/side.rpy:314
translate Spanish reality_673be979_4:

    # nvl clear
    nvl clear

# game/side.rpy:326
translate Spanish mule_18ea101c:

    # story "{b}'DISGUSTING!!!'{/b}" with vpunch
    story "{b}'¡ASQUEROSO!'{/b}" with vpunch

# game/side.rpy:328
translate Spanish mule_3ea0333b:

    # story "Farol threw the bowl on the floor. Some of its contents spilled on my clothes.{p}\n {b}'O-oh... um... sorry. I'll clean this up.'{/b} I hurried to pick up the utensils on the ground."
    story "Farol lanzó el cuenco al suelo. Parte de su contenido cayó sobre mi ropa.{p}\n {b}'O-oh... um... lo siento. Limpiaré esto.'{/b} Me apresuré a recoger los utensilios del suelo."

# game/side.rpy:332
translate Spanish mule_b8559107:

    # story "{b}'Yuck. Why don't you make yourself useful and learn how to cook better, drow?'{/b}{w} the white mage stuck her tongue out and threw the contents on the ground.{p}\n {b}'Ah. Just look at the food we ended up wasting...'{/b} the black mage added, throwing her soup out as well."
    story "{b}'Puaj. ¿Por qué no te vuelves útil y aprendes a cocinar mejor, drow?'{/b}{w} la maga de luz sacó la lengua y tiró su plato al suelo.{p}\n {b}'Ah. Mira toda la comida que terminamos desperdiciando...'{/b} añadió la maga oscura, arrojando también su sopa."

# game/side.rpy:337
translate Spanish mule_8be79f97:

    # story "{b}'I-I'm sorry... I'll... I'll do better next time.'{/b} I lowered my head.{w} I've never had to cook for humans, so I wasn't sure what suited their tastes...{w} then again, it's not like I've ever been any good at cooking for myself.{p}\n As long as it was edible, I was fine with it.{p}\n The black mage crossed her arms, {b}'Farrie, why are we even keeping that thing? He's so useless...'{/b}"
    story "{b}'L-lo siento... Yo... lo haré mejor la próxima vez.'{/b} Bajé la cabeza.{w} Nunca había tenido que cocinar para humanos, así que no estaba seguro de qué les gustaba...{w} aunque, no es como si alguna vez hubiera sido bueno cocinando para mí mismo.{p}\n Mientras fuera comestible, estaba bien para mí.{p}\n La maga oscura cruzó los brazos, {b}'Farrie, ¿por qué seguimos manteniendo a esa cosa? Es tan inútil...'{/b}"

# game/side.rpy:344
translate Spanish mule_0998650d:

    # story "I froze.{w} A-are they kicking me out?{w} I wanted to say that I'd do better, but I bit my tongue. I couldn't promise anything like that.{w} No matter how hard I try at anything, I never get better.{p}\n ...{p}\n ... Maybe they're right.{w} Maybe everyone had been right about me.{w} I'm useless, aren't I...?"
    story "Me quedé helado.{w} ¿M-me van a echar?{w} Quise decir que mejoraría, pero me mordí la lengua. No podía prometer algo así.{w} Por mucho que me esfuerce, nunca mejoro.{p}\n ...{p}\n ... Tal vez tengan razón.{w} Tal vez todos han tenido razón sobre mí.{w} Soy inútil, ¿no...?"

# game/side.rpy:351
translate Spanish mule_70acf116:

    # nvl clear
    # story "{b}'W-well! He's trying hard, can't you see? Give the drow a chance.'{/b} Farol smiled,{w}{b} 'Isn't that right, drow?'{/b}{p}\n I blinked.{w} Did I hear that right? Farol defended me...?{p}\n {b}'H-huh? Uhm... yes! I'll do better next time!'{/b}{w} I suddenly felt motivated.{w} I think I can study some human recipes the next time we make a stop at a town."
    nvl clear
    story "{b}'B-bueno, se está esforzando, ¿no lo ves? Dale una oportunidad al drow.'{/b} Farol sonrió.{w}{b} '¿No es así, drow?'{/b}{p}\n Parpadeé.{w} ¿Había oído bien? ¿Farol me había defendido...?{p}\n {b}'¿E-eh? Ehm... ¡sí! ¡Lo haré mejor la próxima vez!'{/b}{w} De pronto me sentí motivado.{w} Creo que podré estudiar algunas recetas humanas la próxima vez que hagamos escala en un pueblo."

# game/side.rpy:360
translate Spanish mule_2c998f92:

    # story "{b}'Oh Farol, you're way too nice.'{/b}{w} the lady in white leaned on him.{p}\n {b}'Haha! Well, I mean... of course I am!'{/b}{p}\n ..."
    story "{b}'Oh Farol, eres demasiado amable.'{/b}{w} la dama de blanco se apoyó en él.{p}\n {b}'¡Jajaja! Bueno, quiero decir... ¡por supuesto que lo soy!'{/b}{p}\n ..."

# game/side.rpy:366
translate Spanish mule_23b2ca46:

    # story "I wonder.{w} With the direction we are going, I'm pretty sure this is close to my hometown...{p}\n He's not... after our divine blade, is he?"
    story "Me pregunto.{w} Con la dirección que llevamos, estoy bastante seguro de que estamos cerca de mi ciudad natal...{p}\n Él no estará... ¿tras nuestra espada divina, verdad?"

# game/side.rpy:370
translate Spanish mule_bb954845:

    # story "The black mage was tapping my map before she spoke up, {b}'Farrie, are you sure you want to go for Edana Dungeon? No one has gotten through that place yet... and for a reason.'{/b}"
    story "La maga oscura estaba golpeando mi mapa antes de hablar, {b}'Farrie, ¿estás seguro de que quieres ir a la Mazmorra Edana? Nadie ha pasado por ese lugar aún... y por una razón.'{/b}"

# game/side.rpy:373
translate Spanish mule_7b886c62:

    # story "Ah...{w} Of course they are.{p}\n I see.{w} That's... why they took me in.{p}\n ...{p}\n I continued cleaning our utensils while everyone slept."
    story "Ah...{w} Por supuesto que sí.{p}\n Ya veo.{w} Por eso me aceptaron.{p}\n ...{p}\n Continué limpiando nuestros utensilios mientras todos dormían."

# game/side.rpy:381
translate Spanish mule_d5f036db:

    # story "My mind couldn't help but wander off...{w} I felt like crying, but it would have been unsightly so I held it in.{w} Ha. I'm really so weak.{w} I should have known...{p}\n There was no way anyone would have wanted me.{p}\n Yet, what pained me the most, was the fact that despite all this, I was happy.{p}\n ... I was simply happy to have been accepted."
    story "Mi mente no podía evitar divagar...{w} Quise llorar, pero habría sido inapropiado, así que lo contuve.{w} Ja. Realmente soy tan débil.{w} Debería haberlo sabido...{p}\n No había forma de que alguien me quisiera.{p}\n Aun así, lo que más dolía era el hecho de que, a pesar de todo esto, era feliz.{p}\n ... Simplemente era feliz de haber sido aceptado."

# game/side.rpy:392
translate Spanish mule_eb7653cf:

    # nvl clear
    # story "{b}'And- I'd also like to apologize about earlier.'{/b}{p}\n {b}'Perhaps I may have acted irrationally.'{/b}{p}\n {b}'I mean, you were only gone for a moment after all.'{/b}"
    nvl clear
    story "{b}'Y... también quisiera disculparme por lo de antes.'{/b}{p}\n {b}'Puede que haya actuado de forma irracional.'{/b}{p}\n {b}'Quiero decir, después de todo solo estuviste fuera un momento.'{/b}"

# game/side.rpy:400
translate Spanish mule_0c15166d:

    # story "I've upset the princess.{p}\n I've practiced really hard for Farol and the others, so I've gotten to a point where they don't complain about my cooking..."
    story "He molestado a la princesa.{p}\n He practicado mucho para Farol y los demás, así que he llegado a un punto en que ya no se quejan de mi comida..."

# game/side.rpy:404
translate Spanish mule_47ddeb8c:

    # story "So when I thought that I could make use of it for Princess Lumi, I immediately took the chance.{w} I wanted to surprise her, but I also didn't want to let her down...{w} so I kept it a secret."
    story "Así que cuando pensé que podía usar eso para la Princesa Lumi, aproveché la oportunidad de inmediato.{w} Quería sorprenderla, pero tampoco quería decepcionarla...{w} así que lo mantuve en secreto."

# game/side.rpy:407
translate Spanish mule_02068386:

    # story "... Instead, I've upset her.{p}\n Ah... {w} But I feel happy instead..."
    story "... En cambio, la he molestado.{p}\n Ah... {w} Pero, en lugar de eso, me siento feliz..."

# game/side.rpy:411
translate Spanish mule_7733e9cf:

    # story "It baffled me at first-{w} of how much trust she puts on me, despite being a dark elf.{p}\n Well, I figured she must have been naive.{w} N-not that I wanted to take advantage of it!{p}\n No... definitely not.{w} Actually, it's quite worrisome how little she knew."
    story "Al principio me desconcertó —{w} la cantidad de confianza que deposita en mí, a pesar de ser un elfo oscuro.{p}\n Bueno, supuse que debía de ser ingenua.{w} ¡N-no es que quisiera aprovecharme de eso!{p}\n No... definitivamente no.{w} En realidad, es preocupante lo poco que sabía."

# game/side.rpy:417
translate Spanish mule_7b63f796:

    # story "Humans and other races did not trust us, and for a good reason.{p}\n We have a terrible reputation, and... it's not exactly unfounded either.{p}\n Our predecessors have been known to betray, destroy and usurp."
    story "Los humanos y otras razas no confían en nosotros, y con razón.{p}\n Tenemos una terrible reputación, y... tampoco es que sea infundada.{p}\n Nuestros predecesores fueron conocidos por traicionar, destruir y usurpar."

# game/side.rpy:423
translate Spanish mule_1429568b:

    # story "...{p}\n She's wholly unaware of us, isn't she?{p}\n ... or perhaps, she simply chooses to turn a blind eye?"
    story "...{p}\n Ella no sabe nada de nosotros, ¿verdad?{p}\n ... ¿O tal vez simplemente elige no verlo?"

# game/side.rpy:429
translate Spanish mule_d2b9b033:

    # story "No...{w} I am quite certain that the princess simply do not wish to judge me as a dark elf.{p}\n Perhaps I'm putting her on a pedestal.{p}\n No matter what her reason is, it doesn't matter."
    story "No...{w} Estoy bastante seguro de que la princesa simplemente no desea juzgarme como un elfo oscuro.{p}\n Tal vez la estoy idealizando demasiado.{p}\n No importa cuál sea su razón, no tiene importancia."

# game/side.rpy:435
translate Spanish mule_43ca7980:

    # story "I don't deserve her kindness.{w} I lied to her.{p}\n I'm certain that she'd forgive me if I'd come clean,{w} but simply thinking about having her learn the truth disgusts me.{p}\n I don't want her to know that I'm just the party's so-called 'luggage mule'.{w} I don't want her to know how disgusted I am with myself.{w} I don't want her to see the coward hiding behind the hero's mask."
    story "No merezco su amabilidad.{w} Le mentí.{p}\n Estoy seguro de que me perdonaría si le contara la verdad,{w} pero el simple hecho de pensar que la descubra me repugna.{p}\n No quiero que sepa que no soy más que la llamada «mula de carga» del grupo.{w} No quiero que sepa lo asqueado que estoy de mí mismo.{w} No quiero que vea al cobarde que se esconde detrás de la máscara del héroe."

# game/side.rpy:442
translate Spanish mule_912b7fec:

    # story "...{p}\n Maybe someday.{w} Someday, I'll have the courage to confess.{w} Someday, when I've become someone worthy of her attention.{p}\n But for now... I'd like to forget who I am.{p}\n I want just be the 'Cethin' in her eyes."
    story "...{p}\n Quizá algún día.{w} Algún día tendré el valor para confesarlo.{w} Algún día, cuando me haya convertido en alguien digno de su atención.{p}\n Pero por ahora... quiero olvidar quién soy.{p}\n Solo quiero ser el 'Cethin' que ella ve."

# game/side.rpy:450
translate Spanish mule_3c1b0650:

    # story "I just want to keep this happiness.{p}\n And I also want to keep her happy."
    story "Solo quiero conservar esta felicidad.{p}\n Y también quiero hacerla feliz."

# game/side.rpy:454
translate Spanish mule_9ec0a230:

    # story "I could tell.{w} This is a different feeling from when I was still part of Farol's party.{p}\n I was also happy then, yes, but I was also disgusted with myself.{p}\n It was sickening."
    story "Podía notarlo.{w} Era una sensación distinta de la que tenía cuando aún formaba parte del grupo de Farol.{p}\n También era feliz entonces, sí, pero me sentía asqueado de mí mismo.{p}\n Era insoportable."

# game/side.rpy:460
translate Spanish mule_965ba3b1:

    # story "I do feel foul that I feel glad about the princess feeling upset over me being gone..."
    story "Me siento mal por alegrarme de que la princesa se sienta triste por mi ausencia..."

# game/side.rpy:462
translate Spanish mule_f6469771:

    # story "... No,{w} on second thought, I don't.{p}\n I know she was upset, but-{p}\n I just feel... happy."
    story "... No,{w} pensándolo bien, no.{p}\n Sé que estaba molesta, pero-{p}\n Solo me siento... feliz."

# game/side.rpy:468
translate Spanish mule_47ab7423:

    # story "Ngh...{p}\n ... Perhaps I really am a twisted dark elf?"
    story "Ngh...{p}\n ... ¿Quizás realmente soy un elfo oscuro retorcido?"

# game/side.rpy:472
translate Spanish mule_76b2fe88:

    # nvl clear
    nvl clear


#translate Spanish python:
#    gui.nvl_text_ypos = -5
