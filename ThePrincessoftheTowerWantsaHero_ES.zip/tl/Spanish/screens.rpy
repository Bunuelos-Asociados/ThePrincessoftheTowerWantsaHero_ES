# TODO: Translation updated at 2024-02-08 08:02

translate Spanish strings:

    # game/screens.rpy:258
    old "Back"
    new "Volver"

    # game/screens.rpy:259
    old "History"
    new "Historial"

    # game/screens.rpy:260
    old "Skip"
    new "Saltar"

    # game/screens.rpy:261
    old "Auto"
    new "Auto"

    # game/screens.rpy:262
    old "Save"
    new "Guardar"

    # game/screens.rpy:263
    old "Load"
    new "Cargar"

    # game/screens.rpy:264
    old "Settings"
    new "Configuración"

    # game/screens.rpy:305
    old "Start"
    new "Iniciar"

    # game/screens.rpy:315
    old "Preferences"
    new "Preferencias"

    # game/screens.rpy:319
    old "End Replay"
    new "Terminar repetición"

    # game/screens.rpy:323
    old "Main Menu"
    new "Menú principal"

    # game/screens.rpy:325
    old "About"
    new "Acerca de"

    # game/screens.rpy:330
    old "Help"
    new "Ayuda"

    # game/screens.rpy:333
    old "Quit"
    new "Salir"

    # game/screens.rpy:454
    old "Return"
    new "Volver"

    # game/screens.rpy:538
    old "Version [config.version!t]\n"
    new "Versión [config.version!t]\n"

    # game/screens.rpy:544
    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Hecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:584
    old "Page {}"
    new "Página {}"

    # game/screens.rpy:584
    old "Automatic saves"
    new "Guardados automáticos"

    # game/screens.rpy:584
    old "Quick saves"
    new "Guardados rápidos"

    # game/screens.rpy:626
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %B %d %Y, %H:%M"

    # game/screens.rpy:626
    old "empty slot"
    new "ranura vacía"

    # game/screens.rpy:643
    old "<"
    new "<"

    # game/screens.rpy:646
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:649
    old "{#quick_page}Q"
    new "{#quick_page}Q"

    # game/screens.rpy:655
    old ">"
    new ">"

    # game/screens.rpy:712
    old "Display"
    new "Pantalla"

    # game/screens.rpy:713
    old "Window"
    new "Ventana"

    # game/screens.rpy:714
    old "Fullscreen"
    new "Pantalla completa"

    # game/screens.rpy:718
    old "Rollback Side"
    new "Lado del retroceso"

    # game/screens.rpy:719
    old "Disable"
    new "Desactivar"

    # game/screens.rpy:720
    old "Left"
    new "Izquierda"

    # game/screens.rpy:721
    old "Right"
    new "Derecha"

    # game/screens.rpy:726
    old "Unseen Text"
    new "Texto no visto"

    # game/screens.rpy:727
    old "After Choices"
    new "Después de las elecciones"

    # game/screens.rpy:728
    old "Transitions"
    new "Transiciones"

    # game/screens.rpy:735
    old "Language"
    new "Idioma"

    # game/screens.rpy:752
    old "Text Speed"
    new "Velocidad del texto"

    # game/screens.rpy:756
    old "Auto-Forward Time"
    new "Tiempo de avance automático"

    # game/screens.rpy:763
    old "Music Volume"
    new "Volumen de música"

    # game/screens.rpy:770
    old "Sound Volume"
    new "Volumen de sonido"

    # game/screens.rpy:776
    old "Test"
    new "Probar"

    # game/screens.rpy:780
    old "Voice Volume"
    new "Volumen de voz"

    # game/screens.rpy:791
    old "Mute All"
    new "Silenciar todo"

    # game/screens.rpy:910
    old "The dialogue history is empty."
    new "El historial de diálogos está vacío."

    # game/screens.rpy:980
    old "Keyboard"
    new "Teclado"

    # game/screens.rpy:981
    old "Mouse"
    new "Ratón"

    # game/screens.rpy:984
    old "Gamepad"
    new "Gamepad"

    # game/screens.rpy:997
    old "Enter"
    new "Enter"

    # game/screens.rpy:998
    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."

    # game/screens.rpy:1001
    old "Space"
    new "Espacio"

    # game/screens.rpy:1002
    old "Advances dialogue without selecting choices."
    new "Avanza el diálogo sin seleccionar opciones."

    # game/screens.rpy:1005
    old "Arrow Keys"
    new "Teclas de dirección"

    # game/screens.rpy:1006
    old "Navigate the interface."
    new "Navega por la interfaz."

    # game/screens.rpy:1009
    old "Escape"
    new "Escape"

    # game/screens.rpy:1010
    old "Accesses the game menu."
    new "Abre el menú del juego."

    # game/screens.rpy:1013
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1014
    old "Skips dialogue while held down."
    new "Salta los diálogos mientras se mantiene presionada."

    # game/screens.rpy:1017
    old "Tab"
    new "Tab"

    # game/screens.rpy:1018
    old "Toggles dialogue skipping."
    new "Activa o desactiva el salto de diálogos."

    # game/screens.rpy:1021
    old "Page Up"
    new "Re Pág"

    # game/screens.rpy:1022
    old "Rolls back to earlier dialogue."
    new "Retrocede a diálogos anteriores."

    # game/screens.rpy:1025
    old "Page Down"
    new "Av Pág"

    # game/screens.rpy:1026
    old "Rolls forward to later dialogue."
    new "Avanza a diálogos posteriores."

    # game/screens.rpy:1030
    old "Hides the user interface."
    new "Oculta la interfaz de usuario."

    # game/screens.rpy:1034
    old "Takes a screenshot."
    new "Toma una captura de pantalla."

    # game/screens.rpy:1038
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Activa o desactiva la {a=https://www.renpy.org/l/voicing}lectura en voz alta{/a}."

    # game/screens.rpy:1044
    old "Left Click"
    new "Clic izquierdo"

    # game/screens.rpy:1048
    old "Middle Click"
    new "Clic central"

    # game/screens.rpy:1052
    old "Right Click"
    new "Clic derecho"

    # game/screens.rpy:1056
    old "Mouse Wheel Up\nClick Rollback Side"
    new "Rueda del ratón hacia arriba\nClic en el lado del retroceso"

    # game/screens.rpy:1060
    old "Mouse Wheel Down"
    new "Rueda del ratón hacia abajo"

    # game/screens.rpy:1067
    old "Right Trigger\nA/Bottom Button"
    new "Gatillo derecho\nBotón A/inferior"

    # game/screens.rpy:1071
    old "Left Trigger\nLeft Shoulder"
    new "Gatillo izquierdo\nBotón superior izquierdo"

    # game/screens.rpy:1075
    old "Right Shoulder"
    new "Botón superior derecho"

    # game/screens.rpy:1080
    old "D-Pad, Sticks"
    new "Cruceta, palancas"

    # game/screens.rpy:1084
    old "Start, Guide"
    new "Start, Guide"

    # game/screens.rpy:1088
    old "Y/Top Button"
    new "Y/botón superior"

    # game/screens.rpy:1091
    old "Calibrate"
    new "Calibrar"

    # game/screens.rpy:1156
    old "Yes"
    new "Sí"

    # game/screens.rpy:1157
    old "No"
    new "No"

    # game/screens.rpy:1203
    old "Skipping"
    new "Saltando"

    # game/screens.rpy:1426
    old "Menu"
    new "Menú"

