# TODO: Translation updated at 2024-02-08 08:02

# game/extra.rpy:42
translate Spanish extra_af06d1ee:

    # "Locked"
    "Bloqueado"

# game/extra.rpy:60
translate Spanish extra_af06d1ee_1:

    # "Locked"
    "Bloqueado"

# game/extra.rpy:77
translate Spanish extra_af06d1ee_2:

    # "Locked"
    "Bloqueado"

# game/extra.rpy:95
translate Spanish extra_af06d1ee_3:

    # "Locked"
    "Bloqueado"

# game/extra.rpy:113
translate Spanish extra_af06d1ee_4:

    # "Locked"
    "Bloqueado"

# game/extra.rpy:132
translate Spanish extra_af06d1ee_5:

    # "Locked"
    "Bloqueado"

# game/extra.rpy:136
translate Spanish extra_af06d1ee_6:

    # "Locked"
    "Bloqueado"

# game/extra.rpy:148
translate Spanish extra_af06d1ee_7:

    # "Locked"
    "Bloqueado"

# game/extra.rpy:152
translate Spanish extra_af06d1ee_8:

    # "Locked"
    "Bloqueado"

# game/extra.rpy:156
translate Spanish extra_af06d1ee_9:

    # "Locked"
    "Bloqueado"

translate Spanish strings:

    # game/extra.rpy:16
    old "No Fairy Tale"
    new "No Es Un Cuento De Hadas"

    # game/extra.rpy:16
    old "A Butler's Musings"
    new "Reflexiones De Un Mayordomo"

    # game/extra.rpy:16
    old "Twisted Happiness"
    new "Felicidad Retorcida"

    # game/extra.rpy:34
    old "??????? ?????????"
    new "??????? ?????????"

    # game/extra.rpy:127
    old "? ??????? ???????"
    new "? ??????? ???????"

    # game/extra.rpy:146
    old "?? ????? ????"
    new "?? ????? ????"

