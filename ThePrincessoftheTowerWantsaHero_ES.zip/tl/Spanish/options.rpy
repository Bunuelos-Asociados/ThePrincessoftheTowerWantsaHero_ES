# TODO: Translation updated at 2024-02-08 08:02

translate Spanish strings:

    # game/options.rpy:17
    old "The Princess of the Tower Wants a Hero"
    new "La princesa de la torre quiere un héroe"

