# TODO: Translation updated at 2024-02-08 08:02

# game/gallery.rpy:290
translate Spanish gallery_eb523148:

    # "Hints:"
    "Pistas:"

# game/gallery.rpy:292
translate Spanish gallery_b8840519:

    # "Get angry for him."
    "Enfádate por él. "

# game/gallery.rpy:294
translate Spanish gallery_8f05646b:

    # "And be interested in knowing more about him."
    "Y estar interesada en saber más sobre él."

