# TODO: Translation updated at 2024-02-08 08:02

# game/reo.rpy:7
translate Spanish reoroute_b1d94948:

    # cethin "Thank you for taking care of that, Lumi..."
    cethin "Gracias por encargarte de eso, Lumi..."

# game/reo.rpy:9
translate Spanish reoroute_4eff14b4:

    # lumihappy "Think nothing of it."
    lumihappy "No fue nada."

# game/reo.rpy:11
translate Spanish reoroute_7cdc10f2:

    # lumi "Although I would appreciate it if you'd make our dinner special~"
    lumi "Aunque apreciaría que hicieras nuestra cena especial~"

# game/reo.rpy:15
translate Spanish reoroute_40c6d941:

    # cethin "Haha... Of course. Any requests?"
    cethin "Jaja... Por supuesto. ¿Alguna petición?"

# game/reo.rpy:17
translate Spanish reoroute_f8933be8:

    # lumitalk "Well..."
    lumitalk "Bueno..."

# game/reo.rpy:21
translate Spanish reoroute_bf193af6:

    # "Their planning continued throughout the night..."
    "Siguieron planificando durante toda la noche..."

# game/reo.rpy:23
translate Spanish reoroute_0457e79f:

    # "For the following days, the butler and the bard busied themselves with the festival preparations."
    "Durante los días siguientes, el mayordomo y el bardo se ocuparon con los preparativos del festival."

# game/reo.rpy:25
translate Spanish reoroute_67ff1dab:

    # "The princess, who wasn't allowed to leave her room couldn't really do much..."
    "La princesa, que no tenía permitido salir de su habitación, no podía hacer mucho..."

# game/reo.rpy:27
translate Spanish reoroute_e52a8f1e:

    # "And thus, a few days passed."
    "Y así pasaron unos días."

# game/reo.rpy:29
translate Spanish reoroute_25a6bb73:

    # "... The day of the festival finally arrived."
    "... Finalmente llegó el día del festival."

# game/reo.rpy:38
translate Spanish reoroute_175793a7:

    # lumihappy "Oh my, that feast was simply divine..."
    lumihappy "Oh cielos, ese banquete fue simplemente divino..."

# game/reo.rpy:40
translate Spanish reoroute_e2e0b5c7:

    # lumiplead "I couldn't take another bite."
    lumiplead "No me cabe ni un bocado más."

# game/reo.rpy:42
translate Spanish reoroute_a180bcf6:

    # "The two sat across each other, using Lumi's tea table for their feast."
    "Los dos se sentaron frente a frente, usando la mesa de té de Lumi para su festín."

# game/reo.rpy:44
translate Spanish reoroute_9ab84359:

    # "The table itself was small, but they managed to fit in a whole variety of cuisine..."
    "La mesa en sí era pequeña, pero lograron colocar toda una variedad de platillos..."

# game/reo.rpy:46
translate Spanish reoroute_0b51029d:

    # "A wide variety of appetizers, a fancy looking roasted bird, and even sweet desserts!"
    "Una gran variedad de aperitivos, un ave asada con aspecto elegante, ¡e incluso postres dulces!"

# game/reo.rpy:48
translate Spanish reoroute_de40c8af:

    # "It was a yuletide food galore."
    "Era un festín navideño en toda regla."

# game/reo.rpy:50
translate Spanish reoroute_22195f12:

    # "... Well, it ended up being too much for just the two of them."
    "... Bueno, terminó siendo demasiado para solo los dos."

# game/reo.rpy:54
translate Spanish reoroute_40e0d562:

    # cethin "I'm glad you liked it."
    cethin "Me alegra que te haya gustado."

# game/reo.rpy:56
translate Spanish reoroute_c7d733e1:

    # lumitalk "We have quite a lot of leftovers though... why don't we pack some up for Reo?"
    lumitalk "Tenemos bastantes sobras... ¿por qué no empacamos algo para Reo?"

# game/reo.rpy:60
translate Spanish reoroute_1ee962ac:

    # cethin "Okay, I'll take care of it."
    cethin "Está bien, me encargaré de eso."

# game/reo.rpy:62
translate Spanish reoroute_bb66ed1d:

    # cethin "You can take a rest."
    cethin "Puedes descansar."

# game/reo.rpy:64
translate Spanish reoroute_1d362de4:

    # lumihappy "That, I'll do."
    lumihappy "Eso haré."

# game/reo.rpy:70
translate Spanish reoroute_33a3fd64:

    # "The day passed by quite fast."
    "El día pasó bastante rápido."

# game/reo.rpy:72
translate Spanish reoroute_71a5f5bd:

    # "Lumi laid on her bed, mulling how she had spent the past year."
    "Lumi se recostó en su cama, reflexionando sobre cómo había pasado el último año."

# game/reo.rpy:74
translate Spanish reoroute_3e0152b7:

    # "Before Cethin came along... there wasn't really anything memorable to her-"
    "Antes de que llegara Cethin... realmente no había nada memorable para ella-"

# game/reo.rpy:76
translate Spanish reoroute_bdb42bbe:

    # lumisad "No... hold on."
    lumisad "No... espera."

# game/reo.rpy:78
translate Spanish reoroute_17e94f5c:

    # "Wait- there was one:"
    "Un momento- hubo algo:"

# game/reo.rpy:80
translate Spanish reoroute_9372180b:

    # "Reo."
    "Reo."

# game/reo.rpy:82
translate Spanish reoroute_4914fa21:

    # "Before him, the princess had gone through many other butlers."
    "Antes de él, la princesa había tenido muchos otros mayordomos."

# game/reo.rpy:84
translate Spanish reoroute_98361d37:

    # "All of them remained cordial to her- but professionally so."
    "Todos se mantenían cordiales con ella, pero de manera profesional."

# game/reo.rpy:86
translate Spanish reoroute_6ab500ce:

    # "Whenever she'd attempt to have a casual conversation, they would answer formally..."
    "Cada vez que intentaba tener una conversación informal, respondían de manera formal..."

# game/reo.rpy:88
translate Spanish reoroute_8648ab2c:

    # "-Which wasn't what she wanted."
    "-Lo cual no era lo que ella quería."

# game/reo.rpy:90
translate Spanish reoroute_578d8231:

    # "What she wanted was a companion. A friend. Someone she could talk with."
    "Lo que ella quería era un compañero. Un amigo. Alguien con quien pudiera hablar."

# game/reo.rpy:97
translate Spanish reoroute_6c6bfbcd:

    # "And then Reo came along."
    "Y entonces llegó Reo."

# game/reo.rpy:101
translate Spanish reoroute_44e59cf7:

    # lumitalk "If I recall..."
    lumitalk "Si mal no recuerdo..."

# game/reo.rpy:103
translate Spanish reoroute_c78b6fe7:

    # "Right. He was just like every single butler who came before him...{w} at first."
    "Cierto. Era igual que cada uno de los mayordomos que vinieron antes que él...{w} al principio."

# game/reo.rpy:105
translate Spanish reoroute_eb4e1ad6:

    # "But after several attempts to casually chat with him, well, perhaps he got too comfortable and found his footing?"
    "Pero después de varios intentos de charlar casualmente con él, bueno, ¿quizás se sintió demasiado cómodo y encontró su propio ritmo?"

# game/reo.rpy:107
translate Spanish reoroute_3159c280:

    # "-Reo started letting out his sarcasm in front of her."
    "-Reo empezó a soltar su sarcasmo frente a ella."

# game/reo.rpy:109
translate Spanish reoroute_224cc410:

    # lumihappy "(Frustrating he may be at times... but I do like Reo.)"
    lumihappy "(Por más frustrante que sea a veces... me agrada Reo.)"

# game/reo.rpy:111
translate Spanish reoroute_76e54836:

    # lumisad "(He never stayed long before Cethin came around though...)"
    lumisad "(Aunque nunca se quedó mucho tiempo antes de que llegara Cethin...)"

# game/reo.rpy:117
translate Spanish reoroute_1d344ff3:

    # cethin "Lumi."
    cethin "Lumi."

# game/reo.rpy:119
translate Spanish reoroute_bf634fea:

    # "Cethin called out."
    "Cethin la llamó."

# game/reo.rpy:123
translate Spanish reoroute_a92bc57e:

    # lumi "Oh?"
    lumi "¿Oh?"

# game/reo.rpy:125
translate Spanish reoroute_cfa510e1:

    # "The princess sat up on her bed."
    "La princesa se incorporó en su cama."

# game/reo.rpy:130
translate Spanish reoroute_eaee70a7:

    # cethin "I've packed them up. I should bring them over to the kitchen so that they won't spoil."
    cethin "Ya las empaqué. Debería llevarlas a la cocina antes de que se echen a perder."

# game/reo.rpy:132
translate Spanish reoroute_88e01674:

    # lumitalk "So you're leaving? Alright. Take care."
    lumitalk "¿Así que te vas? Está bien. Cuídate."

# game/reo.rpy:143
translate Spanish reoroute_b4031655:

    # "Cethin nodded, and with the packed leftovers in his arms, he exited through the balcony."
    "Cethin asintió, y con las sobras empacadas en sus brazos, salió por el balcón."

# game/reo.rpy:145
translate Spanish reoroute_f167efa7:

    # lumi "..."
    lumi "..."

# game/reo.rpy:147
translate Spanish reoroute_a9c81ec2:

    # lumided "I always wonder if Cethin is truly a bard..."
    lumided "Siempre me pregunto si Cethin es realmente un bardo..."

# game/reo.rpy:149
translate Spanish reoroute_cd8ba904:

    # "The way he leapt out of the railings, he did so with finesse."
    "La forma en que saltó por la barandilla, lo hizo con elegancia."

# game/reo.rpy:151
translate Spanish reoroute_3283d36f:

    # lumided "Mhm. Well, I suppose we turn in for the day."
    lumided "Mhm. Bueno, supongo que es hora de dormir."

# game/reo.rpy:153
translate Spanish reoroute_e4bb5984:

    # "She stretched her arms, ready to get back on her bed-"
    "Estiró los brazos, lista para volver a su cama-"

# game/reo.rpy:157
translate Spanish reoroute_49d19f4e:

    # "*Clack..!*" with vpunch
    "*Clack..!*" with vpunch

# game/reo.rpy:159
translate Spanish reoroute_239e4c63:

    # lumiserious "...?"
    lumiserious "¿...?"

# game/reo.rpy:161
translate Spanish reoroute_9fdd68ba:

    # "It sounded like something from just outside her door."
    "Sonó como si viniera de justo afuera de su puerta."

# game/reo.rpy:165
translate Spanish reoroute_f53d79db:

    # "Reo's (hypothetical) route ends here."
    "La ruta (hipotética) de Reo termina aquí."

# game/reo.rpy:167
translate Spanish reoroute_428f4ae5:

    # "Currently, there are no development plans for his route, but if you're interested, feel free to comment."
    "Actualmente, no hay planes de desarrollo para su ruta, pero si estás interesado, no dudes en dejar un comentario."

# game/reo.rpy:169
translate Spanish reoroute_af456bab:

    # "Thank you for playing!"
    "¡Gracias por jugar!"

