# TODO: Translation updated at 2024-02-08 08:02

# game/chatting.rpy:8
translate Spanish demonhero_5f1cb92b:

    # lumishy "Couldn't you just be my hero then?"
    lumishy "¿No podrías ser tú mi héroe entonces?"

# game/chatting.rpy:12
translate Spanish demonhero_74cbf4c9:

    # "The butler stopped with whatever he was doing with her drawers and turned to her direction."
    "El mayordomo se detuvo con lo que fuera que estaba haciendo con sus cajones y se giró en su dirección."

# game/chatting.rpy:16
translate Spanish demonhero_208e1c05:

    # "His brows were knitted together, giving him a perturbed expression."
    "Frunció el ceño, dándole una expresión preocupada."

# game/chatting.rpy:18
translate Spanish demonhero_992e13dd:

    # butler "Milady, I hope that was a mere jest... or that you do not realize the implication of your words."
    butler "Milady, espero que eso haya sido una simple broma... o que no se dé cuenta de la implicación de sus palabras."

# game/chatting.rpy:20
translate Spanish demonhero_c6b9ef37:

    # lumishy "(Yes... it's akin to a proposal.)"
    lumishy "(Sí... es similar a una propuesta.)"

# game/chatting.rpy:22
translate Spanish demonhero_1d537d37:

    # "Becoming the 'hero' who has vanquished the demon lord gives them the right for her hand in marriage after all."
    "Convertirse en el “héroe” que ha vencido al señor demonio les da el derecho a su mano en matrimonio, después de todo."

# game/chatting.rpy:24
translate Spanish demonhero_71ca50f4:

    # "... More often than not, that was the ending for most princesses- a union between the hero and the lady."
    "... La mayoría de las veces, ese era el final de las historias de las princesas: una unión entre el héroe y la dama."

# game/chatting.rpy:26
translate Spanish demonhero_26c29058:

    # lumihappy "... Pfft- Ohoho~ of course it was a jest!"
    lumihappy "... Pfft- ¡Ohoho~ por supuesto que era una broma!"

# game/chatting.rpy:28
translate Spanish demonhero_c2c6b526:

    # "She chuckled."
    "Ella se rió."

# game/chatting.rpy:32
translate Spanish demonhero_a90a7527:

    # lumithink "You aren't my type."
    lumithink "No eres mi tipo."

# game/chatting.rpy:34
translate Spanish demonhero_bbb9b300:

    # lumiplead "(I prefer men with... *ahem* stronger builds.)"
    lumiplead "(Prefiero hombres con... *ejem* complexiones más fuertes.)"

# game/chatting.rpy:36
translate Spanish demonhero_a7c9bce2:

    # lumisad "Besides, I couldn't possibly have a demon as my hero now, could I?"
    lumisad "Además, no podría tener a un demonio como mi héroe ahora, ¿verdad?"

# game/chatting.rpy:40
translate Spanish demonhero_742f52bf:

    # butler "That's demonkin to you, milady."
    butler "Es demonkin para usted, milady."

# game/chatting.rpy:42
translate Spanish demonhero_18f5be80:

    # "His reply was curt, but he maintained his professional smile."
    "Su respuesta fue cortante, pero mantuvo su sonrisa profesional."

# game/chatting.rpy:46
translate Spanish demonhero_92e9a6e0:

    # butler "Although I ask that you refrain from making such statements... or well, {i}jests{/i} in the future."
    butler "Aunque le pido que se abstenga de hacer tales declaraciones... o bueno, {i}bromas{/i} en el futuro."

# game/chatting.rpy:50
translate Spanish demonhero_c8fa3e96:

    # butler "For your own good, that is."
    butler "Por su propio bien, claro."

# game/chatting.rpy:52
translate Spanish demonhero_c6ce9b31:

    # lumihappy "Oh come now. I may not be overly fond of you, but I wouldn't say that I dislike you."
    lumihappy "Oh, vamos. Puede que no me caigas especialmente bien, pero no diría que me desagradas."

# game/chatting.rpy:54
translate Spanish demonhero_e230b333:

    # lumi "You are easy on the eyes, and you brew the most exquisite tea."
    lumi "Eres agradable a la vista, y preparas el té más exquisito."

# game/chatting.rpy:56
translate Spanish demonhero_e5eaa5f8:

    # lumiehe "With a little polish, I believe you'd make for a dashing hero."
    lumiehe "Con un poco de pulido, creo que podrías ser un héroe apuesto."

# game/chatting.rpy:60
translate Spanish demonhero_6497d948:

    # butler "I do enjoy me some flattery, but enough about me..."
    butler "Disfruto de los halagos, pero basta de hablar de mí..."

# game/chatting.rpy:64
translate Spanish demonhero_baff54b8:

    # butler "Something has been bothering you, isn't there?"
    butler "Hay algo que te preocupa, ¿verdad?"

# game/chatting.rpy:66
translate Spanish demonhero_5e32ed54:

    # lumisad "... Well."
    lumisad "... Bueno."

# game/chatting.rpy:70
translate Spanish demonhero_b34484eb:

    # lumisad "It's rather annoying how perceptive you are."
    lumisad "Es bastante molesto lo perceptivo que eres."

# game/chatting.rpy:72
translate Spanish demonhero_7babb5ee:

    # butler "I'll gladly take that as a compliment."
    butler "Con gusto tomaré eso como un cumplido."

# game/chatting.rpy:76
translate Spanish demonhero_2595ac08:

    # butler "Now, why don't you speak to me about it?"
    butler "Ahora, ¿por qué no me hablas de ello?"

# game/chatting.rpy:78
translate Spanish demonhero_e79553d5:

    # butler "As your butler in charge, it is my duty to also care not only for your physical wellbeing, but your mind as well."
    butler "Como tu mayordomo a cargo, es mi deber cuidar no solo de tu bienestar físico, sino también de tu mente."

# game/chatting.rpy:80
translate Spanish demonhero_9e676fc4:

    # butler "It wouldn't do you good if you keep it all to yourself."
    butler "No te hará bien guardártelo todo."

# game/chatting.rpy:82
translate Spanish demonhero_daddb8a7:

    # lumiserious "My, aren't you a nosy butler."
    lumiserious "Vaya, qué mayordomo tan entrometido."

# game/chatting.rpy:84
translate Spanish demonhero_f41901fa:

    # "She sighed."
    "Ella suspiró."

# game/chatting.rpy:86
translate Spanish demonhero_de6f6b51:

    # lumiserious "I'm simply tired, is all."
    lumiserious "Solo estoy cansada, eso es todo."

# game/chatting.rpy:88
translate Spanish demonhero_5f9b96f7:

    # "Hint of distress slowly sank into her voice as she continued."
    "Mientras seguía hablando, un matiz de angustia fue apoderándose poco a poco de su voz."

# game/chatting.rpy:90
translate Spanish demonhero_8d9ec69d:

    # lumisad "I've stopped counting days."
    lumisad "He dejado de contar los días."

# game/chatting.rpy:92
translate Spanish demonhero_0ef4fc49:

    # lumisad "I do not know how long I've been waiting, nor do I feel that I'd like to know."
    lumisad "No sé cuánto tiempo he estado esperando, ni siento que quiera saberlo."

# game/chatting.rpy:94
translate Spanish demonhero_c2a0420a:

    # lumisad "I worry that I'd just find myself with graying hair one day, still waiting for my hero who may or may not exist."
    lumisad "Temo que un día me encuentre con el cabello encanecido, aún esperando a mi héroe que puede o no existir."

# game/chatting.rpy:96
translate Spanish demonhero_3fe00ed0:

    # lumisad "(And to say that it is rather lonesome would be an understatement...)"
    lumisad "(Y decir que es algo solitario sería quedarse corta...)"

# game/chatting.rpy:98
translate Spanish demonhero_15e00f0b:

    # lumihappy "Alas, what can I do?"
    lumihappy "Ay, ¿qué puedo hacer?"

# game/chatting.rpy:100
translate Spanish demonhero_7cdbb055:

    # "She shrugged with resignation."
    "Ella se encogió de hombros con resignación."

# game/chatting.rpy:104
translate Spanish demonhero_ebc792d0:

    # butler "I see.{w} Patience milady. Patience."
    butler "Ya veo.{w} Paciencia, milady. Paciencia."

# game/chatting.rpy:106
translate Spanish demonhero_07edd987:

    # "He replied gently."
    "Respondió con suavidad."

# game/chatting.rpy:110
translate Spanish demonhero_920f1642:

    # butler "You've endured so far. Do not lose hope just yet, especially when the first party had finally reached this region."
    butler "Has aguantado hasta ahora. No pierdas la esperanza todavía, especialmente cuando el primer grupo finalmente ha llegado a esta región."

# game/chatting.rpy:112
translate Spanish demonhero_2b46623e:

    # butler "I understand your frustration, but this will only be the first one of the many."
    butler "Entiendo tu frustración, pero este será solo el primero de muchos."

# game/chatting.rpy:114
translate Spanish demonhero_7e89e709:

    # butler "You are still quite young; there have been princesses twice, nay, THRICE your age before their hero arrived."
    butler "Aún eres bastante joven; ha habido princesas con el doble, no, el TRIPLE de tu edad antes de que llegara su héroe."

# game/chatting.rpy:116
translate Spanish demonhero_9a6dcecf:

    # lumisad "I {i}have{/i} been patient!"
    lumisad "¡He {i}sido{/i} paciente!"

# game/chatting.rpy:118
translate Spanish demonhero_9bc14aae:

    # "She pouted."
    "Ella hizo un puchero."

# game/chatting.rpy:122
translate Spanish demonhero_2182c515:

    # butler "I know. You've done well so far."
    butler "Lo sé. Lo has hecho bien hasta ahora."

# game/chatting.rpy:126
translate Spanish demonhero_141cd393:

    # butler "But let's not rush this, shall we?"
    butler "Pero no apresuremos esto, ¿de acuerdo?"

# game/chatting.rpy:130
translate Spanish demonhero_82168447:

    # butler "That said, if you find yourself unable to truly endure this ordeal... then feel free to make your proposal once again."
    butler "Dicho esto, si sientes que no puedes soportar realmente esta prueba... entonces siéntete libre de hacer tu propuesta una vez más."

# game/chatting.rpy:132
translate Spanish demonhero_176b6f29:

    # butler "I'll see if I can squeeze {i}'hero'{/i} into my resume."
    butler "Veré si puedo incluir {i}“héroe”{/i} en mi currículum."

# game/chatting.rpy:134
translate Spanish demonhero_ab66d9a3:

    # "He spoke in jest, but there was a {b}slight{/b} tone of seriousness to it."
    "Habló en tono de broma, pero había un {b}ligero{/b} tono de seriedad en ello."

# game/chatting.rpy:136
translate Spanish demonhero_9924d744:

    # "This made her perk up, even by a little."
    "Esto hizo que ella se animara, aunque fuera un poco."

# game/chatting.rpy:138
translate Spanish demonhero_2bfe68b5:

    # lumi "(So it is an option?)"
    lumi "(¿Así que es una opción?)"

# game/chatting.rpy:140
translate Spanish demonhero_becab052:

    # lumihappy "(Wonderful. At least I have a plan B.)"
    lumihappy "(Maravilloso. Al menos tengo un plan B.)"

# game/chatting.rpy:142
translate Spanish demonhero_77971ed4:

    # "Plan A, of course, was to keep waiting for a hero to rescue this damsel in distress."
    "El plan A, por supuesto, era seguir esperando a un héroe que rescatara a esta damisela en apuros."

# game/chatting.rpy:153
translate Spanish helper_86e2bc9c:

    # lumided "Unless... could you perhaps pull a few strings and aid the next hero to succeed?"
    lumided "A menos que... ¿podrías quizá mover algunos hilos y ayudar al próximo héroe a tener éxito?"

# game/chatting.rpy:157
translate Spanish helper_52c09d94:

    # "The demon paused from rummaging with her drawers, and sneered."
    "El demonio dejó de hurgar en sus cajones y sonrió con desdén."

# game/chatting.rpy:161
translate Spanish helper_eba161fb:

    # butler "That is a rather tall order coming from you, princess."
    butler "Esa es una petición bastante grande viniendo de ti, princesa."

# game/chatting.rpy:165
translate Spanish helper_285e9f57:

    # butler "I may have been tasked to serve you, but I do not work {i}for you{/i}."
    butler "Puede que se me haya encomendado servirte, pero no trabajo {i}para ti{/i}."

# game/chatting.rpy:169
translate Spanish helper_fd16c493:

    # butler "I shall oblige you as long as it does not go against my duties."
    butler "Cumpliré tus deseos siempre que no vayan en contra de mis deberes."

# game/chatting.rpy:171
translate Spanish helper_3df5c267:

    # "She let out a huff, and then smiled."
    "Ella soltó un bufido y luego sonrió."

# game/chatting.rpy:173
translate Spanish helper_f7b9a3cb:

    # lumihappy "'Twas worth a try."
    lumihappy "Valía la pena intentarlo."

# game/chatting.rpy:175
translate Spanish helper_44b4a506:

    # lumi "But you promise, okay?"
    lumi "Pero prométemelo, ¿sí?"

# game/chatting.rpy:177
translate Spanish helper_2096ffe0:

    # lumihappy "... That you would oblige my wishes?"
    lumihappy "... ¿Que cumplirás mis deseos?"

# game/chatting.rpy:181
translate Spanish helper_f4c6fdf4:

    # butler "Haven't I already been?"
    butler "¿No lo he hecho ya?"

# game/chatting.rpy:183
translate Spanish helper_77dfddb2:

    # lumisad "Well, yes. But it's... nice to be assured."
    lumisad "Bueno, sí. Pero es... agradable tener la seguridad."

# game/chatting.rpy:187
translate Spanish helper_ab11cbcb:

    # butler "I see. If giving you my word shall put your heart at ease, then I shall do so."
    butler "Ya veo. Si darte mi palabra calma tu corazón, entonces lo haré."

# game/chatting.rpy:191
translate Spanish helper_372e1169:

    # butler "I will see to it to honor any of your requests, as long as it does not contend with my duties."
    butler "Me aseguraré de honrar cualquiera de tus peticiones, siempre que no contradigan mis deberes."

# game/chatting.rpy:195
translate Spanish helper_b17711a2:

    # butler "But really, this is unnecessary..."
    butler "Pero en serio, esto es innecesario..."

# game/chatting.rpy:199
translate Spanish helper_78ad0f2a:

    # lumihappy "It's a promise then. No take backs!"
    lumihappy "Entonces es una promesa. ¡Nada de retractarse!"

# game/chatting.rpy:206
translate Spanish about_mother_cdce4e0e:

    # "The princess continued to stare at the dark elf expectantly."
    "La princesa continuó mirando al elfo oscuro con expectación."

# game/chatting.rpy:208
translate Spanish about_mother_6b58cc1b:

    # "{i}One second.{w} Two seconds.{w}..{/i} until he finally caved in."
    "{i}Un segundo.{w} Dos segundos.{w}..{/i} hasta que finalmente cedió."

# game/chatting.rpy:210
translate Spanish about_mother_16995e01:

    # cethin "... Yes, she did."
    cethin "... Sí, le gustaba."

# game/chatting.rpy:212
translate Spanish about_mother_2a8216b2:

    # lumihappy "I see...! By any chance was it your mother that made you want to become a bard?"
    lumihappy "¡Ya veo...! ¿Por casualidad fue tu madre quien te hizo querer ser un bardo?"

# game/chatting.rpy:214
translate Spanish about_mother_d2671603:

    # "She added gleefully."
    "Agregó alegremente."

# game/chatting.rpy:216
translate Spanish about_mother_3caa2938:

    # "Somehow, it felt nice to learn something new about her roommate."
    "De alguna manera, se sintió bien aprender algo nuevo sobre su compañero de cuarto."

# game/chatting.rpy:218
translate Spanish about_mother_b46a8c10:

    # cethin "Mhm... yes... she was the one who encouraged me."
    cethin "Mhm... sí... fue ella quien me animó."

# game/chatting.rpy:220
translate Spanish about_mother_5fada3c7:

    # "Though his tone didn't make him sound enthusiastic about this subject."
    "Aunque su tono no sonaba entusiasta sobre el tema."

# game/chatting.rpy:222
translate Spanish about_mother_b5216780:

    # lumisad "(Perhaps I should change the subject...)"
    lumisad "(Tal vez debería cambiar de tema...)"

# game/chatting.rpy:228
translate Spanish skip_mother_40e1bba3:

    # "Cethin didn't seem comfortable with the subject, so Lumi decided to save him the trouble."
    "Cethin no parecía cómodo con el tema, así que Lumi decidió ahorrarle la molestia."

# game/chatting.rpy:230
translate Spanish skip_mother_65ae616f:

    # lumi "Oh, you do not have to force yourself to reply."
    lumi "Oh, no tienes que obligarte a responder."

# game/chatting.rpy:232
translate Spanish skip_mother_e1a1ee1b:

    # "She smiled, trying to reassure him that it's fine."
    "Sonrió, tratando de asegurarle que estaba bien."

# game/chatting.rpy:234
translate Spanish skip_mother_84f14a90:

    # "The dark elf, however, only hung his head low."
    "El elfo oscuro, sin embargo, solo bajó la cabeza."

# game/chatting.rpy:236
translate Spanish skip_mother_34880e36:

    # cethin "S-sorry... it's {size=-5}not really...{/size}"
    cethin "L-lo siento... {size=-5}no es realmente...{/size}"

# game/chatting.rpy:238
translate Spanish skip_mother_6d340159:

    # "In the end, he just trailed off."
    "Al final, simplemente se quedó en silencio."

# game/chatting.rpy:240
translate Spanish skip_mother_783b09e6:

    # lumisad "(He's quite closed off, isn't he?)"
    lumisad "(Es bastante reservado, ¿no?)"

# game/chatting.rpy:242
translate Spanish skip_mother_c4bf6da9:

    # "She doesn't know about his circumstances, so she didn't want to judge."
    "No conocía sus circunstancias, así que no quería juzgarlo."

# game/chatting.rpy:244
translate Spanish skip_mother_a6f7f527:

    # lumi "(But I would love to hear more from him...)"
    lumi "(Pero me encantaría saber más sobre él...)"

# game/chatting.rpy:253
translate Spanish about_darkelves_a05f48d0:

    # lumitalk "About the night elves?"
    lumitalk "¿Sobre los elfos nocturnos?"

# game/chatting.rpy:255
translate Spanish about_darkelves_9f2a4468:

    # lumisad "Honestly, I did not have much opportunity to leave the palace before... and then here I am trapped in here."
    lumisad "Honestamente, no tuve muchas oportunidades de salir del palacio antes... y aquí estoy, atrapada."

# game/chatting.rpy:257
translate Spanish about_darkelves_42767c36:

    # "She cupped a hand on her cheek, making a troubled expression."
    "Se llevó una mano a la mejilla, mostrando una expresión preocupada."

# game/chatting.rpy:259
translate Spanish about_darkelves_1ea993b8:

    # lumi "I've only learned about your race in books, and from my teachers when I was back at the palace."
    lumi "Solo he aprendido sobre tu raza en los libros, y por mis maestros cuando estaba en el palacio."

# game/chatting.rpy:261
translate Spanish about_darkelves_80fe2b28:

    # lumitalk "Come to think of it... I have been told me that night elves should be avoided whenever they came up in conversations..."
    lumitalk "Ahora que lo pienso... me dijeron que debía evitar a los elfos nocturnos cada vez que salían en conversación..."

# game/chatting.rpy:263
translate Spanish about_darkelves_121531f7:

    # lumisad "What was it again...? Ah! They were not fond of humans?"
    lumisad "¿Qué era...? ¡Ah! ¿Que no eran muy aficionados a los humanos?"

# game/chatting.rpy:265
translate Spanish about_darkelves_3ddd991b:

    # "A pause."
    "Una pausa."

# game/chatting.rpy:267
translate Spanish about_darkelves_0a89fabc:

    # lumisad "... Oh."
    lumisad "... Oh."

# game/chatting.rpy:271
translate Spanish about_darkelves_a8c92253:

    # lumishy "Oh! I'm sorry...! Have I been too irksome? Is this why you aren't fond of us?"
    lumishy "¡Oh! ¡Lo siento...! ¿He sido demasiado molesta? ¿Es por eso que no te agradamos?"

# game/chatting.rpy:275
translate Spanish about_darkelves_59c04770:

    # cethin "N-no! The princess has been nothing but kind to me! I don't find you annoying at all!"
    cethin "¡N-no! ¡La princesa ha sido nada más que amable conmigo! ¡No la encuentro molesta en absoluto!"

# game/chatting.rpy:277
translate Spanish about_darkelves_84bdd53f:

    # "He firmly denied."
    "Negó firmemente."

# game/chatting.rpy:282
translate Spanish about_darkelves_24e998b4:

    # cethin "I admit... my... people try not to mingle with humans."
    cethin "Debo admitir... mi... gente trata de no mezclarse con los humanos."

# game/chatting.rpy:284
translate Spanish about_darkelves_d3e04caa:

    # "It's quite obvious that he's trying to put this as lightly as he could."
    "Es bastante obvio que intentaba expresarlo lo más suavemente posible."

# game/chatting.rpy:288
translate Spanish about_darkelves_2dec46fc:

    # cethin "So, before I started travelling, I wasn't sure what to think of you all."
    cethin "Así que, antes de comenzar a viajar, no estaba seguro de qué pensar de ustedes."

# game/chatting.rpy:293
translate Spanish about_darkelves_bf2348f2:

    # cethin "But humans... aren't bad."
    cethin "Pero los humanos... no son malos."

# game/chatting.rpy:297
translate Spanish about_darkelves_f7e23da5:

    # lumisad "(He sounds unconvinced...)"
    lumisad "(Suena poco convencido...)"

# game/chatting.rpy:302
translate Spanish about_darkelves_e5aa77be:

    # lumihappy "Well, if all night elves are like Cethin, then I think I like night elves."
    lumihappy "Bueno, si todos los elfos nocturnos son como Cethin, entonces creo que me gustan los elfos nocturnos."

# game/chatting.rpy:306
translate Spanish about_darkelves_238cbfd2:

    # cethin "L-l-l-l-like...?"
    cethin "¿G-g-g-gustar...?"

# game/chatting.rpy:308
translate Spanish about_darkelves_b1ba6fde:

    # lumi "Hm? Yes? You are rather timid, but I am quite fond of you."
    lumi "¿Hm? ¿Sí? Eres bastante tímido, pero me caes muy bien."

# game/chatting.rpy:310
translate Spanish about_darkelves_5065492a:

    # lumihappy "(I'd certainly love to be friends.)"
    lumihappy "(Me encantaría ser amiga tuya, sin duda.)"

# game/chatting.rpy:314
translate Spanish about_darkelves_bc8bb510:

    # cethin "Uh... ehm... ah..."
    cethin "Uh... ehm... ah..."

# game/chatting.rpy:316
translate Spanish about_darkelves_893e9f74:

    # lumided "(Cethin seemed to have stopped working.)"
    lumided "(Parece que Cethin ha dejado de funcionar.)"

# game/chatting.rpy:318
translate Spanish about_darkelves_46122013:

    # lumiblush "(Goodness, he's quite adorable.)"
    lumiblush "(Dios mío, es bastante adorable.)"

# game/chatting.rpy:320
translate Spanish about_darkelves_6a659905:

    # lumided "(... But as much I as enjoyed this, I should stop teasing him for now.)"
    lumided "(... Pero por mucho que haya disfrutado esto, debería dejar de molestarlo por ahora.)"

# game/chatting.rpy:329
translate Spanish about_cethin_08883383:

    # lumi "About you? I'd like to hear more about you."
    lumi "¿Sobre ti? Me gustaría saber más de ti."

# game/chatting.rpy:333
translate Spanish about_cethin_8fe82ade:

    # "His gaze fell downwards, though it was quite evident that he was a tad flustered."
    "Su mirada se desvió hacia abajo, aunque era evidente que estaba un poco sonrojado."

# game/chatting.rpy:338
translate Spanish about_cethin_9b3b2ab8:

    # cethin "... I don't think there's anything interesting about me."
    cethin "... No creo que haya nada interesante sobre mí."

# game/chatting.rpy:340
translate Spanish about_cethin_5e89bd1d:

    # lumishock "Is that a jest? You are a night elf, and you are a bard! You have traveled across lands, and you have reached this very room-"
    lumishock "¿Eso es una broma? ¡Eres un elfo nocturno, y eres un bardo! ¡Has viajado por tierras y has llegado hasta esta misma habitación!"

# game/chatting.rpy:345
translate Spanish about_cethin_701739f7:

    # lumiwish "{b}Everything{/b} about you is interesting!"
    lumiwish "{b}¡Todo{/b} sobre ti es interesante!"

# game/chatting.rpy:347
translate Spanish about_cethin_3dd419b4:

    # lumihappy "You can count on my word as a princess."
    lumihappy "Puedes contar con mi palabra como princesa."

# game/chatting.rpy:349
translate Spanish about_cethin_46c1bec2:

    # "She declared proudly."
    "Declaró con orgullo."

# game/chatting.rpy:353
translate Spanish about_cethin_46c85f95:

    # cethin "..."
    cethin "..."

# game/chatting.rpy:357
translate Spanish about_cethin_52c75afa:

    # cethin "... Our clan resides at the south western end of the kingdom. Most of our neighbors are of the werebeast folk."
    cethin "... Nuestro clan reside en el extremo suroeste del reino. La mayoría de nuestros vecinos son de la gente bestia."

# game/chatting.rpy:361
translate Spanish about_cethin_560d10db:

    # lumi "(Oh! He's talking!)"
    lumi "(¡Oh! ¡Está hablando!)"

# game/chatting.rpy:363
translate Spanish about_cethin_589e6095:

    # lumitalk "I believe night elves typically stay underground, yes?"
    lumitalk "Creo que los elfos nocturnos suelen vivir bajo tierra, ¿verdad?"

# game/chatting.rpy:365
translate Spanish about_cethin_9b7a8e6e:

    # "He nodded."
    "Él asintió."

# game/chatting.rpy:369
translate Spanish about_cethin_50d0bd57:

    # cethin "We specialize in the use of dark arts, so it's common for my people to be commissioned for subjugation of demonic beasts."
    cethin "Nos especializamos en el uso de artes oscuras, por lo que es común que mi gente sea contratada para la subyugación de bestias demoníacas."

# game/chatting.rpy:373
translate Spanish about_cethin_f0da4d5d:

    # cethin "Our region is remote, so we don't have much use for money, rather, we prefer trading resources with our neighbors."
    cethin "Nuestra región es remota, así que no tenemos mucho uso para el dinero; más bien, preferimos intercambiar recursos con nuestros vecinos."

# game/chatting.rpy:375
translate Spanish about_cethin_84f5d85d:

    # lumi "(Mhm... so they get paid in resources?)"
    lumi "(Mhm... ¿entonces les pagan con recursos?)"

# game/chatting.rpy:380
translate Spanish about_cethin_fc782ed1:

    # lumitalk "Then does that mean you are adept in the dark arts?"
    lumitalk "¿Entonces eso significa que eres hábil en las artes oscuras?"

# game/chatting.rpy:382
translate Spanish about_cethin_391e0e6d:

    # "{b}Dark arts{/b}, simply put, was the use of dark magic- it delved in the manipulation of dark matter."
    "{b}Las artes oscuras{/b}, dicho de forma simple, eran el uso de magia oscura: se adentraban en la manipulación de materia oscura."

# game/chatting.rpy:384
translate Spanish about_cethin_a98c3001:

    # "Its main application was subduing and binding targets, not only physically, but mentally as well."
    "Su aplicación principal era someter y atar objetivos, no solo físicamente, sino también mentalmente."

# game/chatting.rpy:386
translate Spanish about_cethin_200a66b7:

    # "Some say, it can also be used offensively as weapons."
    "Algunos dicen que también puede usarse ofensivamente como arma."

# game/chatting.rpy:388
translate Spanish about_cethin_9984634f:

    # "Amongst humans, only a handful bother to use learn it."
    "Entre los humanos, solo unos pocos se molestaban en aprenderla."

# game/chatting.rpy:390
translate Spanish about_cethin_3363b81e:

    # "Amongst other races... it was a rarity to find someone who had an affinity to learn it."
    "Entre otras razas... era raro encontrar a alguien con afinidad para dominarla."

# game/chatting.rpy:392
translate Spanish about_cethin_2ef1891e:

    # cethin "I... can use a little."
    cethin "Yo... puedo usar un poco."

# game/chatting.rpy:394
translate Spanish about_cethin_9c4e86f3:

    # "He said, avoiding her gaze."
    "Dijo, evitando su mirada."

# game/chatting.rpy:396
translate Spanish about_cethin_5e37cb4f:

    # lumided "(He makes it rather obvious that he isn't good at it.)"
    lumided "(Deja bastante claro que no es bueno en ello.)"

# game/chatting.rpy:398
translate Spanish about_cethin_391abf64:

    # lumisad "(Did he think I'd make fun of him?)"
    lumisad "(¿Pensó que me burlaría de él?)"

# game/chatting.rpy:400
translate Spanish about_cethin_1de7cfe3:

    # "She giggled."
    "Ella soltó una risita."

# game/chatting.rpy:402
translate Spanish about_cethin_57ab35c5:

    # lumi "(He was supposed to talk more about himself, but he ended up telling more about his clan.)"
    lumi "(Se suponía que hablaría más de sí mismo, pero terminó contándome más sobre su clan.)"

# game/chatting.rpy:404
translate Spanish about_cethin_11ddaf53:

    # lumihappy "(I suppose learning about his background counts.)"
    lumihappy "(Supongo que aprender sobre sus orígenes cuenta.)"

# game/chatting.rpy:406
translate Spanish about_cethin_f90dadd9:

    # lumi "(... And I did learn that he can use the dark arts.)"
    lumi "(... Y aprendí que puede usar las artes oscuras.)"

# game/chatting.rpy:408
translate Spanish about_cethin_a9abac6f:

    # lumi "(That said, there has been something I've been meaning to ask...)"
    lumi "(Dicho esto, hay algo que he querido preguntar...)"

# game/chatting.rpy:416
translate Spanish about_hero_30688435:

    # lumiplead "Oh! About the hero- would you kindly tell me more about him?"
    lumiplead "¡Oh! Sobre el héroe, ¿serías tan amable de contarme más sobre él?"

# game/chatting.rpy:418
translate Spanish about_hero_c1f71481:

    # lumiwish "How does he look like? What kind of weapon does he wield? What color are his eyes?"
    lumiwish "¿Cómo es? ¿Qué tipo de arma empuña? ¿De qué color son sus ojos?"

# game/chatting.rpy:420
translate Spanish about_hero_8d0c0a71:

    # "Cethin seemed to have been overwhelmed by her barrage of questions, but she couldn't help it-!"
    "Cethin parecía abrumado por su ráfaga de preguntas, pero ella no pudo evitarlo-"

# game/chatting.rpy:422
translate Spanish about_hero_d85a7d0d:

    # "Sure, the hero left a terrible first impression... and his party may have failed their first attempt, but he was still the first hero to reach this region!"
    "Claro, el héroe dejó una terrible primera impresión... y su grupo puede que haya fallado en su primer intento, pero ¡aún así fue el primer héroe en llegar a esta región!"

# game/chatting.rpy:425
translate Spanish about_hero_7a9c37de:

    # "While it may seem peaceful outside the tower, it was actually protected by a powerful snowstorm hailed by the demon lord."
    "Aunque pudiera parecer tranquilo fuera de la torre, en realidad estaba protegida por una poderosa tormenta de nieve invocada por el señor demonio."

# game/chatting.rpy:427
translate Spanish about_hero_4e5f357d:

    # "Due to this, Lumi's tower was known to be one of the most perilous to reach."
    "Por ello, la torre de Lumi era conocida como una de las más peligrosas de alcanzar."

# game/chatting.rpy:429
translate Spanish about_hero_b5d28f30:

    # "With that in mind, the hero's party could still be considered commendable."
    "Teniendo eso en cuenta, el grupo del héroe aún podía considerarse digno de elogio."

# game/chatting.rpy:434
translate Spanish about_hero_2cb471cf:

    # cethin "Farol? Well, he's-"
    cethin "¿Farol? Bueno, él es—"

# game/chatting.rpy:443
translate Spanish about_hero_721a334c:

    # lumiwish "His name is Farol then? Such a unique name!"
    lumiwish "¿Así que su nombre es Farol? ¡Qué nombre tan único!"

# game/chatting.rpy:450
translate Spanish about_hero_76322c32:

    # cethin "Hm? Erm yes... Farol is... brave. Yes."
    cethin "¿Hm? Ehm, sí... Farol es... valiente. Sí."

# game/chatting.rpy:455
translate Spanish about_hero_14eba84d:

    # cethin "He wields a sword called 'Edana'. We unearthed it from a dungeon near my hometown."
    cethin "Empuña una espada llamada “Edana”. La desenterramos de una mazmorra cerca de mi ciudad natal."

# game/chatting.rpy:457
translate Spanish about_hero_b45361d0:

    # lumishock "A named sword? Doesn't that mean it's a divine blade?"
    lumishock "¿Una espada con nombre? ¿Eso no significa que es una hoja divina?"

# game/chatting.rpy:461
translate Spanish about_hero_415880f9:

    # cethin "Ah, yes. You are quite well-informed."
    cethin "Ah, sí. Está bastante bien informada."

# game/chatting.rpy:465
translate Spanish about_hero_ffdc4fc2:

    # cethin "{i}Edana{/i} is indeed a divine blade that has power over flames."
    cethin "{i}Edana{/i} es, en efecto, una espada divina que tiene poder sobre las llamas."

# game/chatting.rpy:469
translate Spanish about_hero_5d249630:

    # cethin "It's thanks to {i}Edana{/i} that we were able to travese the snowstorm surrounding this region."
    cethin "Gracias a {i}Edana{/i} pudimos atravesar la tormenta de nieve que rodea esta región."

# game/chatting.rpy:473
translate Spanish about_hero_1cee1b03:

    # cethin "It is also because of {i}Edana{/i} that Farol managed to gain the king's approval as a hero."
    cethin "También fue por {i}Edana{/i} que Farol logró obtener la aprobación del rey como héroe."

# game/chatting.rpy:475
translate Spanish about_hero_71405d71:

    # lumishock "Oh, father?"
    lumishock "¿Oh, padre?"

# game/chatting.rpy:479
translate Spanish about_hero_38e452ee:

    # "Her eyes suddenly brightened up."
    "Sus ojos se iluminaron de repente."

# game/chatting.rpy:481
translate Spanish about_hero_7ecdd8ab:

    # lumi "Speaking of which..."
    lumi "Hablando de eso..."

# game/chatting.rpy:489
translate Spanish badend1_7bc69ba5:

    # "Worried for the dark elf, the princess' eyes fell on the bell that the demon had told her to use in case of emergency."
    "Preocupada por el elfo oscuro, la mirada de la princesa se posó en la campana que el demonio le había dicho que usara en caso de emergencia."

# game/chatting.rpy:491
translate Spanish badend1_79099cfe:

    # lumisad "(Perhaps I could ask him to help...)"
    lumisad "(Tal vez podría pedirle ayuda...)"

# game/chatting.rpy:495
translate Spanish badend1_6b0717c3:

    # "She immediately picked up the bell beside her bed and rang it."
    "Inmediatamente tomó la campana junto a su cama y la hizo sonar."

# game/chatting.rpy:497
translate Spanish badend1_ec71b7bf:

    # "The demon butler said he'd come immediately so-"
    "El mayordomo demonio dijo que vendría de inmediato, así que—"

# game/chatting.rpy:505
translate Spanish badend1_b445e05c:

    # butler "Milady, what happened?"
    butler "Milady, ¿qué ha pasado?"

# game/chatting.rpy:507
translate Spanish badend1_a554d8a3:

    # "In an instant, the butler did appear from the shadows."
    "En un instante, el mayordomo apareció desde las sombras."

# game/chatting.rpy:511
translate Spanish badend1_5cd5a739:

    # lumisad "My... my friend! He's... he's disappeared!"
    lumisad "¡Mi... mi amigo! ¡Él... ha desaparecido!"

# game/chatting.rpy:513
translate Spanish badend1_7f55bb2f:

    # "The butler raised a brow."
    "El mayordomo arqueó una ceja."

# game/chatting.rpy:517
translate Spanish badend1_6b2b36f6:

    # butler "Friend? Princess, what are you talking about?"
    butler "¿Amigo? Princesa, ¿de qué está hablando?"

# game/chatting.rpy:521
translate Spanish badend1_a4e021f9:

    # butler "Calm down and explain properly."
    butler "Cálmese y explíquese correctamente."

# game/chatting.rpy:525
translate Spanish badend1_09abe8e7:

    # "The girl bit her lips."
    "La chica se mordió los labios."

# game/chatting.rpy:527
translate Spanish badend1_6a35d24c:

    # "She took a few deep breaths to calm her nerves just as the demonkin had suggested."
    "Respiró hondo varias veces para calmar sus nervios, tal como el demonkin le había sugerido."

# game/chatting.rpy:529
translate Spanish badend1_f3ebbd89:

    # lumitalk "... The one you were looking for... the missing member of the hero's party- I've been keeping him here."
    lumitalk "... Aquel que buscabas... el miembro desaparecido del grupo del héroe... lo he estado escondiendo aquí."

# game/chatting.rpy:531
translate Spanish badend1_a74bfc20:

    # lumisad "But he's suddenly disappeared!"
    lumisad "¡Pero de repente ha desaparecido!"

# game/chatting.rpy:533
translate Spanish badend1_a295e774:

    # lumisad "I do not know if he left or... something else."
    lumisad "No sé si se fue o... algo más."

# game/chatting.rpy:535
translate Spanish badend1_b9153e6e:

    # lumitalk "Please! Please look for him...!"
    lumitalk "¡Por favor! ¡Por favor, búscalo...!"

# game/chatting.rpy:539
translate Spanish badend1_3b466e39:

    # "The butler blinked, stunned by her reveal."
    "El mayordomo parpadeó, atónito por su revelación."

# game/chatting.rpy:541
translate Spanish badend1_1cd505be:

    # "He sighed, massaging his forehead."
    "Suspiró, masajeándose la frente."

# game/chatting.rpy:545
translate Spanish badend1_281d5662:

    # butler "There's so much I'd like to say about this, but your orders are much more urgent."
    butler "Hay mucho que me gustaría decir sobre esto, pero sus órdenes son mucho más urgentes."

# game/chatting.rpy:549
translate Spanish badend1_f34b667b:

    # butler "Very well, I shall search for the rat."
    butler "Muy bien, buscaré a la rata."

# game/chatting.rpy:555
translate Spanish badend1_ec78d4e6:

    # "With that, he disappeared into the shadows once again."
    "Con eso, desapareció nuevamente entre las sombras."

# game/chatting.rpy:557
translate Spanish badend1_6d658969:

    # "Lumi just collapsed on the floor then and there."
    "Lumi simplemente colapsó en el suelo, allí mismo."

# game/chatting.rpy:559
translate Spanish badend1_38f47efb:

    # lumisad "I hope he's fine... I hope the butler would find him first..."
    lumisad "Espero que esté bien... espero que el mayordomo lo encuentre primero..."

# game/chatting.rpy:561
translate Spanish badend1_02e87c6a:

    # lumisad "Please, Cethin... please be safe..."
    lumisad "Por favor, Cethin... por favor, mantente a salvo..."

# game/chatting.rpy:563
translate Spanish badend1_10e2c0c5:

    # "Unfortunately, her prayers were never meant to be answered."
    "Desafortunadamente, sus plegarias nunca estaban destinadas a ser escuchadas."

# game/chatting.rpy:565
translate Spanish badend1_8f2ed374:

    # "... For that was the last she'd hear of the bard ever again."
    "... Pues esa fue la última vez que oiría hablar del bardo."

# game/chatting.rpy:572
translate Spanish badend1_edd2e1a3:

    # "BAD END."
    "FINAL MALO."

# game/chatting.rpy:582
translate Spanish drowholiday_eac50a00:

    # lumi "I've been wondering Cethin, how do you celebrate the yule?"
    lumi "He estado preguntándome, Cethin, ¿cómo celebran el yule?"

# game/chatting.rpy:586
translate Spanish drowholiday_2579d39d:

    # cethin "Ah... well, it's not really a festive holiday for us."
    cethin "Ah... bueno, no es realmente una festividad para nosotros."

# game/chatting.rpy:590
translate Spanish drowholiday_2dc068a6:

    # cethin "We do get together outside, share a meal with the whole clan, share some stories..."
    cethin "Nos reunimos afuera, compartimos una comida con todo el clan, contamos algunas historias..."

# game/chatting.rpy:594
translate Spanish drowholiday_c10c3933:

    # cethin "I guess there's also a battle exhibition?"
    cethin "¿Supongo que también hay una exhibición de combate?"

# game/chatting.rpy:596
translate Spanish drowholiday_aa75c60a:

    # lumitalk "(How is that not festive enough?!)" with vpunch
    lumitalk "(¡¿Cómo es que eso no es lo suficientemente festivo?!)" with vpunch

# game/chatting.rpy:600
translate Spanish drowholiday_110abfd9:

    # cethin "Before we end the festival and return to our homes, we'd give away handmade trinkets to family and friends."
    cethin "Antes de terminar el festival y regresar a nuestros hogares, entregamos amuletos hechos a mano a la familia y los amigos."

# game/chatting.rpy:605
translate Spanish drowholiday_a2c1fff7:

    # cethin "Gifting them is an expression of our gratitude for each other."
    cethin "Regalarlos es una expresión de gratitud mutua."

# game/chatting.rpy:607
translate Spanish drowholiday_80432967:

    # lumitalk "Oh! That's interesting."
    lumitalk "¡Oh! Eso es interesante."

# game/chatting.rpy:609
translate Spanish drowholiday_16f9cd4b:

    # lumihappy "I'd say, it sounds like your community is rather tightknit."
    lumihappy "Diría que su comunidad parece bastante unida."

# game/chatting.rpy:614
translate Spanish drowholiday_d244d34f:

    # cethin "Ehm... well... we really only get together during certain festivals, so I wouldn't say so."
    cethin "Ehm... bueno... en realidad solo nos reunimos durante ciertos festivales, así que no diría eso."

# game/chatting.rpy:620
translate Spanish drowholiday_40617e9d:

    # reo "I believe drows are solitary beings. They dislike working with others, especially other races."
    reo "Creo que los drows son seres solitarios. No les gusta trabajar con otros, especialmente con otras razas."

# game/chatting.rpy:624
translate Spanish drowholiday_07306b2b:

    # reo "When they do have tasks that require large groups, they'd tend to group up together."
    reo "Cuando tienen tareas que requieren grandes grupos, tienden a agruparse entre ellos."

# game/chatting.rpy:628
translate Spanish drowholiday_fea3a957:

    # reo "This is one of the reasons that drows are rarely seen- they {i}really{/i} avoid other races."
    reo "Esta es una de las razones por las que los drows son raramente vistos: {i}realmente{/i} evitan a otras razas."

# game/chatting.rpy:632
translate Spanish drowholiday_1749d5bc:

    # reo "... Or am I mistaken?"
    reo "... ¿O me equivoco?"

# game/chatting.rpy:637
translate Spanish drowholiday_271649de:

    # cethin "Ha... I guess that's true for a lot of us."
    cethin "Ja... Supongo que eso es cierto para muchos de nosotros."

# game/chatting.rpy:639
translate Spanish drowholiday_76b3c19e:

    # "He replied sheepishly."
    "Respondió con timidez."

# game/chatting.rpy:643
translate Spanish drowholiday_459a7397:

    # lumihappy "Cethin is an outlier then!"
    lumihappy "¡Entonces Cethin es una excepción!"

# game/chatting.rpy:647
translate Spanish drowholiday_64a2b6b6:

    # reo "That, he is."
    reo "Así es."

# game/chatting.rpy:652
translate Spanish drowholiday_fd0d2e86:

    # reo "But Cethin, aren't you leaving out a small detail?"
    reo "Pero Cethin, ¿no estás omitiendo un pequeño detalle?"

# game/chatting.rpy:656
translate Spanish drowholiday_f9ad35ca:

    # cethin "Hm? Was I?"
    cethin "¿Hm? ¿Lo estoy?"

# game/chatting.rpy:660
translate Spanish drowholiday_c5cc806a:

    # reo "I believe this trinket exchange for you drows is also for lov-"
    reo "Creo que este intercambio de amuletos para ustedes los drows también es por amo—"

# game/chatting.rpy:688
translate Spanish drowholiday_244e9d69:

    # "Before he could finish, the dark elf leapt onto the butler and covered his mouth."
    "Antes de que pudiera terminar, el elfo oscuro se lanzó sobre el mayordomo y le cubrió la boca."

# game/chatting.rpy:692
translate Spanish drowholiday_d62df225:

    # reo "-RRS...?!" with vpunch
    reo "-RRS...?!" with vpunch

# game/chatting.rpy:694
translate Spanish drowholiday_4fed4d73:

    # "-So his words ended up all muffled."
    "—Así que sus palabras terminaron completamente ahogadas."

# game/chatting.rpy:696
translate Spanish drowholiday_34699fd5:

    # "That was the fastest any of them had seen the bard move."
    "Fue lo más rápido que cualquiera de ellos había visto moverse al bardo."

# game/chatting.rpy:698
translate Spanish drowholiday_3f38662d:

    # "It was actually impressive."
    "De hecho, fue impresionante."

# game/chatting.rpy:721
translate Spanish drowholiday_e0856272:

    # reo "Pwah--"
    reo "Pwah—"

# game/chatting.rpy:732
translate Spanish drowholiday_6a50dde6:

    # "Reo pulled Cethin's hand off."
    "Reo apartó la mano de Cethin."

# game/chatting.rpy:736
translate Spanish drowholiday_18fae086:

    # reo "Goodness, why are you so pressed on that?"
    reo "Por todos los cielos, ¿por qué te alteras tanto por eso?"

# game/chatting.rpy:738
translate Spanish drowholiday_a0705dc8:

    # "His tone was teasing. Obviously, he knew."
    "Su tono era burlón. Obviamente, él lo sabía."

# game/chatting.rpy:740
translate Spanish drowholiday_470daa86:

    # reo "Are you certain you are a bard? You move as swift as an assassin..."
    reo "¿Estás seguro de que eres un bardo? Te mueves tan rápido como un asesino..."

# game/chatting.rpy:742
translate Spanish drowholiday_a334accb:

    # lumi "Yes, Cethin... why did you stop Reo from speaking?"
    lumi "Sí, Cethin... ¿por qué detuviste a Reo antes de que hablara?"

# game/chatting.rpy:747
translate Spanish drowholiday_01526406:

    # cethin "Ngh..."
    cethin "Ngh..."

# game/chatting.rpy:749
translate Spanish drowholiday_0ad59a97:

    # cethin "It's..."
    cethin "Es..."

# game/chatting.rpy:751
translate Spanish drowholiday_0903524d:

    # "It was evident that he was hesitating to answer."
    "Era evidente que dudaba en responder."

# game/chatting.rpy:753
translate Spanish drowholiday_062496fd:

    # "The princess' expression softened."
    "La expresión de la princesa se suavizó."

# game/chatting.rpy:755
translate Spanish drowholiday_087bdd94:

    # lumihappy "If you do not wish to tell us, it's fine."
    lumihappy "Si no deseas contárnoslo, está bien."

# game/chatting.rpy:760
translate Spanish drowholiday_76b75d38:

    # cethin "Y-yeah... thanks."
    cethin "S-sí... gracias."

# game/chatting.rpy:768
translate Spanish demonholiday_ad7687fb:

    # lumitalk "Ah yes, Reo."
    lumitalk "Ah sí, Reo."

# game/chatting.rpy:770
translate Spanish demonholiday_9fb61658:

    # "She called out to the butler."
    "Llamó al mayordomo."

# game/chatting.rpy:772
translate Spanish demonholiday_105f428c:

    # lumi "I was not aware that you demons celebrate yule as well."
    lumi "No sabía que ustedes los demonios también celebraban el yule."

# game/chatting.rpy:776
translate Spanish demonholiday_dc90fc6d:

    # reo "Yes, of course we do. Just like every other race."
    reo "Sí, por supuesto que lo hacemos. Como todas las demás razas."

# game/chatting.rpy:780
translate Spanish demonholiday_2edf792e:

    # reo "And demonkin, princess. There's a clear distinction."
    reo "Y los demonkin, princesa. Hay una clara diferencia."

# game/chatting.rpy:784
translate Spanish demonholiday_fdcee192:

    # cethin "Oh? Demons and demonkin aren't the same?"
    cethin "¿Oh? ¿Los demonios y los demonkin no son lo mismo?"

# game/chatting.rpy:790
translate Spanish demonholiday_b953cdcb:

    # "Cethin leaped off the stool, having finished decorating his part."
    "Cethin saltó del taburete, habiendo terminado de decorar su parte."

# game/chatting.rpy:794
translate Spanish demonholiday_541fbadb:

    # reo "Ah yes... I suppose it is a common misconception."
    reo "Ah, sí... Supongo que es un error común."

# game/chatting.rpy:798
translate Spanish demonholiday_53849eae:

    # reo "We {i}can{/i} be referred to as demons, however... we prefer being addressed to as {i}demonkin{/i} due to the existence of demonic beasts."
    reo "Podemos ser llamados demonios, sin embargo... preferimos ser nombrados {i}demonkin{/i} debido a la existencia de las bestias demoníacas."

# game/chatting.rpy:800
translate Spanish demonholiday_7fd44148:

    # reo "In olden times, we were the only ones who were known as 'demons'..."
    reo "En tiempos antiguos, éramos los únicos conocidos como “demonios”..."

# game/chatting.rpy:804
translate Spanish demonholiday_e48822f8:

    # reo "However, due to the birth of demon lords who have the ability to produce mindless demonic beasts..."
    reo "Sin embargo, debido al nacimiento de los señores demonio, que poseen la habilidad de crear bestias demoníacas sin mente..."

# game/chatting.rpy:808
translate Spanish demonholiday_1a552b6c:

    # reo "Well, let's just say there had been confusion, and other races who do not know any better started addressing these demonic beasts as 'demons' just as well."
    reo "Bueno, digamos que hubo cierta confusión, y otras razas que no sabían mejor comenzaron a llamar también “demonios” a esas bestias demoníacas."

# game/chatting.rpy:813
translate Spanish demonholiday_b04a87a6:

    # reo "Which is why, to provide the difference, we {i}'true demons'{/i} decided to create a distinction by taking on 'demonkin' as a way of address."
    reo "Por eso, para marcar la diferencia, nosotros, los {i}“verdaderos demonios”{/i}, decidimos crear una distinción adoptando el término “demonkin” como forma de identificación."

# game/chatting.rpy:817
translate Spanish demonholiday_355cf0a6:

    # lumishock "I've known that you preferred 'demonkin' but I was not aware of this story."
    lumishock "Sabía que preferían ser llamados “demonkin”, pero no conocía esta historia."

# game/chatting.rpy:822
translate Spanish demonholiday_96fc2cfd:

    # cethin "I was not even aware of the difference..."
    cethin "Ni siquiera sabía que existía una diferencia..."

# game/chatting.rpy:827
translate Spanish demonholiday_0fd56472:

    # cethin "So if I understood correctly... the original demons-"
    cethin "Entonces, si entendí bien... los demonios originales—"

# game/chatting.rpy:829
translate Spanish demonholiday_433ad970:

    # cethin "The demon race, prefer to be called 'demonkin', while demonic beasts, beings spawned by the demon lords are simply 'demons'?"
    cethin "¿La raza demonio prefiere ser llamada 'demonkin', mientras que las bestias demoníacas, seres engendrados por los señores demonio, son simplemente 'demonios'?"

# game/chatting.rpy:834
translate Spanish demonholiday_99535542:

    # reo "A gold star for you, drow!"
    reo "¡Una estrella dorada para ti, drow!"

# game/chatting.rpy:838
translate Spanish demonholiday_8ea525ab:

    # lumihappy "That's Cethin to you."
    lumihappy "Es Cethin, para ti."

# game/chatting.rpy:840
translate Spanish demonholiday_e7f3b748:

    # reo "That is what I said. Cethin."
    reo "Eso fue lo que dije. Cethin."

# game/chatting.rpy:842
translate Spanish demonholiday_aeb105a1:

    # "Lumi rolled her eyes."
    "Lumi puso los ojos en blanco."

# game/chatting.rpy:846
translate Spanish demonholiday_46d78d70:

    # reo "In any case, as I've said- this is a common misconception, especially among the... well... uneducated."
    reo "En cualquier caso, como dije, es un error común, especialmente entre los... bueno... los ignorantes."

# game/chatting.rpy:848
translate Spanish demonholiday_a13b992e:

    # lumisad "From how I see it, whoever decided to call demonic beasts 'demons' as well, created this confusion. How troublesome."
    lumisad "Desde mi punto de vista, quien haya decidido llamar también “demonios” a las bestias demoníacas creó toda esta confusión. Qué problemático."

# game/chatting.rpy:857
translate Spanish demonholiday_15537674:

    # reo "You. Humans started it."
    reo "Tú. Los humanos empezaron."

# game/chatting.rpy:863
translate Spanish demonholiday_02f92aa2:

    # lumishock "Oh."
    lumishock "Oh."

# game/chatting.rpy:865
translate Spanish demonholiday_87a16d92:

    # lumisad "I'm... I apologize..."
    lumisad "Yo... lo siento..."

# game/chatting.rpy:867
translate Spanish demonholiday_3613f9c8:

    # "She said weakly, evidently distraught by the revelation."
    "Dijo débilmente, evidentemente afectada por la revelación."

# game/chatting.rpy:871
translate Spanish demonholiday_ac13b547:

    # reo "I've no need for your apology. It means nothing, coming from you."
    reo "No necesito tus disculpas. No significan nada, viniendo de ti."

# game/chatting.rpy:875
translate Spanish demonholiday_74c61653:

    # reo "You need not carry the sins of your forebearers. There was nothing you could have done."
    reo "No tienes por qué cargar con los pecados de tus antepasados. No había nada que pudieras haber hecho."

# game/chatting.rpy:877
translate Spanish demonholiday_7b9b4782:

    # lumitalk "But there is something I could do!"
    lumitalk "¡Pero hay algo que puedo hacer!"

# game/chatting.rpy:879
translate Spanish demonholiday_35121d69:

    # lumisad "At the very least, I feel that I must take responsibility."
    lumisad "Al menos, siento que debo asumir cierta responsabilidad."

# game/chatting.rpy:881
translate Spanish demonholiday_b85673cc:

    # lumitalk "I may be a prisoner now, but I am still a princess. I believe that I can at least do something about it?"
    lumitalk "Puede que ahora sea una prisionera, pero sigo siendo una princesa. ¿Creo que al menos puedo hacer algo al respecto?"

# game/chatting.rpy:885
translate Spanish demonholiday_5b6bee10:

    # reo "Hm. Really, no need to make a fuss over this."
    reo "Hm. En serio, no hay necesidad de hacer un drama de esto."

# game/chatting.rpy:887
translate Spanish demonholiday_4e58404d:

    # "He shrugged."
    "Se encogió de hombros."

# game/chatting.rpy:891
translate Spanish demonholiday_b97f44fb:

    # reo "It may be rather annoying when others make a mistake, but we do not really find it a huge issue."
    reo "Puede que resulte molesto cuando otros cometen un error, pero realmente no lo consideramos un gran problema."

# game/chatting.rpy:893
translate Spanish demonholiday_d944dc14:

    # reo "... I do appreciate the sentiment."
    reo "... Aun así, aprecio el gesto."
